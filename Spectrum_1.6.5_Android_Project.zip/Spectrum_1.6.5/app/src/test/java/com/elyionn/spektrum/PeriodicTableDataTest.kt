package com.elyionn.spektrum

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class PeriodicTableDataTest {
    @Test
    fun elementDatasetContainsAllAtomicNumbersExactlyOnce() {
        assertEquals(118, elementRows.size)
        assertEquals((1..118).toList(), elementRows.map { it[2].toInt() })
    }

    @Test
    fun periodicLayoutContainsEveryElementExactlyOnce() {
        val numbers = periodicTableRows.flatten().filterNotNull()
        assertEquals(118, numbers.size)
        assertEquals((1..118).toList(), numbers.sorted())
    }

    @Test
    fun searchNormalizationHandlesTurkishDotlessIAndDiacritics() {
        assertEquals("isik", normalizeElementSearch("IŞIK"))
        assertEquals("isik", normalizeElementSearch("ışık"))
        assertEquals("cagri", normalizeElementSearch("Çağrı"))
    }

    @Test
    fun englishElementNamesAreAvailableForAllElements() {
        for (atomicNumber in 1..118) {
            assertNotNull(englishElementName(atomicNumber))
        }
    }
}
