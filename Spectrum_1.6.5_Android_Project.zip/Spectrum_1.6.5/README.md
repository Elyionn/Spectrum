# Spectrum 1.6.5 — Science Platform

**Developer:** Elyionn  
**Application ID:** `com.elyionn.spectrum`  
**Namespace:** `com.elyionn.spektrum`  
**Version:** `1.6.5` (`versionCode` 18)  
**Minimum Android:** API 26  
**Compile / target SDK:** 35  
**JDK:** 17  
**Android Gradle Plugin:** 8.7.3  
**Gradle:** 8.9  
**Kotlin:** 2.0.21

## 1.6.5 highlights

- Fixed Three.js shared-material disposal during scene switching.
- Added WebGL startup fallback and Android WebView console diagnostics.
- Fixed the 3D stage height in the compact Chemistry embed and improved pinch-to-drag pointer handling.
- Added Turkish and English labels/descriptions for the 12 3D scenes and their controls.
- Reworked the periodic-table overview into a denser 18-column layout with a 75% initial zoom, pinch zoom and drag navigation.
- Extracted periodic-table data/helpers into `PeriodicTableData.kt` and lesson JSON parsing into `ScienceContentData.kt`; added JUnit data/search tests.
- Normalized the `geology` category ID to `yer_bilimleri` and fixed Turkish dotless-I search.
- Corrected stale 1.6.3 UI labels and advanced metadata to 1.6.5 / 18.

## Language status

The application interface and 3D laboratory controls support Turkish and English. The 102 imported lesson records are not fully translated: 95 records lack topic-specific source lists and most lesson prose is Turkish. When English is selected, topic detail pages disclose that the original Turkish source text is being shown. This is intentional; unverified machine translations are not presented as reviewed scientific translations.

## Build

Open the `Spectrum_1.6.5` folder in Android Studio. The GitHub Actions workflow is `.github/workflows/android-apk.yml`. It validates the source, compiles Kotlin, runs unit tests, builds debug and release APKs, verifies their package IDs and uploads the APKs and diagnostics.

The project does not include a Gradle wrapper JAR or signing key. The workflow generates the Gradle wrapper when missing. The release APK is unsigned unless GitHub repository secrets are configured: `SPECTRUM_KEYSTORE_BASE64`, `SPECTRUM_STORE_PASSWORD`, `SPECTRUM_KEY_ALIAS` and `SPECTRUM_KEY_PASSWORD`. The keystore is materialized only in the runner temporary directory; no private key or password belongs in source control.

## Validation status

Source-level JSON, XML, JavaScript, model-registry, periodic-table, YAML and archive checks are performed during preparation. Android Gradle compilation, unit-test execution, APK packaging and physical-device WebView/WebGL profiling have **not** been run in this environment. See `TEST_REPORT_1.6.5.md` and `PERFORMANCE_REPORT_1.6.5.md` for exact limits.

## Reports

- `CHANGELOG_1.6.5.md`
- `SOURCE_AUDIT_1.6.5.md`
- `TEST_REPORT_1.6.5.md`
- `PERFORMANCE_REPORT_1.6.5.md`
- `DATA_SOURCES.md`
- `THIRD_PARTY_NOTICES.md`
