# Spectrum 1.6.2 — Science Platform

**Developer:** Elyionn  
**Android application ID:** `com.elyionn.spectrum`  
**Namespace:** `com.elyionn.spektrum`  
**versionName:** `1.6.2`  
**versionCode:** `15`  
**Minimum Android:** API 26  
**Compile / target SDK:** 35  
**JDK:** 17  
**Gradle:** 8.9  

## What changed in 1.6.2

### Information architecture and navigation

- Replaced the bottom navigation with **Ana Sayfa, Keşfet, Ara, Laboratuvar, Profil**.
- Removed the standalone Science Atlas and Library destinations.
- Added a search action in the top app bar and a dedicated unified search destination.
- Search covers 102 local lesson records and the 118-element dataset. Element results open the existing element detail screen.
- Added a category-specific horizontal lesson shelf above the existing category content.
- Settings are reached from Profil; the top app-bar action is reserved for search.
- Removed old unused home/library hub composables and old Atlas route source.

### Lesson content and shelves

- Imported the supplied Grok Workspace's 14 static catalog records and 81 topic records, merging duplicate slugs into **95 unique lessons**.
- Added **7 Earth Science lessons** using USGS, National Geographic, Smithsonian and National Park Service educational material, bringing the local catalogue to **102 unique lessons**.
- Each lesson is organized into learning levels (Explore / Learn / Deep Dive) and shelves (Overview, Mechanism, Everyday Examples, Data & Formulas, Sources).
- Existing source records that do not contain topic-level references are labelled as educational material without fabricated citations. Earth Science lessons include clickable source links.
- Added an Earth Science category and lesson shelf.
- Added a compressed, original AI-generated cosmic home hero image (`space_hero.webp`).

### 3D laboratory

- Bundled the Three.js browser module locally. No CDN is required.
- Added 12 procedural 3D scenes: atom, water, carbon dioxide, methane, DNA, cell, human-body schematic, Solar System, optics, wave, circuit and gravity/orbit.
- Models support drag rotation, zoom and reset. Auto-rotation can be disabled; idle rendering is paused when possible and the animation loop is capped near 30 FPS.
- WebView assets are served through `WebViewAssetLoader`; direct file access, universal file access, mixed content and network loading are disabled. No JavaScript bridge is exposed.
- Anatomical, orbital and some molecular scenes are educational schematics, not clinically validated meshes or scale-accurate physical simulations.

### Existing modules retained

- 118-element periodic table and its existing 18-column layout, search, zoom and pan controls.
- Existing biology, chemistry, physics, mathematics, space, electronics, settings and theme pages.
- Existing local preferences and application identity.

## Build

Open the `Spectrum_1.6.2` folder in Android Studio. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and Gradle 8.9. The repository workflow can generate a Gradle wrapper if one is absent, then build both debug and release APKs.

GitHub Actions workflow: `.github/workflows/android-apk.yml`.

## Important validation status

The source package was checked for ZIP integrity, JSON structure, 102 unique lessons, all 118 atomic numbers, Android XML parsing, JavaScript syntax, YAML parsing and Kotlin parser-level syntax diagnostics. A full Android Gradle build and on-device runtime test were **not** performed in the authoring environment because Android SDK / Gradle were not available there. The workflow is configured to perform the actual debug and release builds and upload logs/APKs only when generated.

## Source archive note

The supplied archive named as the previous 1.6.1 project had `versionName = "1.6.0"` and `versionCode = 13` inside `app/build.gradle.kts`. This release corrects the metadata to 1.6.2 / 15 rather than trusting the archive filename.

See:
- `CHANGELOG_1.6.2.md`
- `TEST_REPORT_1.6.2.md`
- `PERFORMANCE_REPORT_1.6.2.md`
- `SOURCE_AUDIT_1.6.2.md`
- `DATA_SOURCES.md`
- `THIRD_PARTY_NOTICES.md`
