# Spectrum 1.7.3 — UI ve arşiv doğrulama raporu

- Ayarlar ekranındaki altı temalı tek satır düzeni kaldırıldı; adaptif 2/3 sütunlu kart düzeni kullanılıyor.
- Tema, yazı tipi ve dil seçimleri daha geniş etkileşim alanlarına taşındı.
- Ayarları sıfırlama işlemi onay diyaloğu ve SharedPreferences kalıcılığı ile uygulanıyor.
- Kaynak arşivi 1.7.2 ZIP'inden çıkarıldıktan sonra yeniden oluşturuldu.
- ZIP bütünlük kontrolü, proje kökü keşfi, XML/JSON/JavaScript ve mevcut statik içerik kontrolleri authoring ortamında yapılır.
- Android SDK/Gradle derlemesi ve gerçek cihaz davranışı burada doğrulanmadı; workflow çalışması gereklidir.
