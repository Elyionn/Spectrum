# Spectrum 1.7.1 — Validation report

## Passed source-level checks
- Original 1.7.0 source ZIP was CRC-validated before modification.
- App metadata: `versionName=1.7.1`, `versionCode=24`.
- Application ID and namespace preserved.
- 151 lesson records parsed; all slugs unique and required fields present.
- 48 3D scene buttons matched all 48 model registry entries.
- Three.js bundle passed Node.js syntax validation.
- Both inline JavaScript blocks in the 3D lab HTML passed Node.js syntax validation.
- Android XML resources parsed successfully.
- GitHub Actions YAML parsed successfully.
- Source assertions confirmed local-origin WebView loading, the JS diagnostic bridge, lazy search rendering and six theme palettes.
- Final project ZIP passed `unzip -t` integrity validation.

## Not run / not verified
- Full Android Gradle/Kotlin compilation and JUnit execution: no Gradle executable, Android SDK or configured Android build environment is installed in this authoring container.
- Debug and Release APK generation.
- Emulator or physical-device tests.
- Actual WebView asset loading and WebGL rendering on the user's phone.
- Measured CPU, GPU, RAM, battery or frame-time benchmarks.

The WebView fix addresses the source-level configuration conflict by allowing the virtual HTTPS appassets origin while explicitly rejecting requests to all other hosts. The final runtime result still requires the GitHub Actions build and a device test. No APK success or device-level WebGL success is claimed here.
