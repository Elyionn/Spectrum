# Spectrum 1.7.1 — Kotlin compile fix report

## Root cause
The 3D laboratory's diagnostic WebView client extended `androidx.webkit.WebViewClientCompat` and attempted to override `onReceivedError`. In the project's AndroidX WebKit API, that callback is final on `WebViewClientCompat`, so Kotlin compilation failed at `MainActivity.kt:1743`.

## Fix applied
- Changed only the 3D laboratory's diagnostic client to the platform `android.webkit.WebViewClient`, whose `onReceivedError` and `onReceivedHttpError` callbacks are overridable.
- Added the platform `WebViewClient` import.
- Updated the 3D WebView cleanup path to restore a platform `WebViewClient`.
- Kept the separate legacy viewer's `WebViewClientCompat` unchanged.
- Kept the diagnostic callbacks, local asset interception, request-origin restrictions and JavaScript bridge.
- Added a GitHub Actions source-level regression check to reject reintroducing the incompatible `WebViewClientCompat` override.

## Validation status
- Kotlin source-level regression assertions: passed.
- Workflow YAML syntax and ZIP integrity: checked during packaging.
- Kotlin/Gradle compilation: not run in this authoring environment (no Gradle executable / Android SDK configured).
- APK build and physical-device WebGL test: not run.

This is a corrected 1.7.1 build package, not a new app version. `versionName` remains `1.7.1` and `versionCode` remains `24`. The next GitHub Actions run must confirm Kotlin compilation and APK creation.
