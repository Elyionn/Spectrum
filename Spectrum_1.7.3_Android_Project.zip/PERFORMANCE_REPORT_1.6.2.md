# Spectrum 1.6.2 — Performance Review

## Static findings and changes

1. **Periodic table:** retained the existing fixed 18-column layout and lazy 2-column search results. Element lookup uses a remembered atomic-number map; query filtering is memoized by query. The pan/zoom gesture handler remains keyed by `Unit` to avoid restarting the gesture detector during state updates. Transform state is applied through `graphicsLayer`.
2. **Lesson catalogue:** 102 records are loaded once at the app root from a local JSON asset and passed to screens. Search filtering is memoized by query and selected category. No network call is needed for local lessons.
3. **3D rendering:** Three.js is bundled locally. Pixel ratio is capped at 1.5, geometry counts are modest, and auto-rotation is capped at approximately 30 FPS. When auto-rotation is off, rendering is requested on interaction rather than continuously.
4. **Model lifecycle:** changing scenes removes previous scene objects and disposes geometries/materials. The WebView is stopped, blanked, detached and destroyed when released.
5. **WebView security / startup:** `WebViewAssetLoader` serves the bundled JS module and scene from app assets. External network loads, mixed content, direct file access and universal file access are disabled. No JavaScript interface is exposed.
6. **Navigation:** removed the old Atlas and Library destinations and their unused screen composables, reducing duplicate routes and dead UI code.

## Likely remaining cost centres

- The 118-element full table draws a modest but non-trivial set of Compose cards; on very low-end GPUs, high zoom levels may still cost more than the search grid.
- WebGL context creation and Three.js shader compilation cause a one-time cost when the 3D lab opens.
- The 3D scene uses antialiasing and 24-segment spheres; devices with weak GPUs may benefit from a future quality toggle.
- Existing older biology / space pages still contain their own Compose drawings and WebViews; they were not all rewritten in this update.

## Measurement status

No before/after frame-time, memory, startup or energy numbers are reported. Android Studio Profiler, Macrobenchmark and physical-device measurements were unavailable in this environment. The above are code-level optimizations and expected cost centres, not measured performance claims.
