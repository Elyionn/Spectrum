# Spectrum 1.6.9 — Atlas, lesson UI and 3D laboratory

## Content
- 151 unique lessons across seven categories: Biology 26, Physics 26, Chemistry 23, Mathematics 21, Space 21, Electronics 20 and Earth Science 14.
- 35 new lesson records, five per category. Each has two HTTPS learning references.

## Learning interface
- Category topic directory changed to a two-column card grid.
- Lesson details now begin with a core concept, numbered learning map and key-data cards, followed by learning levels, overview, mechanism, everyday examples, data/formulas and sources.
- Category lesson navigation remains available; the old clipped horizontal shelf is removed.

## Mathematics and performance
- Quadratic plot uses bounded coordinates, internal padding and a clamped marker.
- Three.js mobile renderer uses a lower-cost pixel ratio and mediump precision, waits for measured WebView dimensions, and reports context loss.
- The 3D scene render loop remains idle unless auto-rotation or a pointer interaction requires a frame.

## 3D laboratory
- Added 35 new schematic scenes: neuron, mitochondrion, immune cells, chloroplast, ribosome, projectile motion, pendulum, induction, heat engine, sound waves, equilibrium, acid-base, redox, organic molecule, polymer, geometry, logarithm, calculus, vectors, combinatorics, stellar evolution, black hole, galaxy, exoplanet, CMB, semiconductor, transistor, capacitor, microcontroller, sensor, crystal, volcano, seismic waves, aquifer and ice core.
- Total selectable scenes: 48.

## Version
- `versionName`: 1.6.9
- `versionCode`: 22
- Application ID and namespace preserved.
