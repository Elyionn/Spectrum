# Spectrum 1.7.3

Spectrum is an Android science-learning application built with Kotlin, Jetpack Compose and a locally bundled Three.js laboratory.

## Build

The GitHub Actions workflow is located at `.github/workflows/android-apk.yml`. It validates the project, checks the bundled laboratory JavaScript and scene registry, compiles Kotlin, runs unit tests, builds Debug and Release APKs, and uploads build artifacts.

## App identity
- Application ID: `com.elyionn.spectrum`
- Namespace: `com.elyionn.spektrum`
- Version: `1.7.3` (code 26)

## Main areas
- Science home, categories and structured lesson pages
- Search with cached lesson index and lazy result rendering
- Periodic table and element details
- Interactive local 3D laboratory with WebView diagnostics and retry
- Six themes and six system typeface choices

See `CHANGELOG_1.7.3.md`, `TEST_REPORT_1.7.3.md` and `PERFORMANCE_REPORT_1.7.3.md` for release details and verification limits.


## 1.7.3 — Optimizasyon, Tema ve Stil

Ayarlar ekranı adaptif hale getirildi, tema/yazı tipi/dil kontrolleri yeniden düzenlendi ve varsayılan ayarları geri yükleme eklendi. Kaynak ZIP, proje kökü arşivin kökünde olacak şekilde yeniden paketlendi.
