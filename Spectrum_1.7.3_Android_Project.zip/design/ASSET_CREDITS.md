# Asset notes

- `singularity-logo-source.png`: original AI-generated visual asset created for Spectrum 1.7.0, based on the approved Singularity (B) concept.
- `app/src/main/res/drawable-nodpi/spectrum_logo.png`: 512px application-header/brand logo derived from the source render.
- `app/src/main/res/drawable/ic_spectrum.xml`: lightweight vector fallback mark for the launcher drawable resource.
- `app/src/main/res/drawable-nodpi/space_hero.webp`: retained from the previous project version.
