# Spectrum 1.6.7 — Stability and performance pass

## Changes
- Version metadata advanced to 1.6.7 / versionCode 20. Application ID and namespace are unchanged.
- Removed the permanent infinite Compose animation from the DNA educational diagram. The helix remains visible as a static illustration and no longer schedules continuous recomposition/redraws.
- Changed the embedded atom canvas to render on demand by default instead of rotating continuously while the user is reading the element page. Drag interaction still updates the scene; visibility and teardown handling remain in place.
- Expanded periodic-table unit tests to verify the 9×18 layout, 118 unique element symbols, valid record fields, and safe out-of-range helper behavior.
- Added CI checks for JSON lesson completeness/unique slugs, all 118 periodic-table records, XML parsing, local JavaScript syntax, workflow shell syntax, debug/release compilation, unit-test report presence, APK integrity and package identity.
- Replaced the 1.6.6 workflow's brittle fixed archive extraction with exact-root discovery, ZIP traversal/symlink rejection and a deterministic 1.6.7 archive path. SDK license acceptance avoids the `yes | sdkmanager` SIGPIPE failure mode.

## Preserved
- Package identity, namespace, existing settings and themes, Turkish/English UI, Science Atlas (102 lessons), technology catalogue, local Three.js scenes, and all 118 periodic-table entries.

## Validation limits
- Source-level Python/JSON/XML/ZIP/YAML/JavaScript checks are run during packaging.
- Android Gradle compilation, JUnit execution, APK creation and APK metadata checks are delegated to the included GitHub Actions workflow. They are not claimed as successful until that workflow completes.
- No emulator or physical-device UI test or performance profiler is available in this authoring environment. Real device frame time, memory, battery and WebGL compatibility remain unmeasured.
- Release APK is unsigned unless the repository owner configures signing secrets and `SPECTRUM_KEYSTORE_PATH`.
