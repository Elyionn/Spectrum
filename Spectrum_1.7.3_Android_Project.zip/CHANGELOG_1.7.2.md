# Spectrum 1.7.2 — WebView lifecycle and release update

## Reliability and performance
- Removed the process-wide `WebView.pauseTimers()` call from the chemistry water-model viewer's disposal path. A screen leaving composition must not pause timers belonging to other WebViews in the app.
- Kept per-view cleanup: stop loading, navigate to a blank document, detach clients and child views where applicable, then destroy the view.
- Added unit coverage for Turkish and English science-category aliases and unknown-category fallback behavior.

## Release metadata
- Updated the app version to `1.7.2` and `versionCode` to `25`.
- Updated in-app version labels and the Android build workflow to target 1.7.2.
- Preserved application ID `com.elyionn.spectrum`, namespace `com.elyionn.spektrum`, min SDK 26, all existing lesson and element records, and the 3D scene library.

## Verification boundaries
- Source-level validation, JSON/XML parsing, JavaScript syntax checks, ZIP integrity and workflow syntax are checked in the authoring environment.
- Android Gradle compilation, JUnit execution, APK generation and on-device WebView/WebGL behavior require the Android build environment and are not claimed as passed unless the GitHub Actions run confirms them.
