# Spectrum 1.6.6

## UI and navigation
- Replaced the bottom navigation's Laboratory and Profile entries with a dedicated Settings entry. The 3D viewer remains available from learning modules so removing the old lab destination does not remove interactive science content.
- Removed all embedded quiz cards and the quiz component from the application source.
- Added a dedicated technology learning catalogue and separate detail pages for 3D printing, AI, robotics, nanotechnology, semiconductors, battery technology, cybersecurity, communication networks, and sensors/IoT.
- Each technology module now contains an introduction, sequential explanation, real-world applications, and a relevant interactive scene when one exists.

## 3D
- Added an interactive schematic FDM 3D-printer scene with frame, build plate, print head, spool and layered sample object.
- Added the scene to the local model selector and mapped the 3D-printing lesson directly to it.
- Kept the existing offline WebViewAssetLoader route for the local Three.js module and the local-only network policy.

## Version
- versionName: 1.6.6
- versionCode: 19
