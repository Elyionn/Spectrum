# Spectrum 1.6.3

- Version metadata advanced to 1.6.3 (versionCode 16).
- GitHub Actions upgraded to checkout v6, setup-java v6, Gradle setup v6 and upload-artifact v6. Android SDK setup remains on its independently maintained v4 action.
- CI now runs a dedicated Kotlin compilation task before packaging, prints compiler diagnostics on failure, and uploads the complete Kotlin/debug/release logs even when compilation fails.
- Gradle output uses plain console mode and info logging so Kotlin source locations are retained in CI logs.
- No claim of a successful APK build is made until GitHub Actions completes both variants.
