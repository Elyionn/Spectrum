# Spectrum 1.7.2 — Performance and lifecycle report

## Change
The chemistry water-model viewer previously called `WebView.pauseTimers()` during disposal. Android exposes this as a process-wide WebView timer control, so disposing one screen could interfere with timers in another WebView. The call has been removed. Cleanup remains scoped to the departing view.

## Retained optimizations
- Lazy search-result rendering and precomputed normalized lesson search data.
- Demand-driven rendering for the embedded atom scene and capped WebGL pixel ratio in the 3D laboratory.
- Locally bundled Three.js assets and explicit rejection of non-local requests in the main 3D lab.

## Measurement status
No device-side CPU, GPU, memory, startup, battery or frame-time benchmark was run. This report describes code-level changes, not measured performance gains.
