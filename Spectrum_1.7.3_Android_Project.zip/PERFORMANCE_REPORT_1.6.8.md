# Spectrum 1.6.8 performance and UI review

- New topic data is loaded through the existing background `produceState` + `Dispatchers.IO` path.
- New-content badges reuse existing Compose `Surface` and text components; no new runtime dependency or image asset was added.
- Existing 3D renderer limits, visibility pause, on-demand atom rendering and static DNA diagram are preserved from 1.6.7.
- No quantitative CPU, GPU, memory, battery or startup measurements are claimed: no Android profiler/device run was available during packaging.
