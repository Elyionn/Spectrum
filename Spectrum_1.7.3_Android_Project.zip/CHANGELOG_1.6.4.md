# Spectrum 1.6.4

## Reliability and performance
- Moved bundled science-catalogue file reading and JSON parsing off the main thread; the app displays a lightweight loading indicator while it is prepared.
- Fixed the Chemistry screen's unresolved `Molecule3DView` reference by adding a secure, offline WebView viewer that reuses the bundled water scene.
- Reused a single immutable isotope-mass lookup instead of allocating a map on each lookup.
- Reduced the 3D laboratory's maximum device pixel ratio from 1.5 to 1.25 to lower GPU fill cost on mobile devices.
- Made automatic 3D rotation opt-in so the scene does not continuously render when the user is reading or interacting with a static model.
- Corrected Three.js scene cleanup to detach objects from the scene graph before disposing geometries/materials, and disconnected the resize observer when the page exits.
- Updated app metadata to version 1.6.4 / versionCode 17.

## Validation limits
- Source-level checks cover JSON, XML, Kotlin parser diagnostics, JavaScript module syntax, and archive integrity.
- A full Android Gradle build, device profiling, and WebView/WebGL runtime test must still be confirmed by GitHub Actions or Android Studio. No APK build success or measured runtime gain is claimed here.
