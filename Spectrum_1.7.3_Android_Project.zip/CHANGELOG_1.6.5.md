# Spectrum 1.6.5

## Critical fixes
- Fixed a Three.js model-switching defect: scene cleanup previously disposed shared palette materials, which could leave later models invisible or incorrectly rendered. Shared materials now survive model changes and are released only when the WebGL page exits.
- Added a visible fallback when WebGL renderer initialization fails, plus browser-console diagnostics forwarded to Android logs.
- Corrected the 3D laboratory's minimum stage height so the fixed-height Chemistry embed no longer clips most of its lower controls.
- Improved pointer cancellation and the transition from two-finger pinch back to one-finger rotation.
- Improved WebView release cleanup and explicitly pauses timers before destroying the view.

## Periodic table
- Moved element reference data and pure periodic-table helpers from the oversized `MainActivity.kt` into `PeriodicTableData.kt`.
- Extracted the local lesson model, JSON parser and category localization into `ScienceContentData.kt`.
- Reduced element tiles from 52 × 58 dp to 30 × 42 dp and set a compact 75% initial view. This makes substantially more columns visible on a phone without removing pinch zoom or drag navigation.
- Removed tiny element-name text from the compact cells; atomic number and symbol remain readable, and the full name/properties remain on the element profile.
- Moved the periodic layout into a single immutable data structure and added tests that assert all 118 atomic numbers occur exactly once.
- Fixed Turkish search normalization for dotless `ı`.

## Language and consistency
- Updated every visible app version label to 1.6.5.
- Added Turkish and English model names, descriptions, controls and fallback messages to the 3D laboratory.
- Fixed category labels and normalized the `geology` content category to `yer_bilimleri`.
- The English interface now explicitly identifies imported lesson text that is still Turkish. No unverified machine translation is silently presented as a verified translation.

## Build and tests
- Updated GitHub Actions to v6 where those upstream actions publish a v6 release: checkout, setup-java, setup-gradle and upload-artifact.
- Kept `android-actions/setup-android@v4`: upstream currently publishes v4.0.4 as its latest release and does not publish a v6 tag.
- Added JUnit tests for the 118-element dataset, periodic-table layout, English element names and Turkish search normalization.
- Added optional release signing through GitHub repository secrets; private signing material is never stored in the project.
- Advanced app metadata to `versionName = 1.6.5`, `versionCode = 18`.

## Known limitations
- The 102-topic JSON catalogue is structurally checked. Only 7 topic records currently include topic-specific external source links; 95 records still lack their own bibliography. They are not claimed as fully source-verified.
- The existing lesson prose is predominantly Turkish. The English UI identifies this limitation instead of claiming complete English localization.
- Android Gradle compilation, APK packaging, WebView/WebGL runtime and physical-device profiling must still be confirmed by GitHub Actions and on-device testing. They are not claimed as completed in this authoring environment.
