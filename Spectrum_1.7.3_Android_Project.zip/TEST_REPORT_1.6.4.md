# Spectrum 1.6.4 — Validation report

## Source-level checks
- ZIP integrity and project structure checked.
- Version metadata set to 1.6.4 / versionCode 17.
- Bundled science JSON, periodic-table source, Android XML, and Three.js module checked by the release workflow.
- Chemistry's `Molecule3DView` call now has a matching composable implementation.
- Full Android Gradle compilation and APK packaging are not claimed as locally completed. The new GitHub Actions workflow performs Kotlin compilation, unit-test task, debug/release packaging, and APK integrity checks.

## Runtime checks still required
- Install and navigate the app on a physical Android device.
- Verify the Chemistry water model, model switching, rotation toggle, pinch zoom, and lifecycle cleanup.
- Profile lower-end devices for startup, scrolling, GPU, memory, and battery behavior.
