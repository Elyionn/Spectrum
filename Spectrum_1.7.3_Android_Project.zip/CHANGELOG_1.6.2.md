# Spectrum 1.6.2 — Change Log

## Navigation and UI
- New five-item navigation: Home, Explore, Search, Laboratory, Profile.
- Search replaces the separate Atlas and Library destinations.
- Search icon is available in the top app bar.
- Settings moved under Profile.
- Home screen content hierarchy simplified; redundant Atlas/library promotional cards removed.
- Category detail screens now begin with a horizontally browsable lesson shelf.
- Lesson detail pages use explicit shelves rather than isolated short paragraphs.

## Content
- 95 unique lesson records imported from the supplied Grok Workspace source (14 catalog records + 81 topic records, duplicate slugs merged).
- 7 Earth Science lesson records added from educational references.
- Total local lesson catalogue: 102 unique records across Biology, Chemistry, Physics, Electronics, Mathematics, Space and Geology.
- Topic pages now separate overview, mechanisms, everyday examples, formulas/data and sources.
- Source links are shown only where a source was attached to the record; no missing citation is fabricated.

## Laboratory
- Bundled Three.js locally and created an offline 3D laboratory route.
- Added 12 selectable procedural 3D scenes.
- Drag rotation, wheel/pinch-compatible zoom, reset and auto-rotation controls.
- Auto-rotation can be stopped; static scenes avoid continuous GPU rendering when idle.
- WebView uses WebViewAssetLoader and blocks external network requests.

## Retained / refined
- Existing 118-element periodic table and detail pages retained.
- Existing category-specific learning pages retained.
- Application ID and namespace preserved.
- Version metadata updated to versionName 1.6.2 / versionCode 15.

## Limitations
- The procedural human-body scene is schematic, not a medically validated anatomical mesh.
- Molecular and orbital scenes are conceptual visual models; dimensions are not to scale.
- The 3D lab is a model viewer, not a complete physics engine.
- Most imported Grok topic records did not carry per-topic bibliography fields; those records are not presented as independently source-verified.
- Full Gradle build and physical-device validation remain pending CI/device execution.
