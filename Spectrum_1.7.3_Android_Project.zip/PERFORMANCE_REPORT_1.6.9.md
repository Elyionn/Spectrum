# Spectrum 1.6.9 — Performance and UI notes

- Three.js renderer antialiasing disabled for mobile efficiency; pixel ratio capped at 1.25 and mediump precision requested.
- Scene rendering is event-driven while auto-rotation is off; model changes and pointer movement request a frame.
- WebView resize is observed and repeated after initial layout and orientation changes.
- WebGL context loss is surfaced in the laboratory caption.
- Geometry/material cleanup remains in the shared scene teardown path.
- Category topic cards use a bounded two-column lazy grid rather than a long horizontal carousel.
- Quadratic graph coordinates and marker positions are clamped to an inset plot rectangle.

No device-side frame-time, memory, startup, battery or GPU benchmark was run in this environment.
