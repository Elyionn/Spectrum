# Spectrum 1.6.8 — Science expansion and interface polish

## New learning content
- Added 14 original lesson records: two each for Biology, Physics, Chemistry, Mathematics, Space, Electronics and Earth Science.
- Each new record includes a summary, core explanation, three mechanism steps, everyday examples, data cards and at least two external learning references.
- Added a `NEW · 1.6.8` marker to new lessons in search results and on lesson detail pages.

## UI and stability
- New lesson markers use the active theme accent and existing card/chip styling.
- Preserved existing horizontally scrollable lesson tabs, category navigation, themes, language settings, periodic table, 3D lab and all earlier lessons.
- Kept new-content metadata optional in the JSON parser so older lesson records remain backward compatible.

## Version
- `versionName`: 1.6.8; `versionCode`: 21.
- Application ID and namespace remain unchanged.

## Validation boundary
- JSON structure, required fields, unique slugs, category counts, sources, XML, JavaScript, YAML and ZIP integrity are checked during packaging and CI.
- Android Gradle compilation, JUnit execution, APK creation, emulator/device UI tests and performance profiling must be confirmed by the GitHub Actions run or a physical test device.
