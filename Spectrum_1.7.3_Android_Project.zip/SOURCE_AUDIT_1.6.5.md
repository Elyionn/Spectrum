# Spectrum 1.6.5 — Source audit

## Scope reviewed
- `MainActivity.kt`, `PeriodicTableData.kt`, `app/build.gradle.kts`, Android manifest, local science JSON, 3D lab HTML and bundled Three.js module.
- The periodic-table reference data/helpers were extracted into `PeriodicTableData.kt`; the local lesson model, JSON parser and category mapper were extracted into `ScienceContentData.kt`. The rest of the UI has not been fully decomposed into feature modules; this release is a targeted refactor, not a full architecture rewrite.

## Findings and corrections
1. **Three.js shared-material disposal:** the previous `clear()` disposed shared materials while switching scenes. This was a concrete model-switch defect. Cleanup now disposes per-scene resources but preserves shared palette materials until the WebGL page is destroyed.
2. **Chemistry embed sizing:** the 230 dp stage minimum exceeded the available space inside a 290 dp WebView. Reduced to 150 dp so the model and controls fit.
3. **Pointer state:** ending a pinch gesture could leave stale pointer coordinates for the remaining finger. The active pointer position is now reset on transition to one-finger drag.
4. **WebGL failure visibility:** renderer startup failures now show an explanatory fallback instead of leaving only an empty canvas area.
5. **Periodic-table density:** the previous 52 × 58 dp cards meant only a small portion of the 18-column table fit on a phone. A compact 30 × 42 dp view and 75% initial zoom expose substantially more columns; users can still zoom and drag.
6. **Search normalization:** dotless Turkish `ı` was not folded to `i`; this is now corrected.
7. **Stale UI version:** 1.6.3 labels were replaced with 1.6.5.
8. **Category identifier:** the JSON category `geology` was inconsistent with the Turkish app taxonomy and is now `yer_bilimleri`.

## Scientific-content provenance
- The catalogue has 102 unique lessons and the required display fields are structurally present.
- Seven Earth Science records contain topic-specific external sources. The other 95 records have no per-topic source list. The source package notes that many imported lesson records did not include a bibliography.
- This audit does not claim a line-by-line scientific fact check of all 102 lesson bodies. Unsupported citations have not been invented. A full scientific fact-check requires reviewing each statement against appropriate primary or authoritative references and recording those references per lesson.
- The periodic-table values remain the existing project dataset; this release adds integrity tests but does not claim a complete independent verification of every atomic mass, electron configuration or physical property.
