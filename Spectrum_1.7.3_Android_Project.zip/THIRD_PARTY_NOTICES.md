# Third-party notices

## Three.js

Spectrum bundles the Three.js browser module from the Grok Workspace source archive (`three.module-CZwSHvn9.js`, package metadata identifies `three` version `^0.187.0`). Three.js is distributed under the MIT License.

Copyright (c) 2010-2025 Three.js authors.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.

The Grok Workspace topic text and model source files were used as a source/reference for this integration. The topic content is stored in `app/src/main/assets/data/science_topics.json`. No Grok authentication, database, server routes, user data, or unrelated app code is included.
