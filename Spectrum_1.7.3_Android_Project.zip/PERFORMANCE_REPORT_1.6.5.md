# Spectrum 1.6.5 — Performance and stability review

## Code-level fixes
- Three.js model changes no longer dispose materials shared by other scene models. Per-model geometry and non-shared materials are disposed when a model is replaced.
- The WebGL renderer is configured with `powerPreference: low-power` and a device-pixel-ratio cap of 1.25. Idle rendering remains paused unless auto-rotation or interaction requires another frame.
- The 3D scene stage now uses a 150 dp minimum height rather than 230 dp, preventing the 290 dp Chemistry WebView from clipping the scene controls.
- The resize observer and animation frame are stopped on page exit; shared materials and renderer context are released on page exit.
- WebView cleanup pauses timers, stops loading, clears clients and destroys the view.
- Periodic-table data/layout are immutable top-level values instead of being reconstructed inside the composable. Element cards are smaller and the initial zoom is 0.75 to show more columns at once.
- Turkish search normalization now maps dotless `ı` to `i`, avoiding common failed searches.

## Not measured
No Android device, emulator, Android SDK, Gradle installation, Android Studio Profiler, Macrobenchmark or GPU profiler was available in this environment. Startup time, frame time, RAM, thermal behavior, battery use and actual device compatibility are not measured. The compact table's visible-column improvement is derived from the new layout dimensions, not a benchmark.

## Required runtime checks
- Test WebGL renderer startup and fallback on devices with and without WebGL 2 support.
- Switch through all 12 scenes repeatedly and confirm material reuse, rendering and memory cleanup.
- Test one-finger rotation, two-finger pinch, pinch-to-drag transition, reset, auto-rotation, background/foreground and screen resizing.
- Confirm the Chemistry 290 dp embed shows all controls.
- Profile table scroll/zoom and element selection on low- and mid-range Android devices.
