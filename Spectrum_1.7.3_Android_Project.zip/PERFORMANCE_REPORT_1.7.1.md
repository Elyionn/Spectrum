# Spectrum 1.7.1 — Performance changes and measurement status

## Code-level changes
- Search lesson corpus is normalized once per dataset/language change and results are rendered lazily with `LazyColumn`.
- The 3D renderer uses a 1.15 device-pixel-ratio ceiling, low-power preference, antialiasing disabled and demand-driven frames when auto-rotation is off.
- WebView rejects non-local origins and is disposed without calling the global `pauseTimers()` API.
- The Settings page uses compact sections and short theme/font selectors to reduce scrolling and screen usage.

## Measurements not available
No device-side CPU, GPU, memory, startup-time, battery or frame-time benchmark was run in this environment. These are code-level optimizations, not measured performance claims.
