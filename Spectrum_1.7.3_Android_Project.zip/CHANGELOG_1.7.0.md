# Spectrum 1.7.0 — Interface, lesson experience and Singularity identity

## Brand identity
- Replaced the previous Spectrum mark in the app header and launcher drawable with the Singularity concept: a luminous geometric triangle and a central cosmic core.
- Added a high-resolution source render to `design/singularity-logo-source.png`.

## Interface
- Reworked the visual system around three named themes: Dark Observatory, Light Laboratory and Deep Space.
- Updated the bottom navigation to five destinations: Home, Explore, Laboratory, Search and Settings.
- Refined the global header and logo treatment.
- Rebuilt the home science-field shortcuts around the seven primary study domains.

## Categories and lessons
- Combined category navigation and the lesson collection into a single category screen.
- Replaced the old clipped horizontal topic shelf with a vertically readable lesson collection.
- Added a structured lesson hero, subject-specific visual cue, interactive parameter control, learning map, data cards, examples, formulas/data and source sections.
- Kept the interactive parameter control explicitly labelled as an illustrative control, not a validated subject-specific simulation.
- Retained legacy learning modules for categories without matching lesson records.

## Compatibility
- Application ID remains `com.elyionn.spectrum`.
- Namespace remains `com.elyionn.spektrum`.
- `versionName`: `1.7.0`.
- `versionCode`: `23`.
- Existing lesson JSON and 3D model registry retained.

## Verification status
- ZIP integrity, JSON structure, XML parsing, Three.js syntax, model registry consistency, YAML parsing and source metadata checks are run in the authoring environment.
- Android Gradle compilation, JUnit execution, APK generation, emulator/device UI tests and actual WebGL runtime tests require the Android SDK/Gradle CI environment and are not claimed as completed here.
