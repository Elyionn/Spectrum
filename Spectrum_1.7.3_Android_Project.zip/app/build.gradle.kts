plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val spectrumKeystorePath = System.getenv("SPECTRUM_KEYSTORE_PATH")
val spectrumSigningEnabled = !spectrumKeystorePath.isNullOrBlank()

android {
    namespace = "com.elyionn.spektrum"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.elyionn.spectrum"
        minSdk = 26
        targetSdk = 35
        versionCode = 26
        versionName = "1.7.3"
    }

    buildFeatures { compose = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    signingConfigs {
        if (spectrumSigningEnabled) {
            create("spectrumRelease") {
                storeFile = file(spectrumKeystorePath!!)
                storePassword = System.getenv("SPECTRUM_STORE_PASSWORD")
                keyAlias = System.getenv("SPECTRUM_KEY_ALIAS")
                keyPassword = System.getenv("SPECTRUM_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            if (spectrumSigningEnabled) signingConfig = signingConfigs.getByName("spectrumRelease")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    packaging {
        resources.excludes += setOf("META-INF/AL2.0", "META-INF/LGPL2.1")
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation-core")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.webkit:webkit:1.12.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")
}
