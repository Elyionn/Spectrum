package com.elyionn.spektrum

import org.junit.Assert.assertEquals
import org.junit.Test

class ScienceContentDataTest {
    @Test
    fun categoryAliasesResolveToTheSameTurkishLabel() {
        assertEquals("Biyoloji", topicCategoryLabel("biyoloji"))
        assertEquals("Biyoloji", topicCategoryLabel("biology"))
        assertEquals("Teknoloji & Elektronik", topicCategoryLabel("electronics"))
        assertEquals("Yer Bilimleri", topicCategoryLabel("earth science"))
    }

    @Test
    fun categoryAliasesResolveToEnglishLabels() {
        assertEquals("Biology", topicCategoryLabel("biyoloji", english = true))
        assertEquals("Technology & Electronics", topicCategoryLabel("technology", english = true))
        assertEquals("Earth Science", topicCategoryLabel("yer_bilimleri", english = true))
    }

    @Test
    fun unknownCategoryRemainsReadable() {
        assertEquals("Astrophysics", topicCategoryLabel("astrophysics", english = true))
    }
}
