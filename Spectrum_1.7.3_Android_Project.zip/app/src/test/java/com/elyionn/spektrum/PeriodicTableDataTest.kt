package com.elyionn.spektrum

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class PeriodicTableDataTest {
    @Test
    fun elementDatasetContainsAllAtomicNumbersExactlyOnce() {
        assertEquals(118, elementRows.size)
        assertEquals((1..118).toList(), elementRows.map { it[2].toInt() })
    }

    @Test
    fun periodicLayoutContainsEveryElementExactlyOnce() {
        val numbers = periodicTableRows.flatten().filterNotNull()
        assertEquals(118, numbers.size)
        assertEquals((1..118).toList(), numbers.sorted())
    }

    @Test
    fun searchNormalizationHandlesTurkishDotlessIAndDiacritics() {
        assertEquals("isik", normalizeElementSearch("IŞIK"))
        assertEquals("isik", normalizeElementSearch("ışık"))
        assertEquals("cagri", normalizeElementSearch("Çağrı"))
    }

    @Test
    fun englishElementNamesAreAvailableForAllElements() {
        for (atomicNumber in 1..118) {
            assertNotNull(englishElementName(atomicNumber))
        }
    }
    @Test
    fun periodicTableHasNineRowsAndEighteenColumns() {
        assertEquals(9, periodicTableRows.size)
        periodicTableRows.forEach { row -> assertEquals(18, row.size) }
    }

    @Test
    fun elementRecordsHaveValidFieldsAndUniqueSymbols() {
        assertEquals(118, elementRows.map { it[0] }.distinct().size)
        elementRows.forEach { row ->
            assertEquals(5, row.size)
            assertEquals(true, row[0].matches(Regex("[A-Z][a-z]?")))
            assertEquals(true, row[1].isNotBlank())
            assertEquals(true, row[3].toDoubleOrNull() != null)
        }
    }

    @Test
    fun elementHelpersRejectOutOfRangeAtomicNumbersSafely() {
        assertEquals("Element", englishElementName(0))
        assertEquals("Element", englishElementName(119))
        assertNull(covalentRadiusPm(0))
        assertNull(covalentRadiusPm(104))
    }

}
