package com.elyionn.spektrum

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.ConsoleMessage
import android.webkit.WebSettings
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.JavascriptInterface
import java.io.ByteArrayInputStream
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import kotlin.math.pow
import java.util.Locale
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class Palette(val name: String, val bg: Color, val panel: Color, val accent: Color, val text: Color, val muted: Color)
private val palettes = listOf(
    Palette("Dark Observatory", Color(0xFF050B18), Color(0xFF10223B), Color(0xFF58C8FF), Color(0xFFF1F7FF), Color(0xFF9FB5CC)),
    Palette("Light Laboratory", Color(0xFFF2F6FA), Color(0xFFFFFFFF), Color(0xFF087FA6), Color(0xFF152635), Color(0xFF607482)),
    Palette("Deep Space", Color(0xFF080516), Color(0xFF191333), Color(0xFF9B83FF), Color(0xFFF5F0FF), Color(0xFFB8ADD5)),
    Palette("Aurora Field", Color(0xFF061713), Color(0xFF102B27), Color(0xFF62E6B4), Color(0xFFE8FFF6), Color(0xFF9BCDBB)),
    Palette("Arctic Signal", Color(0xFF071522), Color(0xFF142E43), Color(0xFF83D8F2), Color(0xFFEAF8FF), Color(0xFFA5C5D6)),
    Palette("Graphite Lab", Color(0xFF14171C), Color(0xFF252B33), Color(0xFFFFB86B), Color(0xFFF4F5F7), Color(0xFFADB5C0))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { SpectrumApp() }
    }
}

@Composable
private fun SpectrumApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("spectrum_settings", Context.MODE_PRIVATE) }
    var page by rememberSaveable { mutableStateOf("Ana Sayfa") }
    var category by rememberSaveable { mutableStateOf("") }
    var categoryReturnPage by rememberSaveable { mutableStateOf("Keşfet") }
    var selectedTopicSlug by rememberSaveable { mutableStateOf("optik") }
    var topicReturnPage by rememberSaveable { mutableStateOf("Ara") }
    var elementReturnPage by rememberSaveable { mutableStateOf("Ara") }
    var requestedModel by rememberSaveable { mutableStateOf("atom") }
    var selectedTechTopic by rememberSaveable { mutableStateOf("3d") }
    val scienceTopics by produceState<List<ScienceTopicData>?>(null, context.applicationContext) {
        value = withContext(Dispatchers.IO) { loadScienceTopics(context.applicationContext) }
    }
    val topics = scienceTopics.orEmpty()
    var selectedElement by rememberSaveable { mutableStateOf("H") }
    var fontIndex by rememberSaveable { mutableIntStateOf(prefs.getInt("font", 0).coerceIn(0, 5)) }
    var themeIndex by rememberSaveable { mutableIntStateOf(prefs.getInt("theme", palettes.indexOfFirst { it.name == "Deep Space" }.coerceAtLeast(0)).coerceIn(palettes.indices)) }
    var soundOn by rememberSaveable { mutableStateOf(prefs.getBoolean("sound", true)) }
    var language by rememberSaveable { mutableStateOf(prefs.getString("language", "tr") ?: "tr") }
    val english = language == "en"
    val p = palettes[themeIndex]
    val tone = remember { ToneGenerator(AudioManager.STREAM_MUSIC, 35) }
    DisposableEffect(Unit) { onDispose { tone.release() } }
    fun clickSound() { if (soundOn) tone.startTone(ToneGenerator.TONE_PROP_ACK, 55) }
    fun selectSound() { if (soundOn) tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 45) }
    fun confirmSound() { if (soundOn) tone.startTone(ToneGenerator.TONE_PROP_PROMPT, 75) }
    val scheme = if (p.name == "Light Laboratory") lightColorScheme(
        primary = p.accent, background = p.bg, surface = p.panel, onSurface = p.text, onBackground = p.text
    ) else darkColorScheme(
        primary = p.accent, background = p.bg, surface = p.panel, onSurface = p.text, onBackground = p.text
    )

    val appFont = when (fontIndex) {
        1 -> androidx.compose.ui.text.font.FontFamily(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.NORMAL))
        2 -> androidx.compose.ui.text.font.FontFamily.Monospace
        3 -> androidx.compose.ui.text.font.FontFamily.Serif
        4 -> androidx.compose.ui.text.font.FontFamily(android.graphics.Typeface.create("sans-serif-rounded", android.graphics.Typeface.NORMAL))
        5 -> androidx.compose.ui.text.font.FontFamily(android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL))
        else -> androidx.compose.ui.text.font.FontFamily.SansSerif
    }
    MaterialTheme(colorScheme = scheme) {
      androidx.compose.runtime.CompositionLocalProvider(androidx.compose.material3.LocalTextStyle provides androidx.compose.material3.LocalTextStyle.current.copy(fontFamily = appFont)) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = p.bg,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                NavigationBar(
                    containerColor = p.panel,
                    contentColor = p.text,
                    tonalElevation = 0.dp
                ) {
                    val items = listOf(
                        Triple("Ana Sayfa", Icons.Default.Home, if (english) "Home" else "Ana Sayfa"),
                        Triple("Keşfet", Icons.Default.Explore, if (english) "Explore" else "Keşfet"),
                        Triple("Laboratuvar", Icons.Default.Science, if (english) "Lab" else "Laboratuvar"),
                        Triple("Ara", Icons.Default.Search, if (english) "Search" else "Ara"),
                        Triple("Ayarlar", Icons.Default.Settings, if (english) "Settings" else "Ayarlar")
                    )
                    items.forEach { item ->
                        NavigationBarItem(
                            selected = page == item.first || (page == "KonuDetay" && item.first == "Ara") ||
                                ((page == "Detay" || page == "ElementDetay" || page == "TeknolojiDetay") && item.first == "Keşfet") ||
                                (page == "3DLab" && item.first == "Laboratuvar"),
                            onClick = { clickSound(); page = item.first; category = "" },
                            icon = { Icon(item.second, contentDescription = item.first) },
                            label = { Text(item.third, fontSize = 9.sp, maxLines = 1) },
                            alwaysShowLabel = true,
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = p.accent,
                                selectedTextColor = p.accent,
                                indicatorColor = p.accent.copy(alpha = .13f),
                                unselectedIconColor = p.muted,
                                unselectedTextColor = p.muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).background(p.bg)
            ) {
                Header(p = p, title = when (page) { "Detay" -> category; "ElementDetay" -> selectedElement; "KonuDetay" -> topics.firstOrNull { it.slug == selectedTopicSlug }?.title ?: "Konu"; "TeknolojiDetay" -> techLessons.firstOrNull { it.id == selectedTechTopic }?.let { if (english) it.titleEn else it.titleTr } ?: "Teknoloji"; "Ana Sayfa" -> if (english) "Home" else "Ana Sayfa"; "Keşfet" -> if (english) "Explore" else "Keşfet"; "Ara" -> if (english) "Search" else "Ara"; else -> page }, onSearch = { page = "Ara" })
                if (scienceTopics == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = p.accent)
                    }
                } else when (page) {
                    "Ana Sayfa" -> SpectrumHomePage(p, english, topics,
                        onOpenCategory = { category = it; categoryReturnPage = "Ana Sayfa"; page = "Detay" },
                        onExplore = { page = "Keşfet" }, onLab = { page = "Laboratuvar" }, onSearch = { page = "Ara" },
                        onTopic = { selectedTopicSlug = it; topicReturnPage = "Ana Sayfa"; page = "KonuDetay" })
                    "Keşfet" -> SpectrumExplorePage(p, english, onOpen = { category = it; categoryReturnPage = "Keşfet"; page = "Detay" })
                    "Ara" -> ScienceSearchPage(p, english, topics,
                        onOpenTopic = { selectedTopicSlug = it; topicReturnPage = "Ara"; page = "KonuDetay" },
                        onOpenElement = { selectedElement = it; elementReturnPage = "Ara"; page = "ElementDetay" })
                    "TeknolojiDetay" -> TechnologyTopicDetailPage(p, english, selectedTechTopic, onOpenModel = { requestedModel = modelForTechTopic(selectedTechTopic); page = "3DLab" }, onBack = { page = "Detay" })
                    "KonuDetay" -> ScienceTopicDetailPage(p, english, topics.firstOrNull { it.slug == selectedTopicSlug },
                        onBack = { page = topicReturnPage }, onOpenModel = { requestedModel = modelForTopic(selectedTopicSlug, topics.firstOrNull { it.slug == selectedTopicSlug }?.category.orEmpty()); page = "3DLab" })
                    "3DLab" -> VisualLabPage(p, english, requestedModel)
                    "Laboratuvar" -> SpectrumLabHubPage(p, english,
                        onOpenVisual = { requestedModel = "atom"; page = "3DLab" },
                        onOpenPhysics = { category = "Fizik & Elektrik"; categoryReturnPage = "Laboratuvar"; page = "Detay" },
                        onOpenChemistry = { category = "Kimya"; categoryReturnPage = "Laboratuvar"; page = "Detay" },
                        onOpenBiology = { category = "Biyoloji"; categoryReturnPage = "Laboratuvar"; page = "Detay" })
                    "Ayarlar" -> SettingsPage(
                        p, themeIndex, soundOn, fontIndex, language,
                        onTheme = { themeIndex = it; prefs.edit().putInt("theme", it).apply(); clickSound() },
                        onSound = { soundOn = it; prefs.edit().putBoolean("sound", it).apply() },
                        onFont = { fontIndex = it; prefs.edit().putInt("font", it).apply() },
                        onLanguage = { language = it; prefs.edit().putString("language", it).apply(); confirmSound() },
                        onReset = {
                            val defaultTheme = palettes.indexOfFirst { it.name == "Deep Space" }.coerceAtLeast(0)
                            themeIndex = defaultTheme
                            soundOn = true
                            fontIndex = 0
                            language = "tr"
                            prefs.edit().putInt("theme", defaultTheme).putBoolean("sound", true)
                                .putInt("font", 0).putString("language", "tr").apply()
                        }
                    )
                    "ElementDetay" -> ElementDetailPage(p, elementRows.firstOrNull { it[0] == selectedElement } ?: elementRows.first(), english, onBack = { page = elementReturnPage })
                    "Detay" -> CategoryDetail(
                        p, category, english, topics,
                        onBack = { page = categoryReturnPage; category = "" },
                        onElement = { selectedElement = it; elementReturnPage = "Detay"; page = "ElementDetay"; selectSound() },
                        onTopic = { selectedTopicSlug = it; topicReturnPage = "Detay"; page = "KonuDetay" },
                        onTechTopic = { selectedTechTopic = it; page = "TeknolojiDetay"; selectSound() }
                    )
                    else -> SpectrumHomePage(p, english, topics,
                        onOpenCategory = { category = it; categoryReturnPage = "Ana Sayfa"; page = "Detay" },
                        onExplore = { page = "Keşfet" }, onLab = { page = "Laboratuvar" }, onSearch = { page = "Ara" },
                        onTopic = { selectedTopicSlug = it; topicReturnPage = "Ana Sayfa"; page = "KonuDetay" })
                }
            }
        }
      }
    }
}

@Composable
private fun Header(p: Palette, title: String, onSearch: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(com.elyionn.spektrum.R.drawable.spectrum_logo),
            contentDescription = "Spectrum logo",
            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(13.dp))
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("SPECTRUM", color = p.text, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 2.1.sp)
            Text(title, color = p.muted, fontSize = 11.sp, maxLines = 1)
        }
        IconButton(onClick = onSearch) {
            Icon(Icons.Default.Search, contentDescription = if (title == "Settings") "Search" else "Ara", tint = p.accent)
        }
    }
}

@Composable
fun Panel(p: Palette, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth()
            .background(p.panel, RoundedCornerShape(20.dp))
            .border(1.dp, p.accent.copy(alpha = .18f), RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}

private val categoryDescriptions = listOf(
    "Biyoloji" to "İnsan anatomisi, hücre, DNA, genetik ve canlı sistemleri",
    "Kimya" to "Kimyasal bağlar, tepkimeler, çözeltiler, asitler ve bazlar",
    "Elementler" to "118 element, etkileşimli periyodik tablo ve ayrıntılı element dosyaları",
    "Atomlar" to "Atomun yapısı, orbitaller, elektron dizilimi, iyonlar ve izotoplar",
    "Fizik & Elektrik" to "Kuvvet, hareket, enerji, dalgalar, optik ve elektrik",
    "Uzay" to "Güneş Sistemi, gezegenler, yıldızlar, galaksiler ve kozmoloji",
    "Matematik" to "Sayılar, cebir, geometri, fonksiyonlar ve olasılık",
    "Mikrobiyoloji" to "Bakteriler, virüsler, mantarlar ve mikroskobik yaşam",
    "Teknoloji" to "Elektronik, sensörler, işlemciler ve modern mühendislik",
    "3B Bilim Laboratuvarı" to "Atom, molekül ve biyolojik yapıların etkileşimli görselleştirmeleri",
    "Yer Bilimleri" to "Dünya’nın iç yapısı, levha tektoniği, kayaçlar, mineraller ve jeolojik süreçler"
)



@Composable
private fun ScienceSearchPage(
    p: Palette, english: Boolean, topics: List<ScienceTopicData>,
    onOpenTopic: (String) -> Unit, onOpenElement: (String) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("Tümü") }
    val categories = listOf("Tümü", "fizik", "kimya", "biyoloji", "uzay", "matematik", "elektronik", "yer_bilimleri")
    val normalized = normalizeElementSearch(query.trim())
    // Build each lesson's searchable text once; typing only filters the cached index.
    val searchIndex = remember(topics, english) {
        topics.map { topic ->
            topic to normalizeElementSearch(
                "${topic.title} ${topic.summary} ${topic.lead} ${topicCategoryLabel(topic.category, english)} ${topic.how.joinToString(" ")} ${topic.facts.joinToString(" ") { "${it.first} ${it.second}" }}"
            )
        }
    }
    val topicResults = remember(searchIndex, normalized, filter) {
        searchIndex.asSequence()
            .filter { (topic, corpus) -> (filter == "Tümü" || topic.category == filter) && (normalized.isEmpty() || corpus.contains(normalized)) }
            .map { it.first }
            .toList()
    }
    val elementResults = remember(normalized) {
        if (normalized.length < 2) emptyList() else elementRows.asSequence().filter { e ->
            normalizeElementSearch("${e[0]} ${e[1]} ${e[2]} ${e[4]}").contains(normalized)
        }.take(12).toList()
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(if (english) "Search science" else "Bilimsel arama", color = p.text, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text(if (english) "Find lessons, elements, formulas and fields." else "Dersleri, elementleri, formülleri ve bilim dallarını bul.", color = p.muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, placeholder = { Text(if (english) "Search a topic or element…" else "Optik, DNA, demir, enerji…") },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = p.accent) },
            trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, null) } },
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            categories.forEach { id ->
                val label = if (id == "Tümü") { if (english) "All" else "Tümü" } else topicCategoryLabel(id, english)
                FilterChip(selected = filter == id, onClick = { filter = id }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (elementResults.isNotEmpty()) {
                item { Text(if (english) "ELEMENTS" else "ELEMENTLER", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp) }
                lazyItems(elementResults, key = { "element-${it[0]}" }) { e ->
                    Panel(p, Modifier.fillMaxWidth().clickable { onOpenElement(e[0]) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(e[0], color = p.accent, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.width(48.dp))
                            Column(Modifier.weight(1f)) {
                                Text(if (english) englishElementName(e[2].toInt()) else e[1], color = p.text, fontWeight = FontWeight.Bold)
                                Text("Z = ${e[2]} · ${localizedElementFamily(e[4], english)}", color = p.muted, fontSize = 11.sp)
                            }
                            Icon(Icons.Default.ChevronRight, null, tint = p.muted)
                        }
                    }
                }
            }
            item { Text(if (english) "LESSONS · ${topicResults.size}" else "KONU RAFI · ${topicResults.size}", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp) }
            lazyItems(topicResults, key = { it.slug }) { topic ->
                Panel(p, Modifier.fillMaxWidth().clickable { onOpenTopic(topic.slug) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(topicCategoryLabel(topic.category, english), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                if (topic.isNew) Surface(color = p.accent.copy(alpha = .14f), shape = RoundedCornerShape(6.dp)) {
                                    Text(if (english) "NEW" else "YENİ", color = p.accent, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                                }
                            }
                            Text(topic.title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            if (english) Text("Turkish source text", color = p.muted, fontSize = 9.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = p.muted)
                    }
                    Text(topic.summary, color = p.muted, fontSize = 12.sp, lineHeight = 17.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(if (english) "${topic.how.size} explanations" else "${topic.how.size} açıklama", color = p.accent, fontSize = 10.sp)
                        Text("·", color = p.muted)
                        Text(if (english) "${topic.facts.size} data cards" else "${topic.facts.size} veri kartı", color = p.accent, fontSize = 10.sp)
                        if (topic.life.isNotEmpty()) { Text("·", color = p.muted); Text(if (english) "${topic.life.size} examples" else "${topic.life.size} örnek", color = p.accent, fontSize = 10.sp) }
                    }
                }
            }
            if (topicResults.isEmpty() && elementResults.isEmpty()) {
                item { Panel(p) {
                    Text(if (english) "No results" else "Sonuç bulunamadı", color = p.text, fontWeight = FontWeight.Bold)
                    Text(if (english) "Try a shorter term or another field." else "Daha kısa bir terim veya başka bir bilim dalı dene.", color = p.muted, fontSize = 12.sp)
                } }
            }
        }
    }
}

private fun modelForTopic(slug: String, category: String = ""): String = when (slug) {
    "su-molekulu" -> "water"
    "karbondioksit" -> "co2"
    "metan" -> "methane"
    "dna" -> "dna"
    "hucre" -> "cell"
    "kalp" -> "body"
    "optik" -> "optics"
    "gunes-sistemi" -> "solar"
    "dalgalar" -> "wave"
    "elektrik" -> "circuit"
    "yercekimi" -> "gravity"
    "sinir-hucresi" -> "neuron"
    "mitokondri" -> "mitochondria"
    "bagisiklik-sistemi" -> "immune"
    "bagisiklik-sistemi-plus" -> "immune"
    "fotosentez" -> "chloroplast"
    "gen-ifadesi" -> "ribosome"
    "newton-hareket-yasalari" -> "projectile"
    "enerjinin-korunumu" -> "pendulum"
    "elektromanyetik-induksiyon" -> "induction"
    "termodinamik-yasalar" -> "heat-engine"
    "ses-dalgalari" -> "sound"
    "kimyasal-denge" -> "equilibrium"
    "asit-baz-tepkimeleri" -> "acid-base"
    "redoks-tepkimeleri" -> "redox"
    "organik-fonksiyonel-gruplar" -> "organic"
    "polimerler" -> "polymer"
    "polimerler-plus" -> "polymer"
    "analitik-geometri" -> "geometry"
    "logaritma" -> "logarithm"
    "logaritma-plus" -> "logarithm"
    "limit-ve-sureklilik" -> "calculus"
    "vektorler" -> "vectors"
    "kombinatorik" -> "combinatorics"
    "yildiz-evrimi" -> "star-life"
    "kara-delikler" -> "black-hole"
    "kara-delikler-plus" -> "black-hole"
    "galaksiler" -> "galaxy"
    "otesi-gezegenler" -> "exoplanet"
    "kozmik-mikrodalga-arka-plan" -> "cmb"
    "yariletkenler" -> "semiconductor"
    "transistor" -> "transistor"
    "kondansator" -> "capacitor"
    "mikrodenetleyici" -> "microcontroller"
    "mikrodenetleyici-plus" -> "microcontroller"
    "sensorler" -> "sensor"
    "mineral-kristal-yapisi" -> "crystal"
    "volkanizma" -> "volcano"
    "deprem-dalgalar" -> "seismic"
    "yeraltisuyu" -> "aquifer"
    "iklim-jeoloji" -> "ice-core"
    "bagisiklik-sistemi-plus" -> "immune"
    "polimerler-plus" -> "polymer"
    "logaritma-plus" -> "logarithm"
    "kara-delikler-plus" -> "black-hole"
    "mikrodenetleyici-plus" -> "microcontroller"
    else -> when (category) {
        "biyoloji" -> "cell"
        "fizik" -> "projectile"
        "kimya" -> "water"
        "matematik" -> "geometry"
        "uzay" -> "solar"
        "elektronik" -> "circuit"
        "yer_bilimleri" -> "volcano"
        else -> "atom"
    }
}

@Composable
private fun ScienceTopicDetailPage(
    p: Palette, english: Boolean, topic: ScienceTopicData?, onBack: () -> Unit, onOpenModel: () -> Unit
) {
    if (topic == null) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text(if (english) "Topic data could not be loaded." else "Konu verisi yüklenemedi.", color = p.text)
            TextButton(onClick = onBack) { Text(if (english) "Back to search" else "Aramaya dön") }
        }
        return
    }
    var shelf by rememberSaveable(topic.slug) { mutableStateOf("overview") }
    var level by rememberSaveable(topic.slug) { mutableIntStateOf(1) }
    val shelves = listOf("overview", "mechanism", "examples", "data", "sources")
    val hasModel = true
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (english) Panel(p) {
            Text("English interface · Turkish source text", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("This imported lesson has not yet received a verified English translation. Its original Turkish text is shown without machine-generated substitutions.", color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = p.accent) }
            Column(Modifier.weight(1f)) {
                Text(if (english) "LESSON DETAIL" else "KONU DETAYI", color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                if (topic.isNew) {
                    Spacer(Modifier.height(4.dp))
                    Surface(color = p.accent.copy(alpha = .14f), shape = RoundedCornerShape(8.dp)) {
                        Text(if (english) "NEW · 1.7.3" else "YENİ · 1.7.3", color = p.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                }
            }
            IconButton(onClick = onOpenModel, enabled = hasModel) { Icon(Icons.Default.ViewInAr, null, tint = if (hasModel) p.accent else p.muted) }
        }
        // Visual lesson header: a clear, subject-first entry point instead of a wall of text.
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(p.panel, p.accent.copy(alpha = .20f), Color(0xFF111C35)))).padding(18.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = p.accent.copy(alpha = .16f), shape = RoundedCornerShape(9.dp)) {
                        Text(topicCategoryLabel(topic.category, english).uppercase(), color = p.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.AutoAwesome, null, tint = p.accent)
                }
                Text(topic.title, color = p.text, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp, lineHeight = 30.sp)
                Text(topic.summary, color = p.muted, fontSize = 13.sp, lineHeight = 19.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MenuBook, null, tint = p.accent, modifier = Modifier.size(15.dp))
                    Text("${topic.how.size} ${if (english) "learning steps" else "öğrenme adımı"}", color = p.muted, fontSize = 10.sp)
                    Text("•", color = p.muted)
                    Text("${topic.facts.size} ${if (english) "key data" else "temel veri"}", color = p.muted, fontSize = 10.sp)
                }
            }
        }
        Panel(p) {
            Text(if (english) "VISUAL MODEL" else "GÖRSEL MODEL", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.2.sp)
            Box(Modifier.fillMaxWidth().height(118.dp).clip(RoundedCornerShape(16.dp)).background(Brush.radialGradient(listOf(p.accent.copy(alpha = .28f), p.panel, p.bg))), contentAlignment = Alignment.Center) {
                Icon(categoryVisualIcon(topic.category), null, tint = p.accent, modifier = Modifier.size(66.dp))
                Text(topicCategoryLabel(topic.category, english).uppercase(), color = p.muted.copy(alpha = .75f), fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp), letterSpacing = 1.3.sp)
            }
            Text(if (english) "Concept illustration" else "Kavram görselleştirmesi", color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(if (english) "A subject-specific visual cue. Open the 3D laboratory for an interactive model when available." else "Konuya özel görsel gösterim. Uygun etkileşimli modeli incelemek için 3B laboratuvarı aç.", color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
            TextButton(onClick = onOpenModel) { Icon(Icons.Default.ViewInAr, null); Spacer(Modifier.width(6.dp)); Text(if (english) "Explore 3D model" else "3B modeli incele") }
        }
        var experimentValue by rememberSaveable(topic.slug) { mutableFloatStateOf(50f) }
        Panel(p) {
            Text(if (english) "INTERACTIVE EXPLORATION" else "ETKİLEŞİMLİ KEŞİF", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.2.sp)
            Text(if (english) "Adjust a parameter" else "Bir parametreyi değiştir", color = p.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(if (english) "Use the control to explore how a value changes. This generic control is illustrative, not a subject-specific scientific simulation." else "Değerin nasıl değiştiğini görmek için kontrolü kullan. Bu genel kontrol açıklayıcıdır; konuya özel bilimsel simülasyon değildir.", color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
            Slider(value = experimentValue, onValueChange = { experimentValue = it }, valueRange = 0f..100f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (english) "Parameter" else "Parametre", color = p.muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                Text("${experimentValue.toInt()} / 100", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(p.muted.copy(alpha = .16f))) {
                Box(Modifier.fillMaxWidth(experimentValue / 100f).fillMaxHeight().clip(CircleShape).background(Brush.horizontalGradient(listOf(p.accent, Color(0xFF9B83FF)))))
            }
        }
        Panel(p) {
            Text(if (english) "CORE CONCEPT" else "TEMEL KAVRAM", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.2.sp)
            Text(topic.lead, color = p.text, fontSize = 14.sp, lineHeight = 22.sp)
            if (topic.note != null) Text(topic.note, color = p.muted, fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 8.dp))
        }
        Panel(p) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountTree, null, tint = p.accent)
                Spacer(Modifier.width(8.dp))
                Text(if (english) "LEARNING MAP" else "ÖĞRENME HARİTASI", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
            }
            topic.how.forEachIndexed { i, step ->
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.Top) {
                    Surface(color = p.accent.copy(alpha=.16f), shape = CircleShape) { Text("${i+1}", color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal=10.dp, vertical=6.dp)) }
                    Spacer(Modifier.width(9.dp))
                    Text(step, color = p.text, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.weight(1f))
                }
            }
        }
        if (topic.facts.isNotEmpty()) {
            Text(if (english) "KEY DATA" else "TEMEL VERİLER", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.2.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                topic.facts.take(2).forEach { (key, value) ->
                    Panel(p, Modifier.weight(1f)) {
                        Text(key.uppercase(if (english) Locale.ENGLISH else Locale.ROOT), color = p.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(value, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold, lineHeight = 18.sp)
                    }
                }
            }
        }
        Text(if (english) "LEARNING LEVEL" else "ÖĞRENME SEVİYESİ", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.2.sp)
        Row(Modifier.fillMaxWidth().background(p.panel, RoundedCornerShape(14.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("Keşfet", "Öğren", "Derinlemesine").forEachIndexed { i, label ->
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if (level == i) p.accent else Color.Transparent).clickable { level = i }.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                    Text(if (english) listOf("Explore", "Learn", "Deep dive")[i] else label, color = if (level == i) Color(0xFF071321) else p.text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        if (level == 0) {
            Panel(p) {
                Text(if (english) "CORE IDEA" else "TEMEL FİKİR", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Text(topic.lead, color = p.text, lineHeight = 22.sp)
                Text(topic.summary, color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        } else if (level == 1) {
            Panel(p) {
                Text(if (english) "EXPLANATION" else "AYRINTILI AÇIKLAMA", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                topic.how.forEachIndexed { i, paragraph ->
                    Text("${i + 1}. ${paragraph}", color = p.text, fontSize = 13.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 7.dp))
                }
            }
        } else {
            Panel(p) {
                Text(if (english) "TECHNICAL VIEW" else "TEKNİK BAKIŞ", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                topic.how.forEach { Text(it, color = p.text, fontSize = 13.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 7.dp)) }
                if (topic.note != null) Text(topic.note, color = p.muted, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            shelves.forEach { key ->
                val label = if (english) when (key) {
                    "overview" -> "Overview"; "mechanism" -> "Mechanism"; "examples" -> "Everyday examples"; "data" -> "Data & formulas"; else -> "Sources"
                } else when (key) {
                    "overview" -> "Genel Bakış"; "mechanism" -> "İşleyiş"; "examples" -> "Günlük Örnekler"; "data" -> "Veriler ve Formüller"; else -> "Kaynaklar"
                }
                FilterChip(selected = shelf == key, onClick = { shelf = key }, label = { Text(label) })
            }
        }
        when (shelf) {
            "overview" -> Panel(p) {
                Text(if (english) "TOPIC SUMMARY" else "KONU ÖZETİ", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Text(topic.summary, color = p.text, lineHeight = 20.sp)
            }
            "mechanism" -> Panel(p) {
                Text(if (english) "HOW IT WORKS" else "NASIL ÇALIŞIR?", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                topic.how.forEachIndexed { i, text ->
                    Text("${i + 1}. adım", color = p.accent, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    Text(text, color = p.text, fontSize = 13.sp, lineHeight = 21.sp)
                }
            }
            "examples" -> Panel(p) {
                Text(if (english) "IN EVERYDAY LIFE" else "GÜNLÜK HAYATTA", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                if (topic.life.isEmpty()) Text(if (english) "No separate everyday examples were included in this source record." else "Bu konu için kaynak pakette ayrı günlük örnek verilmemiş.", color = p.muted, fontSize = 12.sp)
                topic.life.forEach { (title, text) ->
                    Text(title, color = p.text, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    Text(text, color = p.muted, fontSize = 13.sp, lineHeight = 19.sp)
                }
            }
            "data" -> Panel(p) {
                Text(if (english) "DATA · FORMULAS · UNITS" else "VERİLER · FORMÜLLER · BİRİMLER", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                if (topic.facts.isEmpty()) Text(if (english) "No numerical data cards are available in this source record." else "Bu konu için sayısal veri kartı kaynakta bulunmuyor.", color = p.muted, fontSize = 12.sp)
                topic.facts.forEach { (k, v) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
                        Text(k, color = p.muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(v, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.2f))
                    }
                    HorizontalDivider(color = p.muted.copy(alpha = .15f))
                }
            }
            else -> Panel(p) {
                val uriHandler = LocalUriHandler.current
                Text(if (english) "SOURCES" else "KAYNAKLAR", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                if (topic.sources.isEmpty()) Text(if (english) "No topic-specific external source link has been added to this record yet." else "Bu konu kaydına özgü dış kaynak bağlantısı henüz eklenmemiştir.", color = p.muted, fontSize = 12.sp)
                topic.sources.forEach { (title, url) ->
                    TextButton(onClick = { runCatching { uriHandler.openUri(url) } }) {
                        Text(title, color = p.text, fontSize = 11.sp, lineHeight = 16.sp)
                    }
                }
            }
        }
        if (hasModel) Panel(p, Modifier.fillMaxWidth().clickable { onOpenModel() }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ViewInAr, null, tint = p.accent)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (english) "Open interactive model" else "Etkileşimli modeli aç", color = p.text, fontWeight = FontWeight.Bold)
                    Text(if (english) "Open the corresponding 3D scene in the laboratory." else "İlgili 3B sahneyi laboratuvarda görüntüle.", color = p.muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.ArrowForward, null, tint = p.accent)
            }
        }
    }
}

private fun localizedCategoryName(name: String, english: Boolean): String = if (!english) name else when (name) {
    "Biyoloji" -> "Biology"; "Kimya" -> "Chemistry"; "Elementler" -> "Elements"; "Atomlar" -> "Atoms"
    "Fizik & Elektrik" -> "Physics & Electricity"; "Uzay" -> "Space"; "Matematik" -> "Mathematics"
    "Mikrobiyoloji" -> "Microbiology"; "Teknoloji" -> "Technology"; "3B Bilim Laboratuvarı" -> "3D Science Lab"; "Yer Bilimleri" -> "Earth Science"
    else -> name
}
private fun localizedCategoryDescription(index: Int, english: Boolean): String = if (!english) categoryDescriptions[index].second else listOf(
    "Human anatomy, cells, DNA, genetics and living systems", "Chemical bonds, reactions, solutions, acids and bases",
    "118 elements, an interactive periodic table and element profiles", "Atomic structure, orbitals, electron configuration, ions and isotopes",
    "Forces, motion, energy, waves, optics and electricity", "The Solar System, planets, stars, galaxies and cosmology",
    "Numbers, algebra, geometry, functions and probability", "Bacteria, viruses, fungi and microscopic life",
    "Electronics, sensors, processors and modern engineering", "Interactive scientific projections of atoms, molecules and biological structures",
    "Earth's interior, plate tectonics, rocks, minerals and geological processes"
).getOrElse(index) { categoryDescriptions[index].second }

@Composable
private fun SpectrumHomePage(
    p: Palette, english: Boolean, topics: List<ScienceTopicData>,
    onOpenCategory: (String) -> Unit, onExplore: () -> Unit,
    onLab: () -> Unit, onSearch: () -> Unit,
    onTopic: (String) -> Unit
) {
    val daily = if (topics.isEmpty()) null else topics.getOrNull(java.time.LocalDate.now().dayOfYear % topics.size)
    val fields = listOf(
        Triple("Matematik", Icons.Default.Calculate, "Fonksiyonlar, geometri ve analiz"),
        Triple("Fizik & Elektrik", Icons.Default.Bolt, "Kuvvet, enerji, optik ve devreler"),
        Triple("Kimya", Icons.Default.Science, "Atomlar, bağlar ve tepkimeler"),
        Triple("Biyoloji", Icons.Default.Eco, "Hücre, genetik ve insan sistemleri"),
        Triple("Uzay", Icons.Default.Public, "Gezegenler, yıldızlar ve kozmoloji"),
        Triple("Teknoloji", Icons.Default.Memory, "Elektronik ve dijital sistemler"),
        Triple("Yer Bilimleri", Icons.Default.Landscape, "Dünya’nın yapısı ve jeolojik süreçler")
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 15.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Text(if (english) "SPECTRUM SCIENCE" else "SPECTRUM · BİLİM PLATFORMU", color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
        Text(if (english) "Explore how the world works." else "Dünyanın nasıl işlediğini öğren.", color = p.text, fontSize = 25.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold)
        Panel(p, Modifier.fillMaxWidth().clickable { onSearch() }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = p.accent, modifier = Modifier.size(23.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (english) "Search all science" else "Bilimsel konularda ara", color = p.text, fontWeight = FontWeight.SemiBold)
                    Text(if (english) "Topics · elements · formulas · planets" else "Konular · elementler · formüller · gezegenler", color = p.muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = p.muted)
            }
        }
        if (daily != null) {
            Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(22.dp)).clickable { onTopic(daily.slug) }) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(com.elyionn.spektrum.R.drawable.space_hero),
                    contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071321).copy(alpha = .12f), Color(0xFF071321).copy(alpha = .96f)))))
                Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                    Text(if (english) "TODAY'S TOPIC · TURKISH SOURCE TEXT" else "GÜNÜN KONUSU", color = Color(0xFF70E5F4), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    Spacer(Modifier.height(5.dp))
                    Text(daily.title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text(daily.lead, color = Color(0xFFDCEAF6), fontSize = 12.sp, lineHeight = 18.sp, maxLines = 3)
                    Text(if (english) "Open detailed lesson →" else "Ayrıntılı konu anlatımını aç →", color = Color(0xFF70E5F4), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (english) "SCIENCE FIELDS" else "BİLİM DALLARI", color = p.text, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onExplore) { Text(if (english) "All fields" else "Tümünü gör", color = p.accent) }
        }
        fields.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                row.forEach { item ->
                    Panel(p, Modifier.weight(1f).heightIn(min = 106.dp).clickable { onOpenCategory(item.first) }) {
                        Icon(item.second, null, tint = p.accent, modifier = Modifier.size(23.dp))
                        Spacer(Modifier.height(7.dp))
                        Text(item.first, color = p.text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(item.third, color = p.muted, fontSize = 10.sp, lineHeight = 14.sp, maxLines = 2)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Panel(p, Modifier.fillMaxWidth().clickable { onLab() }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ViewInAr, null, tint = p.accent, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (english) "3D Laboratory" else "3B Bilim Laboratuvarı", color = p.text, fontWeight = FontWeight.Bold)
                    Text(if (english) "Interactive geometry and scientific models" else "Etkileşimli geometriler ve bilimsel modeller", color = p.muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.ArrowForward, null, tint = p.accent)
            }
        }
        Text("Elyionn · Spectrum 1.7.3", color = p.muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp))
    }
}

@Composable
private fun SpectrumExplorePage(p: Palette, english: Boolean, onOpen: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = categoryDescriptions.withIndex().filter {
        val title = localizedCategoryName(it.value.first, english)
        val description = localizedCategoryDescription(it.index, english)
        query.isBlank() || normalizeElementSearch("$title $description").contains(normalizeElementSearch(query.trim()))
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 15.dp, vertical = 7.dp)) {
        Text(if (english) "Explore science" else "Bilim dünyasını keşfet", color = p.text, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Text(if (english) "Choose a domain and follow your curiosity." else "Bir bilim dalı seç, merak ettiğin konuların derinliklerine in.", color = p.muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text(if (english) "Search fields and topics…" else "Bilim dallarında ve konularda ara…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(17.dp))
        Spacer(Modifier.height(12.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            filtered.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { indexed ->
                        val title = indexed.value.first
                        Panel(p, Modifier.weight(1f).heightIn(min = 142.dp).clickable { onOpen(title) }) {
                            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(p.accent.copy(alpha=.13f)), contentAlignment = Alignment.Center) { Icon(categoryIcon(title), null, tint = p.accent, modifier = Modifier.size(23.dp)) }
                            Spacer(Modifier.height(10.dp))
                            Text(localizedCategoryName(title, english), color = p.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(localizedCategoryDescription(indexed.index, english), color = p.muted, fontSize = 10.sp, lineHeight = 14.sp, maxLines = 3)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            if (filtered.isEmpty()) Text(if (english) "No matching field." else "Eşleşen bilim dalı bulunamadı.", color = p.muted)
        }
    }
}

@Composable
private fun SpectrumLabHubPage(
    p: Palette, english: Boolean,
    onOpenVisual: () -> Unit, onOpenPhysics: () -> Unit,
    onOpenChemistry: () -> Unit, onOpenBiology: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (english) "Interactive science workspace" else "Etkileşimli bilim çalışma alanı", color = p.text, fontWeight = FontWeight.Bold, fontSize = 23.sp)
        Text(if (english) "Visualize structures, explore models and experiment with scientific relationships." else "Yapıları görselleştir, modelleri incele ve bilimsel ilişkileri simülasyonlarla keşfet.", color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(23.dp)).background(Brush.linearGradient(listOf(Color(0xFF102B42), Color(0xFF123A4A), Color(0xFF20254A)))).clickable { onOpenVisual() }.padding(17.dp)) {
            Icon(Icons.Default.ViewInAr, null, tint = Color(0xFF63E3EF), modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(9.dp))
            Text(if (english) "3D Science Models" else "3B Bilim Modelleri", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(if (english) "Molecules · anatomy · atoms · structures" else "Moleküller · anatomi · atomlar · bilimsel yapılar", color = Color(0xFFD0E4F1), fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Text(if (english) "Open model gallery →" else "Model galerisini aç →", color = Color(0xFF69E7F0), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Text(if (english) "LABORATORY MODULES" else "LABORATUVAR BÖLÜMLERİ", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.4.sp)
        val modules = listOf(
            Triple(if (english) "Physics simulations" else "Fizik simülasyonları", if (english) "Motion, forces, waves and electricity" else "Hareket, kuvvet, dalgalar ve elektrik", Icons.Default.Bolt),
            Triple(if (english) "Chemistry workspace" else "Kimya laboratuvarı", if (english) "Molecules, bonds and periodic table" else "Moleküller, bağlar ve periyodik tablo", Icons.Default.Science),
            Triple(if (english) "Biology & anatomy" else "Biyoloji ve anatomi", if (english) "Cells, organs and body systems" else "Hücreler, organlar ve vücut sistemleri", Icons.Default.Favorite)
        )
        modules.forEachIndexed { index, module ->
            Panel(p, Modifier.fillMaxWidth().clickable { when(index) { 0 -> onOpenPhysics(); 1 -> onOpenChemistry(); else -> onOpenBiology() } }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(p.accent.copy(alpha=.13f)), contentAlignment = Alignment.Center) { Icon(module.third, null, tint = p.accent, modifier = Modifier.size(23.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(module.first, color = p.text, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text(module.second, color = p.muted, fontSize = 11.sp) }
                    Icon(Icons.Default.ChevronRight, null, tint = p.muted)
                }
            }
        }
        Panel(p) {
            Text(if (english) "Model accuracy" else "Model doğruluğu", color = p.accent, fontWeight = FontWeight.Bold)
            Text(if (english) "Interactive models are educational representations. Scientific scale, geometry and assumptions are identified where relevant." else "Etkileşimli modeller eğitim amaçlı temsillerdir. İlgili yerlerde bilimsel ölçek, geometri ve model varsayımları ayrıca belirtilir.", color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

private fun categoryIcon(name: String) = when (name) {
    "Biyoloji" -> Icons.Default.Favorite
    "Uzay" -> Icons.Default.Public
    "Elementler", "Kimya", "Atomlar" -> Icons.Default.Science
    "Matematik" -> Icons.Default.Calculate
    "Mikrobiyoloji" -> Icons.Default.Biotech
    "3B Bilim Laboratuvarı" -> Icons.Default.ViewInAr
    "Fizik & Elektrik" -> Icons.Default.Bolt
    "Teknoloji" -> Icons.Default.Memory
    "Yer Bilimleri" -> Icons.Default.Landscape
    else -> Icons.Default.Explore
}

@Composable
private fun CategoryDetail(p: Palette, category: String, english: Boolean, topics: List<ScienceTopicData>, onBack: () -> Unit, onElement: (String) -> Unit, onTopic: (String) -> Unit, onTechTopic: (String) -> Unit) {
    val ids = when (category) {
        "Biyoloji", "Mikrobiyoloji" -> setOf("biyoloji")
        "Kimya", "Atomlar", "Elementler" -> setOf("kimya")
        "Fizik & Elektrik" -> setOf("fizik")
        "Uzay" -> setOf("uzay")
        "Matematik" -> setOf("matematik")
        "Teknoloji" -> setOf("elektronik")
        "Yer Bilimleri" -> setOf("yer_bilimleri", "geology")
        else -> emptySet()
    }
    val matching = topics.filter { it.category in ids }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, if (english) "Back" else "Geri", tint = p.accent) }
            Column(Modifier.weight(1f)) {
                Text(if (english) "SCIENCE FIELD" else "BİLİM DALI", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 1.5.sp)
                Text(localizedCategoryName(category, english), color = p.text, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            }
            Surface(color = p.accent.copy(alpha = .13f), shape = RoundedCornerShape(10.dp)) {
                Text("${matching.size}", color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp))
            }
        }
        if (matching.isNotEmpty()) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(p.panel, p.accent.copy(alpha = .17f), p.bg))).padding(17.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Icon(categoryIcon(category), null, tint = p.accent, modifier = Modifier.size(30.dp))
                        Text(localizedCategoryName(category, english), color = p.text, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                        Text(categoryDescriptions.firstOrNull { it.first == category }?.second ?: (if (english) "Explore concepts, models and scientific applications." else "Kavramları, modelleri ve bilimsel uygulamaları keşfet."), color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
                        Text(if (english) "LESSON COLLECTION" else "KONU KOLEKSİYONU", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 1.4.sp)
                    }
                }
                matching.forEachIndexed { index, topic ->
                    Panel(p, Modifier.fillMaxWidth().clickable { onTopic(topic.slug) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(p.accent.copy(alpha = .13f)), contentAlignment = Alignment.Center) {
                                Text("${(index + 1).toString().padStart(2, '0')}", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f)) {
                                Text(topic.title, color = p.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("${topic.how.size} ${if (english) "learning steps" else "öğrenme adımı"} · ${topic.facts.size} ${if (english) "key data" else "temel veri"}", color = p.muted, fontSize = 10.sp)
                            }
                            if (topic.isNew) Surface(color = p.accent.copy(alpha = .14f), shape = RoundedCornerShape(6.dp)) { Text(if (english) "NEW" else "YENİ", color = p.accent, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) }
                            Icon(Icons.Default.ChevronRight, null, tint = p.accent)
                        }
                        Text(topic.summary, color = p.muted, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 9.dp))
                        Spacer(Modifier.height(7.dp))
                        Box(Modifier.fillMaxWidth().height(3.dp).clip(CircleShape).background(p.muted.copy(alpha = .14f))) {
                            Box(Modifier.fillMaxWidth(.18f).fillMaxHeight().background(p.accent))
                        }
                    }
                }
            }
        } else {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                when (category) {
                    "Elementler" -> ElementsPage(p, english, onElement)
                    "Atomlar" -> AtomLabPage(p, english)
                    "Teknoloji" -> TechnologyKnowledgePage(p, english, onOpen = onTechTopic)
                    "3B Bilim Laboratuvarı" -> VisualLabPage(p, english)
                    "Biyoloji" -> BiologyPage(p, english)
                    "Uzay" -> SpacePage(p, english)
                    "Kimya" -> ChemistryPage(p, english)
                    "Matematik" -> MathematicsPage(p, english)
                    "Fizik & Elektrik" -> PhysicsKnowledgePage(p, english)
                    else -> Text(if (english) "No lessons are available in this field yet." else "Bu bilim dalında henüz ders bulunmuyor.", color = p.muted, modifier = Modifier.padding(20.dp))
                }
            }
        }
    }
}

private fun categoryVisualIcon(category: String) = when (category) {
    "biyoloji" -> Icons.Default.Biotech
    "fizik" -> Icons.Default.Bolt
    "kimya" -> Icons.Default.Science
    "matematik" -> Icons.Default.Functions
    "uzay" -> Icons.Default.Public
    "elektronik" -> Icons.Default.Memory
    "yer_bilimleri" -> Icons.Default.Landscape
    else -> Icons.Default.AutoAwesome
}

@Composable
private fun LearningTabs(p: Palette, selected: String, english: Boolean, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(p.panel, RoundedCornerShape(14.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        listOf(if (english) "Overview" else "Özet", if (english) "Structure" else "Yapı", if (english) "How it works" else "İşleyiş").forEach { tab ->
            Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if(selected==tab) p.accent else Color.Transparent).clickable { onSelect(tab) }.padding(vertical=10.dp), contentAlignment=Alignment.Center) {
                Text(tab, color=if(selected==tab) Color(0xFF071321) else p.text, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
            }
        }
    }
}

@Composable
private fun BiologyPage(p: Palette, english: Boolean) {
    val systems = if (english) listOf(
        "Nervous system" to "The brain, spinal cord and nerves process sensory information, coordinate movement and regulate organ activity.",
        "Circulatory system" to "The heart, blood and blood vessels transport oxygen, nutrients, hormones and waste products. Capillaries enable exchange with tissues.",
        "Respiratory system" to "Air reaches the alveoli through the airways. Oxygen diffuses into the blood while carbon dioxide moves into the alveolar air. The diaphragm is the main breathing muscle.",
        "Digestive system" to "Digestion begins in the mouth and continues through the stomach and intestines. Most nutrient absorption occurs in the small intestine.",
        "Musculoskeletal system" to "Bones support and protect the body, joints allow movement, and skeletal muscles generate force. Bone marrow produces blood cells.",
        "Urinary system" to "Nephrons in the kidneys filter blood and selectively reabsorb useful substances. Urine travels through the ureters to the bladder.",
        "Endocrine system" to "Hormones regulate growth, metabolism, stress responses and homeostasis. The pituitary, thyroid, pancreas and adrenal glands are key components.",
        "Immune and lymphatic systems" to "Skin and mucous membranes form an early defence. Innate and adaptive immune responses work together to protect the body.",
        "Reproductive system" to "Reproductive organs produce gametes and support reproduction. Hormones regulate development and function.",
        "Integumentary and sensory systems" to "The skin provides a barrier, helps regulate temperature and contains sensory receptors. It includes the epidermis and dermis."
    ) else listOf(
        "Sinir sistemi" to "Beyin, omurilik ve sinirlerden oluşur. Duyuları işler, hareketleri koordine eder ve organların faaliyetlerini düzenler.",
        "Dolaşım sistemi" to "Kalp, kan ve damarlardan oluşur. Atardamarlar kanı kalpten uzaklaştırır; toplardamarlar geri taşır; kılcal damarlar madde alışverişini sağlar.",
        "Solunum sistemi" to "Hava, solunum yollarından alveollere ulaşır. Alveollerde oksijen kana, karbondioksit ise alveol havasına geçer. Diyafram temel solunum kasıdır.",
        "Sindirim sistemi" to "Ağızda başlayan sindirim mide ve bağırsaklarda sürer. İnce bağırsak besinlerin büyük bölümünü emer; karaciğer safra üretir, pankreas enzim salgılar.",
        "Kas-iskelet sistemi" to "Kemikler destek ve koruma sağlar; eklemler hareket açıklığını belirler; iskelet kasları kasılarak kuvvet üretir. Kemik iliği kan hücrelerinin üretiminde rol oynar.",
        "Üriner sistem" to "Böbrek nefronları kanı süzer; gerekli maddeler geri emilir. İdrar üreterlerle mesaneye taşınır ve üretradan atılır.",
        "Endokrin sistem" to "Hormonlar büyüme, metabolizma, stres yanıtı ve iç dengeyi düzenler. Hipofiz, tiroit, pankreas ve böbreküstü bezleri önemli bileşenlerdir.",
        "Bağışıklık ve lenf sistemi" to "Deri ve mukozalar ilk savunma hattıdır. Doğuştan gelen ve kazanılmış bağışıklık sistemleri birlikte çalışır.",
        "Üreme sistemi" to "Üreme organları gamet üretimi ve üreme işlevlerinde rol oynar. Hormonlar sistemin gelişimini ve işleyişini düzenler.",
        "Deri ve duyu sistemi" to "Deri bariyer, sıcaklık düzenleme ve duyu işlevleri görür. Epidermis, dermis ve deri altı dokudan oluşur."
    )
    var expanded by rememberSaveable { mutableStateOf(systems.first().first) }
    var tab by rememberSaveable { mutableStateOf(if (english) "Overview" else "Özet") }
    val overviewTab = if (english) "Overview" else "Özet"
    val structureTab = if (english) "Structure" else "Yapı"
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text(if (english) "HUMAN BODY SYSTEMS" else "İNSAN VÜCUDU SİSTEMLERİ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp, letterSpacing=2.sp)
            Text(if (english) "Explore the body as an integrated system" else "Vücudu bütünleşik bir sistem olarak incele", color=p.text, fontWeight=FontWeight.Bold, fontSize=21.sp)
            Text(if (english) "Organ-system reference, structure and physiology." else "Organ sistemleri, anatomik yapı ve fizyoloji.", color=p.muted, lineHeight=19.sp, fontSize=12.sp)
        }
        LearningTabs(p, tab, english) { tab=it }
        when(tab) {
            overviewTab -> Panel(p) {
                Text(if (english) "The human organism" else "İnsan organizması", color=p.accent, fontWeight=FontWeight.Bold)
                Text(if (english) "The human body is an integrated biological system in which cells, tissues, organs and organ systems work together. Homeostasis helps regulate temperature, fluids, ions and energy." else "İnsan vücudu; hücre, doku, organ ve organ sistemlerinin birlikte çalıştığı bütünleşik bir biyolojik sistemdir. İç denge (homeostaz), sıcaklık, sıvı, iyon ve enerji dengesinin düzenlenmesiyle korunur.", color=p.text, lineHeight=21.sp)
            }
            structureTab -> Panel(p) {
                Text(if (english) "Anatomical organization" else "Anatomik organizasyon", color=p.accent, fontWeight=FontWeight.Bold)
                Text(if (english) "Cells form tissues, tissues form organs, and organs form systems. The four basic tissue types are epithelial, connective, muscle and nervous tissue." else "Hücreler benzer görevli dokuları; dokular organları; organlar da sistemleri oluşturur. Temel doku tipleri epitel, bağ, kas ve sinir dokusudur.", color=p.text, lineHeight=21.sp)
            }
            else -> Panel(p) {
                Text(if (english) "Physiological function" else "Fizyolojik işleyiş", color=p.accent, fontWeight=FontWeight.Bold)
                Text(if (english) "Organ systems coordinate through neural, hormonal and local feedback. For example, the respiratory and circulatory systems work together to deliver oxygen and remove carbon dioxide." else "Organ sistemleri sinirsel, hormonal ve yerel geri bildirim mekanizmalarıyla eşgüdüm sağlar. Örneğin solunum ve dolaşım sistemleri birlikte çalışarak oksijeni dokulara taşır ve karbondioksiti uzaklaştırır.", color=p.text, lineHeight=21.sp)
            }
        }
        Panel(p) {
            Text(if (english) "ANATOMY MODEL STATUS" else "ANATOMİ MODELİ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            Text(if (english) "The previous schematic body view has been removed. A realistic, clinically reviewed 3D human model requires a separately licensed anatomical asset; no inaccurate placeholder is shown." else "Önceki şematik vücut görünümü kaldırıldı. Gerçekçi ve anatomik olarak incelenmiş bir 3B insan modeli için ayrıca lisanslı bir anatomi varlığı gerekiyor; bu nedenle yanlış bir model gösterilmiyor.", color=p.text, lineHeight=19.sp, fontSize=12.sp)
        }
        Panel(p) {
            Text(if (english) "DNA DOUBLE HELIX · ANIMATED PROJECTION" else "DNA ÇİFT SARMALI · ANİMASYONLU İZDÜŞÜM", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            DnaHelixView(p, english)
            Text(if (english) "A pairs with T; G pairs with C. The two strands run in opposite directions." else "A, T ile; G, C ile eşleşir. İki DNA zinciri zıt yönlerde uzanır.", color=p.muted, fontSize=11.sp)
        }
        Text(if (english) "Body systems" else "Vücut sistemleri", color=p.text, fontWeight=FontWeight.Bold, fontSize=18.sp)
        systems.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded=if(expanded==title) "" else title }, verticalAlignment=Alignment.CenterVertically) {
                    Text(title, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                    Icon(if(expanded==title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.accent)
                }
                if(expanded==title) {
                    Spacer(Modifier.height(8.dp))
                    Text(if (english) "Overview" else "Özet", color=p.accent, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
                    Text(body, color=p.text, lineHeight=20.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(if (english) "Structure" else "Yapı", color=p.accent, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
                    Text(if (english) "The system includes specialized organs and tissues connected through blood vessels, nerves or ducts, depending on its function." else "Bu sistemin temel anatomik bileşenleri organlar, dokular ve bunları birbirine bağlayan damar veya sinir ağlarıdır.", color=p.muted, lineHeight=19.sp, fontSize=12.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(if (english) "Function" else "İşleyiş", color=p.accent, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
                    Text(if (english) "The system exchanges matter, energy or information with other systems and contributes to the body's internal balance." else "Sistem, diğer organ sistemleriyle madde, enerji veya bilgi alışverişi yaparak organizmanın iç dengesine katkıda bulunur.", color=p.muted, lineHeight=19.sp, fontSize=12.sp)
                }
            }
        }
    }
}


@Composable
private fun EarthSciencePage(p: Palette, english: Boolean) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text(if (english) "EARTH SYSTEMS" else "DÜNYA SİSTEMLERİ", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.3.sp)
            Text(if (english) "A dynamic planet" else "Dinamik bir gezegen", color = p.text, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text(if (english) "Geology connects the planet's interior, rocks, water, atmosphere and the slow movement of tectonic plates." else "Jeoloji; gezegenin iç yapısını, kayaçları, suyu, atmosferi ve tektonik plakaların yavaş hareketini birlikte inceler.", color = p.muted, fontSize = 13.sp, lineHeight = 20.sp)
        }
        Panel(p) {
            Text(if (english) "EARTH'S LAYERS" else "DÜNYA’NIN KATMANLARI", color = p.accent, fontWeight = FontWeight.Bold)
            listOf("Kabuk" to "Dıştaki ince, katı kayaç katmanı.", "Manto" to "Büyük ölçüde katı; jeolojik zamanlarda yavaşça akabilen kayaçlar.", "Dış çekirdek" to "Sıvı, metalce zengin katman.", "İç çekirdek" to "Yüksek basınç altında katı metalik bölüm.").forEach { (title, desc) ->
                Text(title, color = p.text, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
                Text(desc, color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
        Panel(p) {
            Text(if (english) "PLATE BOUNDARIES" else "PLAKA SINIRLARI", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Ayrılan: plakalar uzaklaşır ve yeni kabuk oluşabilir.\nYakınlaşan: dalma-batma veya kıtasal çarpışma görülebilir.\nDönüşüm: plakalar yanal kayar; faylarda deprem oluşabilir.", color = p.text, fontSize = 13.sp, lineHeight = 21.sp)
        }
        Panel(p) {
            Text(if (english) "ROCK CYCLE" else "KAYAÇ DÖNGÜSÜ", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Magmanın soğuması magmatik kayaçları; çökelme ve taşlaşma tortul kayaçları; erimeden gerçekleşen ısı ve basınç etkisi başkalaşım kayaçlarını oluşturabilir. Süreç tek yönlü değildir.", color = p.text, fontSize = 13.sp, lineHeight = 21.sp)
        }
        Text("İçerik, USGS, National Geographic, Smithsonian ve National Park Service eğitim kaynaklarıyla desteklenmiştir.", color = p.muted, fontSize = 10.sp)
    }
}

@Composable
private fun DnaHelixView(p: Palette, english: Boolean) {
    // Static by default: avoid a permanent Compose redraw loop on an informational diagram.
    val phase = 0f
    androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(210.dp).background(p.bg, RoundedCornerShape(12.dp))) {
        val cx = size.width / 2f
        val top = 16.dp.toPx()
        val usable = size.height - 32.dp.toPx()
        val amplitude = size.width * .23f
        val steps = 28
        val left = androidx.compose.ui.graphics.Path()
        val right = androidx.compose.ui.graphics.Path()
        val rungs = ArrayList<Pair<androidx.compose.ui.geometry.Offset, androidx.compose.ui.geometry.Offset>>()
        for (i in 0..steps) {
            val t = i.toFloat() / steps
            val angle = t * (Math.PI * 4).toFloat() + phase
            val wave = kotlin.math.sin(angle.toDouble()).toFloat()
            val x1 = cx + wave * amplitude
            val x2 = cx - wave * amplitude
            val y = top + t * usable
            if (i == 0) { left.moveTo(x1, y); right.moveTo(x2, y) } else { left.lineTo(x1, y); right.lineTo(x2, y) }
            if (i % 2 == 0) rungs.add(androidx.compose.ui.geometry.Offset(x1,y) to androidx.compose.ui.geometry.Offset(x2,y))
        }
        drawPath(left, Color(0xFF54C6F0), style=Stroke(3.dp.toPx()))
        drawPath(right, Color(0xFFE18ACB), style=Stroke(3.dp.toPx()))
        rungs.forEachIndexed { index, pair ->
            val color = if (index % 2 == 0) Color(0xFFFFC857) else Color(0xFF7AD7A5)
            drawLine(color.copy(alpha=.8f), pair.first, pair.second, 2.dp.toPx())
            drawCircle(color, 3.dp.toPx(), pair.first)
            drawCircle(color, 3.dp.toPx(), pair.second)
        }

    }
}

private data class Planet(val name: String, val type: String, val diameter: String, val year: String, val moons: String, val facts: String, val mission: String)
private val planets = listOf(
    Planet("Merkür","Karasal","4.879 km","88 Dünya günü","0","Güneş'e en yakın gezegendir. Çok ince bir dış gaz örtüsüne sahiptir; gündüz ve gece sıcaklık farkı çok büyüktür. Büyük metalik çekirdeği gezegenin iç yapısında önemli yer tutar.","MESSENGER görevi yüzeyini ve manyetik alanını ayrıntılı haritaladı. BepiColombo Merkür'e yolculuğunu sürdürüyor."),
    Planet("Venüs","Karasal","12.104 km","225 Dünya günü","0","Yoğun karbondioksit atmosferi ve güçlü sera etkisi nedeniyle yüzeyi çok sıcaktır. Sülfürik asit bulutları bulunur. Yavaş ve ters yönlü dönüşüyle dikkat çeker.","Magellan radar haritalaması yaptı; Akatsuki atmosfer dinamiklerini inceledi."),
    Planet("Dünya","Karasal","12.742 km","365,25 gün","1","Yüzeyinde kalıcı sıvı su ve bildiğimiz yaşam bulunur. Atmosferi çoğunlukla azot ve oksijenden oluşur. Manyetik alanı Güneş rüzgârıyla etkileşir.","Çok sayıda uydu atmosferi, okyanusları, iklimi ve yüzeyi izler."),
    Planet("Mars","Karasal","6.779 km","687 Dünya günü","2","Demir oksit yüzeyine kızıl renk verir. Olympus Mons dev bir volkandır; Valles Marineris büyük bir kanyon sistemidir. Eski nehir yatakları ve mineraller geçmişte sıvı su bulunduğunu gösterir.","Curiosity ve Perseverance yüzeyi inceliyor; yörünge araçları haritalama yapıyor."),
    Planet("Jüpiter","Gaz devi","139.820 km","11,86 Dünya yılı","Çok sayıda","En büyük gezegendir; çoğunlukla hidrojen ve helyumdan oluşur. Büyük Kırmızı Leke dev bir fırtınadır. Europa'nın buz altında okyanusu olabileceğine dair güçlü kanıtlar vardır.","Juno gezegenin iç yapısını ve manyetik alanını inceliyor; Europa Clipper Europa'yı araştıracak."),
    Planet("Satürn","Gaz devi","116.460 km","29,4 Dünya yılı","Çok sayıda","Buz ve kaya parçacıklarından oluşan halkalarıyla tanınır. Titan'da metan ve etan gölleri; Enceladus'ta buz altı okyanusuna işaret eden püskürmeler vardır.","Cassini-Huygens görevi Satürn, halkaları ve uyduları hakkında büyük miktarda veri topladı."),
    Planet("Uranüs","Buz devi","50.724 km","84 Dünya yılı","Çok sayıda","Eksen eğikliği yaklaşık 98 derecedir; adeta yan yatmış şekilde döner. Atmosferindeki metan mavi-yeşil görünmesine katkı verir.","Yakından ziyaret eden tek araç Voyager 2'dir. Gelecekte yeni bir yörünge görevi önerilmektedir."),
    Planet("Neptün","Buz devi","49.244 km","165 Dünya yılı","Çok sayıda","Güneş'ten uzaklığı nedeniyle çok az enerji alır. Atmosferinde çok hızlı rüzgârlar ve değişken koyu fırtınalar görülür.","Voyager 2 1989'da yakınından geçti; günümüzde teleskoplarla izlenir.")
)

@Composable
private fun SpacePage(p: Palette, english: Boolean) {
    var expanded by rememberSaveable { mutableStateOf("Dünya") }
    var spaceTab by rememberSaveable { mutableStateOf(if (english) "Overview" else "Özet") }
    val topics = listOf(
        "Güneş'in yapısı" to "Güneş, kütlesinin büyük bölümünü hidrojen ve helyumun oluşturduğu bir yıldızdır. Çekirdeğinde proton-proton zinciriyle füzyon gerçekleşir.",
        "Yörüngeler ve kütleçekim" to "Gezegenler, Güneş'in kütleçekim alanında eliptik yörüngelerde hareket eder. Kepler yasaları yörünge geometrisini ve dolanım sürelerini açıklar.",
        "Ay ve gelgitler" to "Ay ve Güneş'in kütleçekimi okyanus gelgitlerini oluşturur. Dünya-Ay sistemi ortak kütle merkezi çevresinde hareket eder.",
        "Asteroitler ve kuyruklu yıldızlar" to "Asteroitler çoğunlukla kayaç ve metal içerir. Kuyruklu yıldızlarda uçucu buzlar bulunur; Güneş'e yaklaşınca gaz ve toz salımı artar.",
        "Cüce gezegenler" to "Cüce gezegenler Güneş çevresinde dolanır, yaklaşık küresel şekildedir ancak yörünge çevresini diğer cisimlerden temizlememiştir.",
        "Ötegezegenler" to "Ötegezegenler başka yıldızların çevresinde dolanır. Geçiş yöntemi yıldız parlaklığındaki düzenli azalmayı, dikey hız yöntemi yıldızın tayfsal salınımını ölçer.",
        "Yıldızların yaşam döngüsü" to "Yıldızların evrimi başlangıç kütlesine bağlıdır. Güneş benzeri yıldızlar sonunda beyaz cüceye dönüşür; daha büyük kütleli yıldızlarda farklı son evreler görülür.",
        "Galaksiler" to "Galaksiler yıldız, gaz, toz ve karanlık madde içeren kütleçekimsel sistemlerdir. Samanyolu çubuklu sarmal galaksidir."
    )
    val englishTopics = listOf(
        "The Sun's structure" to "The Sun is a star made mostly of hydrogen and helium. Nuclear fusion through the proton-proton chain occurs in its core.",
        "Orbits and gravity" to "Planets move in elliptical orbits within the Sun's gravitational field. Kepler's laws describe orbital geometry and periods.",
        "The Moon and tides" to "The gravitational pull of the Moon and Sun produces ocean tides. The Earth-Moon system moves around a shared centre of mass.",
        "Asteroids and comets" to "Asteroids are mostly rocky or metallic. Comets contain volatile ices and release gas and dust as they approach the Sun.",
        "Dwarf planets" to "Dwarf planets orbit the Sun and are nearly round, but have not cleared their orbital neighbourhood of other objects.",
        "Exoplanets" to "Exoplanets orbit stars beyond the Sun. The transit method measures dips in stellar brightness; radial-velocity measurements detect stellar motion.",
        "Stellar life cycles" to "A star's evolution depends on its initial mass. Sun-like stars end as white dwarfs, while more massive stars have different final stages.",
        "Galaxies" to "Galaxies are gravitational systems of stars, gas, dust and dark matter. The Milky Way is a barred spiral galaxy."
    )
    val planetFactsEnglish = mapOf(
        "Merkür" to "Mercury is the closest planet to the Sun. It has an extremely thin exosphere and large day-night temperature differences. Its large metallic core is a major part of its internal structure.",
        "Venüs" to "Venus has a dense carbon-dioxide atmosphere and an intense greenhouse effect, making its surface extremely hot. Sulfuric-acid clouds and slow retrograde rotation are notable features.",
        "Dünya" to "Earth has stable surface liquid water and the only known life. Its atmosphere is mostly nitrogen and oxygen, and its magnetic field interacts with the solar wind.",
        "Mars" to "Iron oxides give Mars its red colour. Olympus Mons is a giant volcano and Valles Marineris is a vast canyon system. Ancient channels and minerals indicate past liquid water.",
        "Jüpiter" to "Jupiter is the largest planet and consists mainly of hydrogen and helium. The Great Red Spot is a giant storm. Europa may host a subsurface ocean.",
        "Satürn" to "Saturn is known for rings made of ice and rocky particles. Titan has methane and ethane lakes; Enceladus has jets associated with a subsurface ocean.",
        "Uranüs" to "Uranus has an axial tilt of about 98 degrees and rotates almost on its side. Atmospheric methane contributes to its blue-green appearance.",
        "Neptün" to "Neptune receives little solar energy because of its distance. Its atmosphere has very fast winds and changing dark storms."
    )
    val planetMissionsEnglish = mapOf(
        "Merkür" to "MESSENGER mapped its surface and magnetic field. BepiColombo is travelling to the planet.",
        "Venüs" to "Magellan mapped the surface with radar; Akatsuki studied atmospheric dynamics.",
        "Dünya" to "Many satellites monitor the atmosphere, oceans, climate and surface.",
        "Mars" to "Curiosity and Perseverance explore the surface; orbiters map the planet.",
        "Jüpiter" to "Juno studies the interior and magnetic field; Europa Clipper is investigating Europa.",
        "Satürn" to "Cassini-Huygens collected extensive data about Saturn, its rings and moons.",
        "Uranüs" to "Voyager 2 is the only spacecraft to visit Uranus; a future orbiter has been proposed.",
        "Neptün" to "Voyager 2 flew by in 1989; telescopes continue to observe Neptune."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Panel(p) { Text(if (english) "The Solar System" else "Güneş Sistemi", color=p.accent, fontWeight=FontWeight.Bold, fontSize=22.sp); Text(if (english) "A gravitational system containing the Sun, eight planets, moons, dwarf planets and small bodies. Model scales are normalized for clarity." else "Güneş, sekiz gezegen, uydular, cüce gezegenler ve küçük cisimlerden oluşan kütleçekimsel sistem. Model ölçekleri anlaşılır görünüm için normalize edilmiştir.", color=p.muted, lineHeight=19.sp, fontSize=12.sp) }
        Panel(p) { Text(if (english) "Solar-system projection" else "Güneş Sistemi izdüşümü", color=p.accent, fontWeight=FontWeight.Bold); Text(if (english) "Drag to rotate · use + / − to zoom · tap a planet to select it." else "Sürükle: sistemi döndür · + / −: yakınlaş · bir gezegene dokun: bilgi seç.", color=p.muted, fontSize=11.sp); SolarSystem3DView(english) }
        Text(if (english) "Planets" else "Gezegenler", color=p.text, fontWeight=FontWeight.Bold, fontSize=18.sp)
        planets.forEach { planet ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded=if(expanded==planet.name) "" else planet.name }, verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(planet.name, color=p.accent, fontWeight=FontWeight.Bold, fontSize=16.sp); Text(if (english) "${when(planet.type) { "Karasal" -> "Terrestrial"; "Gaz devi" -> "Gas giant"; "Buz devi" -> "Ice giant"; else -> planet.type }} · orbital period ${planet.year}" else "${planet.type} · yörünge dönemi ${planet.year}", color=p.muted, fontSize=11.sp) }
                    Icon(if(expanded==planet.name) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.accent)
                }
                if(expanded==planet.name) { Spacer(Modifier.height(7.dp)); Text(if (english) "Diameter: ${planet.diameter} · Known moons: ${planet.moons}" else "Çap: ${planet.diameter} · Bilinen uydu: ${planet.moons}", color=p.text, fontWeight=FontWeight.SemiBold, fontSize=12.sp); Text(if (english) planetFactsEnglish[planet.name] ?: planet.facts else planet.facts, color=p.text, lineHeight=20.sp); Text(if (english) "Exploration missions: ${when(planet.name) { "Merkür" -> "MESSENGER mapped its surface and magnetic field; BepiColombo is en route."; "Venüs" -> "Magellan mapped the surface with radar; Akatsuki studied atmospheric dynamics."; "Dünya" -> "Many satellites monitor the atmosphere, oceans, climate and surface."; "Mars" -> "Curiosity and Perseverance explore the surface; orbiters map the planet."; "Jüpiter" -> "Juno studies the interior and magnetic field; Europa Clipper is investigating Europa."; "Satürn" -> "Cassini-Huygens collected extensive data on Saturn, its rings and moons."; "Uranüs" -> "Voyager 2 is the only spacecraft to have visited; a future orbiter has been proposed."; else -> "Voyager 2 flew by in 1989; telescopes continue to observe Neptune." }}" else "Keşif görevleri: ${planet.mission}", color=p.muted, fontSize=11.sp, lineHeight=18.sp) }
            }
        }
        LearningTabs(p, spaceTab, english) { spaceTab=it }
        when(spaceTab) {
            if (english) "Overview" else "Özet" -> Panel(p) { Text(if (english) "Solar System overview" else "Güneş Sistemi'nin genel görünümü", color=p.accent, fontWeight=FontWeight.Bold); Text(if (english) "The Solar System contains planets, moons and small bodies bound by the Sun's gravity. Most planetary orbits lie in roughly the same plane and direction." else "Güneş Sistemi, merkezindeki Güneş'in kütleçekimiyle bağlı gezegenleri, uyduları ve küçük cisimleri içerir. Gezegenlerin yörüngeleri yaklaşık aynı düzlemde ve aynı yönde bulunur.", color=p.text, lineHeight=20.sp) }
            if (english) "Structure" else "Yapı" -> Panel(p) { Text(if (english) "System components" else "Sistemin bileşenleri", color=p.accent, fontWeight=FontWeight.Bold); Text(if (english) "The Sun is at the centre. Rocky planets orbit in the inner system; gas and ice giants occupy the outer system. The asteroid belt, Kuiper Belt and Oort Cloud contain smaller bodies." else "Sistemin merkezinde Güneş yer alır. İçte kayasal gezegenler, dışta gaz ve buz devleri bulunur. Asteroit kuşağı, Kuiper Kuşağı ve Oort Bulutu küçük cisim topluluklarıdır.", color=p.text, lineHeight=20.sp) }
            else -> Panel(p) { Text(if (english) "Orbital motion" else "Yörünge hareketi", color=p.accent, fontWeight=FontWeight.Bold); Text(if (english) "Planets travel in elliptical orbits under gravity. They move faster near the Sun and slower when farther away, as described by Kepler's laws." else "Gezegenler kütleçekim etkisiyle eliptik yörüngelerde dolanır. Güneş'e yaklaştıklarında yörünge hızları artar; uzaklaştıklarında azalır. Bu hareket Kepler yasalarıyla açıklanır.", color=p.text, lineHeight=20.sp) }
        }
        Text(if (english) "Space and astrophysics" else "Uzay ve astrofizik", color=p.accent, fontWeight=FontWeight.Bold, fontSize=18.sp)
        (if (english) englishTopics else topics).forEach { (title, body) -> Panel(p) { Text(title, color=p.accent, fontWeight=FontWeight.Bold); Text(body, color=p.text, lineHeight=20.sp) } }
        Panel(p) { Text(if (english) "Dwarf planets and small bodies" else "Cüce gezegenler ve küçük cisimler", color=p.accent, fontWeight=FontWeight.Bold); Text(if (english) "Pluto, Ceres, Eris, Haumea and Makemake are dwarf planets. The main asteroid belt lies between Mars and Jupiter; the Kuiper Belt lies beyond Neptune." else "Plüton, Ceres, Eris, Haumea ve Makemake cüce gezegenler arasındadır. Ana asteroit kuşağı Mars ile Jüpiter arasında; Kuiper Kuşağı Neptün ötesindedir.", color=p.text, lineHeight=20.sp) }
    }
}

@Composable
private fun SolarSystem3DView(english: Boolean) {
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>
    *{box-sizing:border-box}body{margin:0;background:#06111f;color:#eaf4ff;font:12px Arial}.tools{display:flex;gap:7px;padding:8px;align-items:center}.tools button{background:#142b42;color:#eaf4ff;border:1px solid #426b89;border-radius:9px;padding:7px 12px}.stage{height:285px;touch-action:none}canvas{width:100%;height:100%;display:block}.caption{padding:0 10px 8px;color:#a9c3dc;font-size:11px;min-height:18px}
    </style></head><body><div class='tools'><button id='minus'>−</button><button id='plus'>+</button><button id='reset'>${if (english) "Reset" else "Sıfırla"}</button><span>${if (english) "Interactive projection" else "Etkileşimli izdüşüm"}</span></div><div class='stage' id='stage'><canvas id='c'></canvas></div><div class='caption' id='caption'>${if (english) "Tap a planet to select it." else "Bir gezegene dokunarak seç."}</div><script>
    (()=>{const stage=document.getElementById('stage'),c=document.getElementById('c'),ctx=c.getContext('2d');let yaw=-.55,pitch=.38,zoom=1,drag=false,px=0,py=0,selected=-1,anim=0,last=0,raf=0;
    const bodies=[['${if (english) "Mercury" else "Merkür"}',0.42,0.12,'#9a9b9e'],['${if (english) "Venus" else "Venüs"}',0.72,0.19,'#d9a66b'],['${if (english) "Earth" else "Dünya"}',1.02,0.20,'#4c9de8'],['Mars',1.36,0.16,'#d56b4d'],['${if (english) "Jupiter" else "Jüpiter"}',2.05,0.43,'#d7b58b'],['${if (english) "Saturn" else "Satürn"}',2.75,0.36,'#d8c18b'],['${if (english) "Uranus" else "Uranüs"}',3.43,0.28,'#83d5d4'],['${if (english) "Neptune" else "Neptün"}',4.05,0.27,'#477de0']];
    const stars=Array.from({length:90},(_,i)=>[Math.random(),Math.random(),Math.random()*1.5]);function resize(){const d=Math.min(devicePixelRatio||1,1.5),w=stage.clientWidth,h=stage.clientHeight;c.width=Math.floor(w*d);c.height=Math.floor(h*d);ctx.setTransform(d,0,0,d,0,0);draw()}new ResizeObserver(resize).observe(stage);
    function project(x,y,z){const cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch),xx=x*cy-z*sy,zz=x*sy+z*cy,yy=y*cp-zz*sp,depth=y*sp+zz*cp,scale=Math.min(stage.clientWidth*.44,stage.clientHeight*.80)/5.5*zoom/(1+depth*.035);return [stage.clientWidth/2+xx*scale,stage.clientHeight/2+yy*scale,depth,scale]}
    function sphere(x,y,z,r,col,ring=false){const q=project(x,y,z),rad=Math.max(2,r*q[3]);const g=ctx.createRadialGradient(q[0]-rad*.35,q[1]-rad*.4,1,q[0],q[1],rad*1.2);g.addColorStop(0,'#ffffff');g.addColorStop(.18,col);g.addColorStop(1,'#07101b');ctx.fillStyle=g;ctx.beginPath();ctx.arc(q[0],q[1],rad,0,Math.PI*2);ctx.fill();if(ring){ctx.save();ctx.translate(q[0],q[1]);ctx.rotate(-.25);ctx.strokeStyle='#cbbd9a';ctx.lineWidth=Math.max(2,rad*.22);ctx.beginPath();ctx.ellipse(0,0,rad*1.65,rad*.55,0,0,Math.PI*2);ctx.stroke();ctx.restore()}return q}
    function draw(){const w=stage.clientWidth,h=stage.clientHeight;if(!w||!h)return;ctx.clearRect(0,0,w,h);const bg=ctx.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#07172a');bg.addColorStop(1,'#030914');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);stars.forEach(s=>{ctx.fillStyle='rgba(200,225,255,'+(0.2+s[2]*.25)+')';ctx.fillRect(s[0]*w,s[1]*h,1+s[2]*.4,1+s[2]*.4)});
    const center=project(0,0,0);sphere(0,0,0,.56,'#ffb33d');ctx.save();ctx.shadowColor='#ffb33d';ctx.shadowBlur=22;ctx.strokeStyle='rgba(255,183,73,.25)';ctx.lineWidth=2;ctx.beginPath();ctx.arc(center[0],center[1],center[3]*.9,0,Math.PI*2);ctx.stroke();ctx.restore();
    bodies.forEach((b,i)=>{ctx.strokeStyle='rgba(113,167,212,.24)';ctx.lineWidth=1;ctx.beginPath();for(let j=0;j<=100;j++){const a=j/100*Math.PI*2,q=project(Math.cos(a)*b[1]*1.35,0,Math.sin(a)*b[1]*1.35);if(j===0)ctx.moveTo(q[0],q[1]);else ctx.lineTo(q[0],q[1])}ctx.stroke();const a=anim*(.15+i*.018)+i*.8,x=Math.cos(a)*b[1]*1.35,z=Math.sin(a)*b[1]*1.35,q=sphere(x,0,z,b[2],b[3],i===5);if(selected===i){ctx.strokeStyle='#75d5ff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(q[0],q[1],Math.max(7,b[2]*q[3]+5),0,Math.PI*2);ctx.stroke()} });
    ctx.fillStyle='#b9d5ee';ctx.font='10px Arial';ctx.fillText('${if (english) "SUN" else "GÜNEŞ"}',center[0]+14,center[1]-16);}
    function frame(t){if(document.hidden)return;if(t-last>40){anim+=.012;draw();last=t}raf=requestAnimationFrame(frame)}raf=requestAnimationFrame(frame);document.addEventListener('visibilitychange',()=>{if(!document.hidden){last=performance.now();cancelAnimationFrame(raf);raf=requestAnimationFrame(frame)}else cancelAnimationFrame(raf)});
    stage.addEventListener('pointerdown',e=>{drag=true;px=e.clientX;py=e.clientY;stage.setPointerCapture(e.pointerId)});stage.addEventListener('pointermove',e=>{if(!drag)return;yaw+=(e.clientX-px)*.008;pitch=Math.max(-1.1,Math.min(1.1,pitch+(e.clientY-py)*.006));px=e.clientX;py=e.clientY;draw()});stage.addEventListener('pointerup',()=>drag=false);stage.addEventListener('pointercancel',()=>drag=false);stage.addEventListener('click',e=>{const x=e.offsetX,y=e.offsetY;let best=1e9; bodies.forEach((b,i)=>{const a=anim*(.15+i*.018)+i*.8,q=project(Math.cos(a)*b[1]*1.35,0,Math.sin(a)*b[1]*1.35),d=Math.hypot(x-q[0],y-q[1]);if(d<best){best=d;selected=i}});if(best<42)document.getElementById('caption').textContent=bodies[selected][0]+' ${if (english) "selected · schematic orbit" else "seçildi · yörünge şematik gösterilir"}.';draw()});document.getElementById('plus').onclick=()=>{zoom=Math.min(2.2,zoom*1.15);draw()};document.getElementById('minus').onclick=()=>{zoom=Math.max(.55,zoom/1.15);draw()};document.getElementById('reset').onclick=()=>{yaw=-.55;pitch=.38;zoom=1;selected=-1;draw()};document.addEventListener('visibilitychange',()=>{if(document.hidden)last=performance.now()});window.addEventListener('pagehide',()=>{cancelAnimationFrame(raf)})})();
    </script></body></html>"""
    AndroidView(modifier=Modifier.fillMaxWidth().height(355.dp).clip(RoundedCornerShape(14.dp)), factory={ctx->WebView(ctx).apply{settings.javaScriptEnabled=true;settings.domStorageEnabled=false;settings.allowFileAccess=false;settings.allowContentAccess=false;settings.javaScriptCanOpenWindowsAutomatically=false;settings.setSupportMultipleWindows(false);settings.mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW;settings.blockNetworkLoads=true;setBackgroundColor(android.graphics.Color.TRANSPARENT);loadDataWithBaseURL(null,html,"text/html","UTF-8",null)}}, onRelease={ it.stopLoading(); it.loadUrl("about:blank"); it.removeAllViews(); it.destroy() })
}


private fun localizedElementFamily(kind: String, english: Boolean): String = if (!english) kind else when (kind) {
    "Alkali metal" -> "Alkali metal"
    "Toprak alkali" -> "Alkaline earth metal"
    "Geçiş metali" -> "Transition metal"
    "Metal" -> "Post-transition metal"
    "Yarı metal" -> "Metalloid"
    "Ametal" -> "Nonmetal"
    "Halojen" -> "Halogen"
    "Soygaz" -> "Noble gas"
    "Lantanit" -> "Lanthanide"
    "Aktinit" -> "Actinide"
    else -> "Unknown"
}

@Composable
private fun ElementsPage(p: Palette, english: Boolean, onElement: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var zoom by rememberSaveable { mutableFloatStateOf(.75f) }
    var panX by rememberSaveable { mutableFloatStateOf(0f) }
    var panY by rememberSaveable { mutableFloatStateOf(0f) }
    val filtered = remember(query) {
        val normalizedQuery = normalizeElementSearch(query.trim())
        if (normalizedQuery.isEmpty()) elementRows else elementRows.filter { element ->
            normalizeElementSearch(element[0]).contains(normalizedQuery) ||
                normalizeElementSearch(element[1]).contains(normalizedQuery) ||
                normalizeElementSearch(englishElementName(element[2].toInt())).contains(normalizedQuery) ||
                element[2] == normalizedQuery
        }
    }
    val byNumber = remember { elementRows.associateBy { it[2].toInt() } }
    Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 8.dp)) {
        Text(if (english) "Periodic table" else "Periyodik tablo", color = p.text, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text(
            if (english) "118 elements · Compact overview · Pinch or use − / + to zoom" else "118 element · Daha geniş görünüm · Yakınlaştırmak için iki parmak veya − / + kullan",
            color = p.muted, fontSize = 10.sp
        )
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text(if (english) "Search by name, symbol or atomic number" else "İsim, sembol veya atom numarası ara") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(13.dp)
        )
        Spacer(Modifier.height(5.dp))
        if (query.isBlank()) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("Alkali metal", "Toprak alkali", "Geçiş metali", "Metal", "Yarı metal", "Ametal", "Halojen", "Soygaz", "Lantanit", "Aktinit").forEach { family ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                        Box(Modifier.size(7.dp).background(elementFamilyColor(family), CircleShape))
                        Spacer(Modifier.width(3.dp))
                        Text(localizedElementFamily(family, english), color = p.muted, fontSize = 8.sp, maxLines = 1)
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { zoom = (zoom / 1.15f).coerceAtLeast(.75f); if (zoom == .75f) { panX = 0f; panY = 0f } }) {
                    Text("−", color = p.accent, fontSize = 19.sp)
                }
                Text("${(zoom * 100).toInt()}%", color = p.muted, fontSize = 10.sp)
                TextButton(onClick = { zoom = (zoom * 1.15f).coerceAtMost(2.4f) }) {
                    Text("+", color = p.accent, fontSize = 19.sp)
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { zoom = .75f; panX = 0f; panY = 0f }) {
                    Text(if (english) "Reset" else "Sıfırla", color = p.accent, fontSize = 10.sp)
                }
            }
            BoxWithConstraints(
                Modifier.weight(1f).fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(p.panel.copy(alpha = .45f))
            ) {
                val density = androidx.compose.ui.platform.LocalDensity.current
                val contentWidthPx = with(density) { (18 * 30 + 17 * 2 + 8).dp.toPx() }
                val contentHeightPx = with(density) { (14 + 9 * 42 + 8 * 2 + 8).dp.toPx() }
                Box(
                    Modifier.fillMaxSize()
                        .pointerInput(Unit) {
                            detectTransformGestures { centroid, pan, gestureZoom, _ ->
                                val oldZoom = zoom
                                val nextZoom = (oldZoom * gestureZoom).coerceIn(.75f, 2.4f)
                                val ratio = nextZoom / oldZoom
                                val proposedX = centroid.x - (centroid.x - panX) * ratio + pan.x
                                val proposedY = centroid.y - (centroid.y - panY) * ratio + pan.y
                                val minX = minOf(0f, size.width - contentWidthPx * nextZoom)
                                val minY = minOf(0f, size.height - contentHeightPx * nextZoom)
                                panX = proposedX.coerceIn(minX, 0f)
                                panY = proposedY.coerceIn(minY, 0f)
                                zoom = nextZoom
                            }
                        }
                ) {
                    Column(
                        modifier = Modifier.wrapContentSize(unbounded = true, align = Alignment.TopStart).graphicsLayer {
                            scaleX = zoom
                            scaleY = zoom
                            translationX = panX
                            translationY = panY
                            transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0f)
                        }.padding(4.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            (1..18).forEach { group ->
                                Box(Modifier.size(30.dp, 14.dp), contentAlignment = Alignment.Center) {
                                    Text(group.toString(), color = p.muted, fontSize = 6.sp)
                                }
                            }
                        }
                        periodicTableRows.forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                row.forEach { atomicNumber ->
                                    val element = atomicNumber?.let { byNumber[it] }
                                    if (element == null) {
                                        Spacer(Modifier.size(30.dp, 42.dp))
                                    } else {
                                        val familyColor = elementFamilyColor(element[4])
                                        Card(
                                            onClick = { onElement(element[0]) },
                                            modifier = Modifier.size(30.dp, 42.dp),
                                            colors = CardDefaults.cardColors(containerColor = familyColor.copy(alpha = if (themeIsLight(p)) .22f else .20f)),
                                            border = BorderStroke(.7.dp, familyColor.copy(alpha = .85f))
                                        ) {
                                            Column(
                                                Modifier.fillMaxSize().padding(1.dp),
                                                verticalArrangement = Arrangement.Center,
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                Text(element[2], color = p.muted, fontSize = 5.5.sp, lineHeight = 6.sp)
                                                Text(element[0], color = familyColor, fontWeight = FontWeight.Black, fontSize = 12.sp, lineHeight = 13.sp, maxLines = 1)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Text(
                if (english) "Swipe or drag to reveal the right-hand groups. Tap an element for its full profile. The two lower rows are the lanthanides and actinides." else "Sağdaki grupları görmek için tabloyu sürükle. Ayrıntılı bilgi için elemente dokun. Alttaki iki sıra lantanitler ve aktinitlerdir.",
                color = p.muted, fontSize = 9.sp, lineHeight = 12.sp, modifier = Modifier.padding(top = 5.dp)
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2), modifier = Modifier.weight(1f), contentPadding = PaddingValues(3.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                items(filtered, key = { it[2] }) { element ->
                    val familyColor = elementFamilyColor(element[4])
                    Card(
                        onClick = { onElement(element[0]) },
                        colors = CardDefaults.cardColors(containerColor = familyColor.copy(alpha = .18f)),
                        border = BorderStroke(1.dp, familyColor.copy(alpha = .75f)),
                        modifier = Modifier.heightIn(min = 88.dp)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(element[2], color = p.muted, fontSize = 10.sp)
                            Text(element[0], color = familyColor, fontWeight = FontWeight.Black, fontSize = 25.sp)
                            Text(if (english) englishElementName(element[2].toInt()) else element[1], color = p.text, fontSize = 12.sp, maxLines = 1)
                            Text(localizedElementFamily(element[4], english), color = p.muted, fontSize = 9.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

private fun themeIsLight(p: Palette): Boolean = p.name == "Light Laboratory"

@Composable
private fun ElementDetailPage(p: Palette, element: List<String>, english: Boolean, onBack: () -> Unit) {
    val (symbol, name, numberText, mass, kind) = element
    val z = numberText.toIntOrNull() ?: 1
    val period = elementPeriod(z)
    val group = elementGroup(z)
    val block = elementBlock(z)
    val config = elementElectronConfigNote(z)
    val radioactive = z == 43 || z == 61 || z >= 83
    val noStableIsotope = z == 43 || z == 61 || z >= 84
    val massLabel = if (noStableIsotope) "[$mass] u*" else "$mass u"
    val detail = elementEducation(element)
    var infoTab by rememberSaveable { mutableStateOf(if (english) "Overview" else "Özet") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, if (english) "Back" else "Geri", tint = p.accent) }
            Text(if (english) "Element profile" else "Element öğrenme dosyası", color = p.text, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
        Panel(p) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (english) "ATOMIC NUMBER $z" else "ATOM NUMARASI $z", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text(if (english) englishElementName(z) else name, color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text(localizedElementFamily(kind, english), color = p.muted)
                }
                Box(Modifier.size(88.dp).clip(RoundedCornerShape(18.dp)).background(p.accent.copy(alpha = .16f)), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(z.toString(), color = p.muted, fontSize = 11.sp)
                        Text(symbol, color = p.accent, fontSize = 38.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                ElementStat(p, if (english) "Atomic mass" else "Atom kütlesi", massLabel)
                ElementStat(p, if (english) "Protons" else "Proton", z.toString())
                ElementStat(p, if (english) "Electrons*" else "Elektron*", z.toString())
            }
            Text(if (english) "* Electron count is for a neutral atom. Ions have different electron counts depending on their charge." else "* Elektron sayısı nötr atom için verilmiştir. İyonlarda elektron sayısı yük durumuna göre değişir.", color = p.muted, fontSize = 10.sp)
        }
        LearningTabs(p, infoTab, english) { infoTab = it }
        Panel(p) {
            Text(if (english) when(infoTab) { "Overview" -> "Element overview"; "Structure" -> "Atomic structure and classification"; else -> "Chemical behaviour" } else when(infoTab) { "Özet" -> "Elementin genel tanımı"; "Yapı" -> "Atomik yapı ve sınıflandırma"; else -> "Kimyasal davranış ve işleyiş" }, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (english) when(infoTab) { "Overview" -> "${englishElementName(z)} ($symbol) is a chemical element with atomic number $z. An element is defined by its number of protons."; "Structure" -> "A neutral atom contains $z protons and $z electrons. The neutron count depends on the isotope. Electron configuration: $config."; else -> "${englishElementName(z)} belongs to the ${localizedElementFamily(kind, true).lowercase()} family. Its chemical behaviour depends on its electron structure and the conditions of the reaction." } else when(infoTab) { "Özet" -> "$name ( $symbol ), atom numarası $z olan kimyasal elementtir. Elementin kimliği proton sayısıyla belirlenir."; "Yapı" -> "Nötr atomda $z proton ve $z elektron bulunur. Nötron sayısı izotopa göre değişir. Elektron dizilimi: $config."; else -> detail }, color = p.text, lineHeight = 21.sp)
        }
        Panel(p) {
            Text(if (english) "Position in the periodic table" else "Periyodik tablodaki konumu", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (english) "Period: $period     Group: $group     Block: $block" else "Periyot: $period     Grup: $group     Blok: $block", color = p.text, fontWeight = FontWeight.SemiBold)
            Text(if (english) "State: ${when(z) { 1,2,7,8,9,10,17,18,36,54,86 -> "Gas (25 °C, 1 atm)"; 35,80 -> "Liquid (25 °C, 1 atm)"; in 104..118 -> "Unknown experimentally"; else -> "Solid (25 °C, 1 atm)" }}" else "Fiziksel hâl: ${elementState(z)}", color = p.text)
            Text(if (english) "Covalent radius: ${covalentRadiusPm(z)?.let { "$it pm" } ?: "no reliable experimental value"}" else "Kovalent yarıçap: ${covalentRadiusPm(z)?.let { "$it pm" } ?: "güvenilir deneysel değer yok"}", color = p.text)
            Text(if (english) "Electron configuration: $config" else "Elektron dizilimi: $config", color = p.text, lineHeight = 21.sp)
            Text(if (english) "An element’s position in the periodic table is related to its atomic number and electron structure. Elements in the same group often share chemical properties because their valence-electron configurations are similar." else "Elementin periyodik tablodaki konumu, atom numarası ve elektron yapısıyla ilişkilidir. Aynı gruptaki elementlerin değerlik elektron düzenleri benzer olduğundan bazı kimyasal özellikleri de benzerlik gösterir.", color = p.muted, lineHeight = 20.sp, fontSize = 12.sp)
        }
        Panel(p) {
            Text(if (english) "Chemistry and significance" else if (setOf("H", "He", "Li", "C", "N", "O", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "K", "Ca", "Fe", "Cu", "Zn", "Ag", "I", "Au", "Hg", "Pb", "U").contains(symbol)) "Elementin kimyası ve önemi" else "Element ailesi ve kimyasal bağlam", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (english) "${englishElementName(z)} has chemical and physical properties determined by its electron structure, bonding behaviour and environmental conditions. Its practical uses depend on these properties and on the form in which the element is present." else detail, color = p.text, lineHeight = 22.sp)
        }
        Panel(p) {
            Text(if (english) "Fundamental particles" else "Atomun temel parçacıkları", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (english) "Protons: $z\nElectrons in a neutral atom: $z\nNeutrons: depend on the selected isotope." else "Proton sayısı: $z\nNötr atomdaki elektron sayısı: $z\nNötron sayısı: seçilen izotopa bağlıdır.", color = p.text, lineHeight = 22.sp)
            Text(if (english) "The atomic number defines an element. Isotopes of the same element have the same number of protons but different numbers of neutrons, so there is no single neutron count for every atom of an element." else "Atom numarası elementin kimliğini belirler. Aynı elementin proton sayısı aynı, nötron sayısı farklı olan atomlarına izotop denir. Bu nedenle tek bir nötron sayısı bütün atomlar için geçerli değildir.", color = p.muted, lineHeight = 20.sp, fontSize = 12.sp)
        }
        if (radioactive) Panel(p) {
            Text(if (english) "Radioactivity and atomic-mass note" else "Radyoaktivite ve atom kütlesi notu", color = p.accent, fontWeight = FontWeight.Bold)
            Text(if (english) { if (noStableIsotope) "This element has no stable isotopes. The number in square brackets is the mass number of a selected isotope, not a standard atomic weight." else "All known isotopes of bismuth are radioactive; Bi-209 has an extremely long half-life, so the standard atomic-weight notation is retained." } else { if (noStableIsotope) "Bu elementin kararlı izotopu yoktur. Köşeli parantez içindeki sayı, standart atom ağırlığı yerine seçilmiş bir izotopun kütle numarasını belirtir; doğal izotopların ortalama atom ağırlığı gibi yorumlanmamalıdır." else "Bizmutun bilinen izotopları radyoaktiftir; Bi-209 çok uzun yarı ömürlüdür. Bu nedenle tabloda standart atom ağırlığı gösterimi korunur." }, color = p.text, lineHeight = 21.sp)
        }
        Panel(p) {
            Text(if (english) "Schematic atom visualization" else "Şematik atom görselleştirmesi", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Atom3DView(p, symbol, z, english = english)
            Text(if (english) "This is a schematic educational illustration, not a scale-accurate quantum-mechanical model. Electron shells are shown only as a simplified introductory visualization." else "Model, atomun ölçekli veya kuantum-mekanik açıdan tam temsili değildir. Elektronların belirli dairesel yörüngelerde dolaştığı izlenimi vermemek için bu görünüm eğitim amaçlı şematik bir görselleştirmedir.", color = p.muted, fontSize = 11.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun ElementStat(p: Palette, title: String, value: String) {
    Column(Modifier.widthIn(min = 76.dp).background(p.bg.copy(alpha=.5f), RoundedCornerShape(12.dp)).padding(9.dp)) {
        Text(title, color = p.muted, fontSize = 10.sp)
        Text(value, color = p.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}


@Composable
private fun AtomLabPage(p: Palette, english: Boolean) {
    var selected by rememberSaveable { mutableIntStateOf(6) }
    val choices = listOf(1, 2, 6, 8, 11, 17, 26, 29, 79, 92)
    val current = elementRows.firstOrNull { it[2].toIntOrNull() == selected } ?: elementRows[5]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel(p) {
            Text(if (english) "ATOM LAB" else "ATOM LABORATUVARI", color = p.accent, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 11.sp)
            Text(if (english) "Explore the atom layer by layer" else "Atomu katman katman incele", color = p.text, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text(if (english) "Select an element and inspect its nucleus and electron-shell illustration. The model is not to scale and electrons do not travel in classical planetary orbits." else "Element seç, çekirdek ve elektron gösterimini incele. Model ölçekli değildir; elektronlar klasik gezegen yörüngelerinde hareket etmez.", color = p.muted, lineHeight = 20.sp)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            choices.forEach { z ->
                val el = elementRows[z - 1]
                FilterChip(selected = selected == z, onClick = { selected = z }, label = { Text(el[0]) })
            }
        }
        Panel(p) {
            Text("${if (english) englishElementName(selected) else current[1]} (${current[0]})", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text(if (english) "Atomic number ${current[2]} · Protons ${current[2]} · Electrons in a neutral atom ${current[2]}" else "Atom numarası ${current[2]} · Proton ${current[2]} · Nötr atom elektronu ${current[2]}", color = p.text)
            Atom3DView(p, current[0], selected, isotopeMassFor(selected), english)
            Text(if (english) "Electron configuration: ${elementElectronConfigNote(selected)}" else "Elektron dizilimi: ${elementElectronConfigNote(selected)}", color = p.muted, fontSize = 12.sp)
        }
        Panel(p) {
            Text(if (english) "What defines an atom?" else "Atom nasıl tanımlanır?", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (english) "The nucleus contains positively charged protons and neutral neutrons. Negatively charged electrons occupy quantum states. Proton number defines the element; changing neutron number creates an isotope, while changing electron number creates an ion." else "Çekirdekte pozitif yüklü protonlar ve yüksüz nötronlar bulunur. Negatif yüklü elektronlar atomun kuantum durumlarını oluşturur. Proton sayısı atom numarasıdır ve elementin kimliğini belirler. Nötron sayısı değişirse izotop, elektron sayısı değişirse iyon oluşur.", color = p.text, lineHeight = 22.sp)
        }
        Panel(p) {
            Text(if (english) "The orbital model" else "Orbital fikri", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (english) "s, p, d and f orbitals are quantum states describing the probability distribution of electrons. An orbital can contain up to two electrons with opposite spin quantum numbers. Bohr shell drawings can be useful introductions, but real electron structure is described by probability distributions." else "s, p, d ve f orbitalleri elektronların bulunma olasılığını tanımlayan kuantum durumlarıdır. Bir orbital en fazla iki elektron barındırır ve bu elektronların spin kuantum sayıları zıttır. Bohr kabuk çizimleri başlangıç düzeyinde yararlı olabilir; ancak atomların gerçek elektron yapısı olasılık dağılımlarıyla açıklanır.", color = p.text, lineHeight = 22.sp)
        }
    }
}

@Composable
private fun MathematicsPage(p: Palette, english: Boolean) {
    var coefficient by rememberSaveable { mutableFloatStateOf(1f) }
    var xValue by rememberSaveable { mutableFloatStateOf(1.5f) }
    var diceRolls by rememberSaveable { mutableIntStateOf(0) }
    var sixes by rememberSaveable { mutableIntStateOf(0) }
    val yValue = coefficient * xValue * xValue
    val topics = if (english) listOf(
        "Number systems" to "Natural, integer, rational, irrational and real numbers are classified by their algebraic properties.",
        "Algebra and equations" to "An equation states that two expressions are equal. Applying the same valid operation to both sides preserves the solution set.",
        "Functions" to "A function assigns exactly one output to each input in its domain. Its graph reveals how the output changes as the input changes.",
        "Geometry" to "Geometry studies shape, distance, angle, area and volume. In Euclidean geometry, the interior angles of a triangle sum to 180 degrees.",
        "Trigonometry" to "Sine, cosine and tangent connect angles with side ratios. The unit circle extends these relationships to all angles.",
        "Probability and statistics" to "Probability quantifies uncertainty. Statistics collects, summarizes and analyzes data to identify patterns and variation.",
        "Derivatives and integrals" to "A derivative describes instantaneous rate of change; an integral describes accumulation and area."
    ) else listOf(
        "Sayı kümeleri" to "Doğal sayılar, tam sayılar, rasyonel, irrasyonel ve gerçek sayılar farklı özelliklere göre tanımlanır.",
        "Cebir ve denklemler" to "Denklem, iki ifadenin eşitliğini sağlayan bilinmeyen değerlerini arar. Eşitliğin iki tarafına aynı işlem uygulanırsa çözüm kümesi korunur.",
        "Fonksiyonlar" to "Fonksiyon, tanım kümesindeki her girdiye değer kümesinde tek bir çıktı eşleyen kuraldır. Grafik, ilişkinin nasıl değiştiğini gösterir.",
        "Geometri" to "Geometri şekillerin, açıların, uzunlukların, alanların ve hacimlerin ilişkilerini inceler. Üçgen iç açıları toplamı 180 derecedir.",
        "Trigonometri" to "Sinüs, kosinüs ve tanjant açıları kenar oranlarıyla ilişkilendirir. Birim çember bu oranları tüm açılara genişletir.",
        "Olasılık ve istatistik" to "Olasılık belirsiz olayların matematiksel ölçüsüdür. İstatistik veri toplama, özetleme ve çıkarım yöntemlerini kapsar.",
        "Türev ve integral" to "Türev anlık değişim hızını, integral birikimi ve alan ilişkilerini inceler."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text(if (english) "MATHEMATICS WORKSPACE" else "MATEMATİK ATÖLYESİ", color = p.accent, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 11.sp)
            Text(if (english) "Explore relationships, not just formulas" else "Yalnızca formülleri değil, ilişkileri keşfet", color = p.text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(if (english) "Change the parameters and watch the model respond." else "Parametreleri değiştir ve modelin nasıl tepki verdiğini gözlemle.", color = p.muted)
        }
        Panel(p) {
            Text(if (english) "LIVE FUNCTION GRAPH" else "CANLI FONKSİYON GRAFİĞİ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp)
            Text("y = ${"%.1f".format(coefficient)}x²", color=p.text, fontWeight=FontWeight.Bold, fontSize=20.sp)
            Text(if (english) "Curve coefficient (a)" else "Parabol katsayısı (a)", color=p.muted, fontSize=12.sp)
            Slider(value=coefficient, onValueChange={coefficient=it}, valueRange=-2f..2f)
            Text(if (english) "Input value (x)" else "Girdi değeri (x)", color=p.muted, fontSize=12.sp)
            Slider(value=xValue, onValueChange={xValue=it}, valueRange=-4f..4f)
            Text("x = ${"%.2f".format(xValue)}     y = ${"%.2f".format(yValue)}", color=p.accent, fontWeight=FontWeight.Bold)
            androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(205.dp).background(p.bg, RoundedCornerShape(12.dp)).padding(10.dp)) {
                val pad = 18.dp.toPx()
                val plotW = (size.width - 2f * pad).coerceAtLeast(1f)
                val plotH = (size.height - 2f * pad).coerceAtLeast(1f)
                val midX = size.width / 2f
                val midY = size.height / 2f
                val xScale = plotW / 8f
                val yScale = plotH / 16f
                drawLine(p.muted.copy(alpha=.55f), androidx.compose.ui.geometry.Offset(pad,midY), androidx.compose.ui.geometry.Offset(size.width-pad,midY),1.dp.toPx())
                drawLine(p.muted.copy(alpha=.55f), androidx.compose.ui.geometry.Offset(midX,pad), androidx.compose.ui.geometry.Offset(midX,size.height-pad),1.dp.toPx())
                val path=androidx.compose.ui.graphics.Path()
                for(i in 0..240){ val x=-4f+i/30f; val y=coefficient*x*x; val px=(midX+x*xScale).coerceIn(pad,size.width-pad); val py=(midY-y*yScale/2f).coerceIn(pad,size.height-pad); if(i==0)path.moveTo(px,py) else path.lineTo(px,py) }
                drawPath(path,p.accent,style=Stroke(width=3.dp.toPx()))
                val markerX=(midX+xValue*xScale).coerceIn(pad,size.width-pad)
                val markerY=(midY-yValue*yScale/2f).coerceIn(pad,size.height-pad)
                drawCircle(Color(0xFFFFC857),5.dp.toPx(),androidx.compose.ui.geometry.Offset(markerX,markerY))
            }
            Text(if (english) "The graph is a numerical visualization of y = ax²." else "Grafik, y = ax² fonksiyonunun sayısal görselleştirmesidir.", color=p.muted, fontSize=10.sp)
        }
        Panel(p) {
            Text(if (english) "PROBABILITY EXPERIMENT · FAIR DIE" else "OLASILIK DENEYİ · ADİL ZAR", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            Text(if (english) "Roll the die repeatedly and compare the observed frequency of six with the theoretical probability (1/6)." else "Zarı tekrar tekrar at. Altı gelme sıklığını teorik olasılık olan 1/6 ile karşılaştır.", color=p.muted, fontSize=12.sp, lineHeight=18.sp)
            Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                Button(onClick={ val roll=(1..6).random(); diceRolls++; if(roll==6) sixes++ }) { Text(if (english) "Roll" else "Zar at") }
                OutlinedButton(onClick={diceRolls=0; sixes=0}) { Text(if (english) "Reset" else "Sıfırla") }
            }
            Text(if (english) "Trials: $diceRolls · Sixes: $sixes · Observed: ${if(diceRolls==0) "0.0" else "%.1f".format(sixes*100f/diceRolls)}% · Expected: 16.7%" else "Atış: $diceRolls · Altı: $sixes · Gözlenen: ${if(diceRolls==0) "0,0" else "%.1f".format(sixes*100f/diceRolls)}% · Teorik: 16,7%", color=p.text, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
        }
        Panel(p) {
            Text(if (english) "DERIVATIVE EXPLORER" else "TÜREV KEŞFİ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            val slope = 2f * coefficient * xValue
            Text(if (english) "For f(x)=ax², f′(x)=2ax" else "f(x)=ax² için f′(x)=2ax", color=p.text, fontWeight=FontWeight.Bold, fontSize=18.sp)
            Text(if (english) "Instantaneous slope at x=${"%.2f".format(xValue)}: ${"%.2f".format(slope)}" else "x=${"%.2f".format(xValue)} noktasındaki anlık eğim: ${"%.2f".format(slope)}", color=p.accent, fontWeight=FontWeight.SemiBold)
            Text(if (english) "This analytic derivative is exact for the displayed quadratic function." else "Bu analitik türev, gösterilen ikinci dereceden fonksiyon için kesindir.", color=p.muted, fontSize=10.sp)
        }
        topics.forEachIndexed { index, topic ->
            var expanded by rememberSaveable(topic.first) { mutableStateOf(index == 0) }
            Panel(p, Modifier.clickable { expanded = !expanded }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${index + 1}.", color = p.accent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Text(topic.first, color = p.text, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.muted)
                }
                if (expanded) Text(topic.second, color = p.muted, lineHeight = 21.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
private fun ChemistryPage(p: Palette, english: Boolean) {
    val topics = if (english) listOf(
        "Atomic structure" to "An atom contains a nucleus of protons and neutrons surrounded by an electron cloud. Proton number defines the element; isotopes differ in neutron number.",
        "Periodic trends" to "Atomic radius, ionization energy and electronegativity show repeating trends across the periodic table. These trends help explain chemical behaviour.",
        "Chemical bonds" to "Ionic bonds involve electrostatic attraction between ions. Covalent bonds share electron pairs. Metallic bonding involves delocalized valence electrons.",
        "Reactions and balancing" to "Chemical reactions rearrange atoms. In a closed system, atoms and total mass are conserved; equations are balanced by matching atom counts.",
        "Acids, bases and pH" to "pH is a logarithmic measure of acidity in aqueous solutions. At 25 °C, pH 7 is neutral; lower values are acidic and higher values are basic.",
        "Solutions and concentration" to "A solution contains a solute distributed in a solvent. Concentration can be expressed as molarity or percentage; temperature and chemical identity affect solubility.",
        "Organic chemistry" to "Organic chemistry studies carbon compounds, including hydrocarbons, alcohols, carboxylic acids, esters and polymers.",
        "Chemistry and energy" to "Exothermic reactions release energy; endothermic reactions absorb it. Reaction rates depend on temperature, concentration, surface area and catalysts.",
        "Laboratory safety" to "Read labels and safety data. Use appropriate protective equipment. Never taste or directly smell chemicals, and do not mix unknown substances.",
        "Chemical equilibrium" to "Dynamic equilibrium occurs when forward and reverse reaction rates are equal. Concentration, pressure and temperature can shift the equilibrium position.",
        "Electrochemistry" to "Redox reactions transfer electrons. Galvanic cells produce electrical energy from spontaneous reactions; electrolysis uses external energy to drive chemical change.",
        "Polymers" to "Polymers are large molecules made of repeating units. Proteins and cellulose are natural examples; polyethylene and nylon are synthetic examples."
    ) else listOf(
        "Atomun yapısı" to "Atom; proton ve nötronlardan oluşan çekirdek ile elektron bulutundan meydana gelir. Proton sayısı elementin kimliğini belirler. Nötron sayısı izotopları, elektron dizilimi ise kimyasal davranışın önemli bölümünü belirler.",
        "Periyodik eğilimler" to "Aynı gruptaki elementlerin değerlik elektron yapıları benzerdir. Atom yarıçapı, iyonlaşma enerjisi ve elektronegatiflik periyodik tabloda düzenli eğilimler gösterir; bu eğilimler elementlerin tepkime davranışını anlamaya yardımcı olur.",
        "Kimyasal bağlar" to "İyonik bağ zıt yüklü iyonların elektrostatik çekimidir. Kovalent bağda atomlar elektron çiftlerini paylaşır. Metalik bağda değerlik elektronları metal yapısı boyunca delokalizedir.",
        "Tepkimeler ve denkleştirme" to "Kimyasal tepkimelerde atomlar yeniden düzenlenir; kapalı sistemlerde toplam atom sayısı ve kütle korunur. Denklem denkleştirme, her elementin atom sayısını iki tarafta eşitler.",
        "Asit, baz ve pH" to "pH sulu çözeltilerin asitlik-bazlık durumunu ifade eden logaritmik bir ölçüdür. 25 °C'de pH 7 nötr kabul edilir; daha düşük değerler asidik, daha yüksek değerler bazik ortamı gösterir.",
        "Çözeltiler ve derişim" to "Çözelti, çözücü içinde dağılmış çözünen maddeden oluşur. Derişim molarite veya yüzde gibi birimlerle ifade edilebilir. Sıcaklık ve maddenin türü çözünürlüğü etkiler.",
        "Organik kimya" to "Karbon bileşiklerinin yapısını, özelliklerini ve tepkimelerini inceler. Hidrokarbonlar, alkoller, karboksilik asitler, esterler ve polimerler önemli bileşik sınıflarıdır.",
        "Kimya ve enerji" to "Ekzotermik tepkimeler çevreye enerji verir; endotermik tepkimeler çevreden enerji alır. Tepkime hızı sıcaklık, derişim, yüzey alanı ve katalizör gibi etkenlerden etkilenebilir.",
        "Laboratuvar güvenliği" to "Etiketler ve güvenlik bilgi formları okunur; koruyucu gözlük ve uygun ekipman kullanılır. Bilinmeyen maddeler karıştırılmaz, maddeler tadılmaz veya doğrudan koklanmaz. Deneyler yalnızca yetkili gözetiminde yapılır.",
        "Kimyasal denge" to "Tersinir tepkimelerde ileri ve geri tepkime hızları eşitlendiğinde dinamik denge oluşur. Derişim, basınç ve sıcaklık değişimleri denge konumunu etkileyebilir.",
        "Elektrokimya" to "Redoks tepkimelerinde elektron aktarımı gerçekleşir. Galvanik hücreler kendiliğinden gerçekleşen tepkimelerden elektrik üretirken elektroliz dış enerjiyle kimyasal dönüşüm sağlar.",
        "Polimerler" to "Polimerler tekrarlayan monomer birimlerinden oluşan büyük moleküllerdir. Doğal örnekler arasında protein ve selüloz; sentetik örnekler arasında polietilen ve naylon bulunur."
    )
    var expanded by rememberSaveable { mutableStateOf(topics.first().first) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) {
            Text(if (english) "CHEMISTRY LAB" else "KİMYA LABORATUVARI", color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp, letterSpacing=2.sp)
            Text(if (english) "Matter, bonds and transformations" else "Madde, bağlar ve dönüşümler", color=p.text, fontSize=21.sp, fontWeight=FontWeight.Bold)
            Text(if (english) "Water molecule · interactive projection" else "Su molekülü · etkileşimli izdüşüm", color=p.muted, fontSize=12.sp)
            Molecule3DView(p, english)
        }
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded=if(expanded==title) "" else title }, verticalAlignment=Alignment.CenterVertically) {
                    Text(title, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                    Icon(if(expanded==title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.accent)
                }
                if(expanded==title) Text(body, color=p.text, lineHeight=21.sp, modifier=Modifier.padding(top=7.dp))
            }
        }
    }
}


@Composable
private fun Molecule3DView(p: Palette, english: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            if (english) "Interactive local 3D water model" else "Etkileşimli yerel 3B su modeli",
            color = p.muted,
            fontSize = 11.sp
        )
        AndroidView(
            modifier = Modifier.fillMaxWidth().height(290.dp).clip(RoundedCornerShape(14.dp)),
            factory = { ctx ->
                val assetLoader = WebViewAssetLoader.Builder()
                    .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
                    .build()
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = false
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.allowFileAccessFromFileURLs = false
                    settings.allowUniversalAccessFromFileURLs = false
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    settings.setSupportMultipleWindows(false)
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    settings.blockNetworkLoads = true
                    isVerticalScrollBarEnabled = false
                    isHorizontalScrollBarEnabled = false
                    webViewClient = object : WebViewClientCompat() {
                        override fun shouldInterceptRequest(
                            view: WebView,
                            request: WebResourceRequest
                        ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                            android.util.Log.w("Spectrum3D", "${message.message()} (${message.sourceId()}:${message.lineNumber()})")
                            return true
                        }
                    }
                    setBackgroundColor(android.graphics.Color.rgb(7, 19, 33))
                    loadUrl("https://appassets.androidplatform.net/assets/lab/index.html?model=water&lang=${if (english) "en" else "tr"}")
                }
            },
            onRelease = { view ->
                view.onPause()
                view.stopLoading()
                view.loadUrl("about:blank")
                view.webChromeClient = null
                view.webViewClient = WebViewClientCompat()
                view.removeAllViews()
                view.destroy()
            }
        )
    }
}


@Composable
private fun MicrobiologyPage(p: Palette, english: Boolean) {
    val topics = if (english) listOf(
        "Introduction to microorganisms" to "Microbiology studies microorganisms and microscopic biological structures. Bacteria and archaea are prokaryotes; yeasts and protozoa are eukaryotes.",
        "Bacteria" to "Bacteria are single-celled prokaryotes. Their shapes, metabolisms and habitats vary widely. Some are beneficial, while others can cause disease.",
        "Viruses" to "Viruses are not cellular. They carry genetic material inside a protein coat and use host-cell machinery to reproduce. Antibiotics do not treat viral infections.",
        "Fungi and yeasts" to "Fungi are eukaryotes. Yeasts are usually single-celled, while moulds form filamentous structures. Fungi contribute to decomposition and food production.",
        "Protozoa and algae" to "Protozoa are mostly single-celled eukaryotes. Algae include diverse photosynthetic organisms and contribute to aquatic primary production.",
        "Microbiota" to "Microbiota are communities of microorganisms living in and on the body. Gut microbes contribute to digestion, metabolism and immune functions.",
        "Microscopy" to "Light microscopes reveal cells and microorganisms. Resolution, sample preparation and staining matter as much as magnification.",
        "Cell membrane" to "The phospholipid bilayer forms a selectively permeable boundary. Membrane proteins support transport, communication and recognition.",
        "Ribosomes" to "Ribosomes use messenger RNA to assemble amino acids into polypeptide chains. They occur in both prokaryotic and eukaryotic cells.",
        "Mitochondria" to "Mitochondria contribute to ATP production during aerobic respiration. They have two membranes and their own DNA.",
        "Microbial ecology" to "Microorganisms contribute to the carbon, nitrogen and sulfur cycles and help maintain soil and aquatic ecosystems.",
        "Antibiotic resistance" to "Resistance allows bacteria to survive exposure to an antibiotic. Unnecessary or incorrect antibiotic use can increase selection for resistant strains."
    ) else listOf(
        "Mikroorganizmalara giriş" to "Mikrobiyoloji, mikroorganizmaları ve mikroskobik biyolojik yapıları inceler. Bakteriler ve arkeler prokaryot; maya ve protozoalar ökaryot hücre yapısına sahiptir.",
        "Bakteriler" to "Bakteriler tek hücreli prokaryotlardır. Şekilleri, metabolizmaları ve yaşadıkları ortamlar çeşitlidir. Bazıları insan sağlığı için yararlı roller üstlenirken bazıları hastalıklara neden olabilir.",
        "Virüsler" to "Virüsler hücresel yapıda değildir; genetik materyallerini protein kılıf içinde taşırlar. Çoğalmak için konak hücrelerin mekanizmalarını kullanırlar. Antibiyotikler virüslere karşı etkili değildir.",
        "Mantarlar ve mayalar" to "Mantarlar ökaryot canlılardır. Mayalar tek hücreli, küfler çoğunlukla ipliksi yapılara sahip olabilir. Ayrıştırma, gıda üretimi ve ekosistem döngülerinde önemli görevleri vardır.",
        "Protozoalar ve algler" to "Protozoalar çoğunlukla tek hücreli ökaryotlardır. Algler fotosentez yapabilen çeşitli organizmaları kapsar; su ekosistemlerinde birincil üretime katkı sağlar.",
        "Mikrobiyota" to "İnsan vücudunda ve üzerinde yaşayan mikroorganizma toplulukları mikrobiyotayı oluşturur. Bağırsak mikrobiyotası sindirim, metabolizma ve bağışıklıkla ilişkili işlevlerde rol oynar.",
        "Mikroskopi" to "Işık mikroskopları hücre ve mikroorganizma yapılarını incelemekte kullanılır. Büyütme kadar çözünürlük, örnek hazırlama ve uygun boyama yöntemi de gözlemin kalitesini belirler.",
        "Hücre zarı" to "Fosfolipit çift tabakası seçici geçirgen bir sınır oluşturur. Zar proteinleri madde taşınması, hücre iletişimi ve tanımada görev alır.",
        "Ribozomlar" to "Ribozomlar mRNA bilgisini kullanarak amino asitleri polipeptit zincirlerine bağlar. Hem prokaryot hem ökaryot hücrelerde bulunurlar.",
        "Mitokondri" to "Mitokondriler oksijenli solunumun birçok basamağında ATP üretimine katkı sağlar. Kendi DNA'larına ve çift zarlı yapıya sahiptirler.",
        "Mikrobiyal ekoloji" to "Mikroorganizmalar karbon, azot ve kükürt döngülerinde önemli rol oynar. Toprak ve okyanus ekosistemlerinin işleyişine katkı verir.",
        "Antibiyotik direnci" to "Direnç, bakterilerin bir antibiyotiğe rağmen çoğalabilmesini sağlayan kalıtsal özelliklerle ilişkilidir. Antibiyotiklerin gereksiz veya yanlış kullanımı direnç seçilimini artırabilir."
    )
    var expanded by rememberSaveable { mutableStateOf(topics.first().first) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) {
            Text(if (english) "MICROBIOLOGY" else "MİKROBİYOLOJİ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp, letterSpacing=2.sp)
            Text(if (english) "Explore the microscopic world" else "Mikroskobik dünyayı keşfet", color=p.text, fontWeight=FontWeight.Bold, fontSize=21.sp)
            Text(if (english) "Cells, microorganisms and the systems they influence." else "Hücreler, mikroorganizmalar ve etkiledikleri sistemler.", color=p.muted)
        }
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded=if(expanded==title) "" else title }, verticalAlignment=Alignment.CenterVertically) {
                    Text(title, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                    Icon(if(expanded==title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.accent)
                }
                if(expanded==title) { Spacer(Modifier.height(7.dp)); Text(body, color=p.text, lineHeight=21.sp) }
            }
        }
        Panel(p) {
        Text(if (english) "Scientific note" else "Bilimsel not", color=p.accent, fontWeight=FontWeight.Bold)
            Text(if (english) "Whether viruses should be considered living organisms is debated; they are not classified as cellular life." else "Virüslerin canlı olarak sınıflandırılması tartışmalıdır; hücresel canlılarla aynı grupta değerlendirilmezler.", color=p.text)
        }
    }
}

@Composable
private fun VisualLabPage(p: Palette, english: Boolean, initialModel: String = "atom") {
    var loadError by remember { mutableStateOf<String?>(null) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var pageLoaded by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().padding(10.dp)) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (english) "Interactive 3D models" else "Etkileşimli 3B modeller", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(if (english) "Rotate, zoom and switch between locally bundled scientific scenes." else "Yerel olarak pakete eklenmiş bilimsel sahneleri döndür, yakınlaştır ve değiştir.", color = p.muted, fontSize = 12.sp, lineHeight = 17.sp)
            AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(16.dp)),
                factory = { ctx ->
                    val assetLoader = WebViewAssetLoader.Builder()
                        .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
                        .build()
                    WebView(ctx).apply {
                        webViewRef = this
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = false
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        settings.allowFileAccessFromFileURLs = false
                        settings.allowUniversalAccessFromFileURLs = false
                        settings.javaScriptCanOpenWindowsAutomatically = false
                        settings.setSupportMultipleWindows(false)
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        // appassets.androidplatform.net is a virtual HTTPS origin. Do not block it;
                        // instead, explicitly reject every request that is not for this local origin.
                        settings.blockNetworkLoads = false
                        isVerticalScrollBarEnabled = false
                        isHorizontalScrollBarEnabled = false
                        val bridgeView = this
                        addJavascriptInterface(object {
                            @JavascriptInterface fun reportReady() { bridgeView.post { pageLoaded = true; loadError = null } }
                            @JavascriptInterface fun reportError(message: String) { bridgeView.post { pageLoaded = false; loadError = message.take(220) } }
                        }, "SpectrumBridge")
                        webViewClient = object : WebViewClient() {
                            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                                val url = request.url
                                return if (url.scheme == "https" && url.host == "appassets.androidplatform.net") {
                                    assetLoader.shouldInterceptRequest(url) ?: WebResourceResponse("text/plain", "UTF-8", 404, "Local asset not found", mapOf("Cache-Control" to "no-store"), ByteArrayInputStream(ByteArray(0)))
                                } else {
                                    WebResourceResponse("text/plain", "UTF-8", 403, "Blocked by Spectrum", mapOf("Cache-Control" to "no-store"), ByteArrayInputStream(ByteArray(0)))
                                }
                            }
                            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                                request.url.host != "appassets.androidplatform.net" || request.url.scheme != "https"
                            override fun onPageFinished(view: WebView, url: String) {
                                super.onPageFinished(view, url)
                                android.util.Log.i("Spectrum3D", "Local lab document finished: $url")
                            }
                            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                                super.onReceivedError(view, request, error)
                                if (request.isForMainFrame) {
                                    val detail = "WebView ${error.errorCode}: ${error.description}"
                                    android.util.Log.e("Spectrum3D", detail)
                                    loadError = detail
                                }
                            }
                            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
                                super.onReceivedHttpError(view, request, response)
                                if (request.isForMainFrame || response.statusCode >= 400) {
                                    val detail = "Local asset HTTP ${response.statusCode}: ${request.url.lastPathSegment}"
                                    android.util.Log.e("Spectrum3D", detail)
                                    if (request.isForMainFrame) loadError = detail
                                }
                            }
                        }
                        webChromeClient = object : WebChromeClient() {
                            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                                val detail = "${message.message()} (${message.sourceId()}:${message.lineNumber()})"
                                if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                                    android.util.Log.e("Spectrum3D", detail)
                                    loadError = detail.take(220)
                                } else android.util.Log.d("Spectrum3D", detail)
                                return true
                            }
                        }
                        setBackgroundColor(android.graphics.Color.rgb(7, 19, 33))
                        loadUrl("https://appassets.androidplatform.net/assets/lab/index.html?model=$initialModel&lang=${if (english) "en" else "tr"}")
                    }
                },
                onRelease = { view ->
                    if (webViewRef === view) webViewRef = null
                    view.onPause()
                    view.stopLoading()
                    view.loadUrl("about:blank")
                    view.removeJavascriptInterface("SpectrumBridge")
                    view.webChromeClient = null
                    view.webViewClient = WebViewClient()
                    view.removeAllViews()
                    view.destroy()
                }
            )
            Text(if (english) "Educational models are schematic; scale and assumptions are described in each scene." else "Modeller eğitim amaçlı şematik temsillerdir; ölçek ve varsayımlar her sahnede açıklanır.", color = p.muted, fontSize = 10.sp, lineHeight = 14.sp)
        }
        if (loadError != null) {
            Surface(Modifier.align(Alignment.Center).fillMaxWidth().padding(14.dp), color = p.panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, p.accent.copy(alpha = .45f)), shadowElevation = 8.dp) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (english) "3D lab could not start" else "3B laboratuvarı başlatılamadı", color = p.text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(loadError ?: "Unknown WebView error", color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
                    Button(onClick = { loadError = null; pageLoaded = false; webViewRef?.reload() }) { Text(if (english) "Retry" else "Yeniden dene") }
                }
            }
        } else if (!pageLoaded) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = p.accent)
        }
    }
}


private val representativeIsotopeMasses = mapOf(
    1 to 1, 2 to 4, 6 to 12, 8 to 16, 11 to 23,
    17 to 35, 26 to 56, 29 to 64, 79 to 197, 92 to 238
)

private fun isotopeMassFor(z: Int): Int? = representativeIsotopeMasses[z]

@Composable
private fun Atom3DView(p: Palette, symbol: String, atomicNumber: Int, isotopeMass: Int? = null, english: Boolean = false) {
    val shellCounts = when(atomicNumber) { 1->listOf(1);2->listOf(2);6->listOf(2,4);8->listOf(2,6);11->listOf(2,8,1);17->listOf(2,8,7);26->listOf(2,8,14,2);29->listOf(2,8,18,1);79->listOf(2,8,18,32,18,1);92->listOf(2,8,18,32,21,9,2);else->listOf(2, minOf(8,(atomicNumber-2).coerceAtLeast(0)), minOf(18,(atomicNumber-10).coerceAtLeast(0))).filter{it>0} }
    val shellJson = shellCounts.joinToString(",")
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>body{margin:0;background:#071525;color:#eaf4ff;font:12px Arial}.tools{padding:7px;display:flex;gap:8px}.tools button{background:#17334e;color:#eaf4ff;border:1px solid #47718d;border-radius:8px;padding:7px 10px}.stage{height:260px;touch-action:none}canvas{width:100%;height:100%;display:block}</style></head><body><div class='tools'><button id='reset'>${if (english) "Reset view" else "Görünümü sıfırla"}</button><span>$symbol · Z=$atomicNumber</span></div><div class='stage' id='stage'><canvas id='c'></canvas></div><script>(()=>{const st=document.getElementById('stage'),c=document.getElementById('c'),ctx=c.getContext('2d'),shells=[$shellJson];let rot=0,drag=false,px=0,auto=false;function size(){let d=Math.min(devicePixelRatio||1,1.5);c.width=st.clientWidth*d;c.height=st.clientHeight*d;ctx.setTransform(d,0,0,d,0,0)}new ResizeObserver(size).observe(st);function draw(){let w=st.clientWidth,h=st.clientHeight;ctx.clearRect(0,0,w,h);ctx.fillStyle='#071525';ctx.fillRect(0,0,w,h);let cx=w/2,cy=h/2,r0=Math.min(w,h)*.11;let g=ctx.createRadialGradient(cx-r0*.3,cy-r0*.4,1,cx,cy,r0);g.addColorStop(0,'#ffd2c8');g.addColorStop(.35,'#e45f63');g.addColorStop(1,'#651d34');ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,r0,0,Math.PI*2);ctx.fill();shells.forEach((n,i)=>{let r=r0+28+i*24;ctx.strokeStyle='rgba(112,188,225,.48)';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(cx,cy,r,r*.42,rot+i*.3,0,Math.PI*2);ctx.stroke();for(let j=0;j<n;j++){let a=rot*(i%2?-.7:1)+j/n*Math.PI*2;let x=cx+Math.cos(a)*r*Math.cos(rot+i*.3),y=cy+Math.sin(a)*r*.42;let eg=ctx.createRadialGradient(x-2,y-2,1,x,y,5);eg.addColorStop(0,'#fff');eg.addColorStop(.4,'#71d9ff');eg.addColorStop(1,'#14618a');ctx.fillStyle=eg;ctx.beginPath();ctx.arc(x,y,4.5,0,Math.PI*2);ctx.fill()}});ctx.fillStyle='#d5e8f7';ctx.font='11px Arial';ctx.textAlign='center';ctx.fillText('${if (english) "Electron-shell illustration is schematic" else "Elektron katmanları şematik gösterimdir"}',cx,h-10)}let raf=0,last=0;function frame(t){if(document.hidden)return;if(t-last>33){if(auto&&!drag)rot+=.008;draw();last=t}raf=requestAnimationFrame(frame)}raf=requestAnimationFrame(frame);document.addEventListener('visibilitychange',()=>{if(document.hidden)cancelAnimationFrame(raf);else{last=performance.now();raf=requestAnimationFrame(frame)}});window.addEventListener('pagehide',()=>cancelAnimationFrame(raf));st.onpointerdown=e=>{drag=true;px=e.clientX;st.setPointerCapture(e.pointerId)};st.onpointermove=e=>{if(drag){rot+=(e.clientX-px)*.01;px=e.clientX}};st.onpointerup=()=>drag=false;st.onpointercancel=()=>drag=false;document.getElementById('reset').onclick=()=>rot=0})();</script></body></html>"""
    AndroidView(modifier=Modifier.fillMaxWidth().height(320.dp).clip(RoundedCornerShape(12.dp)),factory={ctx->WebView(ctx).apply{settings.javaScriptEnabled=true;settings.allowFileAccess=false;settings.allowContentAccess=false;settings.javaScriptCanOpenWindowsAutomatically=false;settings.setSupportMultipleWindows(false);settings.mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW;settings.blockNetworkLoads=true;setBackgroundColor(android.graphics.Color.TRANSPARENT);loadDataWithBaseURL(null,html,"text/html","UTF-8",null)}}, onRelease={ it.stopLoading(); it.loadUrl("about:blank"); it.removeAllViews(); it.destroy() })
}



@Composable
private fun PhysicsKnowledgePage(p: Palette, english: Boolean) {
    var mass by rememberSaveable { mutableFloatStateOf(5f) }
    var force by rememberSaveable { mutableFloatStateOf(20f) }
    var voltage by rememberSaveable { mutableFloatStateOf(9f) }
    var resistance by rememberSaveable { mutableFloatStateOf(100f) }
    val acceleration = force / mass.coerceAtLeast(.1f)
    val current = voltage / resistance.coerceAtLeast(1f)
    val topics = if (english) listOf(
        "Electric charge and fields" to "Like charges repel and opposite charges attract. An electric field describes the force per unit positive test charge.",
        "Current, voltage and resistance" to "Current is the rate of charge flow. Voltage is energy transferred per unit charge. For an ohmic component, V = IR.",
        "Magnetism" to "Moving electric charges produce magnetic fields. Current-carrying conductors and electromagnets use this principle.",
        "Energy and motion" to "Kinetic energy depends on motion; potential energy depends on position or interaction. Friction can transform mechanical energy into thermal energy.",
        "Waves and light" to "Waves transfer energy. Sound is a mechanical wave and needs a medium; light is electromagnetic and can travel through a vacuum.",
        "Newton's laws" to "The net force on an object equals its mass multiplied by its acceleration: F = ma.",
        "Momentum" to "Momentum is mass multiplied by velocity. Total momentum is conserved in an isolated system.",
        "Thermodynamics" to "Thermodynamics studies heat, work, temperature and internal energy. Energy is conserved.",
        "Optics" to "Light changes direction when it crosses media with different refractive indices. Snell's law relates the angles and indices."
    ) else listOf(
        "Elektrik yükü ve alan" to "Aynı işaretli yükler birbirini iter, zıt işaretli yükler birbirini çeker. Elektrik alan, birim pozitif test yüküne etki eden kuvveti tanımlar.",
        "Akım, gerilim ve direnç" to "Akım yük akış hızıdır. Gerilim birim yük başına aktarılan enerjidir. Ohmik bir elemanda V = IR bağıntısı geçerlidir.",
        "Manyetizma" to "Hareketli elektrik yükleri manyetik alan oluşturur. Akım taşıyan iletkenler ve elektromıknatıslar bu ilkeden yararlanır.",
        "Enerji ve hareket" to "Kinetik enerji harekete, potansiyel enerji konuma veya etkileşime bağlıdır. Sürtünme mekanik enerjiyi ısıya dönüştürebilir.",
        "Dalgalar ve ışık" to "Dalgalar enerji taşır. Ses mekanik dalgadır ve ortam gerektirir; ışık elektromanyetiktir ve boşlukta yayılabilir.",
        "Newton yasaları" to "Bir cisme etki eden net kuvvet, kütlesi ile ivmesinin çarpımına eşittir: F = ma.",
        "Momentum" to "Momentum kütle ile hızın çarpımıdır. Yalıtılmış sistemlerde toplam momentum korunur.",
        "Termodinamik" to "Termodinamik ısı, iş, sıcaklık ve iç enerji arasındaki ilişkileri inceler. Enerji korunur.",
        "Optik" to "Işık, farklı kırılma indislerine sahip ortamlar arasında geçerken yön değiştirebilir. Snell yasası açıları ve indisleri ilişkilendirir."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text(if (english) "PHYSICS LAB" else "FİZİK LABORATUVARI", color=p.accent, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=2.sp)
            Text(if (english) "Change a variable. Observe the result." else "Bir değişkeni değiştir. Sonucu gözlemle.", color=p.text, fontSize=21.sp, fontWeight=FontWeight.Bold)
            Text(if (english) "Interactive models use simplified ideal conditions." else "Etkileşimli modeller basitleştirilmiş ideal koşulları kullanır.", color=p.muted, fontSize=12.sp)
        }
        Panel(p) {
            Text(if (english) "MECHANICS · NEWTON'S SECOND LAW" else "MEKANİK · NEWTON'UN İKİNCİ YASASI", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            Text("F = ma", color=p.text, fontWeight=FontWeight.Black, fontSize=24.sp)
            Text(if (english) "Applied force (N)" else "Uygulanan kuvvet (N)", color=p.muted, fontSize=12.sp)
            Slider(value=force, onValueChange={force=it}, valueRange=0f..100f)
            Text("${"%.1f".format(force)} N", color=p.accent, fontWeight=FontWeight.Bold)
            Text(if (english) "Object mass (kg)" else "Cismin kütlesi (kg)", color=p.muted, fontSize=12.sp)
            Slider(value=mass, onValueChange={mass=it}, valueRange=.5f..20f)
            Text("${"%.1f".format(mass)} kg", color=p.accent, fontWeight=FontWeight.Bold)
            androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(76.dp).background(p.bg, RoundedCornerShape(12.dp)).padding(8.dp)) {
                val y=size.height/2
                drawLine(p.muted.copy(alpha=.5f), androidx.compose.ui.geometry.Offset(8f,y), androidx.compose.ui.geometry.Offset(size.width-8f,y),2.dp.toPx())
                val x=(size.width-28.dp.toPx())*(acceleration/200f).coerceIn(0f,1f)+14.dp.toPx()
                drawCircle(p.accent,14.dp.toPx(),androidx.compose.ui.geometry.Offset(x,y))
            }
            Text(if (english) "Calculated acceleration: ${"%.2f".format(acceleration)} m/s²" else "Hesaplanan ivme: ${"%.2f".format(acceleration)} m/s²", color=p.text, fontWeight=FontWeight.Bold)
        }
        Panel(p) {
            Text(if (english) "ELECTRONICS BENCH · OHM'S LAW" else "ELEKTRONİK TEZGAHI · OHM KANUNU", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            Text("V = I × R", color=p.text, fontSize=22.sp, fontWeight=FontWeight.Black)
            Text(if (english) "Supply voltage (V)" else "Kaynak gerilimi (V)", color=p.muted, fontSize=12.sp)
            Slider(value=voltage, onValueChange={voltage=it}, valueRange=1f..24f)
            Text("${"%.1f".format(voltage)} V", color=p.accent, fontWeight=FontWeight.Bold)
            Text(if (english) "Resistance (Ω)" else "Direnç (Ω)", color=p.muted, fontSize=12.sp)
            Slider(value=resistance, onValueChange={resistance=it}, valueRange=10f..1000f)
            Text("${"%.0f".format(resistance)} Ω", color=p.accent, fontWeight=FontWeight.Bold)
            Text(if (english) "Current: ${"%.3f".format(current)} A · Power: ${"%.2f".format(voltage*current)} W" else "Akım: ${"%.3f".format(current)} A · Güç: ${"%.2f".format(voltage*current)} W", color=p.text, fontWeight=FontWeight.Bold)
            Text(if (english) "Ideal DC calculation. Real components have tolerances and power limits." else "İdeal doğru akım hesabıdır. Gerçek bileşenlerin toleransları ve güç sınırları vardır.", color=p.muted, fontSize=10.sp)
        }
        var launchSpeed by rememberSaveable { mutableFloatStateOf(18f) }
        var launchAngle by rememberSaveable { mutableFloatStateOf(42f) }
        var gravity by rememberSaveable { mutableFloatStateOf(9.81f) }
        val radians = Math.toRadians(launchAngle.toDouble())
        val flight = (2.0 * launchSpeed * kotlin.math.sin(radians) / gravity).toFloat()
        val range = (launchSpeed * launchSpeed * kotlin.math.sin(2.0 * radians) / gravity).toFloat()
        val height = (launchSpeed * launchSpeed * kotlin.math.sin(radians).pow(2.0) / (2.0 * gravity)).toFloat()
        Panel(p) {
            Text(if (english) "PROJECTILE MOTION" else "EĞİK ATIŞ SİMÜLATÖRÜ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            Text("v₀ = ${"%.1f".format(launchSpeed)} m/s · θ = ${"%.0f".format(launchAngle)}°", color=p.text, fontWeight=FontWeight.Bold)
            Text(if (english) "Initial speed" else "İlk hız", color=p.muted, fontSize=11.sp)
            Slider(value=launchSpeed, onValueChange={launchSpeed=it}, valueRange=2f..40f)
            Text(if (english) "Launch angle" else "Fırlatma açısı", color=p.muted, fontSize=11.sp)
            Slider(value=launchAngle, onValueChange={launchAngle=it}, valueRange=0f..90f)
            Text(if (english) "Gravity" else "Yerçekimi", color=p.muted, fontSize=11.sp)
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                listOf("Earth" to 9.81f, "Moon" to 1.62f, "Mars" to 3.71f).forEach { (name,g) ->
                    FilterChip(selected = gravity == g, onClick = { gravity=g }, label = { Text(if (english) name else when(name) { "Earth" -> "Dünya"; "Moon" -> "Ay"; else -> "Mars" }, fontSize=10.sp) })
                }
            }
            androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(130.dp).background(p.bg, RoundedCornerShape(10.dp)).padding(8.dp)) {
                val w=size.width; val h=size.height; val ground=h-12.dp.toPx();
                drawLine(p.muted, androidx.compose.ui.geometry.Offset(8f,ground), androidx.compose.ui.geometry.Offset(w-8f,ground), 1.dp.toPx())
                val points=(0..60).map { i -> val t=flight*i/60f; val x=launchSpeed*kotlin.math.cos(radians).toFloat()*t; val y=launchSpeed*kotlin.math.sin(radians).toFloat()*t-.5f*gravity*t*t; androidx.compose.ui.geometry.Offset(10f+x/(range.coerceAtLeast(1f))* (w-20f), ground-y/(height.coerceAtLeast(1f))*(h-28f)) }
                val path=androidx.compose.ui.graphics.Path(); points.forEachIndexed { i,pt -> if(i==0)path.moveTo(pt.x,pt.y) else path.lineTo(pt.x,pt.y) }; drawPath(path,p.accent,style=Stroke(2.5.dp.toPx()))
            }
            Text(if (english) "Range: ${"%.2f".format(range)} m · Max height: ${"%.2f".format(height)} m · Flight: ${"%.2f".format(flight)} s" else "Menzil: ${"%.2f".format(range)} m · En yüksek nokta: ${"%.2f".format(height)} m · Uçuş: ${"%.2f".format(flight)} s", color=p.accent, fontWeight=FontWeight.SemiBold, fontSize=11.sp)
            Text(if (english) "Ideal model: no air resistance; launch and landing heights are equal." else "İdeal model: hava direnci yoktur; atış ve iniş yükseklikleri eşittir.", color=p.muted, fontSize=10.sp)
        }
        topics.forEachIndexed { index, (title, body) ->
            var open by rememberSaveable(title) { mutableStateOf(index == 0) }
            Panel(p, Modifier.clickable { open = !open }) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text(title, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                    Icon(if(open) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.muted)
                }
                if(open) Text(body, color=p.text, lineHeight=21.sp, modifier=Modifier.padding(top=7.dp))
            }
        }
    }
}

private data class TechLesson(val id: String, val titleTr: String, val titleEn: String, val introTr: String, val introEn: String, val principlesTr: List<String>, val principlesEn: List<String>, val examplesTr: List<String>, val examplesEn: List<String>, val model: String?)

private val techLessons = listOf(
    TechLesson("3d", "3B baskı", "3D printing", "Dijital bir tasarımı fiziksel parçaya dönüştüren eklemeli üretim yöntemidir.", "An additive manufacturing process that turns a digital design into a physical part.", listOf("Model CAD yazılımında hazırlanır ve STL/3MF gibi bir biçime aktarılır.", "Dilimleyici modeli katmanlara ayırır ve yazıcı için hareket talimatları üretir.", "Yazıcı malzemeyi katman katman biriktirir; destekler ve son işlem gerekebilir."), listOf("A CAD model is exported as STL or 3MF.", "A slicer converts it into layers and machine instructions.", "The printer deposits material layer by layer; supports and post-processing may be needed."), listOf("Prototip muhafazalar", "Özel bağlantı parçaları", "Eğitim amaçlı anatomik modeller"), listOf("Prototype enclosures", "Custom brackets", "Educational anatomical models"), "circuit"),
    TechLesson("ai", "Yapay zekâ", "Artificial intelligence", "Yapay zekâ, veriden örüntü çıkaran ve belirli görevlerde tahmin veya içerik üreten sistemleri kapsar.", "AI covers systems that learn patterns from data and make predictions or generate content.", listOf("Veri hazırlanır ve eğitim, doğrulama, test kümelerine ayrılır.", "Model parametrelerini eğitim verisi üzerinde optimize eder.", "Performans görülmemiş veride ölçülür; hata, önyargı ve güvenlik ayrıca değerlendirilir."), listOf("Data is prepared and split into training, validation and test sets.", "The model optimizes parameters using training data.", "Performance is measured on unseen data; errors, bias and safety are evaluated."), listOf("Görüntü sınıflandırma", "Konuşma tanıma", "Öneri sistemleri"), listOf("Image classification", "Speech recognition", "Recommendation systems"), null),
    TechLesson("robotics", "Robotik", "Robotics", "Robotik; algılama, karar verme ve hareketi tek bir sistemde birleştirir.", "Robotics combines sensing, decision-making and motion in one system.", listOf("Sensörler çevreden ölçüm alır.", "Denetleyici hedef ile ölçülen durumu karşılaştırır.", "Motorlar ve aktüatörler komutları fiziksel harekete dönüştürür."), listOf("Sensors measure the environment.", "A controller compares target and measured states.", "Motors and actuators turn commands into physical motion."), listOf("Endüstriyel robot kolları", "Depo taşıma robotları", "Cerrahi destek sistemleri"), listOf("Industrial robot arms", "Warehouse mobile robots", "Surgical assistance systems"), "circuit"),
    TechLesson("nano", "Nanoteknoloji", "Nanotechnology", "Nanoteknoloji, yaklaşık 1–100 nanometre ölçeğinde malzeme ve yapıların özelliklerini inceler.", "Nanotechnology studies materials and structures at roughly the 1–100 nanometre scale.", listOf("Yüzey alanı/hacim oranı çok büyüyebilir.", "Kuantum ve yüzey etkileri malzeme davranışını değiştirebilir.", "Özellikler ölçüm yöntemi ve parçacık boyutuna bağlıdır."), listOf("Surface-area-to-volume ratio can become very large.", "Quantum and surface effects can change material behaviour.", "Properties depend on measurement method and particle size."), listOf("Kaplamalar", "Sensörler", "İlaç taşıyıcı araştırmaları"), listOf("Coatings", "Sensors", "Drug-delivery research"), null),
    TechLesson("semiconductor", "Yarı iletkenler", "Semiconductors", "Yarı iletkenlerin iletkenliği katkılama, sıcaklık ve elektrik alanla kontrol edilebilir.", "Semiconductor conductivity can be controlled through doping, temperature and electric fields.", listOf("Saf silisyum kristal yapı oluşturur.", "Katkılama serbest elektron veya delik yoğunluğunu değiştirir.", "PN birleşimleri diyot ve transistörlerin temelini oluşturur."), listOf("Pure silicon forms a crystal lattice.", "Doping changes free-electron or hole concentration.", "PN junctions form the basis of diodes and transistors."), listOf("İşlemciler", "Güneş hücreleri", "LED ve güç elektroniği"), listOf("Processors", "Solar cells", "LEDs and power electronics"), "circuit"),
    TechLesson("battery", "Batarya teknolojileri", "Battery technology", "Bataryalar kimyasal enerjiyi elektrokimyasal tepkimelerle elektrik enerjisine dönüştürür.", "Batteries convert chemical energy into electrical energy through electrochemical reactions.", listOf("Anot ve katot elektrotları redoks tepkimelerine katılır.", "İyonlar elektrolit içinde, elektronlar dış devrede hareket eder.", "Kapasite, enerji yoğunluğu, güç, çevrim ömrü ve güvenlik birlikte değerlendirilir."), listOf("Anode and cathode participate in redox reactions.", "Ions move through the electrolyte; electrons flow through the external circuit.", "Capacity, energy density, power, cycle life and safety are evaluated together."), listOf("Elektrikli araçlar", "Taşınabilir cihazlar", "Şebeke enerji depolama"), listOf("Electric vehicles", "Portable devices", "Grid energy storage"), "circuit"),
    TechLesson("cyber", "Siber güvenlik", "Cybersecurity", "Siber güvenlik, dijital sistemlerin ve verilerin yetkisiz erişim, değişiklik ve kesintiye karşı korunmasıdır.", "Cybersecurity protects digital systems and data against unauthorized access, alteration and disruption.", listOf("Gizlilik, bütünlük ve erişilebilirlik temel hedeflerdir.", "Kimlik doğrulama ve en az ayrıcalık ilkesi erişimi sınırlar.", "Güncellemeler, yedekler ve olay müdahalesi dayanıklılığı artırır."), listOf("Confidentiality, integrity and availability are core goals.", "Authentication and least privilege restrict access.", "Updates, backups and incident response improve resilience."), listOf("Çok faktörlü doğrulama", "Şifreli bağlantılar", "Güvenli yazılım güncellemeleri"), listOf("Multi-factor authentication", "Encrypted connections", "Secure software updates"), null),
    TechLesson("networks", "İletişim ağları", "Communication networks", "Ağlar cihazların protokoller aracılığıyla veri alışverişi yapmasını sağlar.", "Networks allow devices to exchange data using protocols.", listOf("Veri paketlere bölünür ve adreslenir.", "Yönlendiriciler paketleri uygun yola iletir.", "Gecikme, bant genişliği, kayıp ve güvenilirlik ölçülür."), listOf("Data is divided into addressed packets.", "Routers forward packets along suitable paths.", "Latency, bandwidth, loss and reliability are measured."), listOf("Wi-Fi", "Fiber optik", "Mobil ağlar"), listOf("Wi-Fi", "Fiber optics", "Mobile networks"), null),
    TechLesson("sensors", "Sensörler ve IoT", "Sensors and IoT", "Sensörler fiziksel büyüklükleri ölçülebilir sinyallere dönüştürür; IoT cihazları bu verileri ağ üzerinden paylaşır.", "Sensors convert physical quantities into measurable signals; IoT devices share these data over networks.", listOf("Algılayıcı fiziksel değişimi elektriksel sinyale çevirir.", "Analog sinyal koşullandırılır ve sayısallaştırılır.", "Mikrodenetleyici veriyi işler ve gerektiğinde ağa gönderir."), listOf("A transducer converts a physical change into an electrical signal.", "The analogue signal is conditioned and digitized.", "A microcontroller processes the data and may send it over a network."), listOf("Akıllı termostat", "Endüstriyel izleme", "Tarım sensörleri"), listOf("Smart thermostats", "Industrial monitoring", "Agricultural sensors"), "circuit")
)

private fun modelForTechTopic(id: String) = when (id) { "3d" -> "printer"; "robotics", "semiconductor", "battery", "sensors" -> "circuit"; else -> "atom" }

@Composable
private fun TechnologyKnowledgePage(p: Palette, english: Boolean, onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text(if (english) "TECHNOLOGY FIELD GUIDE" else "TEKNOLOJİ ALAN REHBERİ", color=p.accent, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=1.5.sp)
            Text(if (english) "Explore how modern systems are built" else "Modern sistemlerin nasıl çalıştığını keşfet", color=p.text, fontSize=21.sp, fontWeight=FontWeight.Bold)
            Text(if (english) "Each subject opens a complete learning page with principles, real applications and an interactive visual where available." else "Her başlık; temel ilkeler, gerçek kullanım alanları ve uygun olduğunda etkileşimli görseller içeren ayrı bir eğitim sayfası açar.", color=p.muted, fontSize=12.sp, lineHeight=18.sp)
        }
        techLessons.forEach { lesson ->
            Panel(p, Modifier.fillMaxWidth().clickable { onOpen(lesson.id) }) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(p.accent.copy(alpha=.14f)), contentAlignment=Alignment.Center) {
                        Icon(when(lesson.id) { "ai" -> Icons.Default.AutoAwesome; "3d" -> Icons.Default.ViewInAr; "robotics" -> Icons.Default.Build; "nano" -> Icons.Default.Science; "cyber" -> Icons.Default.Security; "networks" -> Icons.Default.Wifi; "sensors" -> Icons.Default.Memory; else -> Icons.Default.Memory }, null, tint=p.accent)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (english) lesson.titleEn else lesson.titleTr, color=p.text, fontWeight=FontWeight.Bold, fontSize=15.sp)
                        Text(if (english) lesson.introEn else lesson.introTr, color=p.muted, fontSize=11.sp, lineHeight=16.sp, maxLines=2)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint=p.accent)
                }
            }
        }
    }
}

@Composable
private fun TechnologyTopicDetailPage(p: Palette, english: Boolean, id: String, onOpenModel: () -> Unit, onBack: () -> Unit) {
    val lesson = techLessons.firstOrNull { it.id == id } ?: techLessons.first()
    val title = if (english) lesson.titleEn else lesson.titleTr
    val intro = if (english) lesson.introEn else lesson.introTr
    val principles = if (english) lesson.principlesEn else lesson.principlesTr
    val examples = if (english) lesson.examplesEn else lesson.examplesTr
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp), verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=onBack) { Icon(Icons.Default.ArrowBack, if (english) "Back" else "Geri", tint=p.accent) }
            Text(title, color=p.text, fontWeight=FontWeight.Bold, fontSize=18.sp)
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Panel(p) {
                Text(if (english) "LEARNING MODULE" else "EĞİTİM MODÜLÜ", color=p.accent, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=1.5.sp)
                Text(title, color=p.text, fontSize=23.sp, fontWeight=FontWeight.Bold)
                Text(intro, color=p.muted, fontSize=13.sp, lineHeight=20.sp)
            }
            Panel(p) {
                Text(if (english) "HOW IT WORKS" else "NASIL ÇALIŞIR?", color=p.accent, fontWeight=FontWeight.Bold)
                principles.forEachIndexed { i, item ->
                    Row(Modifier.padding(top=10.dp), verticalAlignment=Alignment.Top) {
                        Box(Modifier.size(25.dp).clip(CircleShape).background(p.accent.copy(alpha=.16f)), contentAlignment=Alignment.Center) { Text("${i+1}", color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp) }
                        Spacer(Modifier.width(9.dp)); Text(item, color=p.text, fontSize=13.sp, lineHeight=19.sp, modifier=Modifier.weight(1f))
                    }
                }
            }
            Panel(p) {
                Text(if (english) "REAL-WORLD APPLICATIONS" else "GERÇEK DÜNYADA KULLANIMI", color=p.accent, fontWeight=FontWeight.Bold)
                examples.forEach { Text("•  $it", color=p.text, fontSize=13.sp, lineHeight=19.sp, modifier=Modifier.padding(top=7.dp)) }
            }
            if (lesson.model != null) Panel(p, Modifier.fillMaxWidth().clickable(onClick=onOpenModel)) {
                Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.ViewInAr, null, tint=p.accent); Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f)) { Text(if (english) "Open interactive 3D model" else "Etkileşimli 3B modeli aç", color=p.text, fontWeight=FontWeight.Bold); Text(if (english) "Rotate and zoom the educational scene." else "Eğitim amaçlı sahneyi döndür ve yakınlaştır.", color=p.muted, fontSize=11.sp) }; Icon(Icons.Default.ArrowForward, null, tint=p.accent) }
            }
            Panel(p) {
                Text(if (english) "IMPORTANT NOTE" else "ÖNEMLİ NOT", color=p.accent, fontWeight=FontWeight.Bold)
                Text(if (english) "This module is an introductory learning resource. Engineering specifications and safety requirements depend on the exact product, material and application." else "Bu modül giriş düzeyinde bir eğitim kaynağıdır. Mühendislik değerleri ve güvenlik koşulları kullanılan ürüne, malzemeye ve uygulamaya göre değişir.", color=p.muted, fontSize=12.sp, lineHeight=18.sp)
            }
        }
    }
}

@Composable
private fun SettingsPage(
    p: Palette,
    selected: Int,
    soundOn: Boolean,
    fontIndex: Int,
    language: String,
    onTheme: (Int) -> Unit,
    onSound: (Boolean) -> Unit,
    onFont: (Int) -> Unit,
    onLanguage: (String) -> Unit,
    onReset: () -> Unit
) {
    val en = language == "en"
    var showResetDialog by rememberSaveable { mutableStateOf(false) }
    val themeNames = if (en) listOf("Observatory", "Laboratory", "Deep Space", "Aurora", "Arctic", "Graphite")
        else listOf("Gözlemevi", "Laboratuvar", "Derin Uzay", "Aurora", "Arktik", "Grafit")
    val fontNames = if (en) listOf("Modern", "Condensed", "Technical", "Serif", "Rounded", "Light")
        else listOf("Modern", "Dar", "Teknik", "Kitap", "Yuvarlak", "İnce")

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val columns = if (maxWidth >= 600.dp) 3 else 2
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = if (maxWidth >= 600.dp) 24.dp else 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(if (en) "Personalize Spectrum" else "Spectrum'u kişiselleştir", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(if (en) "Adjust the interface to your preferences." else "Arayüzü kullanım tercihlerine göre düzenle.", color = p.muted, fontSize = 13.sp, lineHeight = 19.sp)
            }

            Panel(p) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(if (en) "COLOR THEMES" else "RENK TEMALARI", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                        Text(if (en) "Choose the atmosphere" else "Uygulamanın görünümünü seç", color = p.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Surface(color = p.accent.copy(alpha = .12f), shape = RoundedCornerShape(10.dp)) {
                        Text("${selected + 1}/6", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                    }
                }
                Spacer(Modifier.height(12.dp))
                palettes.indices.toList().chunked(columns).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { index ->
                            val theme = palettes[index]
                            val active = selected == index
                            Column(
                                Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                                    .border(if (active) 2.dp else 1.dp, if (active) p.accent else p.muted.copy(alpha = .22f), RoundedCornerShape(14.dp))
                                    .clickable { onTheme(index) }.padding(9.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(9.dp))
                                    .background(Brush.horizontalGradient(listOf(theme.bg, theme.panel, theme.accent))), contentAlignment = Alignment.Center) {
                                    if (active) Icon(Icons.Default.CheckCircle, contentDescription = if (en) "Selected" else "Seçili", tint = theme.text, modifier = Modifier.size(22.dp))
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(themeNames[index], color = p.text, fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1)
                                    if (active) Icon(Icons.Default.Check, null, tint = p.accent, modifier = Modifier.size(15.dp))
                                }
                            }
                        }
                        repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }

            Panel(p) {
                Text(if (en) "TYPOGRAPHY" else "YAZI TİPİ", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Text(if (en) "Select a reading style" else "Okuma stilini belirle", color = p.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(9.dp))
                fontNames.indices.toList().chunked(columns).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { index ->
                            FilterChip(
                                modifier = Modifier.weight(1f),
                                selected = fontIndex == index,
                                onClick = { onFont(index) },
                                label = { Text(fontNames[index], fontSize = 11.sp, maxLines = 1) },
                                leadingIcon = if (fontIndex == index) ({ Icon(Icons.Default.Check, null, modifier = Modifier.size(15.dp)) }) else null
                            )
                        }
                        repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }

            Panel(p) {
                Text(if (en) "LANGUAGE" else "DİL", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Text(if (en) "Interface language" else "Uygulama arayüz dili", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    FilterChip(modifier = Modifier.weight(1f), selected = language == "tr", onClick = { onLanguage("tr") }, label = { Text("Türkçe") }, leadingIcon = if (language == "tr") ({ Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp)) }) else null)
                    FilterChip(modifier = Modifier.weight(1f), selected = language == "en", onClick = { onLanguage("en") }, label = { Text("English") }, leadingIcon = if (language == "en") ({ Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp)) }) else null)
                }
                HorizontalDivider(color = p.muted.copy(alpha = .18f), modifier = Modifier.padding(vertical = 8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(if (en) "Interface sounds" else "Arayüz sesleri", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(if (en) "Short sounds for navigation and selection" else "Gezinme ve seçimlerde kısa sesler", color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
                    }
                    Switch(checked = soundOn, onCheckedChange = onSound)
                }
            }

            Panel(p) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = p.accent.copy(alpha = .12f), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Default.ViewInAr, null, tint = p.accent, modifier = Modifier.padding(11.dp).size(23.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(if (en) "Offline 3D laboratory" else "Çevrimdışı 3B laboratuvar", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(if (en) "Scientific scenes are bundled with the app and load locally." else "Bilimsel sahneler uygulama içinde bulunur ve yerel olarak yüklenir.", color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
                    }
                    Icon(Icons.Default.CheckCircle, null, tint = p.accent, modifier = Modifier.size(19.dp))
                }
            }

            Panel(p) {
                Text(if (en) "ABOUT SPECTRUM" else "SPECTRUM HAKKINDA", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Spectrum 1.7.3", color = p.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(if (en) "Science learning platform · Build 26" else "Bilim öğrenme platformu · Derleme 26", color = p.muted, fontSize = 11.sp)
                        Text(if (en) "Created by Elyionn" else "Elyionn tarafından oluşturulmuştur", color = p.muted, fontSize = 11.sp)
                    }
                    Surface(color = p.accent.copy(alpha = .12f), shape = RoundedCornerShape(10.dp)) {
                        Text("1.7.3", color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp))
                    }
                }
                HorizontalDivider(color = p.muted.copy(alpha = .18f), modifier = Modifier.padding(vertical = 10.dp))
                OutlinedButton(onClick = { showResetDialog = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Restore, null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (en) "Restore default settings" else "Varsayılan ayarları geri yükle")
                }
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text(if (en) "Restore defaults?" else "Varsayılan ayarlar geri yüklensin mi?") },
            text = { Text(if (en) "Theme, typography, language and sound preferences will return to their initial values." else "Tema, yazı tipi, dil ve ses tercihleri başlangıç değerlerine döndürülür.") },
            confirmButton = { TextButton(onClick = { showResetDialog = false; onReset() }) { Text(if (en) "Restore" else "Geri yükle") } },
            dismissButton = { TextButton(onClick = { showResetDialog = false }) { Text(if (en) "Cancel" else "İptal") } },
            containerColor = p.panel,
            titleContentColor = p.text,
            textContentColor = p.muted
        )
    }
}
