package com.elyionn.spektrum

import androidx.compose.ui.graphics.Color
import java.text.Normalizer
import java.util.Locale

// Periodic-table reference data and formatting helpers are kept separate from UI code.
val elementRows = listOf(
"H|Hidrojen|1|1.008|Ametal", "He|Helyum|2|4.0026|Soygaz", "Li|Lityum|3|6.94|Alkali metal", "Be|Berilyum|4|9.0122|Toprak alkali", "B|Bor|5|10.81|Yarı metal", "C|Karbon|6|12.011|Ametal", "N|Azot|7|14.007|Ametal", "O|Oksijen|8|15.999|Ametal", "F|Flor|9|18.998|Halojen", "Ne|Neon|10|20.180|Soygaz",
"Na|Sodyum|11|22.990|Alkali metal", "Mg|Magnezyum|12|24.305|Toprak alkali", "Al|Alüminyum|13|26.982|Metal", "Si|Silisyum|14|28.085|Yarı metal", "P|Fosfor|15|30.974|Ametal", "S|Kükürt|16|32.06|Ametal", "Cl|Klor|17|35.45|Halojen", "Ar|Argon|18|39.948|Soygaz",
"K|Potasyum|19|39.098|Alkali metal", "Ca|Kalsiyum|20|40.078|Toprak alkali", "Sc|Skandiyum|21|44.956|Geçiş metali", "Ti|Titanyum|22|47.867|Geçiş metali", "V|Vanadyum|23|50.942|Geçiş metali", "Cr|Krom|24|51.996|Geçiş metali", "Mn|Manganez|25|54.938|Geçiş metali", "Fe|Demir|26|55.845|Geçiş metali", "Co|Kobalt|27|58.933|Geçiş metali", "Ni|Nikel|28|58.693|Geçiş metali", "Cu|Bakır|29|63.546|Geçiş metali", "Zn|Çinko|30|65.38|Geçiş metali", "Ga|Galyum|31|69.723|Metal", "Ge|Germanyum|32|72.630|Yarı metal", "As|Arsenik|33|74.922|Yarı metal", "Se|Selenyum|34|78.971|Ametal", "Br|Brom|35|79.904|Halojen", "Kr|Kripton|36|83.798|Soygaz",
"Rb|Rubidyum|37|85.468|Alkali metal", "Sr|Stronsiyum|38|87.62|Toprak alkali", "Y|İtriyum|39|88.906|Geçiş metali", "Zr|Zirkonyum|40|91.224|Geçiş metali", "Nb|Niyobyum|41|92.906|Geçiş metali", "Mo|Molibden|42|95.95|Geçiş metali", "Tc|Teknesyum|43|98|Geçiş metali", "Ru|Rutenyum|44|101.07|Geçiş metali", "Rh|Rodyum|45|102.91|Geçiş metali", "Pd|Paladyum|46|106.42|Geçiş metali", "Ag|Gümüş|47|107.87|Geçiş metali", "Cd|Kadmiyum|48|112.41|Geçiş metali", "In|İndiyum|49|114.82|Metal", "Sn|Kalay|50|118.71|Metal", "Sb|Antimon|51|121.76|Yarı metal", "Te|Tellür|52|127.60|Yarı metal", "I|İyot|53|126.90|Halojen", "Xe|Ksenon|54|131.29|Soygaz",
"Cs|Sezyum|55|132.91|Alkali metal", "Ba|Baryum|56|137.33|Toprak alkali", "La|Lantan|57|138.91|Lantanit", "Ce|Seryum|58|140.12|Lantanit", "Pr|Praseodim|59|140.91|Lantanit", "Nd|Neodimyum|60|144.24|Lantanit", "Pm|Prometyum|61|145|Lantanit", "Sm|Samaryum|62|150.36|Lantanit", "Eu|Evropiyum|63|151.96|Lantanit", "Gd|Gadolinyum|64|157.25|Lantanit", "Tb|Terbiyum|65|158.93|Lantanit", "Dy|Disprozyum|66|162.50|Lantanit", "Ho|Holmiyum|67|164.93|Lantanit", "Er|Erbiyum|68|167.26|Lantanit", "Tm|Tulyum|69|168.93|Lantanit", "Yb|İterbiyum|70|173.05|Lantanit", "Lu|Lutesyum|71|174.97|Lantanit",
"Hf|Hafniyum|72|178.49|Geçiş metali", "Ta|Tantal|73|180.95|Geçiş metali", "W|Tungsten|74|183.84|Geçiş metali", "Re|Renyum|75|186.21|Geçiş metali", "Os|Osmiyum|76|190.23|Geçiş metali", "Ir|İridyum|77|192.22|Geçiş metali", "Pt|Platin|78|195.08|Geçiş metali", "Au|Altın|79|196.97|Geçiş metali", "Hg|Cıva|80|200.59|Geçiş metali", "Tl|Talyum|81|204.38|Metal", "Pb|Kurşun|82|207.2|Metal", "Bi|Bizmut|83|208.98|Metal", "Po|Polonyum|84|209|Yarı metal", "At|Astatin|85|210|Halojen", "Rn|Radon|86|222|Soygaz",
"Fr|Fransiyum|87|223|Alkali metal", "Ra|Radyum|88|226|Toprak alkali", "Ac|Aktinyum|89|227|Aktinit", "Th|Toryum|90|232.04|Aktinit", "Pa|Protaktinyum|91|231.04|Aktinit", "U|Uranyum|92|238.03|Aktinit", "Np|Neptünyum|93|237|Aktinit", "Pu|Plütonyum|94|244|Aktinit", "Am|Amerikyum|95|243|Aktinit", "Cm|Küriyum|96|247|Aktinit", "Bk|Berkelyum|97|247|Aktinit", "Cf|Kaliforniyum|98|251|Aktinit", "Es|Einsteinyum|99|252|Aktinit", "Fm|Fermiyum|100|257|Aktinit", "Md|Mendelevyum|101|258|Aktinit", "No|Nobelyum|102|259|Aktinit", "Lr|Lavrensiyum|103|266|Aktinit", "Rf|Rutherfordiyum|104|267|Geçiş metali", "Db|Dubniyum|105|268|Geçiş metali", "Sg|Seaborgiyum|106|269|Geçiş metali", "Bh|Bohriyum|107|270|Geçiş metali", "Hs|Hassiyum|108|269|Geçiş metali", "Mt|Meitneriyum|109|278|Bilinmiyor", "Ds|Darmstadtiyum|110|281|Bilinmiyor", "Rg|Röntgenyum|111|282|Bilinmiyor", "Cn|Kopernikyum|112|285|Bilinmiyor", "Nh|Nihonyum|113|286|Bilinmiyor", "Fl|Flerovyum|114|289|Bilinmiyor", "Mc|Moskovyum|115|290|Bilinmiyor", "Lv|Livermoryum|116|293|Bilinmiyor", "Ts|Tennessin|117|294|Halojen", "Og|Oganesson|118|294|Soygaz"
).map { it.split('|') }

val periodicTableRows: List<List<Int?>> = listOf(
    listOf<Int?>(1) + List(16) { null } + listOf(2),
    listOf<Int?>(3, 4) + List(10) { null } + listOf(5, 6, 7, 8, 9, 10),
    listOf<Int?>(11, 12) + List(10) { null } + listOf(13, 14, 15, 16, 17, 18),
    (19..36).map { it }, (37..54).map { it },
    listOf<Int?>(55, 56, null) + (72..86).map { it },
    listOf<Int?>(87, 88, null) + (104..118).map { it },
    listOf<Int?>(null, null, null) + (57..71).map { it },
    listOf<Int?>(null, null, null) + (89..103).map { it }
)

private val covalentRadiiPm = intArrayOf(0, 31, 28, 128, 96, 84, 76, 71, 66, 57, 58, 166, 141, 121, 111, 107, 105, 102, 106, 203, 176, 170, 160, 152, 139, 139, 132, 126, 124, 132, 122, 122, 120, 119, 120, 120, 116, 220, 195, 190, 175, 164, 154, 147, 146, 142, 139, 145, 144, 142, 139, 139, 138, 139, 140, 244, 215, 207, 204, 203, 201, 199, 198, 198, 196, 194, 192, 192, 189, 190, 187, 187, 175, 170, 162, 151, 144, 141, 136, 136, 132, 145, 146, 148, 140, 150, 150, 260, 220, 215, 206, 200, 196, 190, 187, 180, 169, 190, 190, 190, 190, 190, 190, 190)
private val englishNames = listOf(
    "Hydrogen", "Helium", "Lithium", "Beryllium", "Boron", "Carbon", "Nitrogen", "Oxygen",
    "Fluorine", "Neon", "Sodium", "Magnesium", "Aluminium", "Silicon", "Phosphorus", "Sulfur",
    "Chlorine", "Argon", "Potassium", "Calcium", "Scandium", "Titanium", "Vanadium", "Chromium",
    "Manganese", "Iron", "Cobalt", "Nickel", "Copper", "Zinc", "Gallium", "Germanium",
    "Arsenic", "Selenium", "Bromine", "Krypton", "Rubidium", "Strontium", "Yttrium", "Zirconium",
    "Niobium", "Molybdenum", "Technetium", "Ruthenium", "Rhodium", "Palladium", "Silver", "Cadmium",
    "Indium", "Tin", "Antimony", "Tellurium", "Iodine", "Xenon", "Caesium", "Barium",
    "Lanthanum", "Cerium", "Praseodymium", "Neodymium", "Promethium", "Samarium", "Europium", "Gadolinium",
    "Terbium", "Dysprosium", "Holmium", "Erbium", "Thulium", "Ytterbium", "Lutetium", "Hafnium",
    "Tantalum", "Tungsten", "Rhenium", "Osmium", "Iridium", "Platinum", "Gold", "Mercury",
    "Thallium", "Lead", "Bismuth", "Polonium", "Astatine", "Radon", "Francium", "Radium",
    "Actinium", "Thorium", "Protactinium", "Uranium", "Neptunium", "Plutonium", "Americium", "Curium",
    "Berkelium", "Californium", "Einsteinium", "Fermium", "Mendelevium", "Nobelium", "Lawrencium", "Rutherfordium",
    "Dubnium", "Seaborgium", "Bohrium", "Hassium", "Meitnerium", "Darmstadtium", "Roentgenium", "Copernicium",
    "Nihonium", "Flerovium", "Moscovium", "Livermorium", "Tennessine", "Oganesson"
)
fun englishElementName(z: Int): String = englishNames.getOrNull(z - 1) ?: "Element"

fun normalizeElementSearch(value: String): String =
    Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace('ı', 'i')

fun covalentRadiusPm(z: Int): Int? = if (z in 1..103) covalentRadiiPm.getOrNull(z) else null

fun elementFamilyColor(kind: String): Color = when (kind) {
    "Alkali metal" -> Color(0xFFE57373)
    "Toprak alkali" -> Color(0xFFFFB74D)
    "Geçiş metali" -> Color(0xFFFFD54F)
    "Metal" -> Color(0xFFAED581)
    "Yarı metal" -> Color(0xFF4DB6AC)
    "Ametal" -> Color(0xFF4FC3F7)
    "Halojen" -> Color(0xFF7986CB)
    "Soygaz" -> Color(0xFFBA68C8)
    "Lantanit" -> Color(0xFFF06292)
    "Aktinit" -> Color(0xFF9575CD)
    else -> Color(0xFF90A4AE)
}

fun elementPeriod(z: Int): Int = when (z) {
    in 1..2 -> 1
    in 3..10 -> 2
    in 11..18 -> 3
    in 19..36 -> 4
    in 37..54 -> 5
    in 55..86 -> 6
    else -> 7
}

fun elementGroup(z: Int): String = when (z) {
    1 -> "1"; 2 -> "18"
    in 3..4 -> (z - 2).toString()
    in 5..10 -> (z + 8).toString()
    in 11..12 -> (z - 10).toString()
    in 13..18 -> (z + 2).toString()
    in 19..36 -> (z - 18).toString()
    in 37..54 -> (z - 36).toString()
    in 55..56 -> (z - 54).toString()
    in 57..71 -> "3 · f-blok"
    in 72..86 -> (z - 68).toString()
    in 87..88 -> (z - 86).toString()
    in 89..103 -> "3 · f-blok"
    else -> (z - 100).toString()
}

fun elementBlock(z: Int): String = when {
    z == 2 -> "s"
    z in 57..71 || z in 89..103 -> "f"
    elementGroup(z).substringBefore(" ").toIntOrNull()?.let { it in 1..2 } == true -> "s"
    elementGroup(z).substringBefore(" ").toIntOrNull()?.let { it in 13..18 } == true -> "p"
    else -> "d"
}

fun elementState(z: Int): String = when (z) {
    1, 2, 7, 8, 9, 10, 17, 18, 36, 54, 86 -> "Gaz (25 °C, 1 atm)"
    35, 80 -> "Sıvı (25 °C, 1 atm)"
    in 104..118 -> "Makroskopik hâli deneysel olarak belirlenemedi"
    else -> "Katı (25 °C, 1 atm)"
}

fun elementElectronConfig(z: Int): String? = when (z) {
    1 -> "1s¹"; 2 -> "1s²"; 3 -> "[He] 2s¹"; 4 -> "[He] 2s²"
    5 -> "[He] 2s² 2p¹"; 6 -> "[He] 2s² 2p²"; 7 -> "[He] 2s² 2p³"; 8 -> "[He] 2s² 2p⁴"; 9 -> "[He] 2s² 2p⁵"; 10 -> "[He] 2s² 2p⁶"
    11 -> "[Ne] 3s¹"; 12 -> "[Ne] 3s²"; 13 -> "[Ne] 3s² 3p¹"; 14 -> "[Ne] 3s² 3p²"; 15 -> "[Ne] 3s² 3p³"; 16 -> "[Ne] 3s² 3p⁴"; 17 -> "[Ne] 3s² 3p⁵"; 18 -> "[Ne] 3s² 3p⁶"
    19 -> "[Ar] 4s¹"; 20 -> "[Ar] 4s²"; 21 -> "[Ar] 3d¹ 4s²"; 22 -> "[Ar] 3d² 4s²"; 23 -> "[Ar] 3d³ 4s²"; 24 -> "[Ar] 3d⁵ 4s¹"; 25 -> "[Ar] 3d⁵ 4s²"; 26 -> "[Ar] 3d⁶ 4s²"; 27 -> "[Ar] 3d⁷ 4s²"; 28 -> "[Ar] 3d⁸ 4s²"; 29 -> "[Ar] 3d¹⁰ 4s¹"; 30 -> "[Ar] 3d¹⁰ 4s²"
    31 -> "[Ar] 3d¹⁰ 4s² 4p¹"; 32 -> "[Ar] 3d¹⁰ 4s² 4p²"; 33 -> "[Ar] 3d¹⁰ 4s² 4p³"; 34 -> "[Ar] 3d¹⁰ 4s² 4p⁴"; 35 -> "[Ar] 3d¹⁰ 4s² 4p⁵"; 36 -> "[Ar] 3d¹⁰ 4s² 4p⁶"
    47 -> "[Kr] 4d¹⁰ 5s¹"; 53 -> "[Kr] 4d¹⁰ 5s² 5p⁵"; 79 -> "[Xe] 4f¹⁴ 5d¹⁰ 6s¹"; 80 -> "[Xe] 4f¹⁴ 5d¹⁰ 6s²"; 82 -> "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p²"; 92 -> "[Rn] 5f³ 6d¹ 7s²"
    else -> null
}

fun elementElectronConfigNote(z: Int): String = elementElectronConfig(z)
    ?: if (z >= 104) "Bu süper ağır elementin elektron yapısı teorik hesaplamalara dayanır; deneysel doğrulama sınırlıdır."
    else "Tam orbital dizilimi bu ekranda henüz kaynaklı veriyle doğrulanmadı. Yanlış bir dizilim göstermek yerine alan boş bırakıldı."

fun elementEducation(e: List<String>): String {
    val symbol = e[0]
    val kind = e[4]
    val known = mapOf(
        "H" to "Hidrojen en hafif elementtir. En yaygın izotopu bir proton ve bir elektrondan oluşur. Yıldızlarda proton-proton zinciri ve diğer füzyon süreçlerinde enerji açığa çıkmasının temel yakıtıdır. Su ve organik bileşiklerin yapısında bulunur.",
        "He" to "Helyumun atom numarası 2'dir ve kapalı 1s² elektron kabuğu nedeniyle kimyasal tepkimeye girme eğilimi çok düşüktür. Çok düşük kaynama sıcaklığı, kriyojenik soğutma ve süperiletken mıknatıs sistemlerinde önemlidir.",
        "Li" to "Lityum en hafif metaldir. Li⁺ iyonlarının elektrotlar arasında hareket edebilmesi, lityum-iyon pillerin şarj ve deşarj mekanizmasının temelidir. Seramik ve cam bileşiklerinde de kullanılır.",
        "C" to "Karbon dört değerlik elektronu sayesinde çok çeşitli kovalent bağlar kurabilir. Elmas, grafit ve grafen aynı elementin farklı allotroplarıdır. Organik kimyanın ve bilinen yaşam kimyasının temel iskeletini oluşturur.",
        "N" to "Azot atmosferin yaklaşık %78'ini N₂ gazı olarak oluşturur. N₂ molekülündeki üçlü bağın koparılması enerji gerektirir. Azot bağlanması ve Haber-Bosch süreci, biyolojik azot döngüsü ile gübre üretiminde önemlidir.",
        "O" to "Oksijen atmosferde O₂ hâlinde bulunur ve aerobik hücresel solunumda elektron alıcısı olarak görev yapar. Oksijenin allotroplarından ozon (O₃), stratosferde Güneş'in morötesi ışınımının bir bölümünü soğurur.",
        "Na" to "Sodyum bir alkali metaldir ve nötr atomunun dış kabuğunda bir 3s elektronu bulunur. Bileşiklerinde çoğunlukla +1 yükseltgenme basamağındadır. Sodyum iyonları sinir hücrelerinin zar potansiyelinde ve sıvı dengesinde rol oynar.",
        "Mg" to "Magnezyum hafif bir toprak alkali metaldir. Klorofil molekülünün merkezinde Mg²⁺ bulunur. Hafif alaşımlar, piroteknik ışık kaynakları ve biyolojik enzim sistemleri açısından önemlidir.",
        "Al" to "Alüminyum düşük yoğunluklu, elektrik ve ısı iletkenliği iyi bir metaldir. Yüzeyinde oluşan ince alüminyum oksit tabakası korozyonu yavaşlatır. Ambalaj, ulaşım, yapı ve elektrik iletiminde kullanılır.",
        "Si" to "Silisyum yarı iletken teknolojisinin temel malzemelerindendir. Kristal yapısına kontrollü katkılama yapılarak p-tipi ve n-tipi bölgeler oluşturulur. Silisyum dioksit ise kum ve birçok camın ana bileşenidir.",
        "P" to "Fosfor DNA ve RNA'nın fosfat omurgasında, ATP'de ve kemik mineralinde bulunur. Elementel fosfor farklı allotroplara sahiptir; beyaz fosfor oldukça reaktif, kırmızı fosfor ise daha kararlıdır.",
        "S" to "Kükürt proteinlerdeki bazı amino asitlerin yapısında bulunur. İki sistein kalıntısı arasında oluşabilen disülfit bağları proteinlerin üç boyutlu yapısını kararlı hâle getirebilir. Sülfürik asit üretimi büyük ölçekli kimya sanayisinin temel süreçlerindendir.",
        "Cl" to "Klor bir halojendir. Cl₂ güçlü bir oksitleyici ve dezenfektan olarak kontrollü su arıtımında kullanılır; klorür iyonu ise sofra tuzu ve canlıların elektrolit dengesinin parçasıdır. Elementel klor ile klorür iyonunun özellikleri aynı değildir.",
        "K" to "Potasyum bir alkali metaldir. K⁺ iyonu hücre içi sıvının başlıca katyonudur ve sinir iletimi, kas işlevi ile hücresel elektriksel dengenin sürdürülmesine katkıda bulunur.",
        "Ca" to "Kalsiyum kemik ve dişlerde hidroksiapatit mineralinin önemli bileşenidir. Ca²⁺ iyonları kas kasılması, hücre içi sinyal iletimi, kan pıhtılaşması ve birçok enzimin düzenlenmesinde görev alır.",
        "Fe" to "Demir geçiş metalidir. Hemoglobindeki hem grubu oksijenin akciğerlerden dokulara taşınmasına yardımcı olur. Demir ayrıca sitokromlar ve elektron taşıma zincirindeki proteinlerde bulunur.",
        "Cu" to "Bakır elektrik ve ısıyı iyi iletir. Elektrik kabloları, motor sargıları ve elektronik bileşenlerde yaygındır. Canlılarda bazı oksidasyon-indirgenme enzimlerinin aktif merkezinde bakır iyonları bulunur.",
        "Zn" to "Çinko birçok enzimin yapısal veya katalitik bileşenidir. Galvanizleme işlemi çeliğin yüzeyini çinko ile kaplayarak korozyona karşı korur. Bileşiklerinde çoğunlukla +2 iyonu oluşturur.",
        "Ag" to "Gümüş görünür ışığı iyi yansıtır ve metaller arasında en yüksek elektrik iletkenliğine sahiptir. Elektronik kontaklar, özel kaplamalar ve bazı fotoğrafçılık kimyasallarında kullanılır.",
        "I" to "İyot tiroit hormonları T₃ ve T₄'ün yapısında bulunur. İyot eksikliği tiroit hormon üretimini etkileyebilir. Elementel iyot ile iyodür tuzları kimyasal açıdan farklı türlerdir.",
        "Au" to "Altın kimyasal olarak görece kararlı ve dövülebilir bir metaldir. Korozyona dayanımı, elektrik kontaklarında güvenilir yüzeyler oluşturmasını sağlar. Mücevherat, elektronik ve bazı kataliz uygulamalarında kullanılır.",
        "Hg" to "Cıva oda sıcaklığında sıvı olan iki elementten biridir. Yoğunluğu yüksektir; ancak cıva ve birçok bileşiği toksiktir. Eski ölçüm cihazlarında kullanılmış olsa da sağlık ve çevre riskleri nedeniyle kullanımı birçok alanda sınırlandırılmıştır.",
        "Pb" to "Kurşun yoğun ve yumuşak bir metaldir. Kurşun-asit akülerde elektrot malzemesi olarak kullanılır. Kurşun ve bileşiklerinin sinir sistemi üzerindeki toksik etkileri nedeniyle maruziyetin önlenmesi gerekir.",
        "U" to "Uranyum doğal olarak bulunan ağır bir aktinittir. U-235 fisil bir izotoptur; U-238 ise uranyum serisinin ve jeokronolojide kullanılan uranyum-kurşun tarihleme yöntemlerinin parçasıdır. İzotopların özellikleri birbirinden ayrılmalıdır."
    )
    return known[symbol] ?: when (kind) {
        "Alkali metal" -> "${e[1]} alkali metaller grubundadır. Bu grupta dış elektron düzeni genel olarak ns¹ biçimindedir ve elementler çoğunlukla +1 iyon oluşturur. Tepkime eğilimleri ve fiziksel özellikleri grupta aşağı doğru değişir. Saf metalin davranışı bileşiklerinin davranışından farklıdır."
        "Toprak alkali" -> "${e[1]} toprak alkali metaller grubundadır. Genel değerlik elektron düzeni ns²'dir ve bileşiklerinde +2 yükseltgenme basamağı yaygındır. Karbonatlar, oksitler ve sülfatlar gibi bileşikleri jeoloji, malzeme bilimi ve endüstride önem taşır."
        "Halojen" -> "${e[1]} halojenler grubundadır. Bu elementlerin değerlik katmanında genel olarak yedi elektron bulunur; birçok bileşikte −1 yükseltgenme basamağı gösterirler. Moleküler hâlleri, reaktiviteleri ve fiziksel durumları grup boyunca değişir."
        "Soygaz" -> "${e[1]} soygazlar grubundadır. Değerlik kabuklarının dolu olması, kimyasal tepkimeye girme eğilimlerini genellikle düşürür. Aydınlatma, koruyucu atmosferler, kriyojenik uygulamalar ve hassas ölçüm sistemlerinde farklı soygazlardan yararlanılır."
        "Lantanit" -> "${e[1]} lantanitler serisindedir. 4f orbitallerinin dolması manyetik, optik ve ışıldama özelliklerinde önemli rol oynar. Bazı lantanitler kalıcı mıknatıslar, fosforlar, lazer malzemeleri ve katalizörlerde kullanılır."
        "Aktinit" -> "${e[1]} aktinitler serisindedir. Bu elementlerin çekirdekleri radyoaktiftir; birçok izotopları yapay olarak üretilir. Nükleer kimya, çekirdek fiziği ve radyokimya araştırmalarında önem taşırlar."
        "Yarı metal" -> "${e[1]} yarı metal olarak sınıflandırılır. Yarı metallerin elektriksel ve kimyasal özellikleri metaller ile ametaller arasında değişebilir. Bazıları yarı iletken, alaşım, cam ve özel kimyasal malzemelerin üretiminde kullanılır."
        "Ametal" -> "${e[1]} ametaldir. Ametaller metalik parlaklık ve iletkenlik özelliklerini genellikle göstermez; kovalent bağlar veya anyonlar oluşturabilir. Elementin moleküler biçimi ve kimyasal tepkimeleri bulunduğu koşullara bağlıdır."
        "Bilinmiyor" -> "${e[1]} süper ağır, yapay olarak sentezlenen bir elementtir. Çok kısa ömürlü izotopları nedeniyle makroskopik örnekleri üzerinde olağan fiziksel ve kimyasal ölçümler yapılamamıştır. Bu nedenle birçok özellik teorik tahmin olarak kalır."
        else -> "${e[1]} bir metal elementidir. Metalik bağ, elektrik iletkenliği, dövülebilirlik ve alaşım oluşturma gibi özellikler gösterebilir. Geçiş metalleri ve p-blok metalleri arasında fiziksel özellikler ile kimyasal davranış önemli ölçüde farklılaşır."
    }
}

