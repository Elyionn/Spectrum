package com.elyionn.spektrum

import android.content.Context
import org.json.JSONArray
import java.util.Locale

// Local lesson data model, parser and category localization are isolated from Compose UI.
internal data class ScienceTopicData(
    val slug: String,
    val title: String,
    val category: String,
    val summary: String,
    val lead: String,
    val how: List<String>,
    val life: List<Pair<String, String>>,
    val facts: List<Pair<String, String>>,
    val note: String?,
    val sources: List<Pair<String, String>>,
    val isNew: Boolean
)

internal fun loadScienceTopics(context: Context): List<ScienceTopicData> = runCatching {
    val raw = context.assets.open("data/science_topics.json").bufferedReader().use { it.readText() }
    val array = JSONArray(raw)
    buildList {
        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            fun strings(key: String): List<String> {
                val a = item.optJSONArray(key) ?: return emptyList()
                return buildList { for (j in 0 until a.length()) a.optString(j).takeIf { it.isNotBlank() }?.let(::add) }
            }
            fun pairs(key: String): List<Pair<String, String>> {
                val a = item.optJSONArray(key) ?: return emptyList()
                return buildList {
                    for (j in 0 until a.length()) {
                        val o = a.optJSONObject(j) ?: continue
                        add(o.optString("title", o.optString("k", "Bilgi")) to o.optString("text", o.optString("v", "")))
                    }
                }
            }
            val sourceArray = item.optJSONArray("sources")
            val sources = buildList {
                if (sourceArray != null) for (j in 0 until sourceArray.length()) {
                    val source = sourceArray.optJSONObject(j) ?: continue
                    val title = source.optString("title")
                    val url = source.optString("url")
                    if (title.isNotBlank() && url.startsWith("https://")) add(title to url)
                }
            }
            add(ScienceTopicData(
                slug = item.optString("slug"), title = item.optString("title"),
                category = item.optString("category"), summary = item.optString("summary"),
                lead = item.optString("lead"), how = strings("how"), life = pairs("life"),
                facts = pairs("facts"), note = item.optString("note").takeIf { it.isNotBlank() && it != "null" },
                sources = sources,
                isNew = item.optBoolean("isNew", false)
            ))
        }
    }
}.getOrElse { emptyList() }

internal fun topicCategoryLabel(id: String, english: Boolean = false): String = when (id.lowercase(Locale.ROOT)) {
    "biyoloji", "biology" -> if (english) "Biology" else "Biyoloji"
    "elektronik", "electronics", "technology" -> if (english) "Technology & Electronics" else "Teknoloji & Elektronik"
    "fizik", "physics" -> if (english) "Physics & Electricity" else "Fizik & Elektrik"
    "kimya", "chemistry" -> if (english) "Chemistry" else "Kimya"
    "matematik", "mathematics", "math" -> if (english) "Mathematics" else "Matematik"
    "uzay", "space", "astronomy" -> if (english) "Space & Astronomy" else "Uzay & Astronomi"
    "geology", "yer_bilimleri", "yer bilimleri", "earth science" -> if (english) "Earth Science" else "Yer Bilimleri"
    else -> id.replaceFirstChar { it.uppercase(Locale.ROOT) }
}

