# Spectrum 1.6.4 — Performance and code review

## Changes made
- Science lesson JSON is now read and parsed on `Dispatchers.IO` rather than synchronously during the first composition.
- 3D lab animation is paused by default and can be enabled from the existing rotate control.
- WebGL pixel ratio is capped at 1.25 on the bundled Three.js lab.
- Three.js scene objects are removed from the scene graph before GPU resource disposal; the lab resize observer is disconnected on page exit.
- Chemistry now uses the same bundled offline Three.js water model through `WebViewAssetLoader`, resolving the missing `Molecule3DView` function in the supplied source ZIP.
- Isotope reference masses use a top-level immutable map rather than constructing a new map per call.

## Not measured
No Android device, emulator, Android Studio Profiler, Macrobenchmark, or GPU profiler was available during this source edit. Startup, frame-time, memory, thermal, and battery improvements are therefore not quantified. These changes are code-level optimizations, not measured performance claims.
