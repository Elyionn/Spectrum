# Spectrum 1.7.1 — Stability, performance and settings update

## 3D laboratory reliability
- Fixed the WebView loading policy for the local `appassets.androidplatform.net` virtual HTTPS origin. Network loads are no longer globally blocked before the local asset loader can serve the bundled page.
- Added strict request interception: only HTTPS requests to the appassets virtual host are served; all other hosts are rejected.
- Added JavaScript-to-Android readiness and failure reporting, WebView main-frame error reporting, HTTP error reporting, console diagnostics and a retry action instead of a silent blank panel.
- Kept Three.js and all 48 registered scenes local and offline.
- Reduced the WebGL pixel-ratio cap to 1.15 and retained demand-driven rendering to reduce GPU load.

## Performance
- Rebuilt Search results with `LazyColumn` so only visible rows are composed.
- Precomputed normalized lesson search text when the dataset or interface language changes, instead of rebuilding the full search corpus on every keystroke.
- Kept element search bounded to the first 12 matches.
- Avoided global WebView timer pausing during local lab disposal.

## Settings and identity
- Rebuilt Settings as compact sections with smaller spacing and a reduced visual footprint.
- Expanded themes from 3 to 6: Dark Observatory, Light Laboratory, Deep Space, Aurora Field, Arctic Signal and Graphite Lab.
- Expanded system typefaces from 4 to 6: Modern, Condensed, Technical, Serif, Rounded and Light. Existing saved font indexes retain their prior meanings.
- Replaced the previous glowing AI-like mark with a restrained geometric refractive prism logo, supplied as a high-resolution PNG and editable SVG; updated the vector drawable too.
- Corrected all user-visible version labels to 1.7.1 and set `versionCode` to 24.

## Preserved
- Application ID: `com.elyionn.spectrum`.
- Namespace: `com.elyionn.spektrum`.
- Existing 151 lesson records, 118 periodic-table elements, category structure and 48 3D scene registrations.
- Existing home, explore, lesson, element, language and sound functionality.

## Verification boundaries
- Source-level XML, JSON, JavaScript, model-registry, ZIP and YAML checks passed.
- Android Gradle compilation, JUnit execution, APK creation and physical-device WebGL/GPU tests are not claimed as completed here.
