# Spectrum 1.7.3 — Optimizasyon, Tema ve Stil

## Arayüz ve ayarlar
- Yeniden düzenlenen Ayarlar ekranı: temalar artık dar altı sütunlu bir sıraya sıkıştırılmıyor; telefonlarda iki, geniş ekranlarda üç sütun halinde sunuluyor.
- Tema kartları, yazı tipi seçenekleri ve dil seçimleri daha büyük dokunma alanları ve okunabilir etiketlerle düzenlendi.
- Ses, dil, tema ve yazı tipi ayarları mevcut kalıcı tercih deposuyla korunuyor.
- Varsayılan ayarları geri yükleme eklendi; değişiklik öncesinde onay isteniyor.
- Ayarlar sayfası kullanılabilir ekran genişliğini dolduruyor; sabit dar içerik genişliği kullanılmıyor.

## Sürüm
- `versionName`: `1.7.3`
- `versionCode`: `26`
- Application ID ve namespace değişmedi.
- Mevcut bilim içeriği, periyodik tablo kayıtları ve 3B sahneler korundu.

## Arşiv ve derleme
- Kaynak ZIP yeniden üretildi; kök klasör sarmalayıcısı kaldırılarak Gradle proje dosyaları arşivin köküne alındı. Bu, bazı mobil arşiv yöneticilerinin iç içe klasör yapısında çıkardığı sorunları azaltır.
- ZIP CRC/integrity ve güvenli çıkarma kontrolleri yapıldı.
- Android derlemesi bu çalışma ortamında çalıştırılamadı; GitHub Actions sonucuyla doğrulanmalıdır.
