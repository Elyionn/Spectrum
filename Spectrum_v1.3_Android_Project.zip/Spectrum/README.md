# Spectrum 1.3.0

Kotlin + Jetpack Compose tabanlı Android bilim atlası.

## 1.3 yenilikleri
- Uygulama arayüzü ve Spectrum logosu yenilendi.
- Alt gezinme sadeleştirildi; Oyunlar sekmesi ve matematik oyunu kaldırıldı.
- 118 elementin her biri ayrı ayrıntı ekranına açılır; atom numarası, kütle, sınıf, açıklama ve Wikimedia görsel arşivi bulunur.
- Periyodik tablo kartları büyütüldü ve arama eklendi.
- İnsan vücudu bölümüne döndürülebilir şematik 3B anatomi görünümü eklendi.
- Fizik ve teknoloji içerikleri ayrı kategoriler olarak eklendi.
- Dört yeni tema ve yazı tipi seçimi eklendi.
- Tema, yazı tipi ve ses tercihleri cihazda saklanır.

## Derleme
Android Studio ile açıp `:app:assembleDebug` görevini çalıştırabilir veya `.github/workflows/android-apk.yml` GitHub Actions iş akışını kullanabilirsin.

Bazı görsel arşivleri ve NASA'nın etkileşimli 3B sahneleri internet bağlantısı gerektirir. Anatomi sahnesi eğitim amaçlı şematik bir 3B görselleştirmedir; tıbbi model değildir.
