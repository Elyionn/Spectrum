package com.elyionn.spektrum

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebSettings
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.pow
import java.text.Normalizer
import java.util.Locale
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class Palette(val name: String, val bg: Color, val panel: Color, val accent: Color, val text: Color, val muted: Color)
private val palettes = listOf(
    Palette("Kozmik", Color(0xFF081321), Color(0xFF192D45), Color(0xFF75C8FF), Color(0xFFF0F6FF), Color(0xFFB3C3D5)),
    Palette("Aurora", Color(0xFF071A19), Color(0xFF12332E), Color(0xFF73E0B5), Color(0xFFE8FFF6), Color(0xFFB0D4C8)),
    Palette("Nebula", Color(0xFF180E29), Color(0xFF2D1B49), Color(0xFFC5A0FF), Color(0xFFF6F0FF), Color(0xFFC8B8DD)),
    Palette("Arktik", Color(0xFF101C2B), Color(0xFF203B54), Color(0xFF8DD5FF), Color(0xFFEAF7FF), Color(0xFFB8CCDC)),
    Palette("Laboratuvar", Color(0xFFF1F5F7), Color(0xFFFFFFFF), Color(0xFF087F8C), Color(0xFF17232B), Color(0xFF52616B)),
    Palette("Gün Batımı", Color(0xFF24131A), Color(0xFF42232D), Color(0xFFFFAD83), Color(0xFFFFF1E9), Color(0xFFDCC0B5)),
    Palette("Obsidyen", Color(0xFF101014), Color(0xFF22232B), Color(0xFFFFD166), Color(0xFFF8F7F2), Color(0xFFB9B8C2)),
    Palette("Okyanus", Color(0xFF061B2A), Color(0xFF0E3448), Color(0xFF4DE3D0), Color(0xFFE8FBFF), Color(0xFFA7C9D5)),
    Palette("Lavanta", Color(0xFF211B31), Color(0xFF352A4B), Color(0xFFE0B8FF), Color(0xFFFAF0FF), Color(0xFFC9B9D5)),
    Palette("Zümrüt", Color(0xFF0C211A), Color(0xFF19382B), Color(0xFF9AE6A6), Color(0xFFEFFFF0), Color(0xFFB5D2BC)),
    Palette("Cosmic Dark", Color(0xFF05070F), Color(0xFF151B2B), Color(0xFF9B8CFF), Color(0xFFF4F2FF), Color(0xFFB8B5CF)),
    Palette("Deep Space", Color(0xFF030B1C), Color(0xFF102747), Color(0xFF5CC8FF), Color(0xFFE8F5FF), Color(0xFF9FBBD2)),
    Palette("Arctic", Color(0xFF0D202B), Color(0xFF1B3A4A), Color(0xFF7DE3F5), Color(0xFFEAFBFF), Color(0xFFA9C9D2)),
    Palette("Laboratory", Color(0xFF101A18), Color(0xFF1C302B), Color(0xFF7CE0B1), Color(0xFFEFFFF6), Color(0xFFA9CDBB)),
    Palette("Graphite", Color(0xFF17191D), Color(0xFF292D34), Color(0xFFE0B56B), Color(0xFFF3F3F0), Color(0xFFB9BDC4)),
    Palette("Light Science", Color(0xFFF3F7FA), Color(0xFFFFFFFF), Color(0xFF176D91), Color(0xFF152630), Color(0xFF536A77))
)

val elementRows = listOf(
"H|Hidrojen|1|1.008|Ametal", "He|Helyum|2|4.0026|Soygaz", "Li|Lityum|3|6.94|Alkali metal", "Be|Berilyum|4|9.0122|Toprak alkali", "B|Bor|5|10.81|Yarı metal", "C|Karbon|6|12.011|Ametal", "N|Azot|7|14.007|Ametal", "O|Oksijen|8|15.999|Ametal", "F|Flor|9|18.998|Halojen", "Ne|Neon|10|20.180|Soygaz",
"Na|Sodyum|11|22.990|Alkali metal", "Mg|Magnezyum|12|24.305|Toprak alkali", "Al|Alüminyum|13|26.982|Metal", "Si|Silisyum|14|28.085|Yarı metal", "P|Fosfor|15|30.974|Ametal", "S|Kükürt|16|32.06|Ametal", "Cl|Klor|17|35.45|Halojen", "Ar|Argon|18|39.948|Soygaz",
"K|Potasyum|19|39.098|Alkali metal", "Ca|Kalsiyum|20|40.078|Toprak alkali", "Sc|Skandiyum|21|44.956|Geçiş metali", "Ti|Titanyum|22|47.867|Geçiş metali", "V|Vanadyum|23|50.942|Geçiş metali", "Cr|Krom|24|51.996|Geçiş metali", "Mn|Manganez|25|54.938|Geçiş metali", "Fe|Demir|26|55.845|Geçiş metali", "Co|Kobalt|27|58.933|Geçiş metali", "Ni|Nikel|28|58.693|Geçiş metali", "Cu|Bakır|29|63.546|Geçiş metali", "Zn|Çinko|30|65.38|Geçiş metali", "Ga|Galyum|31|69.723|Metal", "Ge|Germanyum|32|72.630|Yarı metal", "As|Arsenik|33|74.922|Yarı metal", "Se|Selenyum|34|78.971|Ametal", "Br|Brom|35|79.904|Halojen", "Kr|Kripton|36|83.798|Soygaz",
"Rb|Rubidyum|37|85.468|Alkali metal", "Sr|Stronsiyum|38|87.62|Toprak alkali", "Y|İtriyum|39|88.906|Geçiş metali", "Zr|Zirkonyum|40|91.224|Geçiş metali", "Nb|Niyobyum|41|92.906|Geçiş metali", "Mo|Molibden|42|95.95|Geçiş metali", "Tc|Teknesyum|43|98|Geçiş metali", "Ru|Rutenyum|44|101.07|Geçiş metali", "Rh|Rodyum|45|102.91|Geçiş metali", "Pd|Paladyum|46|106.42|Geçiş metali", "Ag|Gümüş|47|107.87|Geçiş metali", "Cd|Kadmiyum|48|112.41|Geçiş metali", "In|İndiyum|49|114.82|Metal", "Sn|Kalay|50|118.71|Metal", "Sb|Antimon|51|121.76|Yarı metal", "Te|Tellür|52|127.60|Yarı metal", "I|İyot|53|126.90|Halojen", "Xe|Ksenon|54|131.29|Soygaz",
"Cs|Sezyum|55|132.91|Alkali metal", "Ba|Baryum|56|137.33|Toprak alkali", "La|Lantan|57|138.91|Lantanit", "Ce|Seryum|58|140.12|Lantanit", "Pr|Praseodim|59|140.91|Lantanit", "Nd|Neodimyum|60|144.24|Lantanit", "Pm|Prometyum|61|145|Lantanit", "Sm|Samaryum|62|150.36|Lantanit", "Eu|Evropiyum|63|151.96|Lantanit", "Gd|Gadolinyum|64|157.25|Lantanit", "Tb|Terbiyum|65|158.93|Lantanit", "Dy|Disprozyum|66|162.50|Lantanit", "Ho|Holmiyum|67|164.93|Lantanit", "Er|Erbiyum|68|167.26|Lantanit", "Tm|Tulyum|69|168.93|Lantanit", "Yb|İterbiyum|70|173.05|Lantanit", "Lu|Lutesyum|71|174.97|Lantanit",
"Hf|Hafniyum|72|178.49|Geçiş metali", "Ta|Tantal|73|180.95|Geçiş metali", "W|Tungsten|74|183.84|Geçiş metali", "Re|Renyum|75|186.21|Geçiş metali", "Os|Osmiyum|76|190.23|Geçiş metali", "Ir|İridyum|77|192.22|Geçiş metali", "Pt|Platin|78|195.08|Geçiş metali", "Au|Altın|79|196.97|Geçiş metali", "Hg|Cıva|80|200.59|Geçiş metali", "Tl|Talyum|81|204.38|Metal", "Pb|Kurşun|82|207.2|Metal", "Bi|Bizmut|83|208.98|Metal", "Po|Polonyum|84|209|Yarı metal", "At|Astatin|85|210|Halojen", "Rn|Radon|86|222|Soygaz",
"Fr|Fransiyum|87|223|Alkali metal", "Ra|Radyum|88|226|Toprak alkali", "Ac|Aktinyum|89|227|Aktinit", "Th|Toryum|90|232.04|Aktinit", "Pa|Protaktinyum|91|231.04|Aktinit", "U|Uranyum|92|238.03|Aktinit", "Np|Neptünyum|93|237|Aktinit", "Pu|Plütonyum|94|244|Aktinit", "Am|Amerikyum|95|243|Aktinit", "Cm|Küriyum|96|247|Aktinit", "Bk|Berkelyum|97|247|Aktinit", "Cf|Kaliforniyum|98|251|Aktinit", "Es|Einsteinyum|99|252|Aktinit", "Fm|Fermiyum|100|257|Aktinit", "Md|Mendelevyum|101|258|Aktinit", "No|Nobelyum|102|259|Aktinit", "Lr|Lavrensiyum|103|266|Aktinit", "Rf|Rutherfordiyum|104|267|Geçiş metali", "Db|Dubniyum|105|268|Geçiş metali", "Sg|Seaborgiyum|106|269|Geçiş metali", "Bh|Bohriyum|107|270|Geçiş metali", "Hs|Hassiyum|108|269|Geçiş metali", "Mt|Meitneriyum|109|278|Bilinmiyor", "Ds|Darmstadtiyum|110|281|Bilinmiyor", "Rg|Röntgenyum|111|282|Bilinmiyor", "Cn|Kopernikyum|112|285|Bilinmiyor", "Nh|Nihonyum|113|286|Bilinmiyor", "Fl|Flerovyum|114|289|Bilinmiyor", "Mc|Moskovyum|115|290|Bilinmiyor", "Lv|Livermoryum|116|293|Bilinmiyor", "Ts|Tennessin|117|294|Halojen", "Og|Oganesson|118|294|Soygaz"
).map { it.split('|') }

private val covalentRadiiPm = intArrayOf(0, 31, 28, 128, 96, 84, 76, 71, 66, 57, 58, 166, 141, 121, 111, 107, 105, 102, 106, 203, 176, 170, 160, 152, 139, 139, 132, 126, 124, 132, 122, 122, 120, 119, 120, 120, 116, 220, 195, 190, 175, 164, 154, 147, 146, 142, 139, 145, 144, 142, 139, 139, 138, 139, 140, 244, 215, 207, 204, 203, 201, 199, 198, 198, 196, 194, 192, 192, 189, 190, 187, 187, 175, 170, 162, 151, 144, 141, 136, 136, 132, 145, 146, 148, 140, 150, 150, 260, 220, 215, 206, 200, 196, 190, 187, 180, 169, 190, 190, 190, 190, 190, 190, 190)
private val englishNames = listOf(
    "Hydrogen", "Helium", "Lithium", "Beryllium", "Boron", "Carbon", "Nitrogen", "Oxygen",
    "Fluorine", "Neon", "Sodium", "Magnesium", "Aluminium", "Silicon", "Phosphorus", "Sulfur",
    "Chlorine", "Argon", "Potassium", "Calcium", "Scandium", "Titanium", "Vanadium", "Chromium",
    "Manganese", "Iron", "Cobalt", "Nickel", "Copper", "Zinc", "Gallium", "Germanium",
    "Arsenic", "Selenium", "Bromine", "Krypton", "Rubidium", "Strontium", "Yttrium", "Zirconium",
    "Niobium", "Molybdenum", "Technetium", "Ruthenium", "Rhodium", "Palladium", "Silver", "Cadmium",
    "Indium", "Tin", "Antimony", "Tellurium", "Iodine", "Xenon", "Caesium", "Barium",
    "Lanthanum", "Cerium", "Praseodymium", "Neodymium", "Promethium", "Samarium", "Europium", "Gadolinium",
    "Terbium", "Dysprosium", "Holmium", "Erbium", "Thulium", "Ytterbium", "Lutetium", "Hafnium",
    "Tantalum", "Tungsten", "Rhenium", "Osmium", "Iridium", "Platinum", "Gold", "Mercury",
    "Thallium", "Lead", "Bismuth", "Polonium", "Astatine", "Radon", "Francium", "Radium",
    "Actinium", "Thorium", "Protactinium", "Uranium", "Neptunium", "Plutonium", "Americium", "Curium",
    "Berkelium", "Californium", "Einsteinium", "Fermium", "Mendelevium", "Nobelium", "Lawrencium", "Rutherfordium",
    "Dubnium", "Seaborgium", "Bohrium", "Hassium", "Meitnerium", "Darmstadtium", "Roentgenium", "Copernicium",
    "Nihonium", "Flerovium", "Moscovium", "Livermorium", "Tennessine", "Oganesson"
)
private fun englishElementName(z: Int): String = englishNames.getOrNull(z - 1) ?: "Element"

fun normalizeElementSearch(value: String): String =
    Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")

private fun covalentRadiusPm(z: Int): Int? = if (z in 1..103) covalentRadiiPm.getOrNull(z) else null

private fun elementFamilyColor(kind: String): Color = when (kind) {
    "Alkali metal" -> Color(0xFFE57373)
    "Toprak alkali" -> Color(0xFFFFB74D)
    "Geçiş metali" -> Color(0xFFFFD54F)
    "Metal" -> Color(0xFFAED581)
    "Yarı metal" -> Color(0xFF4DB6AC)
    "Ametal" -> Color(0xFF4FC3F7)
    "Halojen" -> Color(0xFF7986CB)
    "Soygaz" -> Color(0xFFBA68C8)
    "Lantanit" -> Color(0xFFF06292)
    "Aktinit" -> Color(0xFF9575CD)
    else -> Color(0xFF90A4AE)
}

private fun elementPeriod(z: Int): Int = when (z) {
    in 1..2 -> 1
    in 3..10 -> 2
    in 11..18 -> 3
    in 19..36 -> 4
    in 37..54 -> 5
    in 55..86 -> 6
    else -> 7
}

private fun elementGroup(z: Int): String = when (z) {
    1 -> "1"; 2 -> "18"
    in 3..4 -> (z - 2).toString()
    in 5..10 -> (z + 8).toString()
    in 11..12 -> (z - 10).toString()
    in 13..18 -> (z + 2).toString()
    in 19..36 -> (z - 18).toString()
    in 37..54 -> (z - 36).toString()
    in 55..56 -> (z - 54).toString()
    in 57..71 -> "3 · f-blok"
    in 72..86 -> (z - 68).toString()
    in 87..88 -> (z - 86).toString()
    in 89..103 -> "3 · f-blok"
    else -> (z - 100).toString()
}

private fun elementBlock(z: Int): String = when {
    z == 2 -> "s"
    z in 57..71 || z in 89..103 -> "f"
    elementGroup(z).substringBefore(" ").toIntOrNull()?.let { it in 1..2 } == true -> "s"
    elementGroup(z).substringBefore(" ").toIntOrNull()?.let { it in 13..18 } == true -> "p"
    else -> "d"
}

private fun elementState(z: Int): String = when (z) {
    1, 2, 7, 8, 9, 10, 17, 18, 36, 54, 86 -> "Gaz (25 °C, 1 atm)"
    35, 80 -> "Sıvı (25 °C, 1 atm)"
    in 104..118 -> "Makroskopik hâli deneysel olarak belirlenemedi"
    else -> "Katı (25 °C, 1 atm)"
}

private fun elementElectronConfig(z: Int): String? = when (z) {
    1 -> "1s¹"; 2 -> "1s²"; 3 -> "[He] 2s¹"; 4 -> "[He] 2s²"
    5 -> "[He] 2s² 2p¹"; 6 -> "[He] 2s² 2p²"; 7 -> "[He] 2s² 2p³"; 8 -> "[He] 2s² 2p⁴"; 9 -> "[He] 2s² 2p⁵"; 10 -> "[He] 2s² 2p⁶"
    11 -> "[Ne] 3s¹"; 12 -> "[Ne] 3s²"; 13 -> "[Ne] 3s² 3p¹"; 14 -> "[Ne] 3s² 3p²"; 15 -> "[Ne] 3s² 3p³"; 16 -> "[Ne] 3s² 3p⁴"; 17 -> "[Ne] 3s² 3p⁵"; 18 -> "[Ne] 3s² 3p⁶"
    19 -> "[Ar] 4s¹"; 20 -> "[Ar] 4s²"; 21 -> "[Ar] 3d¹ 4s²"; 22 -> "[Ar] 3d² 4s²"; 23 -> "[Ar] 3d³ 4s²"; 24 -> "[Ar] 3d⁵ 4s¹"; 25 -> "[Ar] 3d⁵ 4s²"; 26 -> "[Ar] 3d⁶ 4s²"; 27 -> "[Ar] 3d⁷ 4s²"; 28 -> "[Ar] 3d⁸ 4s²"; 29 -> "[Ar] 3d¹⁰ 4s¹"; 30 -> "[Ar] 3d¹⁰ 4s²"
    31 -> "[Ar] 3d¹⁰ 4s² 4p¹"; 32 -> "[Ar] 3d¹⁰ 4s² 4p²"; 33 -> "[Ar] 3d¹⁰ 4s² 4p³"; 34 -> "[Ar] 3d¹⁰ 4s² 4p⁴"; 35 -> "[Ar] 3d¹⁰ 4s² 4p⁵"; 36 -> "[Ar] 3d¹⁰ 4s² 4p⁶"
    47 -> "[Kr] 4d¹⁰ 5s¹"; 53 -> "[Kr] 4d¹⁰ 5s² 5p⁵"; 79 -> "[Xe] 4f¹⁴ 5d¹⁰ 6s¹"; 80 -> "[Xe] 4f¹⁴ 5d¹⁰ 6s²"; 82 -> "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p²"; 92 -> "[Rn] 5f³ 6d¹ 7s²"
    else -> null
}

private fun elementElectronConfigNote(z: Int): String = elementElectronConfig(z)
    ?: if (z >= 104) "Bu süper ağır elementin elektron yapısı teorik hesaplamalara dayanır; deneysel doğrulama sınırlıdır."
    else "Tam orbital dizilimi bu ekranda henüz kaynaklı veriyle doğrulanmadı. Yanlış bir dizilim göstermek yerine alan boş bırakıldı."

private fun elementEducation(e: List<String>): String {
    val symbol = e[0]
    val kind = e[4]
    val known = mapOf(
        "H" to "Hidrojen en hafif elementtir. En yaygın izotopu bir proton ve bir elektrondan oluşur. Yıldızlarda proton-proton zinciri ve diğer füzyon süreçlerinde enerji açığa çıkmasının temel yakıtıdır. Su ve organik bileşiklerin yapısında bulunur.",
        "He" to "Helyumun atom numarası 2'dir ve kapalı 1s² elektron kabuğu nedeniyle kimyasal tepkimeye girme eğilimi çok düşüktür. Çok düşük kaynama sıcaklığı, kriyojenik soğutma ve süperiletken mıknatıs sistemlerinde önemlidir.",
        "Li" to "Lityum en hafif metaldir. Li⁺ iyonlarının elektrotlar arasında hareket edebilmesi, lityum-iyon pillerin şarj ve deşarj mekanizmasının temelidir. Seramik ve cam bileşiklerinde de kullanılır.",
        "C" to "Karbon dört değerlik elektronu sayesinde çok çeşitli kovalent bağlar kurabilir. Elmas, grafit ve grafen aynı elementin farklı allotroplarıdır. Organik kimyanın ve bilinen yaşam kimyasının temel iskeletini oluşturur.",
        "N" to "Azot atmosferin yaklaşık %78'ini N₂ gazı olarak oluşturur. N₂ molekülündeki üçlü bağın koparılması enerji gerektirir. Azot bağlanması ve Haber-Bosch süreci, biyolojik azot döngüsü ile gübre üretiminde önemlidir.",
        "O" to "Oksijen atmosferde O₂ hâlinde bulunur ve aerobik hücresel solunumda elektron alıcısı olarak görev yapar. Oksijenin allotroplarından ozon (O₃), stratosferde Güneş'in morötesi ışınımının bir bölümünü soğurur.",
        "Na" to "Sodyum bir alkali metaldir ve nötr atomunun dış kabuğunda bir 3s elektronu bulunur. Bileşiklerinde çoğunlukla +1 yükseltgenme basamağındadır. Sodyum iyonları sinir hücrelerinin zar potansiyelinde ve sıvı dengesinde rol oynar.",
        "Mg" to "Magnezyum hafif bir toprak alkali metaldir. Klorofil molekülünün merkezinde Mg²⁺ bulunur. Hafif alaşımlar, piroteknik ışık kaynakları ve biyolojik enzim sistemleri açısından önemlidir.",
        "Al" to "Alüminyum düşük yoğunluklu, elektrik ve ısı iletkenliği iyi bir metaldir. Yüzeyinde oluşan ince alüminyum oksit tabakası korozyonu yavaşlatır. Ambalaj, ulaşım, yapı ve elektrik iletiminde kullanılır.",
        "Si" to "Silisyum yarı iletken teknolojisinin temel malzemelerindendir. Kristal yapısına kontrollü katkılama yapılarak p-tipi ve n-tipi bölgeler oluşturulur. Silisyum dioksit ise kum ve birçok camın ana bileşenidir.",
        "P" to "Fosfor DNA ve RNA'nın fosfat omurgasında, ATP'de ve kemik mineralinde bulunur. Elementel fosfor farklı allotroplara sahiptir; beyaz fosfor oldukça reaktif, kırmızı fosfor ise daha kararlıdır.",
        "S" to "Kükürt proteinlerdeki bazı amino asitlerin yapısında bulunur. İki sistein kalıntısı arasında oluşabilen disülfit bağları proteinlerin üç boyutlu yapısını kararlı hâle getirebilir. Sülfürik asit üretimi büyük ölçekli kimya sanayisinin temel süreçlerindendir.",
        "Cl" to "Klor bir halojendir. Cl₂ güçlü bir oksitleyici ve dezenfektan olarak kontrollü su arıtımında kullanılır; klorür iyonu ise sofra tuzu ve canlıların elektrolit dengesinin parçasıdır. Elementel klor ile klorür iyonunun özellikleri aynı değildir.",
        "K" to "Potasyum bir alkali metaldir. K⁺ iyonu hücre içi sıvının başlıca katyonudur ve sinir iletimi, kas işlevi ile hücresel elektriksel dengenin sürdürülmesine katkıda bulunur.",
        "Ca" to "Kalsiyum kemik ve dişlerde hidroksiapatit mineralinin önemli bileşenidir. Ca²⁺ iyonları kas kasılması, hücre içi sinyal iletimi, kan pıhtılaşması ve birçok enzimin düzenlenmesinde görev alır.",
        "Fe" to "Demir geçiş metalidir. Hemoglobindeki hem grubu oksijenin akciğerlerden dokulara taşınmasına yardımcı olur. Demir ayrıca sitokromlar ve elektron taşıma zincirindeki proteinlerde bulunur.",
        "Cu" to "Bakır elektrik ve ısıyı iyi iletir. Elektrik kabloları, motor sargıları ve elektronik bileşenlerde yaygındır. Canlılarda bazı oksidasyon-indirgenme enzimlerinin aktif merkezinde bakır iyonları bulunur.",
        "Zn" to "Çinko birçok enzimin yapısal veya katalitik bileşenidir. Galvanizleme işlemi çeliğin yüzeyini çinko ile kaplayarak korozyona karşı korur. Bileşiklerinde çoğunlukla +2 iyonu oluşturur.",
        "Ag" to "Gümüş görünür ışığı iyi yansıtır ve metaller arasında en yüksek elektrik iletkenliğine sahiptir. Elektronik kontaklar, özel kaplamalar ve bazı fotoğrafçılık kimyasallarında kullanılır.",
        "I" to "İyot tiroit hormonları T₃ ve T₄'ün yapısında bulunur. İyot eksikliği tiroit hormon üretimini etkileyebilir. Elementel iyot ile iyodür tuzları kimyasal açıdan farklı türlerdir.",
        "Au" to "Altın kimyasal olarak görece kararlı ve dövülebilir bir metaldir. Korozyona dayanımı, elektrik kontaklarında güvenilir yüzeyler oluşturmasını sağlar. Mücevherat, elektronik ve bazı kataliz uygulamalarında kullanılır.",
        "Hg" to "Cıva oda sıcaklığında sıvı olan iki elementten biridir. Yoğunluğu yüksektir; ancak cıva ve birçok bileşiği toksiktir. Eski ölçüm cihazlarında kullanılmış olsa da sağlık ve çevre riskleri nedeniyle kullanımı birçok alanda sınırlandırılmıştır.",
        "Pb" to "Kurşun yoğun ve yumuşak bir metaldir. Kurşun-asit akülerde elektrot malzemesi olarak kullanılır. Kurşun ve bileşiklerinin sinir sistemi üzerindeki toksik etkileri nedeniyle maruziyetin önlenmesi gerekir.",
        "U" to "Uranyum doğal olarak bulunan ağır bir aktinittir. U-235 fisil bir izotoptur; U-238 ise uranyum serisinin ve jeokronolojide kullanılan uranyum-kurşun tarihleme yöntemlerinin parçasıdır. İzotopların özellikleri birbirinden ayrılmalıdır."
    )
    return known[symbol] ?: when (kind) {
        "Alkali metal" -> "${e[1]} alkali metaller grubundadır. Bu grupta dış elektron düzeni genel olarak ns¹ biçimindedir ve elementler çoğunlukla +1 iyon oluşturur. Tepkime eğilimleri ve fiziksel özellikleri grupta aşağı doğru değişir. Saf metalin davranışı bileşiklerinin davranışından farklıdır."
        "Toprak alkali" -> "${e[1]} toprak alkali metaller grubundadır. Genel değerlik elektron düzeni ns²'dir ve bileşiklerinde +2 yükseltgenme basamağı yaygındır. Karbonatlar, oksitler ve sülfatlar gibi bileşikleri jeoloji, malzeme bilimi ve endüstride önem taşır."
        "Halojen" -> "${e[1]} halojenler grubundadır. Bu elementlerin değerlik katmanında genel olarak yedi elektron bulunur; birçok bileşikte −1 yükseltgenme basamağı gösterirler. Moleküler hâlleri, reaktiviteleri ve fiziksel durumları grup boyunca değişir."
        "Soygaz" -> "${e[1]} soygazlar grubundadır. Değerlik kabuklarının dolu olması, kimyasal tepkimeye girme eğilimlerini genellikle düşürür. Aydınlatma, koruyucu atmosferler, kriyojenik uygulamalar ve hassas ölçüm sistemlerinde farklı soygazlardan yararlanılır."
        "Lantanit" -> "${e[1]} lantanitler serisindedir. 4f orbitallerinin dolması manyetik, optik ve ışıldama özelliklerinde önemli rol oynar. Bazı lantanitler kalıcı mıknatıslar, fosforlar, lazer malzemeleri ve katalizörlerde kullanılır."
        "Aktinit" -> "${e[1]} aktinitler serisindedir. Bu elementlerin çekirdekleri radyoaktiftir; birçok izotopları yapay olarak üretilir. Nükleer kimya, çekirdek fiziği ve radyokimya araştırmalarında önem taşırlar."
        "Yarı metal" -> "${e[1]} yarı metal olarak sınıflandırılır. Yarı metallerin elektriksel ve kimyasal özellikleri metaller ile ametaller arasında değişebilir. Bazıları yarı iletken, alaşım, cam ve özel kimyasal malzemelerin üretiminde kullanılır."
        "Ametal" -> "${e[1]} ametaldir. Ametaller metalik parlaklık ve iletkenlik özelliklerini genellikle göstermez; kovalent bağlar veya anyonlar oluşturabilir. Elementin moleküler biçimi ve kimyasal tepkimeleri bulunduğu koşullara bağlıdır."
        "Bilinmiyor" -> "${e[1]} süper ağır, yapay olarak sentezlenen bir elementtir. Çok kısa ömürlü izotopları nedeniyle makroskopik örnekleri üzerinde olağan fiziksel ve kimyasal ölçümler yapılamamıştır. Bu nedenle birçok özellik teorik tahmin olarak kalır."
        else -> "${e[1]} bir metal elementidir. Metalik bağ, elektrik iletkenliği, dövülebilirlik ve alaşım oluşturma gibi özellikler gösterebilir. Geçiş metalleri ve p-blok metalleri arasında fiziksel özellikler ile kimyasal davranış önemli ölçüde farklılaşır."
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { SpectrumApp() }
    }
}

@Composable
private fun SpectrumApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("spectrum_settings", Context.MODE_PRIVATE) }
    var page by rememberSaveable { mutableStateOf("Ana Sayfa") }
    var category by rememberSaveable { mutableStateOf("") }
    var categoryReturnPage by rememberSaveable { mutableStateOf("Keşfet") }
    var selectedTopicSlug by rememberSaveable { mutableStateOf("optik") }
    var topicReturnPage by rememberSaveable { mutableStateOf("Ara") }
    var elementReturnPage by rememberSaveable { mutableStateOf("Ara") }
    var requestedModel by rememberSaveable { mutableStateOf("atom") }
    val scienceTopics by produceState<List<ScienceTopicData>?>(null, context.applicationContext) {
        value = withContext(Dispatchers.IO) { loadScienceTopics(context.applicationContext) }
    }
    val topics = scienceTopics.orEmpty()
    var selectedElement by rememberSaveable { mutableStateOf("H") }
    var fontIndex by rememberSaveable { mutableIntStateOf(prefs.getInt("font", 0).coerceIn(0, 3)) }
    var themeIndex by rememberSaveable { mutableIntStateOf(prefs.getInt("theme", palettes.indexOfFirst { it.name == "Deep Space" }.coerceAtLeast(0)).coerceIn(palettes.indices)) }
    var soundOn by rememberSaveable { mutableStateOf(prefs.getBoolean("sound", true)) }
    var language by rememberSaveable { mutableStateOf(prefs.getString("language", "tr") ?: "tr") }
    val english = language == "en"
    val p = palettes[themeIndex]
    val tone = remember { ToneGenerator(AudioManager.STREAM_MUSIC, 35) }
    DisposableEffect(Unit) { onDispose { tone.release() } }
    fun clickSound() { if (soundOn) tone.startTone(ToneGenerator.TONE_PROP_ACK, 55) }
    fun selectSound() { if (soundOn) tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 45) }
    fun confirmSound() { if (soundOn) tone.startTone(ToneGenerator.TONE_PROP_PROMPT, 75) }
    val scheme = if (p.name == "Laboratuvar" || p.name == "Light Science") lightColorScheme(
        primary = p.accent, background = p.bg, surface = p.panel, onSurface = p.text, onBackground = p.text
    ) else darkColorScheme(
        primary = p.accent, background = p.bg, surface = p.panel, onSurface = p.text, onBackground = p.text
    )

    val appFont = when (fontIndex) {
        1 -> androidx.compose.ui.text.font.FontFamily(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.NORMAL))
        2 -> androidx.compose.ui.text.font.FontFamily.Monospace
        3 -> androidx.compose.ui.text.font.FontFamily.Serif
        else -> androidx.compose.ui.text.font.FontFamily.SansSerif
    }
    MaterialTheme(colorScheme = scheme) {
      androidx.compose.runtime.CompositionLocalProvider(androidx.compose.material3.LocalTextStyle provides androidx.compose.material3.LocalTextStyle.current.copy(fontFamily = appFont)) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = p.bg,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                NavigationBar(
                    containerColor = p.panel,
                    contentColor = p.text,
                    tonalElevation = 0.dp
                ) {
                    val items = listOf(
                        Triple("Ana Sayfa", Icons.Default.Home, if (english) "Home" else "Ana Sayfa"),
                        Triple("Keşfet", Icons.Default.Explore, if (english) "Explore" else "Keşfet"),
                        Triple("Ara", Icons.Default.Search, if (english) "Search" else "Ara"),
                        Triple("Laboratuvar", Icons.Default.Science, if (english) "Lab" else "Laboratuvar"),
                        Triple("Profil", Icons.Default.Person, if (english) "Profile" else "Profil")
                    )
                    items.forEach { item ->
                        NavigationBarItem(
                            selected = page == item.first || (page == "KonuDetay" && item.first == "Ara") ||
                                ((page == "Detay" || page == "ElementDetay") && item.first == "Keşfet") ||
                                (page == "Ayarlar" && item.first == "Profil") || (page == "3DLab" && item.first == "Laboratuvar"),
                            onClick = { clickSound(); page = if (item.first == "Profil") "Ayarlar" else item.first; category = "" },
                            icon = { Icon(item.second, contentDescription = item.first) },
                            label = { Text(item.third, fontSize = 10.sp, maxLines = 1) },
                            alwaysShowLabel = true,
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = p.accent,
                                selectedTextColor = p.accent,
                                indicatorColor = p.accent.copy(alpha = .13f),
                                unselectedIconColor = p.muted,
                                unselectedTextColor = p.muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).background(p.bg)
            ) {
                Header(p = p, title = when (page) { "Detay" -> category; "ElementDetay" -> selectedElement; "KonuDetay" -> topics.firstOrNull { it.slug == selectedTopicSlug }?.title ?: "Konu"; "Ana Sayfa" -> if (english) "Home" else "Ana Sayfa"; "Keşfet" -> if (english) "Explore" else "Keşfet"; "Ara" -> if (english) "Search" else "Ara"; else -> page }, onSearch = { page = "Ara" })
                if (scienceTopics == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = p.accent)
                    }
                } else when (page) {
                    "Ana Sayfa" -> SpectrumHomePage(p, english, topics,
                        onOpenCategory = { category = it; categoryReturnPage = "Ana Sayfa"; page = "Detay" },
                        onExplore = { page = "Keşfet" }, onLab = { page = "Laboratuvar" }, onSearch = { page = "Ara" },
                        onTopic = { selectedTopicSlug = it; topicReturnPage = "Ana Sayfa"; page = "KonuDetay" })
                    "Keşfet" -> SpectrumExplorePage(p, english, onOpen = { category = it; categoryReturnPage = "Keşfet"; page = "Detay" })
                    "Ara" -> ScienceSearchPage(p, english, topics,
                        onOpenTopic = { selectedTopicSlug = it; topicReturnPage = "Ara"; page = "KonuDetay" },
                        onOpenElement = { selectedElement = it; elementReturnPage = "Ara"; page = "ElementDetay" })
                    "KonuDetay" -> ScienceTopicDetailPage(p, english, topics.firstOrNull { it.slug == selectedTopicSlug },
                        onBack = { page = topicReturnPage }, onOpenModel = { requestedModel = modelForTopic(selectedTopicSlug); page = "3DLab" })
                    "3DLab" -> VisualLabPage(p, english, requestedModel)
                    "Laboratuvar" -> SpectrumLabHubPage(p, english,
                        onOpenVisual = { requestedModel = "atom"; page = "3DLab" },
                        onOpenPhysics = { category = "Fizik & Elektrik"; categoryReturnPage = "Laboratuvar"; page = "Detay" },
                        onOpenChemistry = { category = "Kimya"; categoryReturnPage = "Laboratuvar"; page = "Detay" },
                        onOpenBiology = { category = "Biyoloji"; categoryReturnPage = "Laboratuvar"; page = "Detay" })
                    "Ayarlar" -> SettingsPage(
                        p, themeIndex, soundOn, fontIndex, language,
                        onTheme = { themeIndex = it; prefs.edit().putInt("theme", it).apply(); clickSound() },
                        onSound = { soundOn = it; prefs.edit().putBoolean("sound", it).apply() },
                        onFont = { fontIndex = it; prefs.edit().putInt("font", it).apply() },
                        onLanguage = { language = it; prefs.edit().putString("language", it).apply(); confirmSound() }
                    )
                    "ElementDetay" -> ElementDetailPage(p, elementRows.firstOrNull { it[0] == selectedElement } ?: elementRows.first(), english, onBack = { page = elementReturnPage })
                    "Detay" -> CategoryDetail(p, category, english, topics, onBack = { page = categoryReturnPage; category = "" }, onElement = { selectedElement = it; elementReturnPage = "Detay"; page = "ElementDetay"; selectSound() }, onTopic = { selectedTopicSlug = it; topicReturnPage = "Detay"; page = "KonuDetay" })
                    else -> SpectrumHomePage(p, english, topics,
                        onOpenCategory = { category = it; categoryReturnPage = "Ana Sayfa"; page = "Detay" },
                        onExplore = { page = "Keşfet" }, onLab = { page = "Laboratuvar" }, onSearch = { page = "Ara" },
                        onTopic = { selectedTopicSlug = it; topicReturnPage = "Ana Sayfa"; page = "KonuDetay" })
                }
            }
        }
      }
    }
}

@Composable
private fun Header(p: Palette, title: String, onSearch: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(com.elyionn.spektrum.R.drawable.spectrum_logo),
            contentDescription = "Spectrum logo",
            modifier = Modifier.size(38.dp).clip(CircleShape)
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("SPECTRUM", color = p.text, fontWeight = FontWeight.Black, fontSize = 17.sp, letterSpacing = 1.8.sp)
            Text(title, color = p.muted, fontSize = 11.sp, maxLines = 1)
        }
        IconButton(onClick = onSearch) {
            Icon(Icons.Default.Search, contentDescription = if (title == "Settings") "Search" else "Ara", tint = p.accent)
        }
    }
}

@Composable
fun Panel(p: Palette, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth()
            .background(p.panel, RoundedCornerShape(20.dp))
            .border(1.dp, p.accent.copy(alpha = .18f), RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}

@Composable
private fun LearningQuiz(p: Palette, english: Boolean, title: String, question: String, options: List<String>, answer: Int, explanation: String) {
    var selected by rememberSaveable(title) { mutableIntStateOf(-1) }
    var score by rememberSaveable(title) { mutableIntStateOf(0) }
    Panel(p) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.School, contentDescription = null, tint = p.accent)
            Spacer(Modifier.width(7.dp))
            Text(title, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Text("${if (english) "Score" else "Puan"}: $score", color = p.muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(7.dp))
        Text(question, color = p.text, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp)
        options.forEachIndexed { index, option ->
            val chosen = selected == index
            val correct = index == answer
            val tint = if (selected >= 0 && correct) Color(0xFF35B978) else if (chosen) Color(0xFFE06C75) else p.muted
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (chosen || (selected >= 0 && correct)) tint.copy(alpha = .13f) else p.bg)
                    .clickable(enabled = selected < 0) { selected = index; if (correct) score++ }
                    .padding(10.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${'A' + index}.", color = tint, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text(option, color = p.text, fontSize = 12.sp)
            }
        }
        if (selected >= 0) {
            Text(
                (if (selected == answer) (if (english) "Correct. " else "Doğru. ") else (if (english) "Not quite. " else "Doğru değil. ")) + explanation,
                color = if (selected == answer) Color(0xFF35B978) else p.muted,
                fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 8.dp)
            )
            TextButton(onClick = { selected = -1 }) { Text(if (english) "Try again" else "Tekrar dene") }
        }
    }
}

private val categoryDescriptions = listOf(
    "Biyoloji" to "İnsan anatomisi, hücre, DNA, genetik ve canlı sistemleri",
    "Kimya" to "Kimyasal bağlar, tepkimeler, çözeltiler, asitler ve bazlar",
    "Elementler" to "118 element, etkileşimli periyodik tablo ve ayrıntılı element dosyaları",
    "Atomlar" to "Atomun yapısı, orbitaller, elektron dizilimi, iyonlar ve izotoplar",
    "Fizik & Elektrik" to "Kuvvet, hareket, enerji, dalgalar, optik ve elektrik",
    "Uzay" to "Güneş Sistemi, gezegenler, yıldızlar, galaksiler ve kozmoloji",
    "Matematik" to "Sayılar, cebir, geometri, fonksiyonlar ve olasılık",
    "Mikrobiyoloji" to "Bakteriler, virüsler, mantarlar ve mikroskobik yaşam",
    "Teknoloji" to "Elektronik, sensörler, işlemciler ve modern mühendislik",
    "3B Bilim Laboratuvarı" to "Atom, molekül ve biyolojik yapıların etkileşimli görselleştirmeleri",
    "Yer Bilimleri" to "Dünya’nın iç yapısı, levha tektoniği, kayaçlar, mineraller ve jeolojik süreçler"
)


private data class ScienceTopicData(
    val slug: String,
    val title: String,
    val category: String,
    val summary: String,
    val lead: String,
    val how: List<String>,
    val life: List<Pair<String, String>>,
    val facts: List<Pair<String, String>>,
    val note: String?,
    val sources: List<Pair<String, String>>
)

private fun loadScienceTopics(context: Context): List<ScienceTopicData> = runCatching {
    val raw = context.assets.open("data/science_topics.json").bufferedReader().use { it.readText() }
    val array = JSONArray(raw)
    buildList {
        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            fun strings(key: String): List<String> {
                val a = item.optJSONArray(key) ?: return emptyList()
                return buildList { for (j in 0 until a.length()) a.optString(j).takeIf { it.isNotBlank() }?.let(::add) }
            }
            fun pairs(key: String): List<Pair<String, String>> {
                val a = item.optJSONArray(key) ?: return emptyList()
                return buildList {
                    for (j in 0 until a.length()) {
                        val o = a.optJSONObject(j) ?: continue
                        add(o.optString("title", o.optString("k", "Bilgi")) to o.optString("text", o.optString("v", "")))
                    }
                }
            }
            val sourceArray = item.optJSONArray("sources")
            val sources = buildList {
                if (sourceArray != null) for (j in 0 until sourceArray.length()) {
                    val source = sourceArray.optJSONObject(j) ?: continue
                    val title = source.optString("title")
                    val url = source.optString("url")
                    if (title.isNotBlank() && url.startsWith("https://")) add(title to url)
                }
            }
            add(ScienceTopicData(
                slug = item.optString("slug"), title = item.optString("title"),
                category = item.optString("category"), summary = item.optString("summary"),
                lead = item.optString("lead"), how = strings("how"), life = pairs("life"),
                facts = pairs("facts"), note = item.optString("note").takeIf { it.isNotBlank() && it != "null" },
                sources = sources
            ))
        }
    }
}.getOrElse { emptyList() }

private fun topicCategoryLabel(id: String): String = when (id) {
    "biyoloji" -> "Biyoloji"
    "elektronik" -> "Teknoloji"
    "fizik" -> "Fizik & Elektrik"
    "kimya" -> "Kimya"
    "matematik" -> "Matematik"
    "uzay" -> "Uzay"
    "geology" -> "Yer Bilimleri"
    else -> id.replaceFirstChar { it.uppercase(Locale.ROOT) }
}

@Composable
private fun ScienceSearchPage(
    p: Palette, english: Boolean, topics: List<ScienceTopicData>,
    onOpenTopic: (String) -> Unit, onOpenElement: (String) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("Tümü") }
    val categories = listOf("Tümü", "fizik", "kimya", "biyoloji", "uzay", "matematik", "elektronik", "geology")
    val normalized = normalizeElementSearch(query.trim())
    val topicResults = remember(topics, normalized, filter) {
        topics.filter { t ->
            (filter == "Tümü" || t.category == filter) &&
                (normalized.isEmpty() || normalizeElementSearch("${t.title} ${t.summary} ${t.lead} ${t.category} ${t.how.joinToString(" ")}").contains(normalized))
        }
    }
    val elementResults = remember(normalized) {
        if (normalized.length < 2) emptyList() else elementRows.filter { e ->
            normalizeElementSearch("${e[0]} ${e[1]} ${e[2]} ${e[4]}").contains(normalized)
        }.take(12)
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(if (english) "Search science" else "Bilimsel arama", color = p.text, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text(if (english) "Find lessons, elements, formulas and fields." else "Dersleri, elementleri, formülleri ve bilim dallarını bul.", color = p.muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, placeholder = { Text(if (english) "Search a topic or element…" else "Optik, DNA, demir, enerji…") },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = p.accent) },
            trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, null) } },
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            categories.forEach { id ->
                val label = if (id == "Tümü") id else topicCategoryLabel(id)
                FilterChip(selected = filter == id, onClick = { filter = id }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(8.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (elementResults.isNotEmpty()) {
                Text(if (english) "ELEMENTS" else "ELEMENTLER", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                elementResults.forEach { e ->
                    Panel(p, Modifier.fillMaxWidth().clickable { onOpenElement(e[0]) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(e[0], color = p.accent, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.width(48.dp))
                            Column(Modifier.weight(1f)) {
                                Text(e[1], color = p.text, fontWeight = FontWeight.Bold)
                                Text("Z = ${e[2]} · ${e[4]}", color = p.muted, fontSize = 11.sp)
                            }
                            Icon(Icons.Default.ChevronRight, null, tint = p.muted)
                        }
                    }
                }
            }
            Text(if (english) "LESSONS · ${topicResults.size}" else "KONU RAFI · ${topicResults.size}", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
            topicResults.forEach { topic ->
                Panel(p, Modifier.fillMaxWidth().clickable { onOpenTopic(topic.slug) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(topicCategoryLabel(topic.category), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(topic.title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = p.muted)
                    }
                    Text(topic.summary, color = p.muted, fontSize = 12.sp, lineHeight = 17.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${topic.how.size} açıklama", color = p.accent, fontSize = 10.sp)
                        Text("·", color = p.muted)
                        Text("${topic.facts.size} veri kartı", color = p.accent, fontSize = 10.sp)
                        if (topic.life.isNotEmpty()) { Text("·", color = p.muted); Text("${topic.life.size} örnek", color = p.accent, fontSize = 10.sp) }
                    }
                }
            }
            if (topicResults.isEmpty() && elementResults.isEmpty()) {
                Panel(p) {
                    Text(if (english) "No results" else "Sonuç bulunamadı", color = p.text, fontWeight = FontWeight.Bold)
                    Text(if (english) "Try a shorter term or another field." else "Daha kısa bir terim veya başka bir bilim dalı dene.", color = p.muted, fontSize = 12.sp)
                }
            }
        }
    }
}

private fun modelForTopic(slug: String): String = when (slug) {
    "su-molekulu" -> "water"
    "karbondioksit" -> "co2"
    "metan" -> "methane"
    "dna" -> "dna"
    "hucre" -> "cell"
    "kalp" -> "body"
    "optik" -> "optics"
    "gunes-sistemi" -> "solar"
    "dalgalar" -> "wave"
    "elektrik" -> "circuit"
    "yercekimi" -> "gravity"
    else -> "atom"
}

@Composable
private fun ScienceTopicDetailPage(
    p: Palette, english: Boolean, topic: ScienceTopicData?, onBack: () -> Unit, onOpenModel: () -> Unit
) {
    if (topic == null) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text(if (english) "Topic data could not be loaded." else "Konu verisi yüklenemedi.", color = p.text)
            TextButton(onClick = onBack) { Text(if (english) "Back to search" else "Aramaya dön") }
        }
        return
    }
    var shelf by rememberSaveable(topic.slug) { mutableStateOf("Genel Bakış") }
    var level by rememberSaveable(topic.slug) { mutableIntStateOf(1) }
    val shelves = listOf("Genel Bakış", "İşleyiş", "Günlük Örnekler", "Veriler ve Formüller", "Kaynaklar")
    val hasModel = topic.slug in setOf("atom", "su-molekulu", "metan", "karbondioksit", "dna", "hucre", "kalp", "optik", "gunes-sistemi", "dalgalar", "elektrik", "yercekimi")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = p.accent) }
            Column(Modifier.weight(1f)) {
                Text(topicCategoryLabel(topic.category).uppercase(Locale.ROOT), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                Text(topic.title, color = p.text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = onOpenModel, enabled = hasModel) { Icon(Icons.Default.ViewInAr, null, tint = if (hasModel) p.accent else p.muted) }
        }
        Panel(p) {
            Text(topic.summary, color = p.accent, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Spacer(Modifier.height(5.dp))
            Text(topic.lead, color = p.text, fontSize = 14.sp, lineHeight = 21.sp)
        }
        Text(if (english) "LEARNING LEVEL" else "ÖĞRENME SEVİYESİ", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.2.sp)
        Row(Modifier.fillMaxWidth().background(p.panel, RoundedCornerShape(14.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("Keşfet", "Öğren", "Derinlemesine").forEachIndexed { i, label ->
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if (level == i) p.accent else Color.Transparent).clickable { level = i }.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                    Text(if (english) listOf("Explore", "Learn", "Deep dive")[i] else label, color = if (level == i) Color(0xFF071321) else p.text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        if (level == 0) {
            Panel(p) {
                Text(if (english) "CORE IDEA" else "TEMEL FİKİR", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Text(topic.lead, color = p.text, lineHeight = 22.sp)
                Text(topic.summary, color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        } else if (level == 1) {
            Panel(p) {
                Text(if (english) "EXPLANATION" else "AYRINTILI AÇIKLAMA", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                topic.how.forEachIndexed { i, paragraph ->
                    Text("${i + 1}. ${paragraph}", color = p.text, fontSize = 13.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 7.dp))
                }
            }
        } else {
            Panel(p) {
                Text(if (english) "TECHNICAL VIEW" else "TEKNİK BAKIŞ", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                topic.how.forEach { Text(it, color = p.text, fontSize = 13.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 7.dp)) }
                if (topic.note != null) Text(topic.note, color = p.muted, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            shelves.forEach { label -> FilterChip(selected = shelf == label, onClick = { shelf = label }, label = { Text(label) }) }
        }
        when (shelf) {
            "Genel Bakış" -> Panel(p) {
                Text("KONU ÖZETİ", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Text(topic.summary, color = p.text, lineHeight = 20.sp)
            }
            "İşleyiş" -> Panel(p) {
                Text("NASIL ÇALIŞIR?", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                topic.how.forEachIndexed { i, text ->
                    Text("${i + 1}. adım", color = p.accent, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    Text(text, color = p.text, fontSize = 13.sp, lineHeight = 21.sp)
                }
            }
            "Günlük Örnekler" -> Panel(p) {
                Text("GÜNLÜK HAYATTA", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                if (topic.life.isEmpty()) Text("Bu konu için kaynak pakette ayrı günlük örnek verilmemiş.", color = p.muted, fontSize = 12.sp)
                topic.life.forEach { (title, text) ->
                    Text(title, color = p.text, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    Text(text, color = p.muted, fontSize = 13.sp, lineHeight = 19.sp)
                }
            }
            "Veriler ve Formüller" -> Panel(p) {
                Text("VERİLER · FORMÜLLER · BİRİMLER", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                if (topic.facts.isEmpty()) Text("Bu konu için sayısal veri kartı kaynakta bulunmuyor.", color = p.muted, fontSize = 12.sp)
                topic.facts.forEach { (k, v) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
                        Text(k, color = p.muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(v, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.2f))
                    }
                    HorizontalDivider(color = p.muted.copy(alpha = .15f))
                }
            }
            else -> Panel(p) {
                val uriHandler = LocalUriHandler.current
                Text("KAYNAKLAR", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                if (topic.sources.isEmpty()) Text("Bu konu kaydına özgü dış kaynak bağlantısı henüz eklenmemiştir.", color = p.muted, fontSize = 12.sp)
                topic.sources.forEach { (title, url) ->
                    TextButton(onClick = { runCatching { uriHandler.openUri(url) } }) {
                        Text(title, color = p.text, fontSize = 11.sp, lineHeight = 16.sp)
                    }
                }
            }
        }
        if (hasModel) Panel(p, Modifier.fillMaxWidth().clickable { onOpenModel() }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ViewInAr, null, tint = p.accent)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (english) "Open interactive model" else "Etkileşimli modeli aç", color = p.text, fontWeight = FontWeight.Bold)
                    Text(if (english) "Open the corresponding 3D scene in the laboratory." else "İlgili 3B sahneyi laboratuvarda görüntüle.", color = p.muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.ArrowForward, null, tint = p.accent)
            }
        }
    }
}

private fun localizedCategoryName(name: String, english: Boolean): String = if (!english) name else when (name) {
    "Biyoloji" -> "Biology"; "Kimya" -> "Chemistry"; "Elementler" -> "Elements"; "Atomlar" -> "Atoms"
    "Fizik & Elektrik" -> "Physics & Electricity"; "Uzay" -> "Space"; "Matematik" -> "Mathematics"
    "Mikrobiyoloji" -> "Microbiology"; "Teknoloji" -> "Technology"; "3B Bilim Laboratuvarı" -> "3D Science Lab"; "Yer Bilimleri" -> "Earth Science"
    else -> name
}
private fun localizedCategoryDescription(index: Int, english: Boolean): String = if (!english) categoryDescriptions[index].second else listOf(
    "Human anatomy, cells, DNA, genetics and living systems", "Chemical bonds, reactions, solutions, acids and bases",
    "118 elements, an interactive periodic table and element profiles", "Atomic structure, orbitals, electron configuration, ions and isotopes",
    "Forces, motion, energy, waves, optics and electricity", "The Solar System, planets, stars, galaxies and cosmology",
    "Numbers, algebra, geometry, functions and probability", "Bacteria, viruses, fungi and microscopic life",
    "Electronics, sensors, processors and modern engineering", "Interactive scientific projections of atoms, molecules and biological structures",
    "Earth's interior, plate tectonics, rocks, minerals and geological processes"
).getOrElse(index) { categoryDescriptions[index].second }

@Composable
private fun SpectrumHomePage(
    p: Palette, english: Boolean, topics: List<ScienceTopicData>,
    onOpenCategory: (String) -> Unit, onExplore: () -> Unit,
    onLab: () -> Unit, onSearch: () -> Unit,
    onTopic: (String) -> Unit
) {
    val daily = if (topics.isEmpty()) null else topics.getOrNull(java.time.LocalDate.now().dayOfYear % topics.size)
    val fields = listOf(
        Triple("Fizik & Elektrik", Icons.Default.Bolt, "Kuvvet, enerji, optik ve devreler"),
        Triple("Kimya", Icons.Default.Science, "Atomlar, bağlar ve tepkimeler"),
        Triple("Biyoloji", Icons.Default.Eco, "Hücre, genetik ve insan sistemleri"),
        Triple("Uzay", Icons.Default.Public, "Gezegenler, yıldızlar ve kozmoloji"),
        Triple("Matematik", Icons.Default.Calculate, "Fonksiyonlar, geometri ve analiz"),
        Triple("Elementler", Icons.Default.GridOn, "118 element ve özellikleri"),
        Triple("Mikrobiyoloji", Icons.Default.Biotech, "Bakteriler, virüsler ve hücreler"),
        Triple("Teknoloji", Icons.Default.Memory, "Elektronik ve dijital sistemler"),
        Triple("Yer Bilimleri", Icons.Default.Landscape, "Dünya’nın yapısı ve jeolojik süreçler")
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 15.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Text(if (english) "SPECTRUM SCIENCE" else "SPECTRUM · BİLİM PLATFORMU", color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
        Text(if (english) "Explore how the world works." else "Dünyanın nasıl işlediğini öğren.", color = p.text, fontSize = 25.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold)
        Panel(p, Modifier.fillMaxWidth().clickable { onSearch() }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = p.accent, modifier = Modifier.size(23.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (english) "Search all science" else "Bilimsel konularda ara", color = p.text, fontWeight = FontWeight.SemiBold)
                    Text(if (english) "Topics · elements · formulas · planets" else "Konular · elementler · formüller · gezegenler", color = p.muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = p.muted)
            }
        }
        if (daily != null) {
            Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(22.dp)).clickable { onTopic(daily.slug) }) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(com.elyionn.spektrum.R.drawable.space_hero),
                    contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071321).copy(alpha = .12f), Color(0xFF071321).copy(alpha = .96f)))))
                Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                    Text(if (english) "TODAY'S TOPIC" else "GÜNÜN KONUSU", color = Color(0xFF70E5F4), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    Spacer(Modifier.height(5.dp))
                    Text(daily.title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text(daily.lead, color = Color(0xFFDCEAF6), fontSize = 12.sp, lineHeight = 18.sp, maxLines = 3)
                    Text(if (english) "Open detailed lesson →" else "Ayrıntılı konu anlatımını aç →", color = Color(0xFF70E5F4), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (english) "SCIENCE FIELDS" else "BİLİM DALLARI", color = p.text, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onExplore) { Text(if (english) "All fields" else "Tümünü gör", color = p.accent) }
        }
        fields.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                row.forEach { item ->
                    Panel(p, Modifier.weight(1f).heightIn(min = 106.dp).clickable { onOpenCategory(item.first) }) {
                        Icon(item.second, null, tint = p.accent, modifier = Modifier.size(23.dp))
                        Spacer(Modifier.height(7.dp))
                        Text(item.first, color = p.text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(item.third, color = p.muted, fontSize = 10.sp, lineHeight = 14.sp, maxLines = 2)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Panel(p, Modifier.fillMaxWidth().clickable { onLab() }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ViewInAr, null, tint = p.accent, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (english) "3D Laboratory" else "3B Bilim Laboratuvarı", color = p.text, fontWeight = FontWeight.Bold)
                    Text(if (english) "Interactive geometry and scientific models" else "Etkileşimli geometriler ve bilimsel modeller", color = p.muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.ArrowForward, null, tint = p.accent)
            }
        }
        Text("Elyionn · Spectrum 1.6.3", color = p.muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp))
    }
}

@Composable
private fun SpectrumExplorePage(p: Palette, english: Boolean, onOpen: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = categoryDescriptions.withIndex().filter {
        val title = localizedCategoryName(it.value.first, english)
        val description = localizedCategoryDescription(it.index, english)
        query.isBlank() || normalizeElementSearch("$title $description").contains(normalizeElementSearch(query.trim()))
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 15.dp, vertical = 7.dp)) {
        Text(if (english) "Explore science" else "Bilim dünyasını keşfet", color = p.text, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Text(if (english) "Choose a domain and follow your curiosity." else "Bir bilim dalı seç, merak ettiğin konuların derinliklerine in.", color = p.muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text(if (english) "Search fields and topics…" else "Bilim dallarında ve konularda ara…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(17.dp))
        Spacer(Modifier.height(12.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            filtered.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { indexed ->
                        val title = indexed.value.first
                        Panel(p, Modifier.weight(1f).heightIn(min = 142.dp).clickable { onOpen(title) }) {
                            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(p.accent.copy(alpha=.13f)), contentAlignment = Alignment.Center) { Icon(categoryIcon(title), null, tint = p.accent, modifier = Modifier.size(23.dp)) }
                            Spacer(Modifier.height(10.dp))
                            Text(localizedCategoryName(title, english), color = p.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(localizedCategoryDescription(indexed.index, english), color = p.muted, fontSize = 10.sp, lineHeight = 14.sp, maxLines = 3)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            if (filtered.isEmpty()) Text(if (english) "No matching field." else "Eşleşen bilim dalı bulunamadı.", color = p.muted)
        }
    }
}

@Composable
private fun SpectrumLabHubPage(
    p: Palette, english: Boolean,
    onOpenVisual: () -> Unit, onOpenPhysics: () -> Unit,
    onOpenChemistry: () -> Unit, onOpenBiology: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (english) "Interactive science workspace" else "Etkileşimli bilim çalışma alanı", color = p.text, fontWeight = FontWeight.Bold, fontSize = 23.sp)
        Text(if (english) "Visualize structures, explore models and experiment with scientific relationships." else "Yapıları görselleştir, modelleri incele ve bilimsel ilişkileri simülasyonlarla keşfet.", color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(23.dp)).background(Brush.linearGradient(listOf(Color(0xFF102B42), Color(0xFF123A4A), Color(0xFF20254A)))).clickable { onOpenVisual() }.padding(17.dp)) {
            Icon(Icons.Default.ViewInAr, null, tint = Color(0xFF63E3EF), modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(9.dp))
            Text(if (english) "3D Science Models" else "3B Bilim Modelleri", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(if (english) "Molecules · anatomy · atoms · structures" else "Moleküller · anatomi · atomlar · bilimsel yapılar", color = Color(0xFFD0E4F1), fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Text(if (english) "Open model gallery →" else "Model galerisini aç →", color = Color(0xFF69E7F0), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Text(if (english) "LABORATORY MODULES" else "LABORATUVAR BÖLÜMLERİ", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.4.sp)
        val modules = listOf(
            Triple(if (english) "Physics simulations" else "Fizik simülasyonları", if (english) "Motion, forces, waves and electricity" else "Hareket, kuvvet, dalgalar ve elektrik", Icons.Default.Bolt),
            Triple(if (english) "Chemistry workspace" else "Kimya laboratuvarı", if (english) "Molecules, bonds and periodic table" else "Moleküller, bağlar ve periyodik tablo", Icons.Default.Science),
            Triple(if (english) "Biology & anatomy" else "Biyoloji ve anatomi", if (english) "Cells, organs and body systems" else "Hücreler, organlar ve vücut sistemleri", Icons.Default.Favorite)
        )
        modules.forEachIndexed { index, module ->
            Panel(p, Modifier.fillMaxWidth().clickable { when(index) { 0 -> onOpenPhysics(); 1 -> onOpenChemistry(); else -> onOpenBiology() } }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(p.accent.copy(alpha=.13f)), contentAlignment = Alignment.Center) { Icon(module.third, null, tint = p.accent, modifier = Modifier.size(23.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(module.first, color = p.text, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text(module.second, color = p.muted, fontSize = 11.sp) }
                    Icon(Icons.Default.ChevronRight, null, tint = p.muted)
                }
            }
        }
        Panel(p) {
            Text(if (english) "Model accuracy" else "Model doğruluğu", color = p.accent, fontWeight = FontWeight.Bold)
            Text(if (english) "Interactive models are educational representations. Scientific scale, geometry and assumptions are identified where relevant." else "Etkileşimli modeller eğitim amaçlı temsillerdir. İlgili yerlerde bilimsel ölçek, geometri ve model varsayımları ayrıca belirtilir.", color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

private fun categoryIcon(name: String) = when (name) {
    "Biyoloji" -> Icons.Default.Favorite
    "Uzay" -> Icons.Default.Public
    "Elementler", "Kimya", "Atomlar" -> Icons.Default.Science
    "Matematik" -> Icons.Default.Calculate
    "Mikrobiyoloji" -> Icons.Default.Biotech
    "3B Bilim Laboratuvarı" -> Icons.Default.ViewInAr
    "Fizik & Elektrik" -> Icons.Default.Bolt
    "Teknoloji" -> Icons.Default.Memory
    "Yer Bilimleri" -> Icons.Default.Landscape
    else -> Icons.Default.Explore
}

@Composable
private fun CategoryDetail(p: Palette, category: String, english: Boolean, topics: List<ScienceTopicData>, onBack: () -> Unit, onElement: (String) -> Unit, onTopic: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, if (english) "Back" else "Geri", tint = p.accent) }
            Text(localizedCategoryName(category, english), color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        ScienceCategoryTopicShelf(p, category, english, topics, onTopic)
        Box(Modifier.fillMaxSize().weight(1f)) {
            when (category) {
                "Biyoloji" -> BiologyPage(p, english)
                "Uzay" -> SpacePage(p, english)
                "Elementler" -> ElementsPage(p, english, onElement)
                "Atomlar" -> AtomLabPage(p, english)
                "Kimya" -> ChemistryPage(p, english)
                "Matematik" -> MathematicsPage(p, english)
                "Fizik & Elektrik" -> PhysicsKnowledgePage(p, english)
                "Teknoloji" -> TechnologyKnowledgePage(p, english)
                "Mikrobiyoloji" -> MicrobiologyPage(p, english)
                "3B Bilim Laboratuvarı" -> VisualLabPage(p, english)
                else -> Text(if (english) "Category not found." else "Kategori bulunamadı.", color = p.text)
            }
        }
    }
}

@Composable
private fun ScienceCategoryTopicShelf(p: Palette, category: String, english: Boolean, topics: List<ScienceTopicData>, onOpen: (String) -> Unit) {
    val ids = when (category) {
        "Biyoloji" -> setOf("biyoloji")
        "Kimya", "Atomlar", "Elementler" -> setOf("kimya")
        "Fizik & Elektrik" -> setOf("fizik")
        "Uzay" -> setOf("uzay")
        "Matematik" -> setOf("matematik")
        "Teknoloji" -> setOf("elektronik")
        "Mikrobiyoloji" -> setOf("biyoloji")
        "Yer Bilimleri" -> setOf("geology")
        else -> emptySet()
    }
    val matching = topics.filter { it.category in ids }
    if (matching.isNotEmpty()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
            Text(if (english) "LESSON SHELF · ${matching.size}" else "KONU RAFI · ${matching.size} BAŞLIK", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.1.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                matching.forEach { topic ->
                    Panel(p, Modifier.width(220.dp).heightIn(min = 92.dp).clickable { onOpen(topic.slug) }) {
                        Text(topic.title, color = p.text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(topic.summary, color = p.muted, fontSize = 10.sp, lineHeight = 14.sp, maxLines = 3)
                        Text(if (english) "Open lesson →" else "Dersi aç →", color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun LearningTabs(p: Palette, selected: String, english: Boolean, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(p.panel, RoundedCornerShape(14.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        listOf(if (english) "Overview" else "Özet", if (english) "Structure" else "Yapı", if (english) "How it works" else "İşleyiş").forEach { tab ->
            Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if(selected==tab) p.accent else Color.Transparent).clickable { onSelect(tab) }.padding(vertical=10.dp), contentAlignment=Alignment.Center) {
                Text(tab, color=if(selected==tab) Color(0xFF071321) else p.text, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
            }
        }
    }
}

@Composable
private fun BiologyPage(p: Palette, english: Boolean) {
    val systems = if (english) listOf(
        "Nervous system" to "The brain, spinal cord and nerves process sensory information, coordinate movement and regulate organ activity.",
        "Circulatory system" to "The heart, blood and blood vessels transport oxygen, nutrients, hormones and waste products. Capillaries enable exchange with tissues.",
        "Respiratory system" to "Air reaches the alveoli through the airways. Oxygen diffuses into the blood while carbon dioxide moves into the alveolar air. The diaphragm is the main breathing muscle.",
        "Digestive system" to "Digestion begins in the mouth and continues through the stomach and intestines. Most nutrient absorption occurs in the small intestine.",
        "Musculoskeletal system" to "Bones support and protect the body, joints allow movement, and skeletal muscles generate force. Bone marrow produces blood cells.",
        "Urinary system" to "Nephrons in the kidneys filter blood and selectively reabsorb useful substances. Urine travels through the ureters to the bladder.",
        "Endocrine system" to "Hormones regulate growth, metabolism, stress responses and homeostasis. The pituitary, thyroid, pancreas and adrenal glands are key components.",
        "Immune and lymphatic systems" to "Skin and mucous membranes form an early defence. Innate and adaptive immune responses work together to protect the body.",
        "Reproductive system" to "Reproductive organs produce gametes and support reproduction. Hormones regulate development and function.",
        "Integumentary and sensory systems" to "The skin provides a barrier, helps regulate temperature and contains sensory receptors. It includes the epidermis and dermis."
    ) else listOf(
        "Sinir sistemi" to "Beyin, omurilik ve sinirlerden oluşur. Duyuları işler, hareketleri koordine eder ve organların faaliyetlerini düzenler.",
        "Dolaşım sistemi" to "Kalp, kan ve damarlardan oluşur. Atardamarlar kanı kalpten uzaklaştırır; toplardamarlar geri taşır; kılcal damarlar madde alışverişini sağlar.",
        "Solunum sistemi" to "Hava, solunum yollarından alveollere ulaşır. Alveollerde oksijen kana, karbondioksit ise alveol havasına geçer. Diyafram temel solunum kasıdır.",
        "Sindirim sistemi" to "Ağızda başlayan sindirim mide ve bağırsaklarda sürer. İnce bağırsak besinlerin büyük bölümünü emer; karaciğer safra üretir, pankreas enzim salgılar.",
        "Kas-iskelet sistemi" to "Kemikler destek ve koruma sağlar; eklemler hareket açıklığını belirler; iskelet kasları kasılarak kuvvet üretir. Kemik iliği kan hücrelerinin üretiminde rol oynar.",
        "Üriner sistem" to "Böbrek nefronları kanı süzer; gerekli maddeler geri emilir. İdrar üreterlerle mesaneye taşınır ve üretradan atılır.",
        "Endokrin sistem" to "Hormonlar büyüme, metabolizma, stres yanıtı ve iç dengeyi düzenler. Hipofiz, tiroit, pankreas ve böbreküstü bezleri önemli bileşenlerdir.",
        "Bağışıklık ve lenf sistemi" to "Deri ve mukozalar ilk savunma hattıdır. Doğuştan gelen ve kazanılmış bağışıklık sistemleri birlikte çalışır.",
        "Üreme sistemi" to "Üreme organları gamet üretimi ve üreme işlevlerinde rol oynar. Hormonlar sistemin gelişimini ve işleyişini düzenler.",
        "Deri ve duyu sistemi" to "Deri bariyer, sıcaklık düzenleme ve duyu işlevleri görür. Epidermis, dermis ve deri altı dokudan oluşur."
    )
    var expanded by rememberSaveable { mutableStateOf(systems.first().first) }
    var tab by rememberSaveable { mutableStateOf(if (english) "Overview" else "Özet") }
    val overviewTab = if (english) "Overview" else "Özet"
    val structureTab = if (english) "Structure" else "Yapı"
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text(if (english) "HUMAN BODY SYSTEMS" else "İNSAN VÜCUDU SİSTEMLERİ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp, letterSpacing=2.sp)
            Text(if (english) "Explore the body as an integrated system" else "Vücudu bütünleşik bir sistem olarak incele", color=p.text, fontWeight=FontWeight.Bold, fontSize=21.sp)
            Text(if (english) "Organ-system reference, structure and physiology." else "Organ sistemleri, anatomik yapı ve fizyoloji.", color=p.muted, lineHeight=19.sp, fontSize=12.sp)
        }
        LearningTabs(p, tab, english) { tab=it }
        when(tab) {
            overviewTab -> Panel(p) {
                Text(if (english) "The human organism" else "İnsan organizması", color=p.accent, fontWeight=FontWeight.Bold)
                Text(if (english) "The human body is an integrated biological system in which cells, tissues, organs and organ systems work together. Homeostasis helps regulate temperature, fluids, ions and energy." else "İnsan vücudu; hücre, doku, organ ve organ sistemlerinin birlikte çalıştığı bütünleşik bir biyolojik sistemdir. İç denge (homeostaz), sıcaklık, sıvı, iyon ve enerji dengesinin düzenlenmesiyle korunur.", color=p.text, lineHeight=21.sp)
            }
            structureTab -> Panel(p) {
                Text(if (english) "Anatomical organization" else "Anatomik organizasyon", color=p.accent, fontWeight=FontWeight.Bold)
                Text(if (english) "Cells form tissues, tissues form organs, and organs form systems. The four basic tissue types are epithelial, connective, muscle and nervous tissue." else "Hücreler benzer görevli dokuları; dokular organları; organlar da sistemleri oluşturur. Temel doku tipleri epitel, bağ, kas ve sinir dokusudur.", color=p.text, lineHeight=21.sp)
            }
            else -> Panel(p) {
                Text(if (english) "Physiological function" else "Fizyolojik işleyiş", color=p.accent, fontWeight=FontWeight.Bold)
                Text(if (english) "Organ systems coordinate through neural, hormonal and local feedback. For example, the respiratory and circulatory systems work together to deliver oxygen and remove carbon dioxide." else "Organ sistemleri sinirsel, hormonal ve yerel geri bildirim mekanizmalarıyla eşgüdüm sağlar. Örneğin solunum ve dolaşım sistemleri birlikte çalışarak oksijeni dokulara taşır ve karbondioksiti uzaklaştırır.", color=p.text, lineHeight=21.sp)
            }
        }
        Panel(p) {
            Text(if (english) "ANATOMY MODEL STATUS" else "ANATOMİ MODELİ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            Text(if (english) "The previous schematic body view has been removed. A realistic, clinically reviewed 3D human model requires a separately licensed anatomical asset; no inaccurate placeholder is shown." else "Önceki şematik vücut görünümü kaldırıldı. Gerçekçi ve anatomik olarak incelenmiş bir 3B insan modeli için ayrıca lisanslı bir anatomi varlığı gerekiyor; bu nedenle yanlış bir model gösterilmiyor.", color=p.text, lineHeight=19.sp, fontSize=12.sp)
        }
        Panel(p) {
            Text(if (english) "DNA DOUBLE HELIX · ANIMATED PROJECTION" else "DNA ÇİFT SARMALI · ANİMASYONLU İZDÜŞÜM", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            DnaHelixView(p, english)
            Text(if (english) "A pairs with T; G pairs with C. The two strands run in opposite directions." else "A, T ile; G, C ile eşleşir. İki DNA zinciri zıt yönlerde uzanır.", color=p.muted, fontSize=11.sp)
        }
        LearningQuiz(p, english,
            if (english) "CELL BIOLOGY · QUICK CHECK" else "HÜCRE BİYOLOJİSİ · KISA TEST",
            if (english) "Which organelle is the main site of ATP production in most eukaryotic cells?" else "Ökaryot hücrelerde ATP üretiminin büyük bölümünün gerçekleştiği organel hangisidir?",
            if (english) listOf("Golgi apparatus", "Mitochondrion", "Lysosome", "Ribosome") else listOf("Golgi aygıtı", "Mitokondri", "Lizozom", "Ribozom"), 1,
            if (english) "Mitochondria generate most cellular ATP through oxidative phosphorylation." else "Mitokondriler oksidatif fosforilasyon yoluyla hücresel ATP'nin büyük bölümünü üretir.")
        Text(if (english) "Body systems" else "Vücut sistemleri", color=p.text, fontWeight=FontWeight.Bold, fontSize=18.sp)
        systems.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded=if(expanded==title) "" else title }, verticalAlignment=Alignment.CenterVertically) {
                    Text(title, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                    Icon(if(expanded==title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.accent)
                }
                if(expanded==title) {
                    Spacer(Modifier.height(8.dp))
                    Text(if (english) "Overview" else "Özet", color=p.accent, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
                    Text(body, color=p.text, lineHeight=20.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(if (english) "Structure" else "Yapı", color=p.accent, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
                    Text(if (english) "The system includes specialized organs and tissues connected through blood vessels, nerves or ducts, depending on its function." else "Bu sistemin temel anatomik bileşenleri organlar, dokular ve bunları birbirine bağlayan damar veya sinir ağlarıdır.", color=p.muted, lineHeight=19.sp, fontSize=12.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(if (english) "Function" else "İşleyiş", color=p.accent, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
                    Text(if (english) "The system exchanges matter, energy or information with other systems and contributes to the body's internal balance." else "Sistem, diğer organ sistemleriyle madde, enerji veya bilgi alışverişi yaparak organizmanın iç dengesine katkıda bulunur.", color=p.muted, lineHeight=19.sp, fontSize=12.sp)
                }
            }
        }
    }
}


@Composable
private fun EarthSciencePage(p: Palette, english: Boolean) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text(if (english) "EARTH SYSTEMS" else "DÜNYA SİSTEMLERİ", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.3.sp)
            Text(if (english) "A dynamic planet" else "Dinamik bir gezegen", color = p.text, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text(if (english) "Geology connects the planet's interior, rocks, water, atmosphere and the slow movement of tectonic plates." else "Jeoloji; gezegenin iç yapısını, kayaçları, suyu, atmosferi ve tektonik plakaların yavaş hareketini birlikte inceler.", color = p.muted, fontSize = 13.sp, lineHeight = 20.sp)
        }
        Panel(p) {
            Text(if (english) "EARTH'S LAYERS" else "DÜNYA’NIN KATMANLARI", color = p.accent, fontWeight = FontWeight.Bold)
            listOf("Kabuk" to "Dıştaki ince, katı kayaç katmanı.", "Manto" to "Büyük ölçüde katı; jeolojik zamanlarda yavaşça akabilen kayaçlar.", "Dış çekirdek" to "Sıvı, metalce zengin katman.", "İç çekirdek" to "Yüksek basınç altında katı metalik bölüm.").forEach { (title, desc) ->
                Text(title, color = p.text, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
                Text(desc, color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
        Panel(p) {
            Text(if (english) "PLATE BOUNDARIES" else "PLAKA SINIRLARI", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Ayrılan: plakalar uzaklaşır ve yeni kabuk oluşabilir.\nYakınlaşan: dalma-batma veya kıtasal çarpışma görülebilir.\nDönüşüm: plakalar yanal kayar; faylarda deprem oluşabilir.", color = p.text, fontSize = 13.sp, lineHeight = 21.sp)
        }
        Panel(p) {
            Text(if (english) "ROCK CYCLE" else "KAYAÇ DÖNGÜSÜ", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Magmanın soğuması magmatik kayaçları; çökelme ve taşlaşma tortul kayaçları; erimeden gerçekleşen ısı ve basınç etkisi başkalaşım kayaçlarını oluşturabilir. Süreç tek yönlü değildir.", color = p.text, fontSize = 13.sp, lineHeight = 21.sp)
        }
        Text("İçerik, USGS, National Geographic, Smithsonian ve National Park Service eğitim kaynaklarıyla desteklenmiştir.", color = p.muted, fontSize = 10.sp)
    }
}

@Composable
private fun DnaHelixView(p: Palette, english: Boolean) {
    val transition = androidx.compose.animation.core.rememberInfiniteTransition(label = "dna-rotation")
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = (Math.PI * 2).toFloat(),
        animationSpec = androidx.compose.animation.core.infiniteRepeatable<Float>(
            animation = androidx.compose.animation.core.tween<Float>(9000, easing = androidx.compose.animation.core.LinearEasing)
        ), label = "dna-phase"
    )
    androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(210.dp).background(p.bg, RoundedCornerShape(12.dp))) {
        val cx = size.width / 2f
        val top = 16.dp.toPx()
        val usable = size.height - 32.dp.toPx()
        val amplitude = size.width * .23f
        val steps = 28
        val left = androidx.compose.ui.graphics.Path()
        val right = androidx.compose.ui.graphics.Path()
        val rungs = ArrayList<Pair<androidx.compose.ui.geometry.Offset, androidx.compose.ui.geometry.Offset>>()
        for (i in 0..steps) {
            val t = i.toFloat() / steps
            val angle = t * (Math.PI * 4).toFloat() + phase
            val wave = kotlin.math.sin(angle.toDouble()).toFloat()
            val x1 = cx + wave * amplitude
            val x2 = cx - wave * amplitude
            val y = top + t * usable
            if (i == 0) { left.moveTo(x1, y); right.moveTo(x2, y) } else { left.lineTo(x1, y); right.lineTo(x2, y) }
            if (i % 2 == 0) rungs.add(androidx.compose.ui.geometry.Offset(x1,y) to androidx.compose.ui.geometry.Offset(x2,y))
        }
        drawPath(left, Color(0xFF54C6F0), style=Stroke(3.dp.toPx()))
        drawPath(right, Color(0xFFE18ACB), style=Stroke(3.dp.toPx()))
        rungs.forEachIndexed { index, pair ->
            val color = if (index % 2 == 0) Color(0xFFFFC857) else Color(0xFF7AD7A5)
            drawLine(color.copy(alpha=.8f), pair.first, pair.second, 2.dp.toPx())
            drawCircle(color, 3.dp.toPx(), pair.first)
            drawCircle(color, 3.dp.toPx(), pair.second)
        }

    }
}

private data class Planet(val name: String, val type: String, val diameter: String, val year: String, val moons: String, val facts: String, val mission: String)
private val planets = listOf(
    Planet("Merkür","Karasal","4.879 km","88 Dünya günü","0","Güneş'e en yakın gezegendir. Çok ince bir dış gaz örtüsüne sahiptir; gündüz ve gece sıcaklık farkı çok büyüktür. Büyük metalik çekirdeği gezegenin iç yapısında önemli yer tutar.","MESSENGER görevi yüzeyini ve manyetik alanını ayrıntılı haritaladı. BepiColombo Merkür'e yolculuğunu sürdürüyor."),
    Planet("Venüs","Karasal","12.104 km","225 Dünya günü","0","Yoğun karbondioksit atmosferi ve güçlü sera etkisi nedeniyle yüzeyi çok sıcaktır. Sülfürik asit bulutları bulunur. Yavaş ve ters yönlü dönüşüyle dikkat çeker.","Magellan radar haritalaması yaptı; Akatsuki atmosfer dinamiklerini inceledi."),
    Planet("Dünya","Karasal","12.742 km","365,25 gün","1","Yüzeyinde kalıcı sıvı su ve bildiğimiz yaşam bulunur. Atmosferi çoğunlukla azot ve oksijenden oluşur. Manyetik alanı Güneş rüzgârıyla etkileşir.","Çok sayıda uydu atmosferi, okyanusları, iklimi ve yüzeyi izler."),
    Planet("Mars","Karasal","6.779 km","687 Dünya günü","2","Demir oksit yüzeyine kızıl renk verir. Olympus Mons dev bir volkandır; Valles Marineris büyük bir kanyon sistemidir. Eski nehir yatakları ve mineraller geçmişte sıvı su bulunduğunu gösterir.","Curiosity ve Perseverance yüzeyi inceliyor; yörünge araçları haritalama yapıyor."),
    Planet("Jüpiter","Gaz devi","139.820 km","11,86 Dünya yılı","Çok sayıda","En büyük gezegendir; çoğunlukla hidrojen ve helyumdan oluşur. Büyük Kırmızı Leke dev bir fırtınadır. Europa'nın buz altında okyanusu olabileceğine dair güçlü kanıtlar vardır.","Juno gezegenin iç yapısını ve manyetik alanını inceliyor; Europa Clipper Europa'yı araştıracak."),
    Planet("Satürn","Gaz devi","116.460 km","29,4 Dünya yılı","Çok sayıda","Buz ve kaya parçacıklarından oluşan halkalarıyla tanınır. Titan'da metan ve etan gölleri; Enceladus'ta buz altı okyanusuna işaret eden püskürmeler vardır.","Cassini-Huygens görevi Satürn, halkaları ve uyduları hakkında büyük miktarda veri topladı."),
    Planet("Uranüs","Buz devi","50.724 km","84 Dünya yılı","Çok sayıda","Eksen eğikliği yaklaşık 98 derecedir; adeta yan yatmış şekilde döner. Atmosferindeki metan mavi-yeşil görünmesine katkı verir.","Yakından ziyaret eden tek araç Voyager 2'dir. Gelecekte yeni bir yörünge görevi önerilmektedir."),
    Planet("Neptün","Buz devi","49.244 km","165 Dünya yılı","Çok sayıda","Güneş'ten uzaklığı nedeniyle çok az enerji alır. Atmosferinde çok hızlı rüzgârlar ve değişken koyu fırtınalar görülür.","Voyager 2 1989'da yakınından geçti; günümüzde teleskoplarla izlenir.")
)

@Composable
private fun SpacePage(p: Palette, english: Boolean) {
    var expanded by rememberSaveable { mutableStateOf("Dünya") }
    var spaceTab by rememberSaveable { mutableStateOf(if (english) "Overview" else "Özet") }
    val topics = listOf(
        "Güneş'in yapısı" to "Güneş, kütlesinin büyük bölümünü hidrojen ve helyumun oluşturduğu bir yıldızdır. Çekirdeğinde proton-proton zinciriyle füzyon gerçekleşir.",
        "Yörüngeler ve kütleçekim" to "Gezegenler, Güneş'in kütleçekim alanında eliptik yörüngelerde hareket eder. Kepler yasaları yörünge geometrisini ve dolanım sürelerini açıklar.",
        "Ay ve gelgitler" to "Ay ve Güneş'in kütleçekimi okyanus gelgitlerini oluşturur. Dünya-Ay sistemi ortak kütle merkezi çevresinde hareket eder.",
        "Asteroitler ve kuyruklu yıldızlar" to "Asteroitler çoğunlukla kayaç ve metal içerir. Kuyruklu yıldızlarda uçucu buzlar bulunur; Güneş'e yaklaşınca gaz ve toz salımı artar.",
        "Cüce gezegenler" to "Cüce gezegenler Güneş çevresinde dolanır, yaklaşık küresel şekildedir ancak yörünge çevresini diğer cisimlerden temizlememiştir.",
        "Ötegezegenler" to "Ötegezegenler başka yıldızların çevresinde dolanır. Geçiş yöntemi yıldız parlaklığındaki düzenli azalmayı, dikey hız yöntemi yıldızın tayfsal salınımını ölçer.",
        "Yıldızların yaşam döngüsü" to "Yıldızların evrimi başlangıç kütlesine bağlıdır. Güneş benzeri yıldızlar sonunda beyaz cüceye dönüşür; daha büyük kütleli yıldızlarda farklı son evreler görülür.",
        "Galaksiler" to "Galaksiler yıldız, gaz, toz ve karanlık madde içeren kütleçekimsel sistemlerdir. Samanyolu çubuklu sarmal galaksidir."
    )
    val englishTopics = listOf(
        "The Sun's structure" to "The Sun is a star made mostly of hydrogen and helium. Nuclear fusion through the proton-proton chain occurs in its core.",
        "Orbits and gravity" to "Planets move in elliptical orbits within the Sun's gravitational field. Kepler's laws describe orbital geometry and periods.",
        "The Moon and tides" to "The gravitational pull of the Moon and Sun produces ocean tides. The Earth-Moon system moves around a shared centre of mass.",
        "Asteroids and comets" to "Asteroids are mostly rocky or metallic. Comets contain volatile ices and release gas and dust as they approach the Sun.",
        "Dwarf planets" to "Dwarf planets orbit the Sun and are nearly round, but have not cleared their orbital neighbourhood of other objects.",
        "Exoplanets" to "Exoplanets orbit stars beyond the Sun. The transit method measures dips in stellar brightness; radial-velocity measurements detect stellar motion.",
        "Stellar life cycles" to "A star's evolution depends on its initial mass. Sun-like stars end as white dwarfs, while more massive stars have different final stages.",
        "Galaxies" to "Galaxies are gravitational systems of stars, gas, dust and dark matter. The Milky Way is a barred spiral galaxy."
    )
    val planetFactsEnglish = mapOf(
        "Merkür" to "Mercury is the closest planet to the Sun. It has an extremely thin exosphere and large day-night temperature differences. Its large metallic core is a major part of its internal structure.",
        "Venüs" to "Venus has a dense carbon-dioxide atmosphere and an intense greenhouse effect, making its surface extremely hot. Sulfuric-acid clouds and slow retrograde rotation are notable features.",
        "Dünya" to "Earth has stable surface liquid water and the only known life. Its atmosphere is mostly nitrogen and oxygen, and its magnetic field interacts with the solar wind.",
        "Mars" to "Iron oxides give Mars its red colour. Olympus Mons is a giant volcano and Valles Marineris is a vast canyon system. Ancient channels and minerals indicate past liquid water.",
        "Jüpiter" to "Jupiter is the largest planet and consists mainly of hydrogen and helium. The Great Red Spot is a giant storm. Europa may host a subsurface ocean.",
        "Satürn" to "Saturn is known for rings made of ice and rocky particles. Titan has methane and ethane lakes; Enceladus has jets associated with a subsurface ocean.",
        "Uranüs" to "Uranus has an axial tilt of about 98 degrees and rotates almost on its side. Atmospheric methane contributes to its blue-green appearance.",
        "Neptün" to "Neptune receives little solar energy because of its distance. Its atmosphere has very fast winds and changing dark storms."
    )
    val planetMissionsEnglish = mapOf(
        "Merkür" to "MESSENGER mapped its surface and magnetic field. BepiColombo is travelling to the planet.",
        "Venüs" to "Magellan mapped the surface with radar; Akatsuki studied atmospheric dynamics.",
        "Dünya" to "Many satellites monitor the atmosphere, oceans, climate and surface.",
        "Mars" to "Curiosity and Perseverance explore the surface; orbiters map the planet.",
        "Jüpiter" to "Juno studies the interior and magnetic field; Europa Clipper is investigating Europa.",
        "Satürn" to "Cassini-Huygens collected extensive data about Saturn, its rings and moons.",
        "Uranüs" to "Voyager 2 is the only spacecraft to visit Uranus; a future orbiter has been proposed.",
        "Neptün" to "Voyager 2 flew by in 1989; telescopes continue to observe Neptune."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Panel(p) { Text(if (english) "The Solar System" else "Güneş Sistemi", color=p.accent, fontWeight=FontWeight.Bold, fontSize=22.sp); Text(if (english) "A gravitational system containing the Sun, eight planets, moons, dwarf planets and small bodies. Model scales are normalized for clarity." else "Güneş, sekiz gezegen, uydular, cüce gezegenler ve küçük cisimlerden oluşan kütleçekimsel sistem. Model ölçekleri anlaşılır görünüm için normalize edilmiştir.", color=p.muted, lineHeight=19.sp, fontSize=12.sp) }
        Panel(p) { Text(if (english) "Solar-system projection" else "Güneş Sistemi izdüşümü", color=p.accent, fontWeight=FontWeight.Bold); Text(if (english) "Drag to rotate · use + / − to zoom · tap a planet to select it." else "Sürükle: sistemi döndür · + / −: yakınlaş · bir gezegene dokun: bilgi seç.", color=p.muted, fontSize=11.sp); SolarSystem3DView(english) }
        LearningQuiz(p, english,
            if (english) "PLANETARY SCIENCE · QUICK CHECK" else "GEZEGEN BİLİMİ · KISA TEST",
            if (english) "Which planet has the largest volcano known in the Solar System, Olympus Mons?" else "Güneş Sistemi'ndeki bilinen en büyük yanardağ Olympus Mons hangi gezegendedir?",
            if (english) listOf("Venus", "Earth", "Mars", "Mercury") else listOf("Venüs", "Dünya", "Mars", "Merkür"), 2,
            if (english) "Olympus Mons is a giant shield volcano on Mars." else "Olympus Mons, Mars üzerindeki dev bir kalkan yanardağıdır.")
        Text(if (english) "Planets" else "Gezegenler", color=p.text, fontWeight=FontWeight.Bold, fontSize=18.sp)
        planets.forEach { planet ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded=if(expanded==planet.name) "" else planet.name }, verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(planet.name, color=p.accent, fontWeight=FontWeight.Bold, fontSize=16.sp); Text(if (english) "${when(planet.type) { "Karasal" -> "Terrestrial"; "Gaz devi" -> "Gas giant"; "Buz devi" -> "Ice giant"; else -> planet.type }} · orbital period ${planet.year}" else "${planet.type} · yörünge dönemi ${planet.year}", color=p.muted, fontSize=11.sp) }
                    Icon(if(expanded==planet.name) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.accent)
                }
                if(expanded==planet.name) { Spacer(Modifier.height(7.dp)); Text(if (english) "Diameter: ${planet.diameter} · Known moons: ${planet.moons}" else "Çap: ${planet.diameter} · Bilinen uydu: ${planet.moons}", color=p.text, fontWeight=FontWeight.SemiBold, fontSize=12.sp); Text(if (english) planetFactsEnglish[planet.name] ?: planet.facts else planet.facts, color=p.text, lineHeight=20.sp); Text(if (english) "Exploration missions: ${when(planet.name) { "Merkür" -> "MESSENGER mapped its surface and magnetic field; BepiColombo is en route."; "Venüs" -> "Magellan mapped the surface with radar; Akatsuki studied atmospheric dynamics."; "Dünya" -> "Many satellites monitor the atmosphere, oceans, climate and surface."; "Mars" -> "Curiosity and Perseverance explore the surface; orbiters map the planet."; "Jüpiter" -> "Juno studies the interior and magnetic field; Europa Clipper is investigating Europa."; "Satürn" -> "Cassini-Huygens collected extensive data on Saturn, its rings and moons."; "Uranüs" -> "Voyager 2 is the only spacecraft to have visited; a future orbiter has been proposed."; else -> "Voyager 2 flew by in 1989; telescopes continue to observe Neptune." }}" else "Keşif görevleri: ${planet.mission}", color=p.muted, fontSize=11.sp, lineHeight=18.sp) }
            }
        }
        LearningTabs(p, spaceTab, english) { spaceTab=it }
        when(spaceTab) {
            if (english) "Overview" else "Özet" -> Panel(p) { Text(if (english) "Solar System overview" else "Güneş Sistemi'nin genel görünümü", color=p.accent, fontWeight=FontWeight.Bold); Text(if (english) "The Solar System contains planets, moons and small bodies bound by the Sun's gravity. Most planetary orbits lie in roughly the same plane and direction." else "Güneş Sistemi, merkezindeki Güneş'in kütleçekimiyle bağlı gezegenleri, uyduları ve küçük cisimleri içerir. Gezegenlerin yörüngeleri yaklaşık aynı düzlemde ve aynı yönde bulunur.", color=p.text, lineHeight=20.sp) }
            if (english) "Structure" else "Yapı" -> Panel(p) { Text(if (english) "System components" else "Sistemin bileşenleri", color=p.accent, fontWeight=FontWeight.Bold); Text(if (english) "The Sun is at the centre. Rocky planets orbit in the inner system; gas and ice giants occupy the outer system. The asteroid belt, Kuiper Belt and Oort Cloud contain smaller bodies." else "Sistemin merkezinde Güneş yer alır. İçte kayasal gezegenler, dışta gaz ve buz devleri bulunur. Asteroit kuşağı, Kuiper Kuşağı ve Oort Bulutu küçük cisim topluluklarıdır.", color=p.text, lineHeight=20.sp) }
            else -> Panel(p) { Text(if (english) "Orbital motion" else "Yörünge hareketi", color=p.accent, fontWeight=FontWeight.Bold); Text(if (english) "Planets travel in elliptical orbits under gravity. They move faster near the Sun and slower when farther away, as described by Kepler's laws." else "Gezegenler kütleçekim etkisiyle eliptik yörüngelerde dolanır. Güneş'e yaklaştıklarında yörünge hızları artar; uzaklaştıklarında azalır. Bu hareket Kepler yasalarıyla açıklanır.", color=p.text, lineHeight=20.sp) }
        }
        Text(if (english) "Space and astrophysics" else "Uzay ve astrofizik", color=p.accent, fontWeight=FontWeight.Bold, fontSize=18.sp)
        (if (english) englishTopics else topics).forEach { (title, body) -> Panel(p) { Text(title, color=p.accent, fontWeight=FontWeight.Bold); Text(body, color=p.text, lineHeight=20.sp) } }
        Panel(p) { Text(if (english) "Dwarf planets and small bodies" else "Cüce gezegenler ve küçük cisimler", color=p.accent, fontWeight=FontWeight.Bold); Text(if (english) "Pluto, Ceres, Eris, Haumea and Makemake are dwarf planets. The main asteroid belt lies between Mars and Jupiter; the Kuiper Belt lies beyond Neptune." else "Plüton, Ceres, Eris, Haumea ve Makemake cüce gezegenler arasındadır. Ana asteroit kuşağı Mars ile Jüpiter arasında; Kuiper Kuşağı Neptün ötesindedir.", color=p.text, lineHeight=20.sp) }
    }
}

@Composable
private fun SolarSystem3DView(english: Boolean) {
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>
    *{box-sizing:border-box}body{margin:0;background:#06111f;color:#eaf4ff;font:12px Arial}.tools{display:flex;gap:7px;padding:8px;align-items:center}.tools button{background:#142b42;color:#eaf4ff;border:1px solid #426b89;border-radius:9px;padding:7px 12px}.stage{height:285px;touch-action:none}canvas{width:100%;height:100%;display:block}.caption{padding:0 10px 8px;color:#a9c3dc;font-size:11px;min-height:18px}
    </style></head><body><div class='tools'><button id='minus'>−</button><button id='plus'>+</button><button id='reset'>${if (english) "Reset" else "Sıfırla"}</button><span>${if (english) "Interactive projection" else "Etkileşimli izdüşüm"}</span></div><div class='stage' id='stage'><canvas id='c'></canvas></div><div class='caption' id='caption'>${if (english) "Tap a planet to select it." else "Bir gezegene dokunarak seç."}</div><script>
    (()=>{const stage=document.getElementById('stage'),c=document.getElementById('c'),ctx=c.getContext('2d');let yaw=-.55,pitch=.38,zoom=1,drag=false,px=0,py=0,selected=-1,anim=0,last=0,raf=0;
    const bodies=[['${if (english) "Mercury" else "Merkür"}',0.42,0.12,'#9a9b9e'],['${if (english) "Venus" else "Venüs"}',0.72,0.19,'#d9a66b'],['${if (english) "Earth" else "Dünya"}',1.02,0.20,'#4c9de8'],['Mars',1.36,0.16,'#d56b4d'],['${if (english) "Jupiter" else "Jüpiter"}',2.05,0.43,'#d7b58b'],['${if (english) "Saturn" else "Satürn"}',2.75,0.36,'#d8c18b'],['${if (english) "Uranus" else "Uranüs"}',3.43,0.28,'#83d5d4'],['${if (english) "Neptune" else "Neptün"}',4.05,0.27,'#477de0']];
    const stars=Array.from({length:90},(_,i)=>[Math.random(),Math.random(),Math.random()*1.5]);function resize(){const d=Math.min(devicePixelRatio||1,1.5),w=stage.clientWidth,h=stage.clientHeight;c.width=Math.floor(w*d);c.height=Math.floor(h*d);ctx.setTransform(d,0,0,d,0,0);draw()}new ResizeObserver(resize).observe(stage);
    function project(x,y,z){const cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch),xx=x*cy-z*sy,zz=x*sy+z*cy,yy=y*cp-zz*sp,depth=y*sp+zz*cp,scale=Math.min(stage.clientWidth*.44,stage.clientHeight*.80)/5.5*zoom/(1+depth*.035);return [stage.clientWidth/2+xx*scale,stage.clientHeight/2+yy*scale,depth,scale]}
    function sphere(x,y,z,r,col,ring=false){const q=project(x,y,z),rad=Math.max(2,r*q[3]);const g=ctx.createRadialGradient(q[0]-rad*.35,q[1]-rad*.4,1,q[0],q[1],rad*1.2);g.addColorStop(0,'#ffffff');g.addColorStop(.18,col);g.addColorStop(1,'#07101b');ctx.fillStyle=g;ctx.beginPath();ctx.arc(q[0],q[1],rad,0,Math.PI*2);ctx.fill();if(ring){ctx.save();ctx.translate(q[0],q[1]);ctx.rotate(-.25);ctx.strokeStyle='#cbbd9a';ctx.lineWidth=Math.max(2,rad*.22);ctx.beginPath();ctx.ellipse(0,0,rad*1.65,rad*.55,0,0,Math.PI*2);ctx.stroke();ctx.restore()}return q}
    function draw(){const w=stage.clientWidth,h=stage.clientHeight;if(!w||!h)return;ctx.clearRect(0,0,w,h);const bg=ctx.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#07172a');bg.addColorStop(1,'#030914');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);stars.forEach(s=>{ctx.fillStyle='rgba(200,225,255,'+(0.2+s[2]*.25)+')';ctx.fillRect(s[0]*w,s[1]*h,1+s[2]*.4,1+s[2]*.4)});
    const center=project(0,0,0);sphere(0,0,0,.56,'#ffb33d');ctx.save();ctx.shadowColor='#ffb33d';ctx.shadowBlur=22;ctx.strokeStyle='rgba(255,183,73,.25)';ctx.lineWidth=2;ctx.beginPath();ctx.arc(center[0],center[1],center[3]*.9,0,Math.PI*2);ctx.stroke();ctx.restore();
    bodies.forEach((b,i)=>{ctx.strokeStyle='rgba(113,167,212,.24)';ctx.lineWidth=1;ctx.beginPath();for(let j=0;j<=100;j++){const a=j/100*Math.PI*2,q=project(Math.cos(a)*b[1]*1.35,0,Math.sin(a)*b[1]*1.35);if(j===0)ctx.moveTo(q[0],q[1]);else ctx.lineTo(q[0],q[1])}ctx.stroke();const a=anim*(.15+i*.018)+i*.8,x=Math.cos(a)*b[1]*1.35,z=Math.sin(a)*b[1]*1.35,q=sphere(x,0,z,b[2],b[3],i===5);if(selected===i){ctx.strokeStyle='#75d5ff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(q[0],q[1],Math.max(7,b[2]*q[3]+5),0,Math.PI*2);ctx.stroke()} });
    ctx.fillStyle='#b9d5ee';ctx.font='10px Arial';ctx.fillText('${if (english) "SUN" else "GÜNEŞ"}',center[0]+14,center[1]-16);}
    function frame(t){if(document.hidden)return;if(t-last>40){anim+=.012;draw();last=t}raf=requestAnimationFrame(frame)}raf=requestAnimationFrame(frame);document.addEventListener('visibilitychange',()=>{if(!document.hidden){last=performance.now();cancelAnimationFrame(raf);raf=requestAnimationFrame(frame)}else cancelAnimationFrame(raf)});
    stage.addEventListener('pointerdown',e=>{drag=true;px=e.clientX;py=e.clientY;stage.setPointerCapture(e.pointerId)});stage.addEventListener('pointermove',e=>{if(!drag)return;yaw+=(e.clientX-px)*.008;pitch=Math.max(-1.1,Math.min(1.1,pitch+(e.clientY-py)*.006));px=e.clientX;py=e.clientY;draw()});stage.addEventListener('pointerup',()=>drag=false);stage.addEventListener('pointercancel',()=>drag=false);stage.addEventListener('click',e=>{const x=e.offsetX,y=e.offsetY;let best=1e9; bodies.forEach((b,i)=>{const a=anim*(.15+i*.018)+i*.8,q=project(Math.cos(a)*b[1]*1.35,0,Math.sin(a)*b[1]*1.35),d=Math.hypot(x-q[0],y-q[1]);if(d<best){best=d;selected=i}});if(best<42)document.getElementById('caption').textContent=bodies[selected][0]+' ${if (english) "selected · schematic orbit" else "seçildi · yörünge şematik gösterilir"}.';draw()});document.getElementById('plus').onclick=()=>{zoom=Math.min(2.2,zoom*1.15);draw()};document.getElementById('minus').onclick=()=>{zoom=Math.max(.55,zoom/1.15);draw()};document.getElementById('reset').onclick=()=>{yaw=-.55;pitch=.38;zoom=1;selected=-1;draw()};document.addEventListener('visibilitychange',()=>{if(document.hidden)last=performance.now()});window.addEventListener('pagehide',()=>{cancelAnimationFrame(raf)})})();
    </script></body></html>"""
    AndroidView(modifier=Modifier.fillMaxWidth().height(355.dp).clip(RoundedCornerShape(14.dp)), factory={ctx->WebView(ctx).apply{settings.javaScriptEnabled=true;settings.domStorageEnabled=false;settings.allowFileAccess=false;settings.allowContentAccess=false;settings.javaScriptCanOpenWindowsAutomatically=false;settings.setSupportMultipleWindows(false);settings.mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW;settings.blockNetworkLoads=true;setBackgroundColor(android.graphics.Color.TRANSPARENT);loadDataWithBaseURL(null,html,"text/html","UTF-8",null)}}, onRelease={ it.stopLoading(); it.loadUrl("about:blank"); it.removeAllViews(); it.destroy() })
}


private fun localizedElementFamily(kind: String, english: Boolean): String = if (!english) kind else when (kind) {
    "Alkali metal" -> "Alkali metal"
    "Toprak alkali" -> "Alkaline earth metal"
    "Geçiş metali" -> "Transition metal"
    "Metal" -> "Post-transition metal"
    "Yarı metal" -> "Metalloid"
    "Ametal" -> "Nonmetal"
    "Halojen" -> "Halogen"
    "Soygaz" -> "Noble gas"
    "Lantanit" -> "Lanthanide"
    "Aktinit" -> "Actinide"
    else -> "Unknown"
}

@Composable
private fun ElementsPage(p: Palette, english: Boolean, onElement: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var zoom by rememberSaveable { mutableFloatStateOf(1f) }
    var panX by rememberSaveable { mutableFloatStateOf(0f) }
    var panY by rememberSaveable { mutableFloatStateOf(0f) }
    val filtered = remember(query) {
        val normalizedQuery = normalizeElementSearch(query.trim())
        if (normalizedQuery.isEmpty()) elementRows else elementRows.filter { element ->
            normalizeElementSearch(element[0]).contains(normalizedQuery) ||
                normalizeElementSearch(element[1]).contains(normalizedQuery) ||
                normalizeElementSearch(englishElementName(element[2].toInt())).contains(normalizedQuery) ||
                element[2] == normalizedQuery
        }
    }
    val byNumber = remember { elementRows.associateBy { it[2].toInt() } }
    val periodicRows: List<List<Int?>> = listOf(
        listOf<Int?>(1) + List(16) { null } + listOf(2),
        listOf<Int?>(3, 4) + List(10) { null } + listOf(5, 6, 7, 8, 9, 10),
        listOf<Int?>(11, 12) + List(10) { null } + listOf(13, 14, 15, 16, 17, 18),
        (19..36).map { it }, (37..54).map { it },
        listOf<Int?>(55, 56, null) + (72..86).map { it },
        listOf<Int?>(87, 88, null) + (104..118).map { it },
        listOf<Int?>(null, null, null) + (57..71).map { it },
        listOf<Int?>(null, null, null) + (89..103).map { it }
    )
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(if (english) "Periodic table" else "Periyodik tablo", color = p.text, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text(if (english) "118 elements · Pinch with two fingers to zoom · Swipe to move" else "118 element · İki parmağınla yakınlaştır veya uzaklaştır · Kaydırarak tabloda gezin", color = p.muted, fontSize = 11.sp)
        OutlinedTextField(
            value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text(if (english) "Search element, symbol or atomic number" else "Element, sembol veya atom numarası ara") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(14.dp)
        )
        Spacer(Modifier.height(8.dp))
        if (query.isBlank()) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Alkali metal", "Toprak alkali", "Geçiş metali", "Metal", "Yarı metal", "Ametal", "Halojen", "Soygaz", "Lantanit", "Aktinit").forEach { family ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
                        Box(Modifier.size(8.dp).background(elementFamilyColor(family), CircleShape))
                        Spacer(Modifier.width(4.dp))
                        Text(localizedElementFamily(family, english), color = p.muted, fontSize = 9.sp, maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { zoom = (zoom / 1.2f).coerceAtLeast(.55f) }) {
                    Text("−", color = p.accent, fontSize = 20.sp)
                }
                Text("${(zoom * 100).toInt()}%", color = p.muted, fontSize = 11.sp)
                TextButton(onClick = { zoom = (zoom * 1.2f).coerceAtMost(2.2f) }) {
                    Text("+", color = p.accent, fontSize = 20.sp)
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { zoom = 1f; panX = 0f; panY = 0f }) {
                    Text(if (english) "Reset view" else "Görünümü sıfırla", color = p.accent, fontSize = 11.sp)
                }
            }
            BoxWithConstraints(
                Modifier.weight(1f).fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(p.panel.copy(alpha = .45f))
            ) {
                val density = androidx.compose.ui.platform.LocalDensity.current
                val contentWidthPx = with(density) { 1012.dp.toPx() }
                val contentHeightPx = with(density) { 584.dp.toPx() }
                Box(
                    Modifier.fillMaxSize()
                        .pointerInput(Unit) {
                            detectTransformGestures { centroid, pan, gestureZoom, _ ->
                                val oldZoom = zoom
                                val nextZoom = (oldZoom * gestureZoom).coerceIn(.55f, 2.2f)
                                val ratio = nextZoom / oldZoom
                                val proposedX = centroid.x - (centroid.x - panX) * ratio + pan.x
                                val proposedY = centroid.y - (centroid.y - panY) * ratio + pan.y
                                val minX = minOf(0f, size.width - contentWidthPx * nextZoom)
                                val minY = minOf(0f, size.height - contentHeightPx * nextZoom)
                                panX = proposedX.coerceIn(minX, 0f)
                                panY = proposedY.coerceIn(minY, 0f)
                                zoom = nextZoom
                            }
                        }
                ) {
                Column(
                    modifier = Modifier.wrapContentSize(unbounded = true, align = Alignment.TopStart).graphicsLayer {
                        scaleX = zoom
                        scaleY = zoom
                        translationX = panX
                        translationY = panY
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0f)
                    }.padding(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        (1..18).forEach { group ->
                            Box(Modifier.size(52.dp, 18.dp), contentAlignment = Alignment.Center) {
                                Text(group.toString(), color = p.muted, fontSize = 8.sp)
                            }
                        }
                    }
                    periodicRows.forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            row.forEach { atomicNumber ->
                                val element = atomicNumber?.let { byNumber[it] }
                                if (element == null) {
                                    Spacer(Modifier.size(52.dp, 58.dp))
                                } else {
                                    val family = element[4]
                                    val familyColor = elementFamilyColor(family)
                                    Card(
                                        onClick = { onElement(element[0]) },
                                        modifier = Modifier.size(52.dp, 58.dp),
                                        colors = CardDefaults.cardColors(containerColor = familyColor.copy(alpha = if (themeIsLight(p)) .22f else .20f)),
                                        border = BorderStroke(1.dp, familyColor.copy(alpha = .85f))
                                    ) {
                                        Column(
                                            Modifier.fillMaxSize().padding(3.dp),
                                            verticalArrangement = Arrangement.Center,
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(element[2], color = p.muted, fontSize = 7.sp)
                                            Text(element[0], color = familyColor, fontWeight = FontWeight.Black, fontSize = 18.sp)
                                            Text(if (english) englishElementName(element[2].toInt()) else element[1], color = p.text, fontSize = 7.sp, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                }
            }
            Text(if (english) "Lanthanides and actinides are shown in the two detached rows." else "Lantanitler ve aktinitler alttaki iki ayrı sırada gösterilir.", color = p.muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.weight(1f), contentPadding = PaddingValues(3.dp), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(filtered, key = { it[2] }) { element ->
                    val familyColor = elementFamilyColor(element[4])
                    Card(
                        onClick = { onElement(element[0]) },
                        colors = CardDefaults.cardColors(containerColor = familyColor.copy(alpha = .18f)),
                        border = BorderStroke(1.dp, familyColor.copy(alpha = .75f)),
                        modifier = Modifier.heightIn(min = 88.dp)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(element[2], color = p.muted, fontSize = 10.sp)
                            Text(element[0], color = familyColor, fontWeight = FontWeight.Black, fontSize = 25.sp)
                            Text(if (english) englishElementName(element[2].toInt()) else element[1], color = p.text, fontSize = 12.sp, maxLines = 1)
                            Text(localizedElementFamily(element[4], english), color = p.muted, fontSize = 9.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

private fun themeIsLight(p: Palette): Boolean = p.name == "Laboratuvar" || p.name == "Light Science"

@Composable
private fun ElementDetailPage(p: Palette, element: List<String>, english: Boolean, onBack: () -> Unit) {
    val (symbol, name, numberText, mass, kind) = element
    val z = numberText.toIntOrNull() ?: 1
    val period = elementPeriod(z)
    val group = elementGroup(z)
    val block = elementBlock(z)
    val config = elementElectronConfigNote(z)
    val radioactive = z == 43 || z == 61 || z >= 83
    val noStableIsotope = z == 43 || z == 61 || z >= 84
    val massLabel = if (noStableIsotope) "[$mass] u*" else "$mass u"
    val detail = elementEducation(element)
    var infoTab by rememberSaveable { mutableStateOf(if (english) "Overview" else "Özet") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, if (english) "Back" else "Geri", tint = p.accent) }
            Text(if (english) "Element profile" else "Element öğrenme dosyası", color = p.text, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
        Panel(p) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (english) "ATOMIC NUMBER $z" else "ATOM NUMARASI $z", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text(if (english) englishElementName(z) else name, color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text(localizedElementFamily(kind, english), color = p.muted)
                }
                Box(Modifier.size(88.dp).clip(RoundedCornerShape(18.dp)).background(p.accent.copy(alpha = .16f)), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(z.toString(), color = p.muted, fontSize = 11.sp)
                        Text(symbol, color = p.accent, fontSize = 38.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                ElementStat(p, if (english) "Atomic mass" else "Atom kütlesi", massLabel)
                ElementStat(p, if (english) "Protons" else "Proton", z.toString())
                ElementStat(p, if (english) "Electrons*" else "Elektron*", z.toString())
            }
            Text(if (english) "* Electron count is for a neutral atom. Ions have different electron counts depending on their charge." else "* Elektron sayısı nötr atom için verilmiştir. İyonlarda elektron sayısı yük durumuna göre değişir.", color = p.muted, fontSize = 10.sp)
        }
        LearningTabs(p, infoTab, english) { infoTab = it }
        Panel(p) {
            Text(if (english) when(infoTab) { "Overview" -> "Element overview"; "Structure" -> "Atomic structure and classification"; else -> "Chemical behaviour" } else when(infoTab) { "Özet" -> "Elementin genel tanımı"; "Yapı" -> "Atomik yapı ve sınıflandırma"; else -> "Kimyasal davranış ve işleyiş" }, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (english) when(infoTab) { "Overview" -> "${englishElementName(z)} ($symbol) is a chemical element with atomic number $z. An element is defined by its number of protons."; "Structure" -> "A neutral atom contains $z protons and $z electrons. The neutron count depends on the isotope. Electron configuration: $config."; else -> "${englishElementName(z)} belongs to the ${localizedElementFamily(kind, true).lowercase()} family. Its chemical behaviour depends on its electron structure and the conditions of the reaction." } else when(infoTab) { "Özet" -> "$name ( $symbol ), atom numarası $z olan kimyasal elementtir. Elementin kimliği proton sayısıyla belirlenir."; "Yapı" -> "Nötr atomda $z proton ve $z elektron bulunur. Nötron sayısı izotopa göre değişir. Elektron dizilimi: $config."; else -> detail }, color = p.text, lineHeight = 21.sp)
        }
        Panel(p) {
            Text(if (english) "Position in the periodic table" else "Periyodik tablodaki konumu", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (english) "Period: $period     Group: $group     Block: $block" else "Periyot: $period     Grup: $group     Blok: $block", color = p.text, fontWeight = FontWeight.SemiBold)
            Text(if (english) "State: ${when(z) { 1,2,7,8,9,10,17,18,36,54,86 -> "Gas (25 °C, 1 atm)"; 35,80 -> "Liquid (25 °C, 1 atm)"; in 104..118 -> "Unknown experimentally"; else -> "Solid (25 °C, 1 atm)" }}" else "Fiziksel hâl: ${elementState(z)}", color = p.text)
            Text(if (english) "Covalent radius: ${covalentRadiusPm(z)?.let { "$it pm" } ?: "no reliable experimental value"}" else "Kovalent yarıçap: ${covalentRadiusPm(z)?.let { "$it pm" } ?: "güvenilir deneysel değer yok"}", color = p.text)
            Text(if (english) "Electron configuration: $config" else "Elektron dizilimi: $config", color = p.text, lineHeight = 21.sp)
            Text(if (english) "An element’s position in the periodic table is related to its atomic number and electron structure. Elements in the same group often share chemical properties because their valence-electron configurations are similar." else "Elementin periyodik tablodaki konumu, atom numarası ve elektron yapısıyla ilişkilidir. Aynı gruptaki elementlerin değerlik elektron düzenleri benzer olduğundan bazı kimyasal özellikleri de benzerlik gösterir.", color = p.muted, lineHeight = 20.sp, fontSize = 12.sp)
        }
        Panel(p) {
            Text(if (english) "Chemistry and significance" else if (setOf("H", "He", "Li", "C", "N", "O", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "K", "Ca", "Fe", "Cu", "Zn", "Ag", "I", "Au", "Hg", "Pb", "U").contains(symbol)) "Elementin kimyası ve önemi" else "Element ailesi ve kimyasal bağlam", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (english) "${englishElementName(z)} has chemical and physical properties determined by its electron structure, bonding behaviour and environmental conditions. Its practical uses depend on these properties and on the form in which the element is present." else detail, color = p.text, lineHeight = 22.sp)
        }
        Panel(p) {
            Text(if (english) "Fundamental particles" else "Atomun temel parçacıkları", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (english) "Protons: $z\nElectrons in a neutral atom: $z\nNeutrons: depend on the selected isotope." else "Proton sayısı: $z\nNötr atomdaki elektron sayısı: $z\nNötron sayısı: seçilen izotopa bağlıdır.", color = p.text, lineHeight = 22.sp)
            Text(if (english) "The atomic number defines an element. Isotopes of the same element have the same number of protons but different numbers of neutrons, so there is no single neutron count for every atom of an element." else "Atom numarası elementin kimliğini belirler. Aynı elementin proton sayısı aynı, nötron sayısı farklı olan atomlarına izotop denir. Bu nedenle tek bir nötron sayısı bütün atomlar için geçerli değildir.", color = p.muted, lineHeight = 20.sp, fontSize = 12.sp)
        }
        if (radioactive) Panel(p) {
            Text(if (english) "Radioactivity and atomic-mass note" else "Radyoaktivite ve atom kütlesi notu", color = p.accent, fontWeight = FontWeight.Bold)
            Text(if (english) { if (noStableIsotope) "This element has no stable isotopes. The number in square brackets is the mass number of a selected isotope, not a standard atomic weight." else "All known isotopes of bismuth are radioactive; Bi-209 has an extremely long half-life, so the standard atomic-weight notation is retained." } else { if (noStableIsotope) "Bu elementin kararlı izotopu yoktur. Köşeli parantez içindeki sayı, standart atom ağırlığı yerine seçilmiş bir izotopun kütle numarasını belirtir; doğal izotopların ortalama atom ağırlığı gibi yorumlanmamalıdır." else "Bizmutun bilinen izotopları radyoaktiftir; Bi-209 çok uzun yarı ömürlüdür. Bu nedenle tabloda standart atom ağırlığı gösterimi korunur." }, color = p.text, lineHeight = 21.sp)
        }
        Panel(p) {
            Text(if (english) "Schematic atom visualization" else "Şematik atom görselleştirmesi", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Atom3DView(p, symbol, z, english = english)
            Text(if (english) "This is a schematic educational illustration, not a scale-accurate quantum-mechanical model. Electron shells are shown only as a simplified introductory visualization." else "Model, atomun ölçekli veya kuantum-mekanik açıdan tam temsili değildir. Elektronların belirli dairesel yörüngelerde dolaştığı izlenimi vermemek için bu görünüm eğitim amaçlı şematik bir görselleştirmedir.", color = p.muted, fontSize = 11.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun ElementStat(p: Palette, title: String, value: String) {
    Column(Modifier.widthIn(min = 76.dp).background(p.bg.copy(alpha=.5f), RoundedCornerShape(12.dp)).padding(9.dp)) {
        Text(title, color = p.muted, fontSize = 10.sp)
        Text(value, color = p.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}


@Composable
private fun AtomLabPage(p: Palette, english: Boolean) {
    var selected by rememberSaveable { mutableIntStateOf(6) }
    val choices = listOf(1, 2, 6, 8, 11, 17, 26, 29, 79, 92)
    val current = elementRows.firstOrNull { it[2].toIntOrNull() == selected } ?: elementRows[5]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel(p) {
            Text(if (english) "ATOM LAB" else "ATOM LABORATUVARI", color = p.accent, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 11.sp)
            Text(if (english) "Explore the atom layer by layer" else "Atomu katman katman incele", color = p.text, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text(if (english) "Select an element and inspect its nucleus and electron-shell illustration. The model is not to scale and electrons do not travel in classical planetary orbits." else "Element seç, çekirdek ve elektron gösterimini incele. Model ölçekli değildir; elektronlar klasik gezegen yörüngelerinde hareket etmez.", color = p.muted, lineHeight = 20.sp)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            choices.forEach { z ->
                val el = elementRows[z - 1]
                FilterChip(selected = selected == z, onClick = { selected = z }, label = { Text(el[0]) })
            }
        }
        Panel(p) {
            Text("${if (english) englishElementName(selected) else current[1]} (${current[0]})", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text(if (english) "Atomic number ${current[2]} · Protons ${current[2]} · Electrons in a neutral atom ${current[2]}" else "Atom numarası ${current[2]} · Proton ${current[2]} · Nötr atom elektronu ${current[2]}", color = p.text)
            Atom3DView(p, current[0], selected, isotopeMassFor(selected), english)
            Text(if (english) "Electron configuration: ${elementElectronConfigNote(selected)}" else "Elektron dizilimi: ${elementElectronConfigNote(selected)}", color = p.muted, fontSize = 12.sp)
        }
        Panel(p) {
            Text(if (english) "What defines an atom?" else "Atom nasıl tanımlanır?", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (english) "The nucleus contains positively charged protons and neutral neutrons. Negatively charged electrons occupy quantum states. Proton number defines the element; changing neutron number creates an isotope, while changing electron number creates an ion." else "Çekirdekte pozitif yüklü protonlar ve yüksüz nötronlar bulunur. Negatif yüklü elektronlar atomun kuantum durumlarını oluşturur. Proton sayısı atom numarasıdır ve elementin kimliğini belirler. Nötron sayısı değişirse izotop, elektron sayısı değişirse iyon oluşur.", color = p.text, lineHeight = 22.sp)
        }
        Panel(p) {
            Text(if (english) "The orbital model" else "Orbital fikri", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (english) "s, p, d and f orbitals are quantum states describing the probability distribution of electrons. An orbital can contain up to two electrons with opposite spin quantum numbers. Bohr shell drawings can be useful introductions, but real electron structure is described by probability distributions." else "s, p, d ve f orbitalleri elektronların bulunma olasılığını tanımlayan kuantum durumlarıdır. Bir orbital en fazla iki elektron barındırır ve bu elektronların spin kuantum sayıları zıttır. Bohr kabuk çizimleri başlangıç düzeyinde yararlı olabilir; ancak atomların gerçek elektron yapısı olasılık dağılımlarıyla açıklanır.", color = p.text, lineHeight = 22.sp)
        }
    }
}

@Composable
private fun MathematicsPage(p: Palette, english: Boolean) {
    var coefficient by rememberSaveable { mutableFloatStateOf(1f) }
    var xValue by rememberSaveable { mutableFloatStateOf(1.5f) }
    var diceRolls by rememberSaveable { mutableIntStateOf(0) }
    var sixes by rememberSaveable { mutableIntStateOf(0) }
    val yValue = coefficient * xValue * xValue
    val topics = if (english) listOf(
        "Number systems" to "Natural, integer, rational, irrational and real numbers are classified by their algebraic properties.",
        "Algebra and equations" to "An equation states that two expressions are equal. Applying the same valid operation to both sides preserves the solution set.",
        "Functions" to "A function assigns exactly one output to each input in its domain. Its graph reveals how the output changes as the input changes.",
        "Geometry" to "Geometry studies shape, distance, angle, area and volume. In Euclidean geometry, the interior angles of a triangle sum to 180 degrees.",
        "Trigonometry" to "Sine, cosine and tangent connect angles with side ratios. The unit circle extends these relationships to all angles.",
        "Probability and statistics" to "Probability quantifies uncertainty. Statistics collects, summarizes and analyzes data to identify patterns and variation.",
        "Derivatives and integrals" to "A derivative describes instantaneous rate of change; an integral describes accumulation and area."
    ) else listOf(
        "Sayı kümeleri" to "Doğal sayılar, tam sayılar, rasyonel, irrasyonel ve gerçek sayılar farklı özelliklere göre tanımlanır.",
        "Cebir ve denklemler" to "Denklem, iki ifadenin eşitliğini sağlayan bilinmeyen değerlerini arar. Eşitliğin iki tarafına aynı işlem uygulanırsa çözüm kümesi korunur.",
        "Fonksiyonlar" to "Fonksiyon, tanım kümesindeki her girdiye değer kümesinde tek bir çıktı eşleyen kuraldır. Grafik, ilişkinin nasıl değiştiğini gösterir.",
        "Geometri" to "Geometri şekillerin, açıların, uzunlukların, alanların ve hacimlerin ilişkilerini inceler. Üçgen iç açıları toplamı 180 derecedir.",
        "Trigonometri" to "Sinüs, kosinüs ve tanjant açıları kenar oranlarıyla ilişkilendirir. Birim çember bu oranları tüm açılara genişletir.",
        "Olasılık ve istatistik" to "Olasılık belirsiz olayların matematiksel ölçüsüdür. İstatistik veri toplama, özetleme ve çıkarım yöntemlerini kapsar.",
        "Türev ve integral" to "Türev anlık değişim hızını, integral birikimi ve alan ilişkilerini inceler."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text(if (english) "MATHEMATICS WORKSPACE" else "MATEMATİK ATÖLYESİ", color = p.accent, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 11.sp)
            Text(if (english) "Explore relationships, not just formulas" else "Yalnızca formülleri değil, ilişkileri keşfet", color = p.text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(if (english) "Change the parameters and watch the model respond." else "Parametreleri değiştir ve modelin nasıl tepki verdiğini gözlemle.", color = p.muted)
        }
        Panel(p) {
            Text(if (english) "LIVE FUNCTION GRAPH" else "CANLI FONKSİYON GRAFİĞİ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp)
            Text("y = ${"%.1f".format(coefficient)}x²", color=p.text, fontWeight=FontWeight.Bold, fontSize=20.sp)
            Text(if (english) "Curve coefficient (a)" else "Parabol katsayısı (a)", color=p.muted, fontSize=12.sp)
            Slider(value=coefficient, onValueChange={coefficient=it}, valueRange=-2f..2f)
            Text(if (english) "Input value (x)" else "Girdi değeri (x)", color=p.muted, fontSize=12.sp)
            Slider(value=xValue, onValueChange={xValue=it}, valueRange=-4f..4f)
            Text("x = ${"%.2f".format(xValue)}     y = ${"%.2f".format(yValue)}", color=p.accent, fontWeight=FontWeight.Bold)
            androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(185.dp).background(p.bg, RoundedCornerShape(12.dp)).padding(8.dp)) {
                val midY=size.height/2; val midX=size.width/2; val unit=size.width/9f
                drawLine(p.muted.copy(alpha=.55f), androidx.compose.ui.geometry.Offset(0f,midY), androidx.compose.ui.geometry.Offset(size.width,midY),1.dp.toPx())
                drawLine(p.muted.copy(alpha=.55f), androidx.compose.ui.geometry.Offset(midX,0f), androidx.compose.ui.geometry.Offset(midX,size.height),1.dp.toPx())
                val path=androidx.compose.ui.graphics.Path()
                for(i in 0..160){ val x=-4f+i/20f; val y=coefficient*x*x; val pt=androidx.compose.ui.geometry.Offset(midX+x*unit, midY-y.coerceIn(-8f,8f)*unit*.42f); if(i==0)path.moveTo(pt.x,pt.y) else path.lineTo(pt.x,pt.y) }
                drawPath(path,p.accent,style=Stroke(width=3.dp.toPx()))
                drawCircle(Color(0xFFFFC857),5.dp.toPx(),androidx.compose.ui.geometry.Offset(midX+xValue*unit,midY-yValue.coerceIn(-8f,8f)*unit*.42f))
            }
            Text(if (english) "The graph is a numerical visualization of y = ax²." else "Grafik, y = ax² fonksiyonunun sayısal görselleştirmesidir.", color=p.muted, fontSize=10.sp)
        }
        Panel(p) {
            Text(if (english) "PROBABILITY EXPERIMENT · FAIR DIE" else "OLASILIK DENEYİ · ADİL ZAR", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            Text(if (english) "Roll the die repeatedly and compare the observed frequency of six with the theoretical probability (1/6)." else "Zarı tekrar tekrar at. Altı gelme sıklığını teorik olasılık olan 1/6 ile karşılaştır.", color=p.muted, fontSize=12.sp, lineHeight=18.sp)
            Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                Button(onClick={ val roll=(1..6).random(); diceRolls++; if(roll==6) sixes++ }) { Text(if (english) "Roll" else "Zar at") }
                OutlinedButton(onClick={diceRolls=0; sixes=0}) { Text(if (english) "Reset" else "Sıfırla") }
            }
            Text(if (english) "Trials: $diceRolls · Sixes: $sixes · Observed: ${if(diceRolls==0) "0.0" else "%.1f".format(sixes*100f/diceRolls)}% · Expected: 16.7%" else "Atış: $diceRolls · Altı: $sixes · Gözlenen: ${if(diceRolls==0) "0,0" else "%.1f".format(sixes*100f/diceRolls)}% · Teorik: 16,7%", color=p.text, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
        }
        Panel(p) {
            Text(if (english) "DERIVATIVE EXPLORER" else "TÜREV KEŞFİ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            val slope = 2f * coefficient * xValue
            Text(if (english) "For f(x)=ax², f′(x)=2ax" else "f(x)=ax² için f′(x)=2ax", color=p.text, fontWeight=FontWeight.Bold, fontSize=18.sp)
            Text(if (english) "Instantaneous slope at x=${"%.2f".format(xValue)}: ${"%.2f".format(slope)}" else "x=${"%.2f".format(xValue)} noktasındaki anlık eğim: ${"%.2f".format(slope)}", color=p.accent, fontWeight=FontWeight.SemiBold)
            Text(if (english) "This analytic derivative is exact for the displayed quadratic function." else "Bu analitik türev, gösterilen ikinci dereceden fonksiyon için kesindir.", color=p.muted, fontSize=10.sp)
        }
        LearningQuiz(p, english,
            if (english) "FUNCTIONS · QUICK CHECK" else "FONKSİYONLAR · KISA TEST",
            if (english) "If f(x)=x², what is f(3)?" else "f(x)=x² ise f(3) kaçtır?",
            if (english) listOf("6", "9", "3", "12") else listOf("6", "9", "3", "12"), 1,
            if (english) "Substitute x=3: 3²=9." else "x yerine 3 yazılır: 3²=9.")
        topics.forEachIndexed { index, topic ->
            var expanded by rememberSaveable(topic.first) { mutableStateOf(index == 0) }
            Panel(p, Modifier.clickable { expanded = !expanded }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${index + 1}.", color = p.accent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Text(topic.first, color = p.text, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.muted)
                }
                if (expanded) Text(topic.second, color = p.muted, lineHeight = 21.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
private fun ChemistryPage(p: Palette, english: Boolean) {
    val topics = if (english) listOf(
        "Atomic structure" to "An atom contains a nucleus of protons and neutrons surrounded by an electron cloud. Proton number defines the element; isotopes differ in neutron number.",
        "Periodic trends" to "Atomic radius, ionization energy and electronegativity show repeating trends across the periodic table. These trends help explain chemical behaviour.",
        "Chemical bonds" to "Ionic bonds involve electrostatic attraction between ions. Covalent bonds share electron pairs. Metallic bonding involves delocalized valence electrons.",
        "Reactions and balancing" to "Chemical reactions rearrange atoms. In a closed system, atoms and total mass are conserved; equations are balanced by matching atom counts.",
        "Acids, bases and pH" to "pH is a logarithmic measure of acidity in aqueous solutions. At 25 °C, pH 7 is neutral; lower values are acidic and higher values are basic.",
        "Solutions and concentration" to "A solution contains a solute distributed in a solvent. Concentration can be expressed as molarity or percentage; temperature and chemical identity affect solubility.",
        "Organic chemistry" to "Organic chemistry studies carbon compounds, including hydrocarbons, alcohols, carboxylic acids, esters and polymers.",
        "Chemistry and energy" to "Exothermic reactions release energy; endothermic reactions absorb it. Reaction rates depend on temperature, concentration, surface area and catalysts.",
        "Laboratory safety" to "Read labels and safety data. Use appropriate protective equipment. Never taste or directly smell chemicals, and do not mix unknown substances.",
        "Chemical equilibrium" to "Dynamic equilibrium occurs when forward and reverse reaction rates are equal. Concentration, pressure and temperature can shift the equilibrium position.",
        "Electrochemistry" to "Redox reactions transfer electrons. Galvanic cells produce electrical energy from spontaneous reactions; electrolysis uses external energy to drive chemical change.",
        "Polymers" to "Polymers are large molecules made of repeating units. Proteins and cellulose are natural examples; polyethylene and nylon are synthetic examples."
    ) else listOf(
        "Atomun yapısı" to "Atom; proton ve nötronlardan oluşan çekirdek ile elektron bulutundan meydana gelir. Proton sayısı elementin kimliğini belirler. Nötron sayısı izotopları, elektron dizilimi ise kimyasal davranışın önemli bölümünü belirler.",
        "Periyodik eğilimler" to "Aynı gruptaki elementlerin değerlik elektron yapıları benzerdir. Atom yarıçapı, iyonlaşma enerjisi ve elektronegatiflik periyodik tabloda düzenli eğilimler gösterir; bu eğilimler elementlerin tepkime davranışını anlamaya yardımcı olur.",
        "Kimyasal bağlar" to "İyonik bağ zıt yüklü iyonların elektrostatik çekimidir. Kovalent bağda atomlar elektron çiftlerini paylaşır. Metalik bağda değerlik elektronları metal yapısı boyunca delokalizedir.",
        "Tepkimeler ve denkleştirme" to "Kimyasal tepkimelerde atomlar yeniden düzenlenir; kapalı sistemlerde toplam atom sayısı ve kütle korunur. Denklem denkleştirme, her elementin atom sayısını iki tarafta eşitler.",
        "Asit, baz ve pH" to "pH sulu çözeltilerin asitlik-bazlık durumunu ifade eden logaritmik bir ölçüdür. 25 °C'de pH 7 nötr kabul edilir; daha düşük değerler asidik, daha yüksek değerler bazik ortamı gösterir.",
        "Çözeltiler ve derişim" to "Çözelti, çözücü içinde dağılmış çözünen maddeden oluşur. Derişim molarite veya yüzde gibi birimlerle ifade edilebilir. Sıcaklık ve maddenin türü çözünürlüğü etkiler.",
        "Organik kimya" to "Karbon bileşiklerinin yapısını, özelliklerini ve tepkimelerini inceler. Hidrokarbonlar, alkoller, karboksilik asitler, esterler ve polimerler önemli bileşik sınıflarıdır.",
        "Kimya ve enerji" to "Ekzotermik tepkimeler çevreye enerji verir; endotermik tepkimeler çevreden enerji alır. Tepkime hızı sıcaklık, derişim, yüzey alanı ve katalizör gibi etkenlerden etkilenebilir.",
        "Laboratuvar güvenliği" to "Etiketler ve güvenlik bilgi formları okunur; koruyucu gözlük ve uygun ekipman kullanılır. Bilinmeyen maddeler karıştırılmaz, maddeler tadılmaz veya doğrudan koklanmaz. Deneyler yalnızca yetkili gözetiminde yapılır.",
        "Kimyasal denge" to "Tersinir tepkimelerde ileri ve geri tepkime hızları eşitlendiğinde dinamik denge oluşur. Derişim, basınç ve sıcaklık değişimleri denge konumunu etkileyebilir.",
        "Elektrokimya" to "Redoks tepkimelerinde elektron aktarımı gerçekleşir. Galvanik hücreler kendiliğinden gerçekleşen tepkimelerden elektrik üretirken elektroliz dış enerjiyle kimyasal dönüşüm sağlar.",
        "Polimerler" to "Polimerler tekrarlayan monomer birimlerinden oluşan büyük moleküllerdir. Doğal örnekler arasında protein ve selüloz; sentetik örnekler arasında polietilen ve naylon bulunur."
    )
    var expanded by rememberSaveable { mutableStateOf(topics.first().first) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) {
            Text(if (english) "CHEMISTRY LAB" else "KİMYA LABORATUVARI", color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp, letterSpacing=2.sp)
            Text(if (english) "Matter, bonds and transformations" else "Madde, bağlar ve dönüşümler", color=p.text, fontSize=21.sp, fontWeight=FontWeight.Bold)
            Text(if (english) "Water molecule · interactive projection" else "Su molekülü · etkileşimli izdüşüm", color=p.muted, fontSize=12.sp)
            Molecule3DView(p, english)
        }
        LearningQuiz(p, english,
            if (english) "CHEMICAL BONDS · QUICK CHECK" else "KİMYASAL BAĞLAR · KISA TEST",
            if (english) "Which bond involves sharing electron pairs between atoms?" else "Atomlar arasında elektron çiftlerinin ortaklaşa kullanıldığı bağ hangisidir?",
            if (english) listOf("Ionic bond", "Covalent bond", "Metallic bond", "Hydrogen bond") else listOf("İyonik bağ", "Kovalent bağ", "Metalik bağ", "Hidrojen bağı"), 1,
            if (english) "Covalent bonds form when atoms share electron pairs." else "Kovalent bağ, atomların elektron çiftlerini ortaklaşa kullanmasıyla oluşur.")
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded=if(expanded==title) "" else title }, verticalAlignment=Alignment.CenterVertically) {
                    Text(title, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                    Icon(if(expanded==title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.accent)
                }
                if(expanded==title) Text(body, color=p.text, lineHeight=21.sp, modifier=Modifier.padding(top=7.dp))
            }
        }
    }
}


@Composable
private fun Molecule3DView(p: Palette, english: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            if (english) "Interactive local 3D water model" else "Etkileşimli yerel 3B su modeli",
            color = p.muted,
            fontSize = 11.sp
        )
        AndroidView(
            modifier = Modifier.fillMaxWidth().height(290.dp).clip(RoundedCornerShape(14.dp)),
            factory = { ctx ->
                val assetLoader = WebViewAssetLoader.Builder()
                    .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
                    .build()
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = false
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.allowFileAccessFromFileURLs = false
                    settings.allowUniversalAccessFromFileURLs = false
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    settings.setSupportMultipleWindows(false)
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    settings.blockNetworkLoads = true
                    isVerticalScrollBarEnabled = false
                    isHorizontalScrollBarEnabled = false
                    webViewClient = object : WebViewClientCompat() {
                        override fun shouldInterceptRequest(
                            view: WebView,
                            request: WebResourceRequest
                        ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
                    }
                    setBackgroundColor(android.graphics.Color.rgb(7, 19, 33))
                    loadUrl("https://appassets.androidplatform.net/assets/lab/index.html?model=water")
                }
            },
            onRelease = { view ->
                view.stopLoading()
                view.loadUrl("about:blank")
                view.removeAllViews()
                view.destroy()
            }
        )
    }
}


@Composable
private fun MicrobiologyPage(p: Palette, english: Boolean) {
    val topics = if (english) listOf(
        "Introduction to microorganisms" to "Microbiology studies microorganisms and microscopic biological structures. Bacteria and archaea are prokaryotes; yeasts and protozoa are eukaryotes.",
        "Bacteria" to "Bacteria are single-celled prokaryotes. Their shapes, metabolisms and habitats vary widely. Some are beneficial, while others can cause disease.",
        "Viruses" to "Viruses are not cellular. They carry genetic material inside a protein coat and use host-cell machinery to reproduce. Antibiotics do not treat viral infections.",
        "Fungi and yeasts" to "Fungi are eukaryotes. Yeasts are usually single-celled, while moulds form filamentous structures. Fungi contribute to decomposition and food production.",
        "Protozoa and algae" to "Protozoa are mostly single-celled eukaryotes. Algae include diverse photosynthetic organisms and contribute to aquatic primary production.",
        "Microbiota" to "Microbiota are communities of microorganisms living in and on the body. Gut microbes contribute to digestion, metabolism and immune functions.",
        "Microscopy" to "Light microscopes reveal cells and microorganisms. Resolution, sample preparation and staining matter as much as magnification.",
        "Cell membrane" to "The phospholipid bilayer forms a selectively permeable boundary. Membrane proteins support transport, communication and recognition.",
        "Ribosomes" to "Ribosomes use messenger RNA to assemble amino acids into polypeptide chains. They occur in both prokaryotic and eukaryotic cells.",
        "Mitochondria" to "Mitochondria contribute to ATP production during aerobic respiration. They have two membranes and their own DNA.",
        "Microbial ecology" to "Microorganisms contribute to the carbon, nitrogen and sulfur cycles and help maintain soil and aquatic ecosystems.",
        "Antibiotic resistance" to "Resistance allows bacteria to survive exposure to an antibiotic. Unnecessary or incorrect antibiotic use can increase selection for resistant strains."
    ) else listOf(
        "Mikroorganizmalara giriş" to "Mikrobiyoloji, mikroorganizmaları ve mikroskobik biyolojik yapıları inceler. Bakteriler ve arkeler prokaryot; maya ve protozoalar ökaryot hücre yapısına sahiptir.",
        "Bakteriler" to "Bakteriler tek hücreli prokaryotlardır. Şekilleri, metabolizmaları ve yaşadıkları ortamlar çeşitlidir. Bazıları insan sağlığı için yararlı roller üstlenirken bazıları hastalıklara neden olabilir.",
        "Virüsler" to "Virüsler hücresel yapıda değildir; genetik materyallerini protein kılıf içinde taşırlar. Çoğalmak için konak hücrelerin mekanizmalarını kullanırlar. Antibiyotikler virüslere karşı etkili değildir.",
        "Mantarlar ve mayalar" to "Mantarlar ökaryot canlılardır. Mayalar tek hücreli, küfler çoğunlukla ipliksi yapılara sahip olabilir. Ayrıştırma, gıda üretimi ve ekosistem döngülerinde önemli görevleri vardır.",
        "Protozoalar ve algler" to "Protozoalar çoğunlukla tek hücreli ökaryotlardır. Algler fotosentez yapabilen çeşitli organizmaları kapsar; su ekosistemlerinde birincil üretime katkı sağlar.",
        "Mikrobiyota" to "İnsan vücudunda ve üzerinde yaşayan mikroorganizma toplulukları mikrobiyotayı oluşturur. Bağırsak mikrobiyotası sindirim, metabolizma ve bağışıklıkla ilişkili işlevlerde rol oynar.",
        "Mikroskopi" to "Işık mikroskopları hücre ve mikroorganizma yapılarını incelemekte kullanılır. Büyütme kadar çözünürlük, örnek hazırlama ve uygun boyama yöntemi de gözlemin kalitesini belirler.",
        "Hücre zarı" to "Fosfolipit çift tabakası seçici geçirgen bir sınır oluşturur. Zar proteinleri madde taşınması, hücre iletişimi ve tanımada görev alır.",
        "Ribozomlar" to "Ribozomlar mRNA bilgisini kullanarak amino asitleri polipeptit zincirlerine bağlar. Hem prokaryot hem ökaryot hücrelerde bulunurlar.",
        "Mitokondri" to "Mitokondriler oksijenli solunumun birçok basamağında ATP üretimine katkı sağlar. Kendi DNA'larına ve çift zarlı yapıya sahiptirler.",
        "Mikrobiyal ekoloji" to "Mikroorganizmalar karbon, azot ve kükürt döngülerinde önemli rol oynar. Toprak ve okyanus ekosistemlerinin işleyişine katkı verir.",
        "Antibiyotik direnci" to "Direnç, bakterilerin bir antibiyotiğe rağmen çoğalabilmesini sağlayan kalıtsal özelliklerle ilişkilidir. Antibiyotiklerin gereksiz veya yanlış kullanımı direnç seçilimini artırabilir."
    )
    var expanded by rememberSaveable { mutableStateOf(topics.first().first) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) {
            Text(if (english) "MICROBIOLOGY" else "MİKROBİYOLOJİ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp, letterSpacing=2.sp)
            Text(if (english) "Explore the microscopic world" else "Mikroskobik dünyayı keşfet", color=p.text, fontWeight=FontWeight.Bold, fontSize=21.sp)
            Text(if (english) "Cells, microorganisms and the systems they influence." else "Hücreler, mikroorganizmalar ve etkiledikleri sistemler.", color=p.muted)
        }
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded=if(expanded==title) "" else title }, verticalAlignment=Alignment.CenterVertically) {
                    Text(title, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                    Icon(if(expanded==title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.accent)
                }
                if(expanded==title) { Spacer(Modifier.height(7.dp)); Text(body, color=p.text, lineHeight=21.sp) }
            }
        }
        Panel(p) {
            LearningQuiz(p, english,
            if (english) "MICROBIOLOGY · QUICK CHECK" else "MİKROBİYOLOJİ · KISA TEST",
            if (english) "Which structure is present in bacteria but absent from animal cells?" else "Bakterilerde bulunup hayvan hücrelerinde bulunmayan yapı hangisidir?",
            if (english) listOf("Nucleus", "Mitochondrion", "Peptidoglycan cell wall", "Golgi apparatus") else listOf("Çekirdek", "Mitokondri", "Peptidoglikan hücre duvarı", "Golgi aygıtı"), 2,
            if (english) "Most bacteria have a peptidoglycan cell wall; animal cells do not." else "Bakterilerin çoğunda peptidoglikan hücre duvarı bulunur; hayvan hücrelerinde bulunmaz.")
        Text(if (english) "Scientific note" else "Bilimsel not", color=p.accent, fontWeight=FontWeight.Bold)
            Text(if (english) "Whether viruses should be considered living organisms is debated; they are not classified as cellular life." else "Virüslerin canlı olarak sınıflandırılması tartışmalıdır; hücresel canlılarla aynı grupta değerlendirilmezler.", color=p.text)
        }
    }
}

@Composable
private fun VisualLabPage(p: Palette, english: Boolean, initialModel: String = "atom") {
    Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (english) "Interactive 3D models" else "Etkileşimli 3B modeller", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(if (english) "Rotate, zoom and switch between locally bundled scientific scenes." else "Yerel olarak pakete eklenmiş bilimsel sahneleri döndür, yakınlaştır ve değiştir.", color = p.muted, fontSize = 12.sp, lineHeight = 17.sp)
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(16.dp)),
            factory = { ctx ->
                val assetLoader = WebViewAssetLoader.Builder()
                    .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
                    .build()
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = false
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.allowFileAccessFromFileURLs = false
                    settings.allowUniversalAccessFromFileURLs = false
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    settings.setSupportMultipleWindows(false)
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    settings.blockNetworkLoads = true
                    isVerticalScrollBarEnabled = false
                    isHorizontalScrollBarEnabled = false
                    webViewClient = object : WebViewClientCompat() {
                        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                            assetLoader.shouldInterceptRequest(request.url)
                    }
                    setBackgroundColor(android.graphics.Color.rgb(7, 19, 33))
                    loadUrl("https://appassets.androidplatform.net/assets/lab/index.html?model=$initialModel")
                }
            },
            onRelease = { view ->
                view.stopLoading()
                view.loadUrl("about:blank")
                view.removeAllViews()
                view.destroy()
            }
        )
        Text(if (english) "Educational models are schematic; scale and assumptions are described in each scene." else "Modeller eğitim amaçlı şematik temsillerdir; ölçek ve varsayımlar her sahnede açıklanır.", color = p.muted, fontSize = 10.sp, lineHeight = 14.sp)
    }
}


private val representativeIsotopeMasses = mapOf(
    1 to 1, 2 to 4, 6 to 12, 8 to 16, 11 to 23,
    17 to 35, 26 to 56, 29 to 64, 79 to 197, 92 to 238
)

private fun isotopeMassFor(z: Int): Int? = representativeIsotopeMasses[z]

@Composable
private fun Atom3DView(p: Palette, symbol: String, atomicNumber: Int, isotopeMass: Int? = null, english: Boolean = false) {
    val shellCounts = when(atomicNumber) { 1->listOf(1);2->listOf(2);6->listOf(2,4);8->listOf(2,6);11->listOf(2,8,1);17->listOf(2,8,7);26->listOf(2,8,14,2);29->listOf(2,8,18,1);79->listOf(2,8,18,32,18,1);92->listOf(2,8,18,32,21,9,2);else->listOf(2, minOf(8,(atomicNumber-2).coerceAtLeast(0)), minOf(18,(atomicNumber-10).coerceAtLeast(0))).filter{it>0} }
    val shellJson = shellCounts.joinToString(",")
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>body{margin:0;background:#071525;color:#eaf4ff;font:12px Arial}.tools{padding:7px;display:flex;gap:8px}.tools button{background:#17334e;color:#eaf4ff;border:1px solid #47718d;border-radius:8px;padding:7px 10px}.stage{height:260px;touch-action:none}canvas{width:100%;height:100%;display:block}</style></head><body><div class='tools'><button id='reset'>${if (english) "Reset view" else "Görünümü sıfırla"}</button><span>$symbol · Z=$atomicNumber</span></div><div class='stage' id='stage'><canvas id='c'></canvas></div><script>(()=>{const st=document.getElementById('stage'),c=document.getElementById('c'),ctx=c.getContext('2d'),shells=[$shellJson];let rot=0,drag=false,px=0,auto=true;function size(){let d=Math.min(devicePixelRatio||1,1.5);c.width=st.clientWidth*d;c.height=st.clientHeight*d;ctx.setTransform(d,0,0,d,0,0)}new ResizeObserver(size).observe(st);function draw(){let w=st.clientWidth,h=st.clientHeight;ctx.clearRect(0,0,w,h);ctx.fillStyle='#071525';ctx.fillRect(0,0,w,h);let cx=w/2,cy=h/2,r0=Math.min(w,h)*.11;let g=ctx.createRadialGradient(cx-r0*.3,cy-r0*.4,1,cx,cy,r0);g.addColorStop(0,'#ffd2c8');g.addColorStop(.35,'#e45f63');g.addColorStop(1,'#651d34');ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,r0,0,Math.PI*2);ctx.fill();shells.forEach((n,i)=>{let r=r0+28+i*24;ctx.strokeStyle='rgba(112,188,225,.48)';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(cx,cy,r,r*.42,rot+i*.3,0,Math.PI*2);ctx.stroke();for(let j=0;j<n;j++){let a=rot*(i%2?-.7:1)+j/n*Math.PI*2;let x=cx+Math.cos(a)*r*Math.cos(rot+i*.3),y=cy+Math.sin(a)*r*.42;let eg=ctx.createRadialGradient(x-2,y-2,1,x,y,5);eg.addColorStop(0,'#fff');eg.addColorStop(.4,'#71d9ff');eg.addColorStop(1,'#14618a');ctx.fillStyle=eg;ctx.beginPath();ctx.arc(x,y,4.5,0,Math.PI*2);ctx.fill()}});ctx.fillStyle='#d5e8f7';ctx.font='11px Arial';ctx.textAlign='center';ctx.fillText('${if (english) "Electron-shell illustration is schematic" else "Elektron katmanları şematik gösterimdir"}',cx,h-10)}let raf=0,last=0;function frame(t){if(document.hidden)return;if(t-last>33){if(auto&&!drag)rot+=.008;draw();last=t}raf=requestAnimationFrame(frame)}raf=requestAnimationFrame(frame);document.addEventListener('visibilitychange',()=>{if(document.hidden)cancelAnimationFrame(raf);else{last=performance.now();raf=requestAnimationFrame(frame)}});window.addEventListener('pagehide',()=>cancelAnimationFrame(raf));st.onpointerdown=e=>{drag=true;px=e.clientX;st.setPointerCapture(e.pointerId)};st.onpointermove=e=>{if(drag){rot+=(e.clientX-px)*.01;px=e.clientX}};st.onpointerup=()=>drag=false;st.onpointercancel=()=>drag=false;document.getElementById('reset').onclick=()=>rot=0})();</script></body></html>"""
    AndroidView(modifier=Modifier.fillMaxWidth().height(320.dp).clip(RoundedCornerShape(12.dp)),factory={ctx->WebView(ctx).apply{settings.javaScriptEnabled=true;settings.allowFileAccess=false;settings.allowContentAccess=false;settings.javaScriptCanOpenWindowsAutomatically=false;settings.setSupportMultipleWindows(false);settings.mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW;settings.blockNetworkLoads=true;setBackgroundColor(android.graphics.Color.TRANSPARENT);loadDataWithBaseURL(null,html,"text/html","UTF-8",null)}}, onRelease={ it.stopLoading(); it.loadUrl("about:blank"); it.removeAllViews(); it.destroy() })
}



@Composable
private fun PhysicsKnowledgePage(p: Palette, english: Boolean) {
    var mass by rememberSaveable { mutableFloatStateOf(5f) }
    var force by rememberSaveable { mutableFloatStateOf(20f) }
    var voltage by rememberSaveable { mutableFloatStateOf(9f) }
    var resistance by rememberSaveable { mutableFloatStateOf(100f) }
    val acceleration = force / mass.coerceAtLeast(.1f)
    val current = voltage / resistance.coerceAtLeast(1f)
    val topics = if (english) listOf(
        "Electric charge and fields" to "Like charges repel and opposite charges attract. An electric field describes the force per unit positive test charge.",
        "Current, voltage and resistance" to "Current is the rate of charge flow. Voltage is energy transferred per unit charge. For an ohmic component, V = IR.",
        "Magnetism" to "Moving electric charges produce magnetic fields. Current-carrying conductors and electromagnets use this principle.",
        "Energy and motion" to "Kinetic energy depends on motion; potential energy depends on position or interaction. Friction can transform mechanical energy into thermal energy.",
        "Waves and light" to "Waves transfer energy. Sound is a mechanical wave and needs a medium; light is electromagnetic and can travel through a vacuum.",
        "Newton's laws" to "The net force on an object equals its mass multiplied by its acceleration: F = ma.",
        "Momentum" to "Momentum is mass multiplied by velocity. Total momentum is conserved in an isolated system.",
        "Thermodynamics" to "Thermodynamics studies heat, work, temperature and internal energy. Energy is conserved.",
        "Optics" to "Light changes direction when it crosses media with different refractive indices. Snell's law relates the angles and indices."
    ) else listOf(
        "Elektrik yükü ve alan" to "Aynı işaretli yükler birbirini iter, zıt işaretli yükler birbirini çeker. Elektrik alan, birim pozitif test yüküne etki eden kuvveti tanımlar.",
        "Akım, gerilim ve direnç" to "Akım yük akış hızıdır. Gerilim birim yük başına aktarılan enerjidir. Ohmik bir elemanda V = IR bağıntısı geçerlidir.",
        "Manyetizma" to "Hareketli elektrik yükleri manyetik alan oluşturur. Akım taşıyan iletkenler ve elektromıknatıslar bu ilkeden yararlanır.",
        "Enerji ve hareket" to "Kinetik enerji harekete, potansiyel enerji konuma veya etkileşime bağlıdır. Sürtünme mekanik enerjiyi ısıya dönüştürebilir.",
        "Dalgalar ve ışık" to "Dalgalar enerji taşır. Ses mekanik dalgadır ve ortam gerektirir; ışık elektromanyetiktir ve boşlukta yayılabilir.",
        "Newton yasaları" to "Bir cisme etki eden net kuvvet, kütlesi ile ivmesinin çarpımına eşittir: F = ma.",
        "Momentum" to "Momentum kütle ile hızın çarpımıdır. Yalıtılmış sistemlerde toplam momentum korunur.",
        "Termodinamik" to "Termodinamik ısı, iş, sıcaklık ve iç enerji arasındaki ilişkileri inceler. Enerji korunur.",
        "Optik" to "Işık, farklı kırılma indislerine sahip ortamlar arasında geçerken yön değiştirebilir. Snell yasası açıları ve indisleri ilişkilendirir."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text(if (english) "PHYSICS LAB" else "FİZİK LABORATUVARI", color=p.accent, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=2.sp)
            Text(if (english) "Change a variable. Observe the result." else "Bir değişkeni değiştir. Sonucu gözlemle.", color=p.text, fontSize=21.sp, fontWeight=FontWeight.Bold)
            Text(if (english) "Interactive models use simplified ideal conditions." else "Etkileşimli modeller basitleştirilmiş ideal koşulları kullanır.", color=p.muted, fontSize=12.sp)
        }
        Panel(p) {
            Text(if (english) "MECHANICS · NEWTON'S SECOND LAW" else "MEKANİK · NEWTON'UN İKİNCİ YASASI", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            Text("F = ma", color=p.text, fontWeight=FontWeight.Black, fontSize=24.sp)
            Text(if (english) "Applied force (N)" else "Uygulanan kuvvet (N)", color=p.muted, fontSize=12.sp)
            Slider(value=force, onValueChange={force=it}, valueRange=0f..100f)
            Text("${"%.1f".format(force)} N", color=p.accent, fontWeight=FontWeight.Bold)
            Text(if (english) "Object mass (kg)" else "Cismin kütlesi (kg)", color=p.muted, fontSize=12.sp)
            Slider(value=mass, onValueChange={mass=it}, valueRange=.5f..20f)
            Text("${"%.1f".format(mass)} kg", color=p.accent, fontWeight=FontWeight.Bold)
            androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(76.dp).background(p.bg, RoundedCornerShape(12.dp)).padding(8.dp)) {
                val y=size.height/2
                drawLine(p.muted.copy(alpha=.5f), androidx.compose.ui.geometry.Offset(8f,y), androidx.compose.ui.geometry.Offset(size.width-8f,y),2.dp.toPx())
                val x=(size.width-28.dp.toPx())*(acceleration/200f).coerceIn(0f,1f)+14.dp.toPx()
                drawCircle(p.accent,14.dp.toPx(),androidx.compose.ui.geometry.Offset(x,y))
            }
            Text(if (english) "Calculated acceleration: ${"%.2f".format(acceleration)} m/s²" else "Hesaplanan ivme: ${"%.2f".format(acceleration)} m/s²", color=p.text, fontWeight=FontWeight.Bold)
        }
        Panel(p) {
            Text(if (english) "ELECTRONICS BENCH · OHM'S LAW" else "ELEKTRONİK TEZGAHI · OHM KANUNU", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            Text("V = I × R", color=p.text, fontSize=22.sp, fontWeight=FontWeight.Black)
            Text(if (english) "Supply voltage (V)" else "Kaynak gerilimi (V)", color=p.muted, fontSize=12.sp)
            Slider(value=voltage, onValueChange={voltage=it}, valueRange=1f..24f)
            Text("${"%.1f".format(voltage)} V", color=p.accent, fontWeight=FontWeight.Bold)
            Text(if (english) "Resistance (Ω)" else "Direnç (Ω)", color=p.muted, fontSize=12.sp)
            Slider(value=resistance, onValueChange={resistance=it}, valueRange=10f..1000f)
            Text("${"%.0f".format(resistance)} Ω", color=p.accent, fontWeight=FontWeight.Bold)
            Text(if (english) "Current: ${"%.3f".format(current)} A · Power: ${"%.2f".format(voltage*current)} W" else "Akım: ${"%.3f".format(current)} A · Güç: ${"%.2f".format(voltage*current)} W", color=p.text, fontWeight=FontWeight.Bold)
            Text(if (english) "Ideal DC calculation. Real components have tolerances and power limits." else "İdeal doğru akım hesabıdır. Gerçek bileşenlerin toleransları ve güç sınırları vardır.", color=p.muted, fontSize=10.sp)
        }
        var launchSpeed by rememberSaveable { mutableFloatStateOf(18f) }
        var launchAngle by rememberSaveable { mutableFloatStateOf(42f) }
        var gravity by rememberSaveable { mutableFloatStateOf(9.81f) }
        val radians = Math.toRadians(launchAngle.toDouble())
        val flight = (2.0 * launchSpeed * kotlin.math.sin(radians) / gravity).toFloat()
        val range = (launchSpeed * launchSpeed * kotlin.math.sin(2.0 * radians) / gravity).toFloat()
        val height = (launchSpeed * launchSpeed * kotlin.math.sin(radians).pow(2.0) / (2.0 * gravity)).toFloat()
        Panel(p) {
            Text(if (english) "PROJECTILE MOTION" else "EĞİK ATIŞ SİMÜLATÖRÜ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            Text("v₀ = ${"%.1f".format(launchSpeed)} m/s · θ = ${"%.0f".format(launchAngle)}°", color=p.text, fontWeight=FontWeight.Bold)
            Text(if (english) "Initial speed" else "İlk hız", color=p.muted, fontSize=11.sp)
            Slider(value=launchSpeed, onValueChange={launchSpeed=it}, valueRange=2f..40f)
            Text(if (english) "Launch angle" else "Fırlatma açısı", color=p.muted, fontSize=11.sp)
            Slider(value=launchAngle, onValueChange={launchAngle=it}, valueRange=0f..90f)
            Text(if (english) "Gravity" else "Yerçekimi", color=p.muted, fontSize=11.sp)
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                listOf("Earth" to 9.81f, "Moon" to 1.62f, "Mars" to 3.71f).forEach { (name,g) ->
                    FilterChip(selected = gravity == g, onClick = { gravity=g }, label = { Text(if (english) name else when(name) { "Earth" -> "Dünya"; "Moon" -> "Ay"; else -> "Mars" }, fontSize=10.sp) })
                }
            }
            androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(130.dp).background(p.bg, RoundedCornerShape(10.dp)).padding(8.dp)) {
                val w=size.width; val h=size.height; val ground=h-12.dp.toPx();
                drawLine(p.muted, androidx.compose.ui.geometry.Offset(8f,ground), androidx.compose.ui.geometry.Offset(w-8f,ground), 1.dp.toPx())
                val points=(0..60).map { i -> val t=flight*i/60f; val x=launchSpeed*kotlin.math.cos(radians).toFloat()*t; val y=launchSpeed*kotlin.math.sin(radians).toFloat()*t-.5f*gravity*t*t; androidx.compose.ui.geometry.Offset(10f+x/(range.coerceAtLeast(1f))* (w-20f), ground-y/(height.coerceAtLeast(1f))*(h-28f)) }
                val path=androidx.compose.ui.graphics.Path(); points.forEachIndexed { i,pt -> if(i==0)path.moveTo(pt.x,pt.y) else path.lineTo(pt.x,pt.y) }; drawPath(path,p.accent,style=Stroke(2.5.dp.toPx()))
            }
            Text(if (english) "Range: ${"%.2f".format(range)} m · Max height: ${"%.2f".format(height)} m · Flight: ${"%.2f".format(flight)} s" else "Menzil: ${"%.2f".format(range)} m · En yüksek nokta: ${"%.2f".format(height)} m · Uçuş: ${"%.2f".format(flight)} s", color=p.accent, fontWeight=FontWeight.SemiBold, fontSize=11.sp)
            Text(if (english) "Ideal model: no air resistance; launch and landing heights are equal." else "İdeal model: hava direnci yoktur; atış ve iniş yükseklikleri eşittir.", color=p.muted, fontSize=10.sp)
        }
        LearningQuiz(p, english,
            if (english) "NEWTON'S LAWS · QUICK CHECK" else "NEWTON YASALARI · KISA TEST",
            if (english) "A net force of 12 N acts on a 3 kg object. What is its acceleration?" else "3 kg kütleli cisme 12 N net kuvvet uygulanıyor. İvmesi kaçtır?",
            listOf("2 m/s²", "4 m/s²", "9 m/s²", "36 m/s²"), 1,
            if (english) "Newton's second law: a=F/m=12/3=4 m/s²." else "Newton'un ikinci yasası: a=F/m=12/3=4 m/s².")
        topics.forEachIndexed { index, (title, body) ->
            var open by rememberSaveable(title) { mutableStateOf(index == 0) }
            Panel(p, Modifier.clickable { open = !open }) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text(title, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                    Icon(if(open) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.muted)
                }
                if(open) Text(body, color=p.text, lineHeight=21.sp, modifier=Modifier.padding(top=7.dp))
            }
        }
    }
}

@Composable
private fun TechnologyKnowledgePage(p: Palette, english: Boolean) {
    val topics = if (english) listOf(
        "Semiconductors" to "The conductivity of semiconductors such as silicon can be changed by doping, temperature and electric fields. Diodes and transistors are fundamental electronic components.",
        "Processors and memory" to "A processor executes instructions and performs arithmetic and logic operations. RAM stores temporary working data; persistent storage retains data without power.",
        "Sensors" to "Sensors convert physical quantities such as temperature, pressure, acceleration, light or magnetic fields into measurable signals.",
        "Robotics and automation" to "Robotic systems combine sensing, control and motion. Feedback allows a system to correct its behaviour using measured output.",
        "Energy technologies" to "Solar cells convert light into electrical energy. Batteries store energy electrochemically; power electronics manage energy flow.",
        "Communication networks" to "Networks transmit data using protocols. Latency, bandwidth and reliability are key performance measures.",
        "Embedded systems" to "Embedded computers are built into devices to perform dedicated tasks. Microcontrollers combine processing, memory and input/output.",
        "3D printing" to "Additive manufacturing creates objects layer by layer, supporting rapid prototyping and complex geometries.",
        "Artificial intelligence" to "Machine-learning models identify patterns in data. Data quality and careful evaluation strongly affect reliability.",
        "Cybersecurity" to "Confidentiality, integrity and availability are core security goals. Authentication, updates and secure design help protect systems."
    ) else listOf(
        "Yarı iletkenler" to "Silisyum gibi yarı iletkenlerin elektriksel iletkenliği katkılama, sıcaklık ve elektrik alanla değiştirilebilir. Diyotlar ve transistörler modern elektroniğin temel yapı taşlarıdır.",
        "İşlemciler ve bellek" to "İşlemci komutları yürütür ve aritmetik-mantık işlemleri gerçekleştirir. RAM geçici çalışma verilerini tutar; kalıcı depolama veriyi enerji kesildiğinde de korur.",
        "Sensörler" to "Sensörler sıcaklık, basınç, ivme, ışık veya manyetik alan gibi fiziksel büyüklükleri ölçülebilir sinyallere dönüştürür.",
        "Robotik ve otomasyon" to "Robotik sistemler algılama, kontrol ve hareket bileşenlerini birleştirir. Geri besleme, sistemin ölçülen çıktıya göre davranışını düzeltmesini sağlar.",
        "Enerji teknolojileri" to "Güneş hücreleri ışığı elektrik enerjisine dönüştürür. Bataryalar enerjiyi elektrokimyasal süreçlerle depolar; güç elektroniği enerji akışını yönetir.",
        "İletişim ağları" to "Kablosuz ve kablolu ağlar veriyi protokoller aracılığıyla paketler ve iletir. Gecikme, bant genişliği ve güvenilirlik temel performans ölçütleridir.",
        "Gömülü sistemler" to "Gömülü bilgisayarlar belirli görevleri yerine getirmek üzere cihazların içine yerleştirilir. Mikrodenetleyici, bellek, giriş-çıkış ve yazılım birlikte çalışır.",
        "3B baskı" to "Eklemeli üretim, parçaları katmanlar halinde oluşturarak prototipleme ve özel geometrilerin üretimini kolaylaştırır.",
        "Yapay zekâ" to "Makine öğrenmesi, veriden örüntüler öğrenen modeller geliştirir. Eğitim verisinin niteliği ve modelin değerlendirilmesi sonuçların güvenilirliğini belirler.",
        "Siber güvenlik" to "Gizlilik, bütünlük ve erişilebilirlik temel güvenlik hedefleridir. Kimlik doğrulama, güncelleme ve güvenli tasarım sistemleri korumaya yardımcı olur."
    )
    var open by rememberSaveable { mutableStateOf(topics.first().first) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) {
            Text(if (english) "TECHNOLOGY SYSTEMS" else "TEKNOLOJİ SİSTEMLERİ", color=p.accent, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=2.sp)
            Text(if (english) "From components to intelligent systems" else "Bileşenlerden akıllı sistemlere", color=p.text, fontSize=21.sp, fontWeight=FontWeight.Bold)
            Text(if (english) "Explore the principles behind modern technology." else "Modern teknolojinin arkasındaki ilkeleri keşfet.", color=p.muted)
        }
        LearningQuiz(p, english,
            if (english) "ELECTRONICS · QUICK CHECK" else "ELEKTRONİK · KISA TEST",
            if (english) "What is the primary role of a transistor in digital logic circuits?" else "Dijital mantık devrelerinde transistörün temel görevlerinden biri nedir?",
            if (english) listOf("Store chemical energy", "Act as a controllable switch", "Measure temperature directly", "Generate radioactivity") else listOf("Kimyasal enerji depolamak", "Kontrollü anahtar gibi davranmak", "Sıcaklığı doğrudan ölçmek", "Radyoaktivite üretmek"), 1,
            if (english) "Transistors can switch and amplify electrical signals; digital circuits use them as controllable switches." else "Transistörler elektrik sinyallerini anahtarlayabilir ve yükseltebilir; dijital devrelerde kontrollü anahtar olarak kullanılır.")
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { open=if(open==title) "" else title }, verticalAlignment=Alignment.CenterVertically) {
                    Text(title, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                    Icon(if(open==title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.accent)
                }
                if(open==title) Text(body, color=p.text, lineHeight=21.sp, modifier=Modifier.padding(top=7.dp))
            }
        }
    }
}

@Composable
private fun SettingsPage(p: Palette, selected: Int, soundOn: Boolean, fontIndex: Int, language: String, onTheme: (Int) -> Unit, onSound: (Boolean) -> Unit, onFont: (Int) -> Unit, onLanguage: (String) -> Unit) {
    var languageExpanded by rememberSaveable { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text(if (language == "en") "Appearance" else "Görünüm", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (language == "en") "Adjust theme and typeface in one place." else "Tema ve yazı tipini tek bölümden düzenle.", color = p.muted, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                palettes.forEachIndexed { index, theme ->
                    Column(Modifier.width(66.dp).clip(RoundedCornerShape(11.dp)).border(if(selected==index) 2.dp else 1.dp, if(selected==index) p.accent else p.muted.copy(alpha=.25f), RoundedCornerShape(11.dp)).clickable { onTheme(index) }.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.fillMaxWidth().height(25.dp).clip(RoundedCornerShape(7.dp)).background(theme.bg), contentAlignment = Alignment.Center) { Box(Modifier.size(12.dp).clip(CircleShape).background(theme.accent)) }
                        Text(if (language == "en") listOf("Cosmic", "Aurora", "Nebula", "Arctic", "Laboratory", "Sunset", "Obsidian", "Ocean", "Lavender", "Emerald", "Cosmic Dark", "Deep Space", "Arctic Pro", "Lab Green", "Graphite", "Light Science")[index] else theme.name, color = p.text, fontSize = 9.sp, maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(if (language == "en") "Typeface" else "Yazı tipi", color = p.accent, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(if (language == "en") "Standard" else "Standart", if (language == "en") "Compact" else "Kompakt", if (language == "en") "Technical" else "Teknik", if (language == "en") "Book" else "Kitap").forEachIndexed { index, label ->
                    FilterChip(selected = fontIndex == index, onClick = { onFont(index) }, label = { Text(label, fontSize = 10.sp) })
                }
            }
        }
        Panel(p) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(if (language == "en") "Language" else "Dil", color = p.accent, fontWeight = FontWeight.Bold); Text(if (language == "en") "Application language" else "Uygulama dili", color = p.muted, fontSize = 11.sp) }
                Box {
                    TextButton(onClick = { languageExpanded = true }) { Text(if (language == "en") "English ▾" else "Türkçe ▾", color = p.text) }
                    DropdownMenu(expanded = languageExpanded, onDismissRequest = { languageExpanded = false }) {
                        DropdownMenuItem(text = { Text(if (language == "tr") "Türkçe ✓" else "Türkçe") }, onClick = { languageExpanded = false; onLanguage("tr") })
                        DropdownMenuItem(text = { Text(if (language == "en") "English ✓" else "English") }, onClick = { languageExpanded = false; onLanguage("en") })
                    }
                }
            }
        }
        Panel(p) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(if (language == "en") "Interface sounds" else "Arayüz sesleri", color = p.accent, fontWeight = FontWeight.Bold); Text(if (language == "en") "Enable or disable navigation sounds." else "Gezinme seslerini aç veya kapat.", color = p.muted, fontSize = 11.sp) }
                Switch(checked = soundOn, onCheckedChange = onSound)
            }
        }
        Panel(p) {
            Text(if (language == "en") "Offline models" else "Çevrimdışı modeller", color = p.accent, fontWeight = FontWeight.Bold)
            Text(if (language == "en") "The bundled 3D laboratory runs locally without external network requests. Anatomy and several scientific structures are schematic educational models, not clinical or metrology-grade assets." else "Pakete eklenen 3B laboratuvar dış ağ isteği olmadan yerel çalışır. Anatomi ve bazı bilimsel yapılar eğitim amaçlı şematik modellerdir; klinik veya metroloji düzeyinde varlıklar değildir.", color = p.text, lineHeight = 19.sp, fontSize = 12.sp)
        }
        Panel(p) {
            Text("Spectrum 1.6.3 · Science Platform", color = p.accent, fontWeight = FontWeight.Bold)
            Text(if (language == "en") "Created by Elyionn. Spectrum is an independent science and educational project." else "Elyionn tarafından oluşturulmuştur. Spectrum bağımsız bir bilim ve eğitim projesidir.", color = p.text, lineHeight = 19.sp, fontSize = 12.sp)
        }
    }
}

