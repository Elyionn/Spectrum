# Spectrum 1.5.2

Spectrum is a Kotlin + Jetpack Compose educational science atlas for Android.

## 1.5.2 changes

- New dark science-atlas home layout and geometric prism identity.
- Topic learning tabs: Summary, Structure and Operation in the biology, element detail and space sections.
- Updated anatomy, atom and water-molecule views using self-contained Canvas rendering; no remote JavaScript library is loaded.
- New offline perspective-based Solar System explorer with orbit paths, planet selection, rotation and zoom.
- Compact appearance settings combine theme and font selection; language selector currently offers Turkish.
- Periodic-table lookup data is memoized to reduce repeated filtering and mapping work.
- Embedded model WebViews are released and destroyed when their Compose host is disposed.
- The Android manifest no longer requests Internet permission. Runtime science models do not require network access.

## Technical notes and limitations

- The offline models are educational, schematic Canvas renderings with perspective, rotation and interaction. They are not medical-grade anatomical meshes or physically scale-accurate astronomical simulations.
- Planet sizes and orbital distances are normalized for visibility and are not to scale.
- The atom model is a simplified shell illustration and must not be interpreted as a quantum-mechanical orbital visualization.
- Gradle build must be run in an Android SDK environment. Static source checks are not a substitute for a successful APK build.

## Build

The GitHub Actions workflow expects `Spectrum_v1.5.2_Android_Project.zip` in the repository root. It installs Android SDK platform 35 and build-tools 35.0.0, then runs `:app:assembleDebug` with Gradle 8.9 and JDK 17.
