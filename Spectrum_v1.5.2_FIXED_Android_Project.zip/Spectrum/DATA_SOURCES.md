# Spectrum educational data notes

Element identity, atomic number, standard atomic-weight values, periodic placement and broad classifications are provided as curated educational reference data in `MainActivity.kt`. Some superheavy-element properties are not experimentally established; the app labels these as unknown or not experimentally measurable instead of presenting estimates as confirmed facts.

Planet descriptions and orbital-period labels are educational summaries. The interactive offline Solar System view uses normalized orbit radii and planet sizes for mobile readability; it is not a scale model.

The anatomy, atom, molecule and Solar System visuals are schematic teaching aids. They are not substitutes for clinical imaging, a complete anatomical atlas, or a quantum-mechanical calculation.
