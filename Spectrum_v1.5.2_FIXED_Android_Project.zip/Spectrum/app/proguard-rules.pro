# Spectrum application-specific R8 rules.
-keepattributes *Annotation*
