# Spectrum 1.5.4 Patch

Android science atlas project.

- Application version: `1.5.4`
- Android versionCode: `11` (patch increment)
- Namespace: `com.elyionn.spektrum`
- Application ID: `com.elyionn.spectrum`
- Minimum Android: API 26
- Compile/target SDK: 35
- Java: 17

## Build

The GitHub Actions workflow is at `.github/workflows/android-apk.yml`. Place `Spectrum_v1.5.4_PATCH_Android_Project.zip` in the repository root and use the workflow file at `.github/workflows/android-apk.yml`.

The archive is a standard ZIP with stored entries for broad compatibility with Android file managers and archive utilities.
