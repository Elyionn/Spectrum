# Spectrum 1.5.3

Kotlin + Jetpack Compose Android science atlas.

## 1.5.3 changes
- Periodic-table zoom slider and scalable cell layout.
- Turkish/English preference, localized navigation and settings, and English labels for the main periodic-table interface and common element names. Some detailed educational copy remains Turkish and requires a dedicated translation pass.
- Updated interface sound patterns and sound enabled by default for first launch.
- Interactive quadratic-function explorer added to Mathematics.
- Embedded model animations pause while the WebView document is hidden and are cleaned up with the view lifecycle.
- Anatomy view is explicitly labelled as a schematic illustration, not a medically accurate anatomical model.

## Build
Open the `Spectrum` directory in Android Studio or run `gradle :app:assembleDebug` with JDK 17 and Android SDK 35.
