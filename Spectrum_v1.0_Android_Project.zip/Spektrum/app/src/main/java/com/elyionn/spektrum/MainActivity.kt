package com.elyionn.spektrum

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import android.webkit.WebView
import android.webkit.WebViewClient

private data class Palette(val title:String,val bg:Color,val panel:Color,val accent:Color,val text:Color)
private val palettes = listOf(
    Palette("Kozmik Gece",Color(0xFF080F1D),Color(0xFF14243C),Color(0xFF55DCE5),Color(0xFFEDF4FF)),
    Palette("Aurora",Color(0xFF071A19),Color(0xFF10332F),Color(0xFF72E0B4),Color(0xFFE8FFF6)),
    Palette("Nebula",Color(0xFF170D27),Color(0xFF2B1945),Color(0xFFC39BFF),Color(0xFFF5EDFF)),
    Palette("Arktik",Color(0xFF101B2A),Color(0xFF20364C),Color(0xFF8CCBFF),Color(0xFFEAF5FF)),
    Palette("Laboratuvar",Color(0xFFF0F4F7),Color(0xFFFFFFFF),Color(0xFF087F8C),Color(0xFF17212B))
)
private val elementRows = listOf(
"H|Hidrojen|1|1.008|Ametal", "He|Helyum|2|4.0026|Soygaz", "Li|Lityum|3|6.94|Alkali metal", "Be|Berilyum|4|9.0122|Toprak alkali", "B|Bor|5|10.81|Yarı metal", "C|Karbon|6|12.011|Ametal", "N|Azot|7|14.007|Ametal", "O|Oksijen|8|15.999|Ametal", "F|Flor|9|18.998|Halojen", "Ne|Neon|10|20.180|Soygaz",
"Na|Sodyum|11|22.990|Alkali metal", "Mg|Magnezyum|12|24.305|Toprak alkali", "Al|Alüminyum|13|26.982|Metal", "Si|Silisyum|14|28.085|Yarı metal", "P|Fosfor|15|30.974|Ametal", "S|Kükürt|16|32.06|Ametal", "Cl|Klor|17|35.45|Halojen", "Ar|Argon|18|39.948|Soygaz",
"K|Potasyum|19|39.098|Alkali metal", "Ca|Kalsiyum|20|40.078|Toprak alkali", "Sc|Skandiyum|21|44.956|Geçiş metali", "Ti|Titanyum|22|47.867|Geçiş metali", "V|Vanadyum|23|50.942|Geçiş metali", "Cr|Krom|24|51.996|Geçiş metali", "Mn|Manganez|25|54.938|Geçiş metali", "Fe|Demir|26|55.845|Geçiş metali", "Co|Kobalt|27|58.933|Geçiş metali", "Ni|Nikel|28|58.693|Geçiş metali", "Cu|Bakır|29|63.546|Geçiş metali", "Zn|Çinko|30|65.38|Geçiş metali", "Ga|Galyum|31|69.723|Metal", "Ge|Germanyum|32|72.630|Yarı metal", "As|Arsenik|33|74.922|Yarı metal", "Se|Selenyum|34|78.971|Ametal", "Br|Brom|35|79.904|Halojen", "Kr|Kripton|36|83.798|Soygaz",
"Rb|Rubidyum|37|85.468|Alkali metal", "Sr|Stronsiyum|38|87.62|Toprak alkali", "Y|İtriyum|39|88.906|Geçiş metali", "Zr|Zirkonyum|40|91.224|Geçiş metali", "Nb|Niyobyum|41|92.906|Geçiş metali", "Mo|Molibden|42|95.95|Geçiş metali", "Tc|Teknesyum|43|98|Geçiş metali", "Ru|Rutenyum|44|101.07|Geçiş metali", "Rh|Rodyum|45|102.91|Geçiş metali", "Pd|Paladyum|46|106.42|Geçiş metali", "Ag|Gümüş|47|107.87|Geçiş metali", "Cd|Kadmiyum|48|112.41|Geçiş metali", "In|İndiyum|49|114.82|Metal", "Sn|Kalay|50|118.71|Metal", "Sb|Antimon|51|121.76|Yarı metal", "Te|Tellür|52|127.60|Yarı metal", "I|İyot|53|126.90|Halojen", "Xe|Ksenon|54|131.29|Soygaz",
"Cs|Sezyum|55|132.91|Alkali metal", "Ba|Baryum|56|137.33|Toprak alkali", "La|Lantan|57|138.91|Lantanit", "Ce|Seryum|58|140.12|Lantanit", "Pr|Praseodim|59|140.91|Lantanit", "Nd|Neodim|60|144.24|Lantanit", "Pm|Prometyum|61|145|Lantanit", "Sm|Samaryum|62|150.36|Lantanit", "Eu|Öropiyum|63|151.96|Lantanit", "Gd|Gadolinyum|64|157.25|Lantanit", "Tb|Terbiyum|65|158.93|Lantanit", "Dy|Disprozyum|66|162.50|Lantanit", "Ho|Holmiyum|67|164.93|Lantanit", "Er|Erbiyum|68|167.26|Lantanit", "Tm|Tulyum|69|168.93|Lantanit", "Yb|İterbiyum|70|173.05|Lantanit", "Lu|Lutesyum|71|174.97|Lantanit",
"Hf|Hafniyum|72|178.49|Geçiş metali", "Ta|Tantal|73|180.95|Geçiş metali", "W|Tungsten|74|183.84|Geçiş metali", "Re|Ren|75|186.21|Geçiş metali", "Os|Osmiyum|76|190.23|Geçiş metali", "Ir|İridyum|77|192.22|Geçiş metali", "Pt|Platin|78|195.08|Geçiş metali", "Au|Altın|79|196.97|Geçiş metali", "Hg|Cıva|80|200.59|Geçiş metali", "Tl|Talyum|81|204.38|Metal", "Pb|Kurşun|82|207.2|Metal", "Bi|Bizmut|83|208.98|Metal", "Po|Polonyum|84|209|Yarı metal", "At|Astatin|85|210|Halojen", "Rn|Radon|86|222|Soygaz",
"Fr|Fransiyum|87|223|Alkali metal", "Ra|Radyum|88|226|Toprak alkali", "Ac|Aktinyum|89|227|Aktinit", "Th|Toryum|90|232.04|Aktinit", "Pa|Protaktinyum|91|231.04|Aktinit", "U|Uranyum|92|238.03|Aktinit", "Np|Neptünyum|93|237|Aktinit", "Pu|Plütonyum|94|244|Aktinit", "Am|Amerikyum|95|243|Aktinit", "Cm|Küriyum|96|247|Aktinit", "Bk|Berkelyum|97|247|Aktinit", "Cf|Kaliforniyum|98|251|Aktinit", "Es|Aynştaynyum|99|252|Aktinit", "Fm|Fermiyum|100|257|Aktinit", "Md|Mendelevyum|101|258|Aktinit", "No|Nobelyum|102|259|Aktinit", "Lr|Lavrensiyum|103|266|Aktinit", "Rf|Rutherfordiyum|104|267|Geçiş metali", "Db|Dubniyum|105|268|Geçiş metali", "Sg|Seaborgiyum|106|269|Geçiş metali", "Bh|Bohriyum|107|270|Geçiş metali", "Hs|Hassiyum|108|277|Geçiş metali", "Mt|Meitneriyum|109|278|Bilinmiyor", "Ds|Darmstadtiyum|110|281|Bilinmiyor", "Rg|Röntgenyum|111|282|Bilinmiyor", "Cn|Kopernikyum|112|285|Bilinmiyor", "Nh|Nihonyum|113|286|Bilinmiyor", "Fl|Flerovyum|114|289|Bilinmiyor", "Mc|Moskovyum|115|290|Bilinmiyor", "Lv|Livermoryum|116|293|Bilinmiyor", "Ts|Tennessin|117|294|Halojen", "Og|Oganesson|118|294|Soygaz"
).map { it.split('|') }

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { SpectrumApp() } }
}

@Composable private fun SpectrumApp() {
    var page by remember { mutableStateOf("Keşif") }; var paletteIndex by remember { mutableIntStateOf(0) }; var sound by remember { mutableStateOf(false) }
    val p=palettes[paletteIndex]
    MaterialTheme(colorScheme=darkColorScheme(primary=p.accent,background=p.bg,surface=p.panel,onSurface=p.text,onBackground=p.text)) {
        Scaffold(containerColor=p.bg,bottomBar={
            Row(Modifier.fillMaxWidth().background(p.panel).horizontalScroll(rememberScrollState()).padding(horizontal=6.dp, vertical=5.dp), horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                listOf("Keşif" to Icons.Default.Explore,"Biyoloji" to Icons.Default.Favorite,"Uzay" to Icons.Default.Public,"Elementler" to Icons.Default.Science,"Kimya" to Icons.Default.Biotech,"Mikrobiyoloji" to Icons.Default.BugReport,"Ayarlar" to Icons.Default.Settings).forEach { (name,icon)->
                    Column(Modifier.width(76.dp).clip(RoundedCornerShape(14.dp)).background(if(page==name)p.accent.copy(alpha=.15f) else Color.Transparent).clickable{page=name}.padding(vertical=7.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                        Icon(icon,null,tint=if(page==name)p.accent else p.text.copy(alpha=.65f),modifier=Modifier.size(21.dp))
                        Text(name,fontSize=10.sp,color=if(page==name)p.accent else p.text.copy(alpha=.7f),maxLines=1)
                    }
                }
            }
        }) { pad -> Column(Modifier.fillMaxSize().padding(pad).background(p.bg)) {
            Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=16.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                Column { Text("SPECTRUM",color=p.accent,fontWeight=FontWeight.Black,letterSpacing=3.sp); Text("Bilim, keşif ve merak alanı",color=p.text.copy(alpha=.65f),fontSize=12.sp) }
                Text("✦",color=p.accent,fontSize=26.sp)
            }
            when(page) {
                "Keşif" -> Home(p,{page=it})
                "Biyoloji" -> Biology(p)
                "Uzay" -> Space(p)
                "Elementler" -> Elements(p)
                "Kimya" -> Chemistry(p)
                "Mikrobiyoloji" -> Microbiology(p)
                else -> Settings(p,paletteIndex,{paletteIndex=it},sound,{sound=it})
            }
        } }
    }
}

@Composable private fun Panel(p:Palette, modifier:Modifier=Modifier, content:@Composable ColumnScope.()->Unit) { Column(modifier.fillMaxWidth().background(p.panel,RoundedCornerShape(20.dp)).border(1.dp,p.accent.copy(alpha=.17f),RoundedCornerShape(20.dp)).padding(17.dp),content=content) }
@Composable private fun Home(p:Palette, go:(String)->Unit) { Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
    Panel(p,Modifier.height(190.dp)) { Text("SANAL BİLİM ATLASI",color=p.accent,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp); Spacer(Modifier.height(10.dp)); Text("Evreni merak et.\nBilimi keşfet.",fontSize=29.sp,fontWeight=FontWeight.ExtraBold,color=p.text,lineHeight=34.sp); Spacer(Modifier.height(8.dp)); Text("İnsan bedeninden atom altı dünyaya uzanan etkileşimli öğrenme alanı.",color=p.text.copy(alpha=.7f)) }
    listOf("Biyoloji" to "Organlar, sistemler, hücre ve DNA", "Uzay" to "Gezegenler, uydular ve derin uzay", "Elementler" to "118 element, özellikleri ve kullanım alanları", "Kimya" to "Bağlar, tepkimeler, çözeltiler ve pH", "Mikrobiyoloji" to "Bakteriler, virüsler, mantarlar ve mikroskobik yaşam").forEach { (a,b)->Panel(p,Modifier.clickable{go(a)}) { Text(a,fontSize=19.sp,fontWeight=FontWeight.Bold,color=p.accent); Text(b,color=p.text.copy(alpha=.7f),fontSize=13.sp) } }
    Text("Elyionn tarafından tasarlanmıştır",color=p.text.copy(alpha=.45f),fontSize=11.sp,modifier=Modifier.align(Alignment.CenterHorizontally).padding(12.dp))
} }

@Composable private fun Biology(p:Palette) { val systems=listOf(
"Sinir sistemi" to "Beyin, omurilik ve sinirlerden oluşur. Duyusal bilgiyi işler, hareketleri koordine eder ve organların faaliyetlerini düzenler. Beynin farklı bölgeleri hareket, bellek, dil, duygu ve karar verme gibi işlevlerde uzmanlaşır.",
"Dolaşım sistemi" to "Kalp, kan ve damarlardan oluşur. Kalbin sağ tarafı oksijence fakir kanı akciğerlere, sol tarafı oksijenlenmiş kanı vücuda pompalar. Atardamarlar kanı kalpten uzaklaştırır; toplardamarlar kalbe geri taşır; kılcal damarlar madde alışverişini sağlar.",
"Solunum sistemi" to "Burun ve ağızdan alınan hava soluk borusu, bronşlar ve bronşçuklardan geçerek alveollere ulaşır. Alveollerde oksijen kana geçerken karbondioksit kandan hava boşluğuna geçer. Diyafram solunumun temel kasıdır.",
"Sindirim sistemi" to "Ağızda başlayan mekanik ve kimyasal sindirim; yemek borusu, mide ve ince bağırsakta sürer. İnce bağırsak besinlerin büyük bölümünü emer. Kalın bağırsak su ve elektrolit emilimine katkıda bulunur. Karaciğer safra üretir, pankreas sindirim enzimleri salgılar.",
"Kas-iskelet sistemi" to "Kemikler vücuda destek verir, organları korur ve kaslarla birlikte hareketi sağlar. İskelet kasları istemli hareketlerde; düz kaslar iç organlarda; kalp kası kalpte görev yapar. Kemik iliği kan hücrelerinin üretiminde rol oynar.",
"Üriner sistem" to "Böbrekler kanı süzer, atık maddelerin ve fazla suyun uzaklaştırılmasını sağlar. Nefronlar süzülme, geri emilim ve salgılama süreçleriyle idrarı oluşturur. Üreterler idrarı mesaneye taşır; mesane depolar.",
"Endokrin sistem" to "Hormonlar aracılığıyla büyüme, metabolizma, stres yanıtı, üreme ve iç dengeyi düzenler. Hipofiz, tiroit, pankreas, böbreküstü bezleri ve eşey bezleri önemli bileşenleridir.",
"Bağışıklık sistemi" to "Deri ve mukozalar ilk savunma hattıdır. Doğuştan gelen bağışıklık hızlı ve genel yanıt verir; kazanılmış bağışıklık B ve T lenfositleriyle belirli hedefleri tanır ve bağışıklık belleği oluşturabilir.")
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) { Text("İnsan vücudu",fontSize=27.sp,fontWeight=FontWeight.Bold,color=p.text); Text("Organ sistemleri birbirine bağlı çalışır. Bir sistemdeki değişim diğerlerini de etkileyebilir.",color=p.text.copy(alpha=.65f)); systems.forEach { (name,desc)->var open by remember { mutableStateOf(false) }; Panel(p) { Row(Modifier.fillMaxWidth().clickable{open=!open},horizontalArrangement=Arrangement.SpaceBetween){Text(name,fontWeight=FontWeight.Bold,color=p.accent);Text(if(open)"−" else "+",color=p.accent)};if(open){Spacer(Modifier.height(8.dp));Text(desc,color=p.text,lineHeight=21.sp)} } } }
}

@Composable private fun Space(p:Palette) { val context= LocalContext.current; val bodies=listOf(
"Merkür" to "Güneş'e en yakın gezegendir. Atmosferi çok incedir; yüzeyinde büyük sıcaklık farkları görülür. Demirce zengin büyük bir çekirdeğe sahiptir. Güneş çevresindeki dolanımı yaklaşık 88 Dünya günüdür.",
"Venüs" to "Yoğun karbondioksit atmosferi ve güçlü sera etkisi nedeniyle Güneş Sistemi'nin en sıcak gezegenidir. Sülfürik asit damlacıkları içeren bulutları vardır. Kendi ekseni çevresinde çoğu gezegenin ters yönünde döner.",
"Dünya" to "Yüzeyinde kalıcı sıvı su bulunan ve bildiğimiz yaşamı destekleyen tek gezegendir. Atmosferi çoğunlukla azot ve oksijenden oluşur. Manyetik alanı Güneş rüzgârının yüklü parçacıklarına karşı koruma sağlar.",
"Mars" to "Demir oksit nedeniyle kızıl görünür. Olympus Mons adlı dev bir volkana ve Valles Marineris adlı büyük kanyon sistemine sahiptir. Geçmişte yüzeyinde sıvı su bulunduğuna dair güçlü jeolojik kanıtlar vardır.",
"Jüpiter" to "En büyük gezegendir ve çoğunlukla hidrojen ile helyumdan oluşur. Büyük Kırmızı Leke uzun ömürlü dev bir fırtınadır. Güçlü manyetik alanı ve çok sayıda uydusu bulunur.",
"Satürn" to "Buz ve kaya parçacıklarından oluşan geniş halkalarıyla tanınır. Yoğunluğu sudan düşüktür. Titan adlı büyük uydusunda metan ve etan gölleri, Enceladus'ta ise buz altı okyanusuna işaret eden püskürmeler bulunur.",
"Uranüs" to "Eksen eğikliği yaklaşık 98 derece olduğu için adeta yan yatmış halde döner. Atmosferinde metan bulunur ve mavi-yeşil görünür. Üst atmosferi son derece soğuktur.",
"Neptün" to "Güneş'e en uzak ana gezegendir. Çok hızlı atmosferik rüzgârları ve koyu renkli fırtına sistemleri vardır. Güneş çevresindeki bir turu yaklaşık 165 Dünya yılı sürer.",
"Plüton" to "Cüce gezegen sınıfındadır. Kalp biçimli Tombaugh Regio bölgesi, azot buzulları ve ince atmosferiyle dikkat çeker. Büyük uydusu Charon ile ortak kütle merkezi çevresinde hareket eder.")
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) { Text("Güneş Sistemi",fontSize=27.sp,fontWeight=FontWeight.Bold,color=p.text); Text("Gezegen kartlarını aç; yörünge, atmosfer ve keşif görevlerini incele.",color=p.text.copy(alpha=.65f)); bodies.forEach { (name,desc)->var open by remember { mutableStateOf(name=="Dünya") };Panel(p){Row(Modifier.fillMaxWidth().clickable{open=!open},horizontalArrangement=Arrangement.SpaceBetween){Text(name,fontSize=18.sp,fontWeight=FontWeight.Bold,color=p.accent);Text(if(open)"−" else "+",color=p.accent)};if(open){Spacer(Modifier.height(8.dp));Text(desc,color=p.text,lineHeight=21.sp)} } };Panel(p){Text("3B Gözlemevi",fontWeight=FontWeight.Bold,color=p.accent);Text("Gezegenleri döndürme ve yakınlaştırma destekli 3B sahnede incelemek için NASA'nın etkileşimli Solar System sayfasını Chrome'da aç.",color=p.text.copy(alpha=.75f));Button(onClick={context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://eyes.nasa.gov/apps/solar-system/")))}){Text("Chrome'da 3B gözlemevini aç")}} }
}

@Composable private fun Elements(p:Palette) { var selected by remember { mutableStateOf(elementRows.first()) };var query by remember { mutableStateOf("") };val filtered=elementRows.filter{it[0].contains(query,true)||it[1].contains(query,true)||it[2]==query};Column(Modifier.fillMaxSize().padding(14.dp)) { Text("Periyodik tablo",fontSize=26.sp,fontWeight=FontWeight.Bold,color=p.text);Text("118 element · atom numarası · atom kütlesi · sınıf",color=p.text.copy(alpha=.65f));Spacer(Modifier.height(10.dp));OutlinedTextField(query,{query=it},label={Text("Element ara")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));LazyVerticalGrid(columns=GridCells.Fixed(4),modifier=Modifier.weight(1f),contentPadding=PaddingValues(3.dp),horizontalArrangement=Arrangement.spacedBy(6.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){items(filtered){e->Card(onClick={selected=e},colors=CardDefaults.cardColors(containerColor=if(selected==e)p.accent.copy(alpha=.25f) else p.panel),border=BorderStroke(1.dp,if(selected==e)p.accent else p.accent.copy(alpha=.15f))){Column(Modifier.padding(9.dp)){Text(e[2],fontSize=10.sp,color=p.text.copy(alpha=.65f));Text(e[0],fontSize=22.sp,fontWeight=FontWeight.Black,color=p.accent);Text(e[1],fontSize=10.sp,color=p.text,maxLines=1)} } } };Panel(p){Text("${selected[1]} (${selected[0]})",fontSize=20.sp,fontWeight=FontWeight.Bold,color=p.accent);Text("Atom numarası: ${selected[2]}   ·   Atom kütlesi: ${selected[3]} u",color=p.text);Text("Sınıf: ${selected[4]}",color=p.text.copy(alpha=.7f));Spacer(Modifier.height(8.dp));Text(elementDescription(selected),color=p.text,lineHeight=20.sp)} } }
private fun elementDescription(e:List<String>):String { val (s,n,z,m,c)=e;val uses=mapOf("H" to "Yıldızlarda füzyonun temel yakıtıdır; yakıt hücrelerinde ve amonyak üretiminde kullanılır.","He" to "Düşük sıcaklık fiziğinde soğutucu, MRI cihazlarının süperiletken mıknatıslarında ve balonlarda kullanılır.","Li" to "Şarj edilebilir lityum-iyon pillerde, cam-seramiklerde ve bazı alaşımlarda önemli rol oynar.","C" to "Canlı kimyasının temel elementidir. Grafit, elmas ve grafen gibi farklı yapısal biçimleri vardır.","O" to "Hücresel solunumda elektron alıcısıdır; çelik üretimi, tıp ve su arıtma süreçlerinde kullanılır.","N" to "Atmosferin büyük bölümünü oluşturur. Amonyak ve gübre üretiminde, ayrıca inert gaz ortamlarında kullanılır.","Fe" to "Çelik üretiminin ana bileşenidir. Hemoglobindeki demir oksijen taşınmasına katkı verir.","Cu" to "Elektrik ve ısıyı iyi iletir; kablolarda, motorlarda, elektronik devrelerde ve alaşımlarda kullanılır.","Si" to "Yarı iletken teknolojisinin temelidir. Bilgisayar çipleri, güneş hücreleri ve cam üretiminde kullanılır.","Au" to "Korozyona dayanıklı ve iyi iletken olduğu için elektronik bağlantılarda, mücevheratta ve finansal rezervlerde kullanılır.","Ag" to "Metaller arasında çok yüksek elektrik iletkenliğine sahiptir; elektronik, aynalar ve bazı antimikrobiyal uygulamalarda kullanılır.","Al" to "Hafifliği ve korozyon direnci sayesinde ulaşım, yapı, ambalaj ve elektrik iletiminde yaygındır.","Ti" to "Yüksek dayanım/ağırlık oranı ve biyouyumluluğu nedeniyle havacılıkta ve tıbbi implantlarda kullanılır.","U" to "Bazı izotopları nükleer yakıttır. Jeolojide uranyum-kurşun tarihlemesi gibi yöntemlerde de önemlidir.")
val use=uses[s] ?: when(c){"Soygaz"->"Kimyasal tepkimeye girme eğilimi düşüktür. Aydınlatma, koruyucu atmosfer, algılama veya özel optik uygulamalarda kullanılabilir.";"Halojen"->"Tuzlar ve çok sayıda organik bileşik oluşturur. Su arıtma, polimer üretimi ve kimya endüstrisinde farklı bileşikleri önem taşır.";"Alkali metal","Toprak alkali"->"Reaktif metal grubundadır. Saf halde değil, çoğunlukla bileşikleri ve kontrollü endüstriyel süreçleri aracılığıyla kullanılır.";"Lantanit"->"Elektronik, güçlü kalıcı mıknatıslar, optik camlar ve enerji teknolojilerinde kullanılan özel manyetik ve ışıldama özellikleri gösterebilir.";"Aktinit"->"Birçoğu radyoaktiftir. Nükleer bilim, araştırma ve bazı izotopların enerji uygulamalarında önem taşır.";else->"Bu elementin fiziksel ve kimyasal özellikleri alaşımlar, kataliz, elektronik veya özel malzeme tasarımında kullanımını belirler."}
return "$n, atom numarası $z olan $s sembollü elementtir. Göreli atom kütlesi yaklaşık $m u'dur ve sınıflandırması $c olarak verilir. $use Keşif tarihi ve kullanım alanları elementin izotopuna, saflığına ve kimyasal bileşiğine göre değişebilir." }


@Composable private fun Chemistry(p:Palette) {
    val topics = listOf(
        "Atom ve elektronlar" to "Atom; proton ve nötronlardan oluşan bir çekirdek ile çevresindeki elektron bulutundan meydana gelir. Proton sayısı elementin kimliğini belirler. Elektronların enerji düzeyleri ve dizilimleri kimyasal davranışı etkiler.",
        "Kimyasal bağlar" to "İyonik bağda elektron alışverişiyle oluşan zıt yüklü iyonlar birbirini çeker. Kovalent bağda atomlar elektron çiftlerini paylaşır. Metalik bağ, metal atomları arasında delokalize elektronlarla açıklanır.",
        "Kimyasal tepkimeler" to "Tepkimelerde atomlar yok olmaz veya yeniden yaratılmaz; bağlar yeniden düzenlenir. Denklem denkleştirme, her elementin atom sayısının iki tarafta eşit olmasını sağlar. Tepkimeler enerji alabilir veya açığa çıkarabilir.",
        "Asitler, bazlar ve pH" to "pH, sulu çözeltilerin asitlik-bazlık durumunu ifade eden logaritmik bir ölçektir. 25 °C'de pH 7 nötr kabul edilir; daha düşük değerler asidik, daha yüksek değerler bazik ortamı gösterir.",
        "Çözeltiler ve derişim" to "Çözelti, çözücü içinde dağılmış çözünen maddeden oluşur. Derişim; molarite, kütlece yüzde veya başka birimlerle ifade edilebilir. Sıcaklık ve çözünen maddenin türü çözünürlüğü etkiler.",
        "Organik kimya" to "Organik kimya, başta karbon içeren bileşiklerin yapılarını, özelliklerini ve tepkimelerini inceler. Hidrokarbonlar, alkoller, karboksilik asitler, esterler ve polimerler önemli bileşik sınıflarıdır.",
        "Kimya laboratuvarı güvenliği" to "Laboratuvarda koruyucu gözlük ve uygun önlük kullanılır; etiketler ve güvenlik bilgi formları okunur. Bilinmeyen maddeler karıştırılmaz, maddeler tadılmaz veya doğrudan koklanmaz. Öğretmen ya da laboratuvar sorumlusu talimatları izlenir."
    )
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Kimya",fontSize=27.sp,fontWeight=FontWeight.Bold,color=p.text)
        Text("Maddenin yapısını, dönüşümünü ve enerjiyle ilişkisini keşfet.",color=p.text.copy(alpha=.7f))
        topics.forEach { (title,body) -> var expanded by remember { mutableStateOf(title=="Atom ve elektronlar") }
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable{expanded=!expanded},horizontalArrangement=Arrangement.SpaceBetween) {
                    Text(title,fontSize=17.sp,fontWeight=FontWeight.Bold,color=p.accent,modifier=Modifier.weight(1f))
                    Text(if(expanded)"−" else "+",color=p.accent)
                }
                if(expanded){Spacer(Modifier.height(8.dp));Text(body,color=p.text,lineHeight=21.sp)}
            }
        }
        Panel(p) { Text("Temel kavram",fontWeight=FontWeight.Bold,color=p.accent);Text("Kütlenin korunumu: Kapalı bir sistemde kimyasal tepkime öncesi ve sonrası toplam kütle aynıdır.",color=p.text) }
    }
}

@Composable private fun Microbiology(p:Palette) {
    val topics = listOf(
        "Hücre ve mikroskobik yaşam" to "Mikroorganizmalar çıplak gözle genellikle görülemeyen canlıları ve bazı hücresel olmayan biyolojik yapıları kapsayan geniş bir inceleme alanıdır. Bakteriler ve arkeler prokaryot; maya ve protozoalar ökaryot hücre yapısına sahiptir.",
        "Bakteriler" to "Bakteriler tek hücreli prokaryotlardır. Şekilleri, metabolizmaları ve yaşadıkları ortamlar çeşitlidir. Bazıları insan sağlığı için yararlı roller üstlenirken bazıları hastalıklara neden olabilir.",
        "Virüsler" to "Virüsler hücresel yapıda değildir; genetik materyallerini protein kılıf içinde taşırlar. Çoğalmak için konak hücrelerin mekanizmalarını kullanırlar. Antibiyotikler virüslere karşı etkili değildir.",
        "Mantarlar ve mayalar" to "Mantarlar ökaryot canlılardır. Mayalar tek hücreli, küfler çoğunlukla ipliksi yapılara sahip olabilir. Ayrıştırma, gıda üretimi ve ekosistem döngülerinde önemli görevleri vardır.",
        "Protozoalar ve algler" to "Protozoalar çoğunlukla tek hücreli ökaryotlardır. Algler fotosentez yapabilen çeşitli organizmaları kapsar; su ekosistemlerinde birincil üretime ve oksijen döngüsüne katkı sağlar.",
        "Bağışıklık ve mikrobiyota" to "Bağışıklık sistemi zararlı etkenleri tanımaya ve kontrol etmeye yardımcı olur. Mikrobiyota ise vücutta ve üzerinde yaşayan mikroorganizma topluluklarıdır; sindirim ve bağışıklıkla ilişkili işlevleri bulunur.",
        "Mikroskopi ve gözlem" to "Işık mikroskopları hücre ve mikroorganizma yapılarını incelemekte kullanılır. Büyütme kadar çözünürlük, örnek hazırlama ve uygun boyama yöntemi de gözlemin kalitesini belirler."
    )
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Mikrobiyoloji",fontSize=27.sp,fontWeight=FontWeight.Bold,color=p.text)
        Text("Mikroskobik dünyanın çeşitliliğini ve canlılarla ilişkisini öğren.",color=p.text.copy(alpha=.7f))
        topics.forEach { (title,body) -> var expanded by remember { mutableStateOf(title=="Hücre ve mikroskobik yaşam") }
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable{expanded=!expanded},horizontalArrangement=Arrangement.SpaceBetween) {
                    Text(title,fontSize=17.sp,fontWeight=FontWeight.Bold,color=p.accent,modifier=Modifier.weight(1f))
                    Text(if(expanded)"−" else "+",color=p.accent)
                }
                if(expanded){Spacer(Modifier.height(8.dp));Text(body,color=p.text,lineHeight=21.sp)}
            }
        }
        Panel(p) { Text("Bilimsel not",fontWeight=FontWeight.Bold,color=p.accent);Text("Virüslerin canlı olarak sınıflandırılması bilimde tartışmalı bir konudur. Bu nedenle hücresel canlılarla aynı grupta değerlendirilmezler.",color=p.text) }
    }
}

@Composable private fun Settings(p:Palette,index:Int,onPick:(Int)->Unit,sound:Boolean,onSound:(Boolean)->Unit){Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Ayarlar",fontSize=27.sp,fontWeight=FontWeight.Bold,color=p.text);Panel(p){Text("Görünüm teması",fontWeight=FontWeight.Bold,color=p.accent);palettes.forEachIndexed{i,t->Row(Modifier.fillMaxWidth().clickable{onPick(i)}.padding(vertical=9.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(28.dp).background(t.bg,RoundedCornerShape(8.dp)).border(2.dp,t.accent,RoundedCornerShape(8.dp)));Spacer(Modifier.width(12.dp));Text(t.title,color=p.text,modifier=Modifier.weight(1f));RadioButton(selected=index==i,onClick={onPick(i)})}}};Panel(p){Text("Ses",fontWeight=FontWeight.Bold,color=p.accent);Row(verticalAlignment=Alignment.CenterVertically){Text("Arayüz sesleri",color=p.text,modifier=Modifier.weight(1f));Switch(checked=sound,onCheckedChange=onSound)}};Panel(p){Text("Chrome mobil entegrasyonu",fontWeight=FontWeight.Bold,color=p.accent);Text("Dış bağlantılar Android'in varsayılan tarayıcısında açılır. Chrome yüklüyse bağlantıları Chrome ile açabilirsin.",color=p.text.copy(alpha=.75f));Text("3B web modülleri için WebGL ve internet bağlantısı gerekir.",color=p.text.copy(alpha=.75f))};Panel(p){Text("Credits",fontWeight=FontWeight.Bold,color=p.accent);Text("Spectrum · Sürüm 1.0\nElyionn tarafından tasarlanmıştır.\nBilimsel içerikler eğitim amaçlıdır; değerler kaynaklara göre güncellenmelidir.",color=p.text,lineHeight=22.sp)} } }
