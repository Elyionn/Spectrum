# Spectrum Android — v1.0

Kotlin + Jetpack Compose ile hazırlanmış Android bilim keşif uygulaması.

## Uygulama bilgileri
- Uygulama adı: **Spectrum**
- Sürüm: **1.0** (`versionCode: 1`)
- Paket kimliği: `com.elyionn.spectrum`
- Minimum Android: 8.0 (API 26)
- Hedef SDK: 35
- JDK: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9

## Kategoriler
Keşif · Biyoloji · Uzay · Elementler · Kimya (yeni) · Mikrobiyoloji (yeni) · Ayarlar

## Android Studio ile APK oluşturma
1. ZIP'i çıkart ve `Spectrum` proje klasörünü Android Studio'da aç.
2. JDK 17 seçili olsun ve Gradle senkronizasyonunun tamamlanmasını bekle.
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)** seç.
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

## Telefon üzerinden GitHub Actions ile APK oluşturma
1. Projeyi GitHub'da yeni bir depoya yükle.
2. `.github/workflows/android-apk.yml` dosyası depoda bulunmalı.
3. GitHub deposunda **Actions → Build Spectrum Android APK → Run workflow** seç.
4. İşlem tamamlanınca çalışmanın **Artifacts** bölümünden `Spectrum-v1.0-debug-apk` dosyasını indir.
5. ZIP içindeki APK'yı Android'e kur.

## Dağıtım notları
- Debug APK test ve kişisel kurulum içindir.
- Google Play yayını için imzalı release AAB gerekir; yayın anahtarını repoya ekleme.
- Sürüm güncellemesinde `versionCode` artırılmalıdır.
- Bilimsel içerik eğitim amaçlıdır; yayımdan önce kaynaklarla doğrulanmalıdır.

## Credits
Elyionn tarafından tasarlanmıştır.
