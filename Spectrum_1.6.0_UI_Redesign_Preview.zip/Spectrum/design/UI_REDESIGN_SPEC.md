# Spectrum UI Redesign Preparation

## Design reference
`Spectrum_UI_Redesign_Concept.png` is the approved visual direction reference for the first redesign pass. It is a concept board, not an app screenshot. The Android Compose screens are being rebuilt to follow its layout and interaction hierarchy.

## Visual system
- Default direction: Deep Space dark theme, near-black/navy surfaces, cyan focus color, restrained violet secondary lighting.
- Rounded cards (16–24 dp), clear content spacing, concise labels and readable body text.
- Five persistent destinations: Ana Sayfa, Keşfet, Atlas, Laboratuvar, Kütüphane.
- Settings move to the top-right app-bar action, removing Settings from the primary navigation.
- Screen titles and controls remain native Compose components for accessibility and Android behavior.

## Information architecture

### 1. Ana Sayfa
- Brand header and settings action.
- Short orientation statement.
- Daily Science hero card linking to the selected topic.
- Learning path entry to Science Atlas.
- Quick access: Periodic Table, 3D Laboratory, Space, Biology, Physics, Library.
- Explore-all entry.

### 2. Keşfet
- Searchable science-domain catalogue.
- Two-column cards for the existing domain catalogue.
- Existing category detail pages remain the destination, preserving existing content and features.

### 3. Science Atlas
- Existing Atlas topic graph, learning levels and completion tracking retained.
- Entry from the new bottom navigation and Home learning-path card.

### 4. Laboratuvar
- Dedicated laboratory hub.
- 3D model gallery entry.
- Physics simulations, Chemistry workspace and Biology/Anatomy entry points.
- Existing visual atlas and subject pages are reused rather than replaced with mock controls.

### 5. Kütüphane
- Unified search entry with filter chips for All, Elements, Topics and Sections.
- Popular offline topics when the query is empty.
- Existing element and Atlas search results remain connected to their detail pages.

### 6. Detail pages
- Existing element and category detail content is preserved.
- Atlas details keep Explore, Learn and Deep Dive levels plus related concepts and completion state.

## Implementation notes
- This is a first UI implementation pass, not the final redesign of every content detail page.
- The reference image is not used as a full-screen UI asset. Each visible screen is implemented as native Android Compose UI.
- Existing content pages and the 3D/WebView visualizations are preserved and routed through the new information architecture.
- Settings are still reachable from the app-bar gear action.
- Category detail pages return to the originating section where the new routes set a return destination.

## Follow-up refinement checklist
- Compare each implemented screen against the concept board on a real Android device.
- Tune card heights and type sizes for narrow phones and larger font settings.
- Replace remaining text-only model previews with genuine interactive model assets only when licensed, optimized geometry is available.
- Add UI tests for all five destinations, settings entry, search filters and back navigation.
