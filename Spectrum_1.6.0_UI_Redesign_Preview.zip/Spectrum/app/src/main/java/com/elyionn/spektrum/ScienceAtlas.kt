package com.elyionn.spektrum

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import java.time.LocalDate

internal data class AtlasTopic(
    val id: String, val title: String, val category: String,
    val explore: String, val learn: String, val deepDive: String,
    val related: List<String>
)

internal val atlasTopics = listOf(
    AtlasTopic("atom", "Atom", "Chemistry", "Maddenin kimyasal özelliklerini koruyan temel yapı birimidir.", "Atom; proton ve nötronlardan oluşan bir çekirdek ile elektronlardan oluşan elektron bulutuna sahiptir. Atom numarası proton sayısını belirler.", "Kuantum mekaniğinde elektronlar klasik gezegen yörüngelerinde dolaşmaz. Orbitaller, elektronun bulunma olasılık genliğinin matematiksel çözümleridir.", listOf("electron", "bond", "light")),
    AtlasTopic("electron", "Elektron", "Physics", "Negatif elektrik yüküne sahip temel parçacıktır.", "Elektronlar atomların kimyasal bağlarında, elektrik akımında ve elektromanyetik olaylarda rol oynar.", "Elektronun yükü −e, durgun kütlesi yaklaşık 9.109×10⁻³¹ kg'dır. Spin-1/2 fermiyondur ve Pauli dışarlama ilkesine uyar.", listOf("atom", "electromagnetism")),
    AtlasTopic("electromagnetism", "Elektromanyetizma", "Physics", "Elektrik ve manyetik olayları birlikte açıklar.", "Elektrik yükleri elektrik alanı oluşturur; hareketli yükler ve değişen elektrik alanları manyetik alanla ilişkilidir.", "Klasik elektromanyetizma Maxwell denklemleriyle ifade edilir. Elektromanyetik dalgalar vakumda c ışık hızıyla yayılır.", listOf("electron", "light")),
    AtlasTopic("light", "Işık", "Physics", "Işık, elektromanyetik ışınımın insan gözünün algılayabildiği bölümüdür.", "Işık dalga-parçacık ikiliği gösterir. Kırılma, yansıma, girişim ve kırınım optiğin temel olaylarıdır.", "Foton enerjisi E=hf bağıntısıyla verilir. Kuantum elektrodinamiği ışık-madde etkileşimini açıklar.", listOf("electromagnetism", "astronomy")),
    AtlasTopic("astronomy", "Astronomi", "Astronomy", "Evreni ve gök cisimlerini gözlem ve fizik yoluyla inceler.", "Yıldızlar, gezegenler ve galaksilerin özellikleri ışınım ve hareketlerinden çıkarılır.", "Gözlemsel kozmoloji genel görelilik, kozmik mikrodalga arka planı ve galaksi dağılımlarını birlikte değerlendirir.", listOf("light", "gravity", "star")),
    AtlasTopic("gravity", "Yerçekimi", "Physics", "Kütle ve enerji arasında etkili temel etkileşimdir.", "Newton yaklaşımında iki kütle arasındaki çekim kuvveti kütlelerle doğru, uzaklığın karesiyle ters orantılıdır.", "Genel görelilikte kütle-enerji uzay-zaman geometrisini belirler; serbest düşüş jeodezik hareket olarak tanımlanır.", listOf("astronomy", "orbit")),
    AtlasTopic("orbit", "Yörünge", "Astronomy", "Bir cismin başka bir cismin çevresindeki hareket yoludur.", "Yörüngeler hız, kütleçekim ve başlangıç koşullarına bağlıdır. Gezegen yörüngeleri yaklaşık elipstir.", "İki cisim probleminde konik kesit çözümleri elde edilir. Çok cisimli sistemler sayısal integrasyon gerektirebilir.", listOf("gravity", "astronomy")),
    AtlasTopic("cell", "Hücre", "Biology", "Canlıların temel yapısal ve işlevsel birimidir.", "Hücre zarı madde alışverişini düzenler. Ökaryot hücrelerde çekirdek ve zarla çevrili organeller bulunur.", "Hücre işlevleri gen ifadesi, sinyal ağları, membran taşınımı ve metabolik reaksiyonların etkileşiminden doğar.", listOf("dna", "protein", "microbiology")),
    AtlasTopic("dna", "DNA", "Genetics", "Kalıtsal bilginin büyük bölümünü taşıyan nükleik asittir.", "DNA çift sarmallı bir moleküldür. Baz eşleşmesi A-T ve G-C biçimindedir.", "DNA replikasyonu yarı korunumlu gerçekleşir; polimerazlar yeni zinciri 5′→3′ yönünde sentezler.", listOf("cell", "protein", "rna")),
    AtlasTopic("protein", "Protein sentezi", "Biology", "Hücreler genetik bilgiyi kullanarak protein üretir.", "Transkripsiyonda DNA'dan RNA üretilir; translasyonda ribozom mRNA kodonlarını amino asit dizisine çevirir.", "Ribozomal translasyon başlama, uzama ve sonlanma evrelerinden oluşur. Katlanma ve post-translasyonel değişiklikler proteinin işlevini etkiler.", listOf("dna", "cell", "rna")),
    AtlasTopic("rna", "RNA", "Genetics", "Gen ifadesinde görev alan nükleik asit ailesidir.", "mRNA, tRNA ve rRNA gibi RNA türleri protein sentezinde farklı görevler üstlenir.", "RNA, riboz şekeri ve urasil içeren nükleotitlerden oluşur; bazı RNA molekülleri katalitik ribozim işlevi de gösterebilir.", listOf("dna", "protein")),
    AtlasTopic("microbiology", "Mikrobiyoloji", "Microbiology", "Mikroorganizmaları ve mikroskobik biyolojik süreçleri inceler.", "Bakteriler prokaryot hücrelerdir; virüsler hücresel değildir ve çoğalmak için konak hücre mekanizmalarını kullanır.", "Mikrobiyal ekoloji, metabolik çeşitlilik, yatay gen aktarımı ve konak-mikrop etkileşimlerini kapsar.", listOf("cell", "dna")),
    AtlasTopic("plate", "Tektonik plakalar", "Geology", "Litosfer, hareket eden büyük ve küçük plakalara ayrılmıştır.", "Plaka sınırlarında ayrılma, yakınlaşma veya yanal kayma görülür. Bu süreçler deprem ve volkanizmayla ilişkilidir.", "Plaka tektoniği manto konveksiyonu, slab çekişi ve sırt itmesi gibi mekanizmalarla modellenir.", listOf("earthquake", "earth")),
    AtlasTopic("earthquake", "Depremler", "Geology", "Yer kabuğunda biriken gerilimin kırılma veya kayma ile boşalmasıdır.", "Sismik dalgalar deprem kaynağından yayılır. P ve S dalgalarının hız farkı iç yapı araştırmalarında kullanılır.", "Elastik geri sıçrama modeli fay çevresinde gerinim birikimini açıklar; büyüklük ve şiddet farklı ölçütlerdir.", listOf("plate", "earth")),
    AtlasTopic("function", "Fonksiyonlar", "Mathematics", "Her girdiye tek bir çıktı eşleyen matematiksel ilişkidir.", "Fonksiyonlar cebir, fizik ve veri modellemesinde değişkenler arasındaki ilişkiyi tanımlar.", "Fonksiyonların süreklilik, türevlenebilirlik ve integrallenebilirlik özellikleri analizde incelenir.", listOf("derivative", "integral")),
    AtlasTopic("derivative", "Türev", "Mathematics", "Bir fonksiyonun anlık değişim oranını ifade eder.", "Grafikte türev, eğrinin teğet eğimidir. Konumun zamana göre türevi hızdır.", "Türev limit ile tanımlanır: f′(x)=lim(h→0)[f(x+h)−f(x)]/h. Zincir kuralı bileşik fonksiyonların türevini verir.", listOf("function", "integral")),
    AtlasTopic("integral", "İntegral", "Mathematics", "Biriken miktarı ve eğri altındaki işaretli alanı hesaplamada kullanılır.", "Belirli integral, sürekli bir büyüklüğün aralık boyunca birikimini modeller.", "Temel kalkülüs teoremi türev ve integral işlemlerini ilişkilendirir; sayısal integrasyon yaklaşık çözümler üretir.", listOf("function", "derivative")),
    AtlasTopic("bond", "Kimyasal bağ", "Chemistry", "Atomları molekül ve kristal yapılarda bir arada tutan etkileşimdir.", "İyonik, kovalent ve metalik bağlar farklı elektron düzenleri ve yapı özellikleriyle ilişkilidir.", "Bağlar kuantum mekaniğinde moleküler orbital ve değerlik bağı modelleriyle açıklanır.", listOf("atom", "electron", "molecule")),
    AtlasTopic("molecule", "Molekül", "Chemistry", "Kimyasal bağlarla bir arada tutulan atom grubudur.", "Molekül geometrisi bağ açıları ve elektron çiftlerinin düzeninden etkilenir.", "VSEPR yararlı bir nitel modeldir; nicel yapı ve titreşimler kuantum kimyası ve spektroskopiyle incelenir.", listOf("bond", "atom")),
    AtlasTopic("star", "Yıldızların yaşam döngüsü", "Astronomy", "Yıldızlar gaz bulutlarının kütleçekimsel çökmesiyle oluşur.", "Yıldızın kütlesi ana kol ömrünü ve son evresini büyük ölçüde belirler.", "Yıldız evrimi hidrostatik denge, nükleer füzyon, opaklık ve kütle kaybı denklemleriyle modellenir.", listOf("astronomy", "light")),
    AtlasTopic("earth", "Dünya sistemi", "Geology", "Dünya; katı iç kısımlar, okyanuslar, atmosfer ve canlı yaşamının etkileştiği bir sistemdir.", "Jeosfer, hidrosfer, atmosfer ve biyosfer enerji ve madde alışverişi yapar.", "Dünya sistemi bilimi iklim geri beslemelerini, jeokimyasal döngüleri ve jeodinamik süreçleri bağlı modellerle inceler.", listOf("plate", "earthquake"))
)

internal fun atlasTopicById(id: String): AtlasTopic? = atlasTopics.firstOrNull { it.id == id }

@Composable
fun ScienceAtlasPage(p: Palette, english: Boolean, completed: Set<String>, onComplete: (String) -> Unit, onOpenTopic: (String) -> Unit, onOpenCategory: (String) -> Unit) {
    val progress = completed.intersect(atlasTopics.map { it.id }.toSet()).size.toFloat() / atlasTopics.size
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Panel(p) {
            Text("SPECTRUM · SCIENCE ATLAS", color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp, letterSpacing=2.sp)
            Text(if (english) "A connected map of science" else "Bilimin bağlantılı keşif haritası", color=p.text, fontSize=23.sp, fontWeight=FontWeight.Bold)
            Text(if (english) "Move from a short introduction to deeper scientific models. Core atlas content is stored locally." else "Kısa girişlerden ileri bilimsel modellere ilerle. Atlasın temel içeriği cihazda saklanır.", color=p.muted, lineHeight=19.sp)
            Row(verticalAlignment=Alignment.CenterVertically) { Text(if (english) "Learning progress" else "Öğrenme ilerlemesi", color=p.text, modifier=Modifier.weight(1f)); Text("${(progress*100).toInt()}%", color=p.accent, fontWeight=FontWeight.Bold) }
            LinearProgressIndicator(progress=progress, modifier=Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color=p.accent, trackColor=p.muted.copy(alpha=.2f))
        }
        val daily = atlasTopics[(LocalDate.now().dayOfYear % atlasTopics.size)]
        Panel(p) {
            Text(if (english) "DAILY SCIENCE" else "GÜNÜN BİLİMİ", color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp, letterSpacing=1.5.sp)
            Text(daily.title, color=p.text, fontSize=18.sp, fontWeight=FontWeight.Bold)
            Text(daily.explore, color=p.muted, lineHeight=19.sp)
            TextButton(onClick={onOpenTopic(daily.id)}) { Text(if (english) "Explore topic →" else "Konuyu keşfet →", color=p.accent) }
        }
        Text(if (english) "SCIENCE DOMAINS" else "BİLİM DALLARI", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
        val domains = listOf("Physics", "Chemistry", "Biology", "Astronomy", "Mathematics", "Geology", "Genetics", "Microbiology", "Technology", "Human Anatomy")
        domains.chunked(2).forEach { row -> Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { row.forEach { domain ->
            val target = when(domain) { "Physics"->"Fizik & Elektrik"; "Chemistry"->"Kimya"; "Biology","Human Anatomy"->"Biyoloji"; "Astronomy"->"Uzay"; "Mathematics"->"Matematik"; "Microbiology"->"Mikrobiyoloji"; "Technology"->"Teknoloji"; else->"" }
            Panel(p, Modifier.weight(1f).clickable { if(target.isNotEmpty()) onOpenCategory(target) else atlasTopics.firstOrNull { it.category==domain }?.let { onOpenTopic(it.id) } }) { Text(domain, color=p.accent, fontWeight=FontWeight.Bold); Text("${atlasTopics.count { it.category==domain }} ${if(english) "topics" else "konu"}", color=p.muted, fontSize=11.sp) }
        } } }
        Panel(p) {
            Text(if (english) "CONCEPT MAP" else "KAVRAM HARİTASI", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
            Text("Atom → Elektron → Elektromanyetizma → Işık → Astronomi", color=p.muted, fontSize=12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(6.dp)) { listOf("atom","electron","electromagnetism","light","astronomy").forEach { id -> atlasTopicById(id)?.let { AssistChip(onClick={onOpenTopic(id)}, label={Text(it.title)}) } } }
        }
        Text(if (english) "ALL TOPICS" else "TÜM KONULAR", color=p.accent, fontWeight=FontWeight.Bold, fontSize=12.sp)
        atlasTopics.forEach { topic -> Panel(p, Modifier.fillMaxWidth().clickable { onOpenTopic(topic.id) }) {
            Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(topic.title, color=p.text, fontWeight=FontWeight.Bold); Text(topic.category, color=p.muted, fontSize=11.sp) }; if(completed.contains(topic.id)) Icon(Icons.Default.CheckCircle,null,tint=p.accent) else Icon(Icons.Default.ChevronRight,null,tint=p.muted) }
            Text(topic.explore, color=p.muted, fontSize=12.sp, maxLines=2)
        } }
    }
}

@Composable
fun AtlasTopicPage(p: Palette, english: Boolean, topicId: String, completed: Boolean, onBack: () -> Unit, onComplete: () -> Unit, onRelated: (String) -> Unit) {
    val topic = atlasTopicById(topicId)
    if(topic==null) { TextButton(onClick=onBack) { Text(if(english) "Back" else "Geri") }; return }
    var level by rememberSaveable(topicId) { mutableIntStateOf(0) }
    val labels = if(english) listOf("Explore","Learn","Deep Dive") else listOf("Keşfet","Öğren","Derinlemesine")
    val texts = listOf(topic.explore,topic.learn,topic.deepDive)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement=Arrangement.spacedBy(11.dp)) {
        TextButton(onClick=onBack) { Icon(Icons.Default.ArrowBack,null); Text("Science Atlas") }
        Panel(p) { Text(topic.category.uppercase(Locale.ROOT), color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp); Text(topic.title,color=p.text,fontWeight=FontWeight.Bold,fontSize=24.sp) }
        Row(Modifier.fillMaxWidth().background(p.panel,RoundedCornerShape(14.dp)).padding(4.dp), horizontalArrangement=Arrangement.spacedBy(4.dp)) { labels.forEachIndexed { i,label -> Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if(level==i)p.accent else Color.Transparent).clickable { level=i }.padding(vertical=11.dp), contentAlignment=Alignment.Center) { Text(label,color=if(level==i)Color(0xFF071321) else p.text,fontSize=11.sp,fontWeight=FontWeight.SemiBold) } } }
        Panel(p) { Text(labels[level],color=p.accent,fontWeight=FontWeight.Bold); Text(texts[level],color=p.text,lineHeight=22.sp); if(level==2) Text(if(english) "Educational overview; consult specialist references for research use." else "Eğitim amaçlı özettir; araştırma kullanımı için uzmanlık kaynaklarına başvur.",color=p.muted,fontSize=11.sp) }
        Panel(p) { Text(if(english) "RELATED CONCEPTS" else "İLİŞKİLİ KAVRAMLAR",color=p.accent,fontWeight=FontWeight.Bold); Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) { topic.related.forEach { id -> atlasTopicById(id)?.let { AssistChip(onClick={onRelated(id)},label={Text(it.title)}) } } } }
        Button(onClick=onComplete,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=p.accent)) { Icon(if(completed)Icons.Default.CheckCircle else Icons.Default.TaskAlt,null); Spacer(Modifier.width(8.dp)); Text(if(completed)(if(english)"Completed" else "Tamamlandı") else (if(english)"Mark completed" else "Tamamlandı olarak işaretle"),color=Color(0xFF071321)) }
    }
}

@Composable
fun ScienceLibraryPage(p: Palette, english: Boolean, query: String, onQuery: (String)->Unit, onOpenElement:(String)->Unit, onOpenTopic:(String)->Unit, onOpenCategory:(String)->Unit) {
    val q=normalizeElementSearch(query.trim())
    val topics=atlasTopics.filter { q.isNotEmpty() && normalizeElementSearch("${it.title} ${it.category} ${it.explore}").contains(q) }
    val elements=elementRows.filter { q.isNotEmpty() && (normalizeElementSearch(it[0]).contains(q)||normalizeElementSearch(it[1]).contains(q)||it[2]==q) }.take(25)
    val sections=listOf("Biyoloji","Uzay","Elementler","Atomlar","Kimya","Matematik","Fizik & Elektrik","Teknoloji","Mikrobiyoloji","3B Bilim Laboratuvarı").filter { q.isNotEmpty() && normalizeElementSearch(it).contains(q) }
    var activeFilter by rememberSaveable(english) { mutableStateOf(if (english) "All" else "Tümü") }
    val filters = if (english) listOf("All", "Elements", "Topics", "Sections") else listOf("Tümü", "Elementler", "Konular", "Bölümler")
    val allLabel = filters[0]
    val elementLabel = filters[1]
    val topicLabel = filters[2]
    val sectionLabel = filters[3]
    Column(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
        Text(if(english)"Science Library" else "Bilim Kütüphanesi",color=p.text,fontWeight=FontWeight.Bold,fontSize=22.sp)
        Text(if(english)"A searchable index of scientific knowledge" else "Bilimsel bilginin aranabilir dizini",color=p.muted,fontSize=11.sp)
        OutlinedTextField(value=query,onValueChange=onQuery,modifier=Modifier.fillMaxWidth(),singleLine=true,placeholder={Text(if(english)"Search concepts, elements, organs…" else "Kavram, element, organ, gezegen ara…")},leadingIcon={Icon(Icons.Default.Search,null)})
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            filters.forEach { filter -> FilterChip(selected=activeFilter==filter,onClick={activeFilter=filter},label={Text(filter)}) }
        }
        if(query.isBlank()) {
            Panel(p) { Text(if(english)"OFFLINE SCIENCE INDEX" else "ÇEVRİMDIŞI BİLİM DİZİNİ",color=p.accent,fontWeight=FontWeight.Bold,fontSize=11.sp); Text(if(english)"Search 118 elements and curated Science Atlas topics. Core reference content remains available offline." else "118 element ve seçilmiş Science Atlas konuları arasında ara. Temel başvuru içerikleri çevrimdışı kullanılabilir.",color=p.muted,lineHeight=20.sp) }
            Text(if(english)"POPULAR COLLECTIONS" else "POPÜLER KOLEKSİYONLAR",color=p.accent,fontWeight=FontWeight.Bold,fontSize=11.sp)
            listOf("atom","cell","astronomy","gravity","dna").forEach { id -> atlasTopicById(id)?.let { topic ->
                Panel(p,Modifier.fillMaxWidth().clickable { onOpenTopic(id) }) { Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(topic.title,color=p.text,fontWeight=FontWeight.Bold); Text(topic.category,color=p.muted,fontSize=10.sp) }; Icon(Icons.Default.ChevronRight,null,tint=p.muted) } }
            } }
        } else {
            if(activeFilter==allLabel || activeFilter==topicLabel) {
            Text("ATLAS (${topics.size})",color=p.accent,fontWeight=FontWeight.Bold,fontSize=11.sp)
            topics.forEach { t->Panel(p,Modifier.fillMaxWidth().clickable { onOpenTopic(t.id) }) { Text(t.title,color=p.text,fontWeight=FontWeight.Bold); Text(t.category,color=p.muted,fontSize=11.sp) } }
            }
            if(activeFilter==allLabel || activeFilter==elementLabel) {
            Text("ELEMENTS (${elements.size})",color=p.accent,fontWeight=FontWeight.Bold,fontSize=11.sp)
            elements.forEach { e->Panel(p,Modifier.fillMaxWidth().clickable { onOpenElement(e[0]) }) { Text("${e[0]} · ${e[1]} · Z=${e[2]}",color=p.text,fontWeight=FontWeight.SemiBold) } }
            }
            if(activeFilter==allLabel || activeFilter==sectionLabel) {
            Text(if(english)"SECTIONS (${sections.size})" else "BÖLÜMLER (${sections.size})",color=p.accent,fontWeight=FontWeight.Bold,fontSize=11.sp)
            sections.forEach { section->Panel(p,Modifier.fillMaxWidth().clickable { onOpenCategory(section) }) { Text(section,color=p.text,fontWeight=FontWeight.SemiBold) } }
            }
            if((activeFilter==allLabel && topics.isEmpty()&&elements.isEmpty()&&sections.isEmpty()) || (activeFilter==topicLabel && topics.isEmpty()) || (activeFilter==elementLabel && elements.isEmpty()) || (activeFilter==sectionLabel && sections.isEmpty())) Text(if(english)"No results." else "Sonuç bulunamadı.",color=p.muted)
        }
    }
}
