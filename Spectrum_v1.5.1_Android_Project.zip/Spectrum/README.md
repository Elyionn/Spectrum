# Spectrum 1.5.1

Kotlin + Jetpack Compose Android science atlas.

## 1.5.1 update

- Reorganized the discovery screen into a compact two-column category grid.
- Added dedicated Atom Lab and Mathematics categories, following the supplied reference project's category and learning structure.
- Expanded the periodic-table detail view with period, group, block, physical state, electron-configuration availability, isotope and radioactivity notes.
- Corrected several Turkish element labels and the hassium representative mass number shown by the previous source.
- Added a 3D atom teaching view. It only renders explicit isotope nucleon counts and shell arrangements for the curated examples; for other elements it avoids inventing neutron counts or electron configurations.
- Reworked the anatomy scene with independently switchable bone, muscle, major vessel, organ, nerve and outer-body layers; added touch rotation, pinch zoom, zoom buttons, orientation presets and selectable structure descriptions.
- Reduced WebGL pixel ratio and changed anatomy rendering to event-driven redraws for better mobile performance.

## Build requirements

- JDK 17
- Android SDK platform 35 and build-tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.3

Run `gradle --no-daemon :app:assembleDebug` from this directory.

## Scientific and technical limitations

- The human-body viewer is an interactive educational schematic built from separate 3D meshes. It is not a full clinical anatomical dataset, and the displayed vessel paths and muscle/organ shapes are simplified. It must not be used for diagnosis or medical decisions.
- The atom viewer is an explanatory visualization, not a scale-accurate quantum-mechanical model. A classical orbit depiction is not a literal description of electron behaviour. Nucleon counts are shown only for selected named isotopes; the app does not guess neutron counts for unspecified isotopes.
- Electron configurations that have not been verified in the bundled data are explicitly marked unavailable instead of being fabricated. Properties of superheavy elements are not presented as measured when they are not experimentally established.
- Three.js is loaded from a CDN, so the interactive 3D views require an internet connection. The NASA solar-system scene also requires internet access.
- Scientific content is educational and should not be used for diagnosis or engineering design.

## Reference and attribution

The supplied Grok science-atlas project was reviewed for its mobile information architecture, category organization, topic-page structure, periodic-table interaction and atom visualization approach. Spectrum's Android implementation is independently written in Kotlin and Jetpack Compose. No reference-project source code is bundled as an Android dependency.

See `DATA_SOURCES.md` for the periodic-table data provenance, known gaps and anatomy/atom model limitations.
