package com.elyionn.spektrum

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private data class Palette(val name: String, val bg: Color, val panel: Color, val accent: Color, val text: Color, val muted: Color)
private val palettes = listOf(
    Palette("Kozmik", Color(0xFF081321), Color(0xFF192D45), Color(0xFF75C8FF), Color(0xFFF0F6FF), Color(0xFFB3C3D5)),
    Palette("Aurora", Color(0xFF071A19), Color(0xFF12332E), Color(0xFF73E0B5), Color(0xFFE8FFF6), Color(0xFFB0D4C8)),
    Palette("Nebula", Color(0xFF180E29), Color(0xFF2D1B49), Color(0xFFC5A0FF), Color(0xFFF6F0FF), Color(0xFFC8B8DD)),
    Palette("Arktik", Color(0xFF101C2B), Color(0xFF203B54), Color(0xFF8DD5FF), Color(0xFFEAF7FF), Color(0xFFB8CCDC)),
    Palette("Laboratuvar", Color(0xFFF1F5F7), Color(0xFFFFFFFF), Color(0xFF087F8C), Color(0xFF17232B), Color(0xFF52616B)),
    Palette("Gün Batımı", Color(0xFF24131A), Color(0xFF42232D), Color(0xFFFFAD83), Color(0xFFFFF1E9), Color(0xFFDCC0B5)),
    Palette("Obsidyen", Color(0xFF101014), Color(0xFF22232B), Color(0xFFFFD166), Color(0xFFF8F7F2), Color(0xFFB9B8C2)),
    Palette("Okyanus", Color(0xFF061B2A), Color(0xFF0E3448), Color(0xFF4DE3D0), Color(0xFFE8FBFF), Color(0xFFA7C9D5)),
    Palette("Lavanta", Color(0xFF211B31), Color(0xFF352A4B), Color(0xFFE0B8FF), Color(0xFFFAF0FF), Color(0xFFC9B9D5)),
    Palette("Zümrüt", Color(0xFF0C211A), Color(0xFF19382B), Color(0xFF9AE6A6), Color(0xFFEFFFF0), Color(0xFFB5D2BC))
)

private val elementRows = listOf(
"H|Hidrojen|1|1.008|Ametal", "He|Helyum|2|4.0026|Soygaz", "Li|Lityum|3|6.94|Alkali metal", "Be|Berilyum|4|9.0122|Toprak alkali", "B|Bor|5|10.81|Yarı metal", "C|Karbon|6|12.011|Ametal", "N|Azot|7|14.007|Ametal", "O|Oksijen|8|15.999|Ametal", "F|Flor|9|18.998|Halojen", "Ne|Neon|10|20.180|Soygaz",
"Na|Sodyum|11|22.990|Alkali metal", "Mg|Magnezyum|12|24.305|Toprak alkali", "Al|Alüminyum|13|26.982|Metal", "Si|Silisyum|14|28.085|Yarı metal", "P|Fosfor|15|30.974|Ametal", "S|Kükürt|16|32.06|Ametal", "Cl|Klor|17|35.45|Halojen", "Ar|Argon|18|39.948|Soygaz",
"K|Potasyum|19|39.098|Alkali metal", "Ca|Kalsiyum|20|40.078|Toprak alkali", "Sc|Skandiyum|21|44.956|Geçiş metali", "Ti|Titanyum|22|47.867|Geçiş metali", "V|Vanadyum|23|50.942|Geçiş metali", "Cr|Krom|24|51.996|Geçiş metali", "Mn|Manganez|25|54.938|Geçiş metali", "Fe|Demir|26|55.845|Geçiş metali", "Co|Kobalt|27|58.933|Geçiş metali", "Ni|Nikel|28|58.693|Geçiş metali", "Cu|Bakır|29|63.546|Geçiş metali", "Zn|Çinko|30|65.38|Geçiş metali", "Ga|Galyum|31|69.723|Metal", "Ge|Germanyum|32|72.630|Yarı metal", "As|Arsenik|33|74.922|Yarı metal", "Se|Selenyum|34|78.971|Ametal", "Br|Brom|35|79.904|Halojen", "Kr|Kripton|36|83.798|Soygaz",
"Rb|Rubidyum|37|85.468|Alkali metal", "Sr|Stronsiyum|38|87.62|Toprak alkali", "Y|İtriyum|39|88.906|Geçiş metali", "Zr|Zirkonyum|40|91.224|Geçiş metali", "Nb|Niyobyum|41|92.906|Geçiş metali", "Mo|Molibden|42|95.95|Geçiş metali", "Tc|Teknesyum|43|98|Geçiş metali", "Ru|Rutenyum|44|101.07|Geçiş metali", "Rh|Rodyum|45|102.91|Geçiş metali", "Pd|Paladyum|46|106.42|Geçiş metali", "Ag|Gümüş|47|107.87|Geçiş metali", "Cd|Kadmiyum|48|112.41|Geçiş metali", "In|İndiyum|49|114.82|Metal", "Sn|Kalay|50|118.71|Metal", "Sb|Antimon|51|121.76|Yarı metal", "Te|Tellür|52|127.60|Yarı metal", "I|İyot|53|126.90|Halojen", "Xe|Ksenon|54|131.29|Soygaz",
"Cs|Sezyum|55|132.91|Alkali metal", "Ba|Baryum|56|137.33|Toprak alkali", "La|Lantan|57|138.91|Lantanit", "Ce|Seryum|58|140.12|Lantanit", "Pr|Praseodim|59|140.91|Lantanit", "Nd|Neodimyum|60|144.24|Lantanit", "Pm|Prometyum|61|145|Lantanit", "Sm|Samaryum|62|150.36|Lantanit", "Eu|Evropiyum|63|151.96|Lantanit", "Gd|Gadolinyum|64|157.25|Lantanit", "Tb|Terbiyum|65|158.93|Lantanit", "Dy|Disprozyum|66|162.50|Lantanit", "Ho|Holmiyum|67|164.93|Lantanit", "Er|Erbiyum|68|167.26|Lantanit", "Tm|Tulyum|69|168.93|Lantanit", "Yb|İterbiyum|70|173.05|Lantanit", "Lu|Lutesyum|71|174.97|Lantanit",
"Hf|Hafniyum|72|178.49|Geçiş metali", "Ta|Tantal|73|180.95|Geçiş metali", "W|Tungsten|74|183.84|Geçiş metali", "Re|Renyum|75|186.21|Geçiş metali", "Os|Osmiyum|76|190.23|Geçiş metali", "Ir|İridyum|77|192.22|Geçiş metali", "Pt|Platin|78|195.08|Geçiş metali", "Au|Altın|79|196.97|Geçiş metali", "Hg|Cıva|80|200.59|Geçiş metali", "Tl|Talyum|81|204.38|Metal", "Pb|Kurşun|82|207.2|Metal", "Bi|Bizmut|83|208.98|Metal", "Po|Polonyum|84|209|Yarı metal", "At|Astatin|85|210|Halojen", "Rn|Radon|86|222|Soygaz",
"Fr|Fransiyum|87|223|Alkali metal", "Ra|Radyum|88|226|Toprak alkali", "Ac|Aktinyum|89|227|Aktinit", "Th|Toryum|90|232.04|Aktinit", "Pa|Protaktinyum|91|231.04|Aktinit", "U|Uranyum|92|238.03|Aktinit", "Np|Neptünyum|93|237|Aktinit", "Pu|Plütonyum|94|244|Aktinit", "Am|Amerikyum|95|243|Aktinit", "Cm|Küriyum|96|247|Aktinit", "Bk|Berkelyum|97|247|Aktinit", "Cf|Kaliforniyum|98|251|Aktinit", "Es|Einsteinyum|99|252|Aktinit", "Fm|Fermiyum|100|257|Aktinit", "Md|Mendelevyum|101|258|Aktinit", "No|Nobelyum|102|259|Aktinit", "Lr|Lavrensiyum|103|266|Aktinit", "Rf|Rutherfordiyum|104|267|Geçiş metali", "Db|Dubniyum|105|268|Geçiş metali", "Sg|Seaborgiyum|106|269|Geçiş metali", "Bh|Bohriyum|107|270|Geçiş metali", "Hs|Hassiyum|108|269|Geçiş metali", "Mt|Meitneriyum|109|278|Bilinmiyor", "Ds|Darmstadtiyum|110|281|Bilinmiyor", "Rg|Röntgenyum|111|282|Bilinmiyor", "Cn|Kopernikyum|112|285|Bilinmiyor", "Nh|Nihonyum|113|286|Bilinmiyor", "Fl|Flerovyum|114|289|Bilinmiyor", "Mc|Moskovyum|115|290|Bilinmiyor", "Lv|Livermoryum|116|293|Bilinmiyor", "Ts|Tennessin|117|294|Halojen", "Og|Oganesson|118|294|Soygaz"
).map { it.split('|') }

private val covalentRadiiPm = intArrayOf(0, 31, 28, 128, 96, 84, 76, 71, 66, 57, 58, 166, 141, 121, 111, 107, 105, 102, 106, 203, 176, 170, 160, 152, 139, 139, 132, 126, 124, 132, 122, 122, 120, 119, 120, 120, 116, 220, 195, 190, 175, 164, 154, 147, 146, 142, 139, 145, 144, 142, 139, 139, 138, 139, 140, 244, 215, 207, 204, 203, 201, 199, 198, 198, 196, 194, 192, 192, 189, 190, 187, 187, 175, 170, 162, 151, 144, 141, 136, 136, 132, 145, 146, 148, 140, 150, 150, 260, 220, 215, 206, 200, 196, 190, 187, 180, 169, 190, 190, 190, 190, 190, 190, 190)
private fun covalentRadiusPm(z: Int): Int? = if (z in 1..103) covalentRadiiPm.getOrNull(z) else null

private fun elementPeriod(z: Int): Int = when (z) {
    in 1..2 -> 1
    in 3..10 -> 2
    in 11..18 -> 3
    in 19..36 -> 4
    in 37..54 -> 5
    in 55..86 -> 6
    else -> 7
}

private fun elementGroup(z: Int): String = when (z) {
    1 -> "1"; 2 -> "18"
    in 3..4 -> (z - 2).toString()
    in 5..10 -> (z + 8).toString()
    in 11..12 -> (z - 10).toString()
    in 13..18 -> (z + 2).toString()
    in 19..36 -> (z - 18).toString()
    in 37..54 -> (z - 36).toString()
    in 55..56 -> (z - 54).toString()
    in 57..71 -> "3 · f-blok"
    in 72..86 -> (z - 68).toString()
    in 87..88 -> (z - 86).toString()
    in 89..103 -> "3 · f-blok"
    else -> (z - 100).toString()
}

private fun elementBlock(z: Int): String = when {
    z == 2 -> "s"
    z in 57..71 || z in 89..103 -> "f"
    elementGroup(z).substringBefore(" ").toIntOrNull()?.let { it in 1..2 } == true -> "s"
    elementGroup(z).substringBefore(" ").toIntOrNull()?.let { it in 13..18 } == true -> "p"
    else -> "d"
}

private fun elementState(z: Int): String = when (z) {
    1, 2, 7, 8, 9, 10, 17, 18, 36, 54, 86 -> "Gaz (25 °C, 1 atm)"
    35, 80 -> "Sıvı (25 °C, 1 atm)"
    in 104..118 -> "Makroskopik hâli deneysel olarak belirlenemedi"
    else -> "Katı (25 °C, 1 atm)"
}

private fun elementElectronConfig(z: Int): String? = when (z) {
    1 -> "1s¹"; 2 -> "1s²"; 3 -> "[He] 2s¹"; 4 -> "[He] 2s²"
    5 -> "[He] 2s² 2p¹"; 6 -> "[He] 2s² 2p²"; 7 -> "[He] 2s² 2p³"; 8 -> "[He] 2s² 2p⁴"; 9 -> "[He] 2s² 2p⁵"; 10 -> "[He] 2s² 2p⁶"
    11 -> "[Ne] 3s¹"; 12 -> "[Ne] 3s²"; 13 -> "[Ne] 3s² 3p¹"; 14 -> "[Ne] 3s² 3p²"; 15 -> "[Ne] 3s² 3p³"; 16 -> "[Ne] 3s² 3p⁴"; 17 -> "[Ne] 3s² 3p⁵"; 18 -> "[Ne] 3s² 3p⁶"
    19 -> "[Ar] 4s¹"; 20 -> "[Ar] 4s²"; 21 -> "[Ar] 3d¹ 4s²"; 22 -> "[Ar] 3d² 4s²"; 23 -> "[Ar] 3d³ 4s²"; 24 -> "[Ar] 3d⁵ 4s¹"; 25 -> "[Ar] 3d⁵ 4s²"; 26 -> "[Ar] 3d⁶ 4s²"; 27 -> "[Ar] 3d⁷ 4s²"; 28 -> "[Ar] 3d⁸ 4s²"; 29 -> "[Ar] 3d¹⁰ 4s¹"; 30 -> "[Ar] 3d¹⁰ 4s²"
    31 -> "[Ar] 3d¹⁰ 4s² 4p¹"; 32 -> "[Ar] 3d¹⁰ 4s² 4p²"; 33 -> "[Ar] 3d¹⁰ 4s² 4p³"; 34 -> "[Ar] 3d¹⁰ 4s² 4p⁴"; 35 -> "[Ar] 3d¹⁰ 4s² 4p⁵"; 36 -> "[Ar] 3d¹⁰ 4s² 4p⁶"
    47 -> "[Kr] 4d¹⁰ 5s¹"; 53 -> "[Kr] 4d¹⁰ 5s² 5p⁵"; 79 -> "[Xe] 4f¹⁴ 5d¹⁰ 6s¹"; 80 -> "[Xe] 4f¹⁴ 5d¹⁰ 6s²"; 82 -> "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p²"; 92 -> "[Rn] 5f³ 6d¹ 7s²"
    else -> null
}

private fun elementElectronConfigNote(z: Int): String = elementElectronConfig(z)
    ?: if (z >= 104) "Bu süper ağır elementin elektron yapısı teorik hesaplamalara dayanır; deneysel doğrulama sınırlıdır."
    else "Tam orbital dizilimi bu ekranda henüz kaynaklı veriyle doğrulanmadı. Yanlış bir dizilim göstermek yerine alan boş bırakıldı."

private fun elementEducation(e: List<String>): String {
    val symbol = e[0]
    val kind = e[4]
    val known = mapOf(
        "H" to "Hidrojen en hafif elementtir. En yaygın izotopu bir proton ve bir elektrondan oluşur. Yıldızlarda proton-proton zinciri ve diğer füzyon süreçlerinde enerji açığa çıkmasının temel yakıtıdır. Su ve organik bileşiklerin yapısında bulunur.",
        "He" to "Helyumun atom numarası 2'dir ve kapalı 1s² elektron kabuğu nedeniyle kimyasal tepkimeye girme eğilimi çok düşüktür. Çok düşük kaynama sıcaklığı, kriyojenik soğutma ve süperiletken mıknatıs sistemlerinde önemlidir.",
        "Li" to "Lityum en hafif metaldir. Li⁺ iyonlarının elektrotlar arasında hareket edebilmesi, lityum-iyon pillerin şarj ve deşarj mekanizmasının temelidir. Seramik ve cam bileşiklerinde de kullanılır.",
        "C" to "Karbon dört değerlik elektronu sayesinde çok çeşitli kovalent bağlar kurabilir. Elmas, grafit ve grafen aynı elementin farklı allotroplarıdır. Organik kimyanın ve bilinen yaşam kimyasının temel iskeletini oluşturur.",
        "N" to "Azot atmosferin yaklaşık %78'ini N₂ gazı olarak oluşturur. N₂ molekülündeki üçlü bağın koparılması enerji gerektirir. Azot bağlanması ve Haber-Bosch süreci, biyolojik azot döngüsü ile gübre üretiminde önemlidir.",
        "O" to "Oksijen atmosferde O₂ hâlinde bulunur ve aerobik hücresel solunumda elektron alıcısı olarak görev yapar. Oksijenin allotroplarından ozon (O₃), stratosferde Güneş'in morötesi ışınımının bir bölümünü soğurur.",
        "Na" to "Sodyum bir alkali metaldir ve nötr atomunun dış kabuğunda bir 3s elektronu bulunur. Bileşiklerinde çoğunlukla +1 yükseltgenme basamağındadır. Sodyum iyonları sinir hücrelerinin zar potansiyelinde ve sıvı dengesinde rol oynar.",
        "Mg" to "Magnezyum hafif bir toprak alkali metaldir. Klorofil molekülünün merkezinde Mg²⁺ bulunur. Hafif alaşımlar, piroteknik ışık kaynakları ve biyolojik enzim sistemleri açısından önemlidir.",
        "Al" to "Alüminyum düşük yoğunluklu, elektrik ve ısı iletkenliği iyi bir metaldir. Yüzeyinde oluşan ince alüminyum oksit tabakası korozyonu yavaşlatır. Ambalaj, ulaşım, yapı ve elektrik iletiminde kullanılır.",
        "Si" to "Silisyum yarı iletken teknolojisinin temel malzemelerindendir. Kristal yapısına kontrollü katkılama yapılarak p-tipi ve n-tipi bölgeler oluşturulur. Silisyum dioksit ise kum ve birçok camın ana bileşenidir.",
        "P" to "Fosfor DNA ve RNA'nın fosfat omurgasında, ATP'de ve kemik mineralinde bulunur. Elementel fosfor farklı allotroplara sahiptir; beyaz fosfor oldukça reaktif, kırmızı fosfor ise daha kararlıdır.",
        "S" to "Kükürt proteinlerdeki bazı amino asitlerin yapısında bulunur. İki sistein kalıntısı arasında oluşabilen disülfit bağları proteinlerin üç boyutlu yapısını kararlı hâle getirebilir. Sülfürik asit üretimi büyük ölçekli kimya sanayisinin temel süreçlerindendir.",
        "Cl" to "Klor bir halojendir. Cl₂ güçlü bir oksitleyici ve dezenfektan olarak kontrollü su arıtımında kullanılır; klorür iyonu ise sofra tuzu ve canlıların elektrolit dengesinin parçasıdır. Elementel klor ile klorür iyonunun özellikleri aynı değildir.",
        "K" to "Potasyum bir alkali metaldir. K⁺ iyonu hücre içi sıvının başlıca katyonudur ve sinir iletimi, kas işlevi ile hücresel elektriksel dengenin sürdürülmesine katkıda bulunur.",
        "Ca" to "Kalsiyum kemik ve dişlerde hidroksiapatit mineralinin önemli bileşenidir. Ca²⁺ iyonları kas kasılması, hücre içi sinyal iletimi, kan pıhtılaşması ve birçok enzimin düzenlenmesinde görev alır.",
        "Fe" to "Demir geçiş metalidir. Hemoglobindeki hem grubu oksijenin akciğerlerden dokulara taşınmasına yardımcı olur. Demir ayrıca sitokromlar ve elektron taşıma zincirindeki proteinlerde bulunur.",
        "Cu" to "Bakır elektrik ve ısıyı iyi iletir. Elektrik kabloları, motor sargıları ve elektronik bileşenlerde yaygındır. Canlılarda bazı oksidasyon-indirgenme enzimlerinin aktif merkezinde bakır iyonları bulunur.",
        "Zn" to "Çinko birçok enzimin yapısal veya katalitik bileşenidir. Galvanizleme işlemi çeliğin yüzeyini çinko ile kaplayarak korozyona karşı korur. Bileşiklerinde çoğunlukla +2 iyonu oluşturur.",
        "Ag" to "Gümüş görünür ışığı iyi yansıtır ve metaller arasında en yüksek elektrik iletkenliğine sahiptir. Elektronik kontaklar, özel kaplamalar ve bazı fotoğrafçılık kimyasallarında kullanılır.",
        "I" to "İyot tiroit hormonları T₃ ve T₄'ün yapısında bulunur. İyot eksikliği tiroit hormon üretimini etkileyebilir. Elementel iyot ile iyodür tuzları kimyasal açıdan farklı türlerdir.",
        "Au" to "Altın kimyasal olarak görece kararlı ve dövülebilir bir metaldir. Korozyona dayanımı, elektrik kontaklarında güvenilir yüzeyler oluşturmasını sağlar. Mücevherat, elektronik ve bazı kataliz uygulamalarında kullanılır.",
        "Hg" to "Cıva oda sıcaklığında sıvı olan iki elementten biridir. Yoğunluğu yüksektir; ancak cıva ve birçok bileşiği toksiktir. Eski ölçüm cihazlarında kullanılmış olsa da sağlık ve çevre riskleri nedeniyle kullanımı birçok alanda sınırlandırılmıştır.",
        "Pb" to "Kurşun yoğun ve yumuşak bir metaldir. Kurşun-asit akülerde elektrot malzemesi olarak kullanılır. Kurşun ve bileşiklerinin sinir sistemi üzerindeki toksik etkileri nedeniyle maruziyetin önlenmesi gerekir.",
        "U" to "Uranyum doğal olarak bulunan ağır bir aktinittir. U-235 fisil bir izotoptur; U-238 ise uranyum serisinin ve jeokronolojide kullanılan uranyum-kurşun tarihleme yöntemlerinin parçasıdır. İzotopların özellikleri birbirinden ayrılmalıdır."
    )
    return known[symbol] ?: when (kind) {
        "Alkali metal" -> "${e[1]} alkali metaller grubundadır. Bu grupta dış elektron düzeni genel olarak ns¹ biçimindedir ve elementler çoğunlukla +1 iyon oluşturur. Tepkime eğilimleri ve fiziksel özellikleri grupta aşağı doğru değişir. Saf metalin davranışı bileşiklerinin davranışından farklıdır."
        "Toprak alkali" -> "${e[1]} toprak alkali metaller grubundadır. Genel değerlik elektron düzeni ns²'dir ve bileşiklerinde +2 yükseltgenme basamağı yaygındır. Karbonatlar, oksitler ve sülfatlar gibi bileşikleri jeoloji, malzeme bilimi ve endüstride önem taşır."
        "Halojen" -> "${e[1]} halojenler grubundadır. Bu elementlerin değerlik katmanında genel olarak yedi elektron bulunur; birçok bileşikte −1 yükseltgenme basamağı gösterirler. Moleküler hâlleri, reaktiviteleri ve fiziksel durumları grup boyunca değişir."
        "Soygaz" -> "${e[1]} soygazlar grubundadır. Değerlik kabuklarının dolu olması, kimyasal tepkimeye girme eğilimlerini genellikle düşürür. Aydınlatma, koruyucu atmosferler, kriyojenik uygulamalar ve hassas ölçüm sistemlerinde farklı soygazlardan yararlanılır."
        "Lantanit" -> "${e[1]} lantanitler serisindedir. 4f orbitallerinin dolması manyetik, optik ve ışıldama özelliklerinde önemli rol oynar. Bazı lantanitler kalıcı mıknatıslar, fosforlar, lazer malzemeleri ve katalizörlerde kullanılır."
        "Aktinit" -> "${e[1]} aktinitler serisindedir. Bu elementlerin çekirdekleri radyoaktiftir; birçok izotopları yapay olarak üretilir. Nükleer kimya, çekirdek fiziği ve radyokimya araştırmalarında önem taşırlar."
        "Yarı metal" -> "${e[1]} yarı metal olarak sınıflandırılır. Yarı metallerin elektriksel ve kimyasal özellikleri metaller ile ametaller arasında değişebilir. Bazıları yarı iletken, alaşım, cam ve özel kimyasal malzemelerin üretiminde kullanılır."
        "Ametal" -> "${e[1]} ametaldir. Ametaller metalik parlaklık ve iletkenlik özelliklerini genellikle göstermez; kovalent bağlar veya anyonlar oluşturabilir. Elementin moleküler biçimi ve kimyasal tepkimeleri bulunduğu koşullara bağlıdır."
        "Bilinmiyor" -> "${e[1]} süper ağır, yapay olarak sentezlenen bir elementtir. Çok kısa ömürlü izotopları nedeniyle makroskopik örnekleri üzerinde olağan fiziksel ve kimyasal ölçümler yapılamamıştır. Bu nedenle birçok özellik teorik tahmin olarak kalır."
        else -> "${e[1]} bir metal elementidir. Metalik bağ, elektrik iletkenliği, dövülebilirlik ve alaşım oluşturma gibi özellikler gösterebilir. Geçiş metalleri ve p-blok metalleri arasında fiziksel özellikler ile kimyasal davranış önemli ölçüde farklılaşır."
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { SpectrumApp() }
    }
}

@Composable
private fun SpectrumApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("spectrum_settings", Context.MODE_PRIVATE) }
    var page by rememberSaveable { mutableStateOf("Keşif") }
    var category by rememberSaveable { mutableStateOf("") }
    var selectedElement by rememberSaveable { mutableStateOf("H") }
    var fontIndex by rememberSaveable { mutableIntStateOf(prefs.getInt("font", 0).coerceIn(0, 3)) }
    var themeIndex by rememberSaveable { mutableIntStateOf(prefs.getInt("theme", 0).coerceIn(palettes.indices)) }
    var soundOn by rememberSaveable { mutableStateOf(prefs.getBoolean("sound", false)) }
    val p = palettes[themeIndex]
    val tone = remember { ToneGenerator(AudioManager.STREAM_MUSIC, 35) }
    DisposableEffect(Unit) { onDispose { tone.release() } }
    fun clickSound() { if (soundOn) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 65) }
    val scheme = if (themeIndex == 4) lightColorScheme(
        primary = p.accent, background = p.bg, surface = p.panel, onSurface = p.text, onBackground = p.text
    ) else darkColorScheme(
        primary = p.accent, background = p.bg, surface = p.panel, onSurface = p.text, onBackground = p.text
    )

    val appFont = when (fontIndex) { 1 -> androidx.compose.ui.text.font.FontFamily.Serif; 2 -> androidx.compose.ui.text.font.FontFamily.Monospace; 3 -> androidx.compose.ui.text.font.FontFamily.Cursive; else -> androidx.compose.ui.text.font.FontFamily.SansSerif }
    MaterialTheme(colorScheme = scheme) {
      androidx.compose.runtime.CompositionLocalProvider(androidx.compose.material3.LocalTextStyle provides androidx.compose.material3.LocalTextStyle.current.copy(fontFamily = appFont)) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = p.bg,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                NavigationBar(
                    containerColor = p.panel,
                    contentColor = p.text
                ) {
                    val items = listOf(
                        Triple("Keşif", Icons.Default.Explore, "Keşif"),
                        Triple("Kategoriler", Icons.Default.Category, "Kategoriler"),
                        Triple("Ayarlar", Icons.Default.Settings, "Ayarlar")
                    )
                    items.forEach { item ->
                        NavigationBarItem(
                            selected = page == item.first || ((page == "Detay" || page == "ElementDetay") && item.first == "Kategoriler"),
                            onClick = { clickSound(); page = item.first; category = "" },
                            icon = { Icon(item.second, contentDescription = item.first) },
                            label = { Text(item.first, fontSize = 11.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = p.accent,
                                selectedTextColor = p.accent,
                                indicatorColor = p.accent.copy(alpha = .16f),
                                unselectedIconColor = p.muted,
                                unselectedTextColor = p.muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).background(p.bg)
            ) {
                Header(p = p, title = when (page) { "Detay" -> category; "ElementDetay" -> selectedElement; else -> page })
                when (page) {
                    "Keşif" -> HomePage(p, onOpen = { category = it; page = "Detay" }, onAll = { page = "Kategoriler" })
                    "Kategoriler" -> CategoryHub(p, onOpen = { category = it; page = "Detay" })
                    "Ayarlar" -> SettingsPage(
                        p, themeIndex, soundOn, fontIndex,
                        onTheme = { themeIndex = it; prefs.edit().putInt("theme", it).apply(); clickSound() },
                        onSound = { soundOn = it; prefs.edit().putBoolean("sound", it).apply() },
                        onFont = { fontIndex = it; prefs.edit().putInt("font", it).apply() }
                    )
                    "ElementDetay" -> ElementDetailPage(p, elementRows.firstOrNull { it[0] == selectedElement } ?: elementRows.first(), onBack = { page = "Detay" })
                    "Detay" -> CategoryDetail(p, category, onBack = { page = "Kategoriler"; category = "" }, onElement = { selectedElement = it; page = "ElementDetay" })
                    else -> HomePage(p, onOpen = { category = it; page = "Detay" }, onAll = { page = "Kategoriler" })
                }
            }
        }
      }
    }
}

@Composable
private fun Header(p: Palette, title: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("S P E C T R U M", color = p.accent, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text(if (title == "Keşif") "Bilim, keşif ve merak alanı" else title, color = p.muted, fontSize = 12.sp)
        }
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(com.elyionn.spektrum.R.drawable.spectrum_logo),
            contentDescription = "Spectrum logosu",
            modifier = Modifier.size(42.dp).clip(CircleShape)
        )
    }
}

@Composable
private fun Panel(p: Palette, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth()
            .background(p.panel, RoundedCornerShape(20.dp))
            .border(1.dp, p.accent.copy(alpha = .18f), RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}

private val categoryDescriptions = listOf(
    "Biyoloji" to "İnsan anatomisi, hücre, DNA, genetik ve canlı sistemleri",
    "Kimya" to "Kimyasal bağlar, tepkimeler, çözeltiler, asitler ve bazlar",
    "Elementler" to "118 element, etkileşimli periyodik tablo ve ayrıntılı element dosyaları",
    "Atomlar" to "Atomun yapısı, orbitaller, elektron dizilimi, iyonlar ve izotoplar",
    "Fizik & Elektrik" to "Kuvvet, hareket, enerji, dalgalar, optik ve elektrik",
    "Uzay" to "Güneş Sistemi, gezegenler, yıldızlar, galaksiler ve kozmoloji",
    "Matematik" to "Sayılar, cebir, geometri, fonksiyonlar ve olasılık",
    "Mikrobiyoloji" to "Bakteriler, virüsler, mantarlar ve mikroskobik yaşam",
    "Teknoloji" to "Elektronik, sensörler, işlemciler ve modern mühendislik",
    "3B Bilim Laboratuvarı" to "İnsan vücudu, atomlar ve molekülleri etkileşimli 3B inceleme"
)

@Composable
private fun HomePage(p: Palette, onOpen: (String) -> Unit, onAll: () -> Unit) {
    var search by rememberSaveable { mutableStateOf("") }
    val results = categoryDescriptions.filter { it.first.contains(search, true) || it.second.contains(search, true) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel(p, Modifier.heightIn(min = 165.dp)) {
            Text("BİLİM ATLASI  ·  SÜRÜM 1.5.1", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(10.dp))
            Text("Merak et.\nKeşfet. Öğren.", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = p.text, lineHeight = 35.sp)
            Spacer(Modifier.height(8.dp))
            Text("İnsan bedeninden galaksilere, atomlardan modern teknolojilere uzanan etkileşimli öğrenme alanı.", color = p.muted, lineHeight = 21.sp)
        }
        OutlinedTextField(
            value = search, onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Kategori ara...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(16.dp)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Keşif kategorileri", color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            TextButton(onClick = onAll) { Text("Tümünü gör", color = p.accent) }
        }
        results.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { (name, desc) ->
                    Panel(p, Modifier.weight(1f).heightIn(min = 112.dp).clickable { onOpen(name) }) {
                        Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(p.accent.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                            Icon(categoryIcon(name), null, tint = p.accent)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(name, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(desc, color = p.muted, fontSize = 11.sp, lineHeight = 15.sp, maxLines = 3)
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Text("Elyionn tarafından tasarlanmıştır · Spectrum 1.5.1", color = p.muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(8.dp))
    }
}

@Composable
private fun CategoryHub(p: Palette, onOpen: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = categoryDescriptions.filter { it.first.contains(query, true) || it.second.contains(query, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text("Bilim alanları", color = p.text, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Text("Bir kategori seçerek kendi bölümüne geç.", color = p.muted)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Kategori veya konu ara") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            filtered.forEach { (name, desc) ->
                Panel(p, Modifier.clickable { onOpen(name) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(p.accent.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                            Icon(categoryIcon(name), null, tint = p.accent)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(desc, color = p.muted, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = p.muted)
                    }
                }
            }
            if (filtered.isEmpty()) Text("Eşleşen kategori bulunamadı.", color = p.muted, modifier = Modifier.padding(12.dp))
        }
    }
}

@Composable
private fun categoryIcon(name: String) = when (name) {
    "Biyoloji" -> Icons.Default.Favorite
    "Uzay" -> Icons.Default.Public
    "Elementler", "Kimya", "Atomlar" -> Icons.Default.Science
    "Matematik" -> Icons.Default.Calculate
    "Mikrobiyoloji" -> Icons.Default.Biotech
    "3B Bilim Laboratuvarı" -> Icons.Default.ViewInAr
    "Fizik & Elektrik" -> Icons.Default.Bolt
    "Teknoloji" -> Icons.Default.Memory
    else -> Icons.Default.Explore
}

@Composable
private fun CategoryDetail(p: Palette, category: String, onBack: () -> Unit, onElement: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri", tint = p.accent) }
            Text(category, color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        when (category) {
            "Biyoloji" -> BiologyPage(p)
            "Uzay" -> SpacePage(p)
            "Elementler" -> ElementsPage(p, onElement)
            "Atomlar" -> AtomLabPage(p)
            "Kimya" -> ChemistryPage(p)
            "Matematik" -> MathematicsPage(p)
            "Fizik & Elektrik" -> PhysicsKnowledgePage(p)
            "Teknoloji" -> TechnologyKnowledgePage(p)
            "Mikrobiyoloji" -> MicrobiologyPage(p)
            "3B Bilim Laboratuvarı" -> VisualAtlasPage(p)
            else -> Text("Kategori bulunamadı.", color = p.text)
        }
    }
}

@Composable
private fun BiologyPage(p: Palette) {
    val systems = listOf(
        "Sinir sistemi" to "Beyin, omurilik ve sinirlerden oluşur. Duyuları işler, hareketleri koordine eder ve organların faaliyetlerini düzenler. Beyincik denge ve hareket koordinasyonunda; beyin sapı solunum ve kalp ritmi gibi yaşamsal işlevlerde rol oynar.",
        "Dolaşım sistemi" to "Kalp, kan ve damarlardan oluşur. Kalbin sağ tarafı kanı akciğerlere, sol tarafı vücuda pompalar. Atardamarlar kanı kalpten uzaklaştırır; toplardamarlar geri taşır; kılcal damarlar oksijen, besin ve atık alışverişini sağlar.",
        "Solunum sistemi" to "Burun ve ağızdan alınan hava yutak, gırtlak, soluk borusu, bronşlar ve bronşçuklardan geçerek alveollere ulaşır. Alveollerde oksijen kana, karbondioksit ise alveol havasına geçer. Diyafram solunumun temel kasıdır.",
        "Sindirim sistemi" to "Ağızda mekanik ve kimyasal sindirim başlar. Yemek borusu besini mideye taşır. Mide asit ve enzimlerle sindirime katkı verir. İnce bağırsak besinlerin büyük bölümünü emer; kalın bağırsak su ve elektrolit emilimine katkıda bulunur. Karaciğer safra üretir, pankreas enzim salgılar.",
        "Kas-iskelet sistemi" to "Kemikler destek ve koruma sağlar; eklemler hareket açıklığını belirler; kaslar kasılarak kuvvet üretir. İskelet kasları istemli hareketlerde, düz kaslar iç organlarda, kalp kası kalpte görev yapar. Kemik iliği kan hücrelerinin üretiminde rol alır.",
        "Üriner sistem" to "Böbreklerdeki nefronlar kanı süzer; gerekli maddeler geri emilir ve bazı maddeler tübüllere salgılanır. Oluşan idrar üreterlerle mesaneye taşınır ve üretradan atılır. Sistem su, elektrolit ve asit-baz dengesine katkı sağlar.",
        "Endokrin sistem" to "Hormonlar aracılığıyla büyüme, metabolizma, stres yanıtı ve iç dengeyi düzenler. Hipofiz, tiroit, paratiroit, pankreas, böbreküstü bezleri ve eşey bezleri önemli bileşenleridir.",
        "Bağışıklık ve lenf sistemi" to "Deri ve mukozalar ilk savunma hattıdır. Doğuştan gelen bağışıklık hızlı ve genel yanıt verir; B ve T lenfositleri kazanılmış bağışıklıkta görev alır. Lenf düğümleri bağışıklık hücrelerinin karşılaşma ve etkinleşme alanlarıdır.",
        "Üreme sistemi" to "Üreme organları gamet üretimi ve üreme işlevlerinde rol oynar. Hormonlar üreme sisteminin gelişimini ve işleyişini düzenler. İnsan gelişimi döllenme, embriyonik gelişim ve doğum sonrası büyüme aşamalarını kapsar.",
        "Deri ve duyu sistemi" to "Deri vücudun dış örtüsüdür; bariyer, sıcaklık düzenleme ve duyu işlevleri görür. Dokunma, basınç, sıcaklık ve ağrı reseptörleri çevreden bilgi alır. Deri epidermis, dermis ve deri altı dokudan oluşur.",
        "Kan ve bağışıklık hücreleri" to "Plazma, alyuvarlar, akyuvarlar ve trombositler kanın temel bileşenleridir. Alyuvarlar oksijen taşır; akyuvarlar savunmada; trombositler pıhtılaşmada görev alır."
    )
    var expanded by rememberSaveable { mutableStateOf("Sinir sistemi") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) {
            Text("İnsan vücudu atlası", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 21.sp)
            Text("Organlar tek başına değil, birlikte çalışan sistemler halinde işlev görür. Aşağıdaki başlıklardan birini açarak temel yapı ve görevleri incele.", color = p.muted)
        }
        Panel(p) {
            Text("3B anatomi modeli", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Modeli parmağınla sürükleyerek döndür. Organlar şematik gösterimdir.", color = p.muted, fontSize = 12.sp)
            Anatomy3DView()
        }
        systems.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == title) "" else title }, verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded == title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == title) { Spacer(Modifier.height(8.dp)); Text(body, color = p.text, lineHeight = 21.sp) }
            }
        }
        Panel(p) {
            Text("Hücreden organizmaya", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Hücreler dokuları, dokular organları, organlar da sistemleri oluşturur. DNA, hücrelerin kalıtsal bilgisinin büyük bölümünü taşır. Proteinler hücre yapısında ve işlevlerinde temel rol oynar.", color = p.text)
        }
    }
}

private data class Planet(val name: String, val type: String, val diameter: String, val year: String, val moons: String, val facts: String, val mission: String)
private val planets = listOf(
    Planet("Merkür","Karasal","4.879 km","88 Dünya günü","0","Güneş'e en yakın gezegendir. Çok ince bir dış gaz örtüsüne sahiptir; gündüz ve gece sıcaklık farkı çok büyüktür. Büyük metalik çekirdeği gezegenin iç yapısında önemli yer tutar.","MESSENGER görevi yüzeyini ve manyetik alanını ayrıntılı haritaladı. BepiColombo Merkür'e yolculuğunu sürdürüyor."),
    Planet("Venüs","Karasal","12.104 km","225 Dünya günü","0","Yoğun karbondioksit atmosferi ve güçlü sera etkisi nedeniyle yüzeyi çok sıcaktır. Sülfürik asit bulutları bulunur. Yavaş ve ters yönlü dönüşüyle dikkat çeker.","Magellan radar haritalaması yaptı; Akatsuki atmosfer dinamiklerini inceledi."),
    Planet("Dünya","Karasal","12.742 km","365,25 gün","1","Yüzeyinde kalıcı sıvı su ve bildiğimiz yaşam bulunur. Atmosferi çoğunlukla azot ve oksijenden oluşur. Manyetik alanı Güneş rüzgârıyla etkileşir.","Çok sayıda uydu atmosferi, okyanusları, iklimi ve yüzeyi izler."),
    Planet("Mars","Karasal","6.779 km","687 Dünya günü","2","Demir oksit yüzeyine kızıl renk verir. Olympus Mons dev bir volkandır; Valles Marineris büyük bir kanyon sistemidir. Eski nehir yatakları ve mineraller geçmişte sıvı su bulunduğunu gösterir.","Curiosity ve Perseverance yüzeyi inceliyor; yörünge araçları haritalama yapıyor."),
    Planet("Jüpiter","Gaz devi","139.820 km","11,86 Dünya yılı","Çok sayıda","En büyük gezegendir; çoğunlukla hidrojen ve helyumdan oluşur. Büyük Kırmızı Leke dev bir fırtınadır. Europa'nın buz altında okyanusu olabileceğine dair güçlü kanıtlar vardır.","Juno gezegenin iç yapısını ve manyetik alanını inceliyor; Europa Clipper Europa'yı araştıracak."),
    Planet("Satürn","Gaz devi","116.460 km","29,4 Dünya yılı","Çok sayıda","Buz ve kaya parçacıklarından oluşan halkalarıyla tanınır. Titan'da metan ve etan gölleri; Enceladus'ta buz altı okyanusuna işaret eden püskürmeler vardır.","Cassini-Huygens görevi Satürn, halkaları ve uyduları hakkında büyük miktarda veri topladı."),
    Planet("Uranüs","Buz devi","50.724 km","84 Dünya yılı","Çok sayıda","Eksen eğikliği yaklaşık 98 derecedir; adeta yan yatmış şekilde döner. Atmosferindeki metan mavi-yeşil görünmesine katkı verir.","Yakından ziyaret eden tek araç Voyager 2'dir. Gelecekte yeni bir yörünge görevi önerilmektedir."),
    Planet("Neptün","Buz devi","49.244 km","165 Dünya yılı","Çok sayıda","Güneş'ten uzaklığı nedeniyle çok az enerji alır. Atmosferinde çok hızlı rüzgârlar ve değişken koyu fırtınalar görülür.","Voyager 2 1989'da yakınından geçti; günümüzde teleskoplarla izlenir.")
)

@Composable
private fun SpacePage(p: Palette) {
    var expanded by rememberSaveable { mutableStateOf("Dünya") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) {
            Text("Güneş Sistemi", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("Güneş'in kütleçekimiyle bağlı sekiz gezegen, cüce gezegenler, uydular, asteroitler ve kuyruklu yıldızlardan oluşur.", color = p.muted)
        }
        planets.forEach { planet ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == planet.name) "" else planet.name }, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(planet.name, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("${planet.type} · ${planet.year}", color = p.muted, fontSize = 12.sp)
                    }
                    Icon(if (expanded == planet.name) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == planet.name) {
                    Spacer(Modifier.height(8.dp))
                    Text("Çap: ${planet.diameter}   ·   Bilinen uydu: ${planet.moons}", color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(planet.facts, color = p.text, lineHeight = 21.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Keşif görevleri: ${planet.mission}", color = p.muted, lineHeight = 19.sp, fontSize = 12.sp)
                }
            }
        }
        Text("Uzay ve astrofizik konuları", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        val spaceTopics = listOf(
            "Güneş'in yapısı" to "Güneş, kütlesinin büyük bölümünü hidrojen ve helyumun oluşturduğu bir yıldızdır. Çekirdeğinde nükleer füzyon enerji üretir.",
            "Ay ve gelgitler" to "Ay'ın kütleçekimi okyanus gelgitlerinin başlıca nedenidir. Güneş'in çekimi de gelgit düzenini etkiler.",
            "Cüce gezegenler" to "Cüce gezegenler Güneş'in çevresinde dolanır ve yaklaşık küresel şekle ulaşacak kütleye sahiptir; yörüngelerinin çevresini temizlememişlerdir.",
            "Asteroitler" to "Asteroitlerin çoğu Mars ile Jüpiter arasındaki ana kuşakta bulunur. Boyutları küçük kaya parçalarından yüzlerce kilometrelik cisimlere kadar değişir.",
            "Kuyruklu yıldızlar" to "Kuyruklu yıldızlar buz, toz ve kaya içerir. Güneş'e yaklaştıklarında ısınan yüzeylerinden gaz ve toz salınır; koma ve kuyruk oluşabilir.",
            "Ötegezegenler" to "Ötegezegenler Güneş dışındaki yıldızların çevresinde dolanır. Geçiş ve dikey hız yöntemleri keşiflerde sık kullanılır.",
            "Yıldızların yaşam döngüsü" to "Yıldızların evrimi başlangıç kütlesine bağlıdır. Son evrelerinde beyaz cüce, nötron yıldızı veya kara delik oluşturabilirler.",
            "Kara delikler" to "Kara delik, olay ufkunun içinden ışığın kaçamadığı uzay-zaman bölgesidir. Çevresindeki madde güçlü kütleçekimsel etkiler gösterebilir.",
            "Galaksiler" to "Galaksiler yıldızlar, gaz, toz, karanlık madde ve diğer bileşenlerden oluşan kütleçekimsel sistemlerdir. Samanyolu çubuklu sarmal galaksidir.",
            "Kozmik uzaklıklar" to "Astronomide astronomik birim, ışık yılı ve parsek kullanılır. Işık yılı zaman değil, ışığın bir yılda aldığı mesafedir."
        )
        spaceTopics.forEach { (title, body) ->
            Panel(p) {
                Text(title, color = p.accent, fontWeight = FontWeight.Bold)
                Text(body, color = p.text, lineHeight = 20.sp)
            }
        }
        Panel(p) {
            Text("Cüce gezegenler ve küçük cisimler", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Plüton, Ceres, Eris, Haumea ve Makemake cüce gezegenler arasında sayılır. Asteroit kuşağı Mars ile Jüpiter arasında; Kuiper Kuşağı ise Neptün ötesinde bulunur. Kuyruklu yıldızlar buz, toz ve kayaçlardan oluşur.", color = p.text)
        }
        Panel(p) {
            Text("3B Uzay gözlemevi", color = p.accent, fontWeight = FontWeight.Bold)
            Text("NASA'nın etkileşimli sayfasında gezegenleri yakınlaştırıp döndürebilirsin.", color = p.muted)
            Text("Sahneyi parmağınla sürükleyerek döndürebilir, yakınlaştırabilir ve gezegenleri seçebilirsin. İnternet bağlantısı gerekir.", color = p.muted, fontSize = 12.sp)
            AndroidView(modifier = Modifier.fillMaxWidth().height(270.dp).clip(RoundedCornerShape(14.dp)), factory = { ctx -> WebView(ctx).apply { webViewClient = WebViewClient(); webChromeClient = WebChromeClient(); settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.loadWithOverviewMode = true; settings.useWideViewPort = true; loadUrl("https://eyes.nasa.gov/apps/solar-system/") } })
        }
    }
}

@Composable
private fun ElementsPage(p: Palette, onElement: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = elementRows.filter { it[0].contains(query, true) || it[1].contains(query, true) || it[2] == query }
    val byNumber = elementRows.associateBy { it[2].toInt() }
    val periodicRows: List<List<Int?>> = listOf(
        listOf<Int?>(1) + List(16) { null } + listOf(2),
        listOf<Int?>(3, 4) + List(10) { null } + listOf(5, 6, 7, 8, 9, 10),
        listOf<Int?>(11, 12) + List(10) { null } + listOf(13, 14, 15, 16, 17, 18),
        (19..36).map { it },
        (37..54).map { it },
        listOf<Int?>(55, 56, null) + (72..86).map { it },
        listOf<Int?>(87, 88, null) + (104..118).map { it },
        listOf<Int?>(null, null, null) + (57..71).map { it },
        listOf<Int?>(null, null, null) + (89..103).map { it }
    )
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Periyodik tablo · 118 element", color = p.text, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text("Tabloyu yatay kaydır. Bir elemente dokunarak ayrı bilgi sayfasını aç.", color = p.muted, fontSize = 12.sp)
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("İsim, sembol veya atom numarası ara") }, shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.height(8.dp))
        if (query.isBlank()) {
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        (1..18).forEach { group ->
                            Box(Modifier.size(52.dp, 20.dp), contentAlignment = Alignment.Center) { Text(group.toString(), color = p.muted, fontSize = 9.sp) }
                        }
                    }
                    periodicRows.forEachIndexed { rowIndex, row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            row.forEach { atomicNumber ->
                                val e = atomicNumber?.let { byNumber[it] }
                                if (e == null) {
                                    Spacer(Modifier.size(52.dp, 58.dp))
                                } else {
                                    Card(onClick = { onElement(e[0]) }, modifier = Modifier.size(52.dp, 58.dp), colors = CardDefaults.cardColors(containerColor = p.panel), border = BorderStroke(1.dp, p.accent.copy(alpha = .25f))) {
                                        Column(Modifier.fillMaxSize().padding(4.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(e[2], color = p.muted, fontSize = 8.sp)
                                            Text(e[0], color = p.accent, fontWeight = FontWeight.Black, fontSize = 19.sp)
                                            Text(e[1], color = p.text, fontSize = 8.sp, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Text("Üstteki 7 satır ana grupları, alttaki iki satır lantanitleri ve aktinitleri gösterir.", color = p.muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.weight(1f), contentPadding = PaddingValues(3.dp), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(filtered, key = { it[2] }) { e ->
                    Card(onClick = { onElement(e[0]) }, colors = CardDefaults.cardColors(containerColor = p.panel), border = BorderStroke(1.dp, p.accent.copy(alpha = .28f)), modifier = Modifier.heightIn(min = 88.dp)) {
                        Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(e[2], color = p.muted, fontSize = 10.sp)
                            Text(e[0], color = p.accent, fontWeight = FontWeight.Black, fontSize = 25.sp)
                            Text(e[1], color = p.text, fontSize = 11.sp, maxLines = 1)
                            Text(e[4], color = p.muted, fontSize = 9.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ElementDetailPage(p: Palette, element: List<String>, onBack: () -> Unit) {
    val (symbol, name, numberText, mass, kind) = element
    val z = numberText.toIntOrNull() ?: 1
    val period = elementPeriod(z)
    val group = elementGroup(z)
    val block = elementBlock(z)
    val config = elementElectronConfigNote(z)
    val radioactive = z == 43 || z == 61 || z >= 83
    val noStableIsotope = z == 43 || z == 61 || z >= 84
    val massLabel = if (noStableIsotope) "[$mass] u*" else "$mass u"
    val detail = elementEducation(element)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri", tint = p.accent) }
            Text("Element öğrenme dosyası", color = p.text, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
        Panel(p) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ATOM NUMARASI $z", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text(name, color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text(kind, color = p.muted)
                }
                Box(Modifier.size(88.dp).clip(RoundedCornerShape(18.dp)).background(p.accent.copy(alpha = .16f)), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(z.toString(), color = p.muted, fontSize = 11.sp)
                        Text(symbol, color = p.accent, fontSize = 38.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                ElementStat(p, "Atom kütlesi", massLabel)
                ElementStat(p, "Proton", z.toString())
                ElementStat(p, "Elektron*", z.toString())
            }
            Text("* Elektron sayısı nötr atom için verilmiştir. İyonlarda elektron sayısı yük durumuna göre değişir.", color = p.muted, fontSize = 10.sp)
        }
        Panel(p) {
            Text("Periyodik tablodaki konumu", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Periyot: $period     Grup: $group     Blok: $block", color = p.text, fontWeight = FontWeight.SemiBold)
            Text("Fiziksel hâl: ${elementState(z)}", color = p.text)
            Text("Kovalent yarıçap: ${covalentRadiusPm(z)?.let { "$it pm" } ?: "güvenilir deneysel değer yok"}", color = p.text)
            Text("Elektron dizilimi: $config", color = p.text, lineHeight = 21.sp)
            Text("Elementin periyodik tablodaki konumu, atom numarası ve elektron yapısıyla ilişkilidir. Aynı gruptaki elementlerin değerlik elektron düzenleri benzer olduğundan bazı kimyasal özellikleri de benzerlik gösterir.", color = p.muted, lineHeight = 20.sp, fontSize = 12.sp)
        }
        Panel(p) {
            Text(if (setOf("H", "He", "Li", "C", "N", "O", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "K", "Ca", "Fe", "Cu", "Zn", "Ag", "I", "Au", "Hg", "Pb", "U").contains(symbol)) "Elementin kimyası ve önemi" else "Element ailesi ve kimyasal bağlam", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(detail, color = p.text, lineHeight = 22.sp)
        }
        Panel(p) {
            Text("Atomun temel parçacıkları", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Proton sayısı: $z\nNötr atomdaki elektron sayısı: $z\nNötron sayısı: seçilen izotopa bağlıdır.", color = p.text, lineHeight = 22.sp)
            Text("Atom numarası elementin kimliğini belirler. Aynı elementin proton sayısı aynı, nötron sayısı farklı olan atomlarına izotop denir. Bu nedenle tek bir nötron sayısı bütün atomlar için geçerli değildir.", color = p.muted, lineHeight = 20.sp, fontSize = 12.sp)
        }
        if (radioactive) Panel(p) {
            Text("Radyoaktivite ve atom kütlesi notu", color = p.accent, fontWeight = FontWeight.Bold)
            Text(if (noStableIsotope) "Bu elementin kararlı izotopu yoktur. Köşeli parantez içindeki sayı, standart atom ağırlığı yerine seçilmiş bir izotopun kütle numarasını belirtir; doğal izotopların ortalama atom ağırlığı gibi yorumlanmamalıdır." else "Bizmutun bilinen izotopları radyoaktiftir; Bi-209 çok uzun yarı ömürlüdür. Bu nedenle tabloda standart atom ağırlığı gösterimi korunur.", color = p.text, lineHeight = 21.sp)
        }
        Panel(p) {
            Text("3B atom modeli", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Atom3DView(p, symbol, z)
            Text("Model, atomun ölçekli veya kuantum-mekanik açıdan tam temsili değildir. Elektronların belirli dairesel yörüngelerde dolaştığı izlenimi vermemek için bu görünüm eğitim amaçlı şematik bir görselleştirmedir.", color = p.muted, fontSize = 11.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun ElementStat(p: Palette, title: String, value: String) {
    Column(Modifier.widthIn(min = 76.dp).background(p.bg.copy(alpha=.5f), RoundedCornerShape(12.dp)).padding(9.dp)) {
        Text(title, color = p.muted, fontSize = 10.sp)
        Text(value, color = p.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}


@Composable
private fun AtomLabPage(p: Palette) {
    var selected by rememberSaveable { mutableIntStateOf(6) }
    val choices = listOf(1, 2, 6, 8, 11, 17, 26, 29, 79, 92)
    val current = elementRows.firstOrNull { it[2].toIntOrNull() == selected } ?: elementRows[5]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel(p) {
            Text("ATOM LABORATUVARI", color = p.accent, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 11.sp)
            Text("Atomu katman katman incele", color = p.text, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("Element seç, çekirdek ve elektron gösterimini incele. Model ölçekli değildir; elektronlar klasik gezegen yörüngelerinde hareket etmez.", color = p.muted, lineHeight = 20.sp)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            choices.forEach { z ->
                val el = elementRows[z - 1]
                FilterChip(selected = selected == z, onClick = { selected = z }, label = { Text(el[0]) })
            }
        }
        Panel(p) {
            Text("${current[1]} (${current[0]})", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text("Atom numarası ${current[2]} · Proton ${current[2]} · Nötr atom elektronu ${current[2]}", color = p.text)
            Atom3DView(p, current[0], selected, isotopeMassFor(selected))
            Text("Elektron dizilimi: ${elementElectronConfigNote(selected)}", color = p.muted, fontSize = 12.sp)
        }
        Panel(p) {
            Text("Atom nasıl tanımlanır?", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Çekirdekte pozitif yüklü protonlar ve yüksüz nötronlar bulunur. Negatif yüklü elektronlar atomun kuantum durumlarını oluşturur. Proton sayısı atom numarasıdır ve elementin kimliğini belirler. Nötron sayısı değişirse izotop, elektron sayısı değişirse iyon oluşur.", color = p.text, lineHeight = 22.sp)
        }
        Panel(p) {
            Text("Orbital fikri", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("s, p, d ve f orbitalleri elektronların bulunma olasılığını tanımlayan kuantum durumlarıdır. Bir orbital en fazla iki elektron barındırır ve bu elektronların spin kuantum sayıları zıttır. Bohr kabuk çizimleri başlangıç düzeyinde yararlı olabilir; ancak atomların gerçek elektron yapısı olasılık dağılımlarıyla açıklanır.", color = p.text, lineHeight = 22.sp)
        }
    }
}

@Composable
private fun MathematicsPage(p: Palette) {
    val topics = listOf(
        "Sayı kümeleri" to "Doğal sayılar, tam sayılar, rasyonel, irrasyonel ve gerçek sayılar farklı özelliklere göre tanımlanır. Her küme bir öncekinin bazı işlemlere göre kapanışını genişletir.",
        "Cebir ve denklemler" to "Denklem, iki ifadenin eşitliğini sağlayan bilinmeyen değerlerini arar. Eşitliğin iki tarafına aynı işlem uygulanırsa çözüm kümesi korunur.",
        "Fonksiyonlar" to "Fonksiyon, tanım kümesindeki her girdiye değer kümesinde tek bir çıktı eşleyen kuraldır. Grafik, tablo, cebirsel ifade ve sözel açıklama aynı ilişkiyi farklı biçimlerde gösterebilir.",
        "Geometri" to "Geometri şekillerin, açıların, uzunlukların, alanların ve hacimlerin ilişkilerini inceler. Öklid geometrisinde üçgen iç açıları toplamı 180 derecedir.",
        "Trigonometri" to "Sinüs, kosinüs ve tanjant açıları kenar oranlarıyla ilişkilendirir. Birim çember, bu oranların dar açıların ötesine nasıl genişlediğini açıklar.",
        "Olasılık ve istatistik" to "Olasılık belirsiz olayların matematiksel ölçüsüdür. İstatistik veri toplama, özetleme, değişkenliği inceleme ve çıkarım yapma yöntemlerini kapsar.",
        "Türev ve integral" to "Türev anlık değişim hızını, integral birikimi ve alan ilişkilerini inceler. Kalkülüs bu iki işlemin temel teoremiyle birbirine bağlanır."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text("MATEMATİK ATLASI", color = p.accent, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 11.sp)
            Text("Tanımlardan modellere", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Kavramları kısa tanım, temel ilişki ve örneklerle sırayla öğren.", color = p.muted)
        }
        topics.forEachIndexed { index, topic ->
            var expanded by rememberSaveable(topic.first) { mutableStateOf(index == 0) }
            Panel(p, Modifier.clickable { expanded = !expanded }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${index + 1}.", color = p.accent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Text(topic.first, color = p.text, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.muted)
                }
                if (expanded) Text(topic.second, color = p.muted, lineHeight = 21.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
private fun ChemistryPage(p: Palette) {
    val topics = listOf(
        "Atomun yapısı" to "Atom; proton ve nötronlardan oluşan çekirdek ile elektron bulutundan meydana gelir. Proton sayısı elementin kimliğini belirler. Nötron sayısı izotopları, elektron dizilimi ise kimyasal davranışın önemli bölümünü belirler.",
        "Periyodik eğilimler" to "Aynı gruptaki elementlerin değerlik elektron yapıları benzerdir. Atom yarıçapı, iyonlaşma enerjisi ve elektronegatiflik periyodik tabloda düzenli eğilimler gösterir; bu eğilimler elementlerin tepkime davranışını anlamaya yardımcı olur.",
        "Kimyasal bağlar" to "İyonik bağ zıt yüklü iyonların elektrostatik çekimidir. Kovalent bağda atomlar elektron çiftlerini paylaşır. Metalik bağda değerlik elektronları metal yapısı boyunca delokalizedir.",
        "Tepkimeler ve denkleştirme" to "Kimyasal tepkimelerde atomlar yeniden düzenlenir; kapalı sistemlerde toplam atom sayısı ve kütle korunur. Denklem denkleştirme, her elementin atom sayısını iki tarafta eşitler.",
        "Asit, baz ve pH" to "pH sulu çözeltilerin asitlik-bazlık durumunu ifade eden logaritmik bir ölçüdür. 25 °C'de pH 7 nötr kabul edilir; daha düşük değerler asidik, daha yüksek değerler bazik ortamı gösterir.",
        "Çözeltiler ve derişim" to "Çözelti, çözücü içinde dağılmış çözünen maddeden oluşur. Derişim molarite veya yüzde gibi birimlerle ifade edilebilir. Sıcaklık ve maddenin türü çözünürlüğü etkiler.",
        "Organik kimya" to "Karbon bileşiklerinin yapısını, özelliklerini ve tepkimelerini inceler. Hidrokarbonlar, alkoller, karboksilik asitler, esterler ve polimerler önemli bileşik sınıflarıdır.",
        "Kimya ve enerji" to "Ekzotermik tepkimeler çevreye enerji verir; endotermik tepkimeler çevreden enerji alır. Tepkime hızı sıcaklık, derişim, yüzey alanı ve katalizör gibi etkenlerden etkilenebilir.",
        "Laboratuvar güvenliği" to "Etiketler ve güvenlik bilgi formları okunur; koruyucu gözlük ve uygun ekipman kullanılır. Bilinmeyen maddeler karıştırılmaz, maddeler tadılmaz veya doğrudan koklanmaz. Deneyler yalnızca yetkili gözetiminde yapılır.",
        "Kimyasal denge" to "Tersinir tepkimelerde ileri ve geri tepkime hızları eşitlendiğinde dinamik denge oluşur. Derişim, basınç ve sıcaklık değişimleri denge konumunu etkileyebilir.",
        "Elektrokimya" to "Redoks tepkimelerinde elektron aktarımı gerçekleşir. Galvanik hücreler kendiliğinden gerçekleşen tepkimelerden elektrik üretirken elektroliz dış enerjiyle kimyasal dönüşüm sağlar.",
        "Polimerler" to "Polimerler tekrarlayan monomer birimlerinden oluşan büyük moleküllerdir. Doğal örnekler arasında protein ve selüloz; sentetik örnekler arasında polietilen ve naylon bulunur."
    )
    var expanded by rememberSaveable { mutableStateOf("Atomun yapısı") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Kimya", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp); Text("Maddenin yapısını, dönüşümünü ve enerjiyle ilişkisini incele.", color = p.muted) }
        Panel(p) {
            Text("Su molekülü · 3B model", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Model otomatik döner; dokunup sürükleyerek açısını değiştirebilirsin.", color = p.muted, fontSize = 12.sp)
            Molecule3DView()
        }
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == title) "" else title }, verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded == title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == title) { Spacer(Modifier.height(7.dp)); Text(body, color = p.text, lineHeight = 21.sp) }
            }
        }
    }
}

@Composable
private fun MicrobiologyPage(p: Palette) {
    val topics = listOf(
        "Mikroorganizmalara giriş" to "Mikrobiyoloji, mikroorganizmaları ve mikroskobik biyolojik yapıları inceler. Bakteriler ve arkeler prokaryot; maya ve protozoalar ökaryot hücre yapısına sahiptir.",
        "Bakteriler" to "Bakteriler tek hücreli prokaryotlardır. Şekilleri, metabolizmaları ve yaşadıkları ortamlar çeşitlidir. Bazıları insan sağlığı için yararlı roller üstlenirken bazıları hastalıklara neden olabilir.",
        "Virüsler" to "Virüsler hücresel yapıda değildir; genetik materyallerini protein kılıf içinde taşırlar. Çoğalmak için konak hücrelerin mekanizmalarını kullanırlar. Antibiyotikler virüslere karşı etkili değildir.",
        "Mantarlar ve mayalar" to "Mantarlar ökaryot canlılardır. Mayalar tek hücreli, küfler çoğunlukla ipliksi yapılara sahip olabilir. Ayrıştırma, gıda üretimi ve ekosistem döngülerinde önemli görevleri vardır.",
        "Protozoalar ve algler" to "Protozoalar çoğunlukla tek hücreli ökaryotlardır. Algler fotosentez yapabilen çeşitli organizmaları kapsar; su ekosistemlerinde birincil üretime katkı sağlar.",
        "Mikrobiyota" to "İnsan vücudunda ve üzerinde yaşayan mikroorganizma toplulukları mikrobiyotayı oluşturur. Bağırsak mikrobiyotası sindirim, metabolizma ve bağışıklıkla ilişkili işlevlerde rol oynar.",
        "Mikroskopi" to "Işık mikroskopları hücre ve mikroorganizma yapılarını incelemekte kullanılır. Büyütme kadar çözünürlük, örnek hazırlama ve uygun boyama yöntemi de gözlemin kalitesini belirler.",
        "Hücre zarı" to "Fosfolipit çift tabakası seçici geçirgen bir sınır oluşturur. Zar proteinleri madde taşınması, hücre iletişimi ve tanımada görev alır.",
        "Ribozomlar" to "Ribozomlar mRNA bilgisini kullanarak amino asitleri polipeptit zincirlerine bağlar. Hem prokaryot hem ökaryot hücrelerde bulunurlar.",
        "Mitokondri" to "Mitokondriler oksijenli solunumun birçok basamağında ATP üretimine katkı sağlar. Kendi DNA'larına ve çift zarlı yapıya sahiptirler.",
        "Mikrobiyal ekoloji" to "Mikroorganizmalar karbon, azot ve kükürt döngülerinde önemli rol oynar. Toprak ve okyanus ekosistemlerinin işleyişine katkı verir.",
        "Antibiyotik direnci" to "Direnç, bakterilerin bir antibiyotiğe rağmen çoğalabilmesini sağlayan kalıtsal özelliklerle ilişkilidir. Antibiyotiklerin gereksiz veya yanlış kullanımı direnç seçilimini artırabilir."
    )
    var expanded by rememberSaveable { mutableStateOf("Mikroorganizmalara giriş") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Mikrobiyoloji", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp); Text("Mikroskobik dünyanın çeşitliliğini keşfet.", color = p.muted) }
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == title) "" else title }, verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded == title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == title) { Spacer(Modifier.height(7.dp)); Text(body, color = p.text, lineHeight = 21.sp) }
            }
        }
        Panel(p) { Text("Bilimsel not", color = p.accent, fontWeight = FontWeight.Bold); Text("Virüslerin canlı olarak sınıflandırılması tartışmalıdır; hücresel canlılarla aynı grupta değerlendirilmezler.", color = p.text) }
    }
}

@Composable
private fun VisualAtlasPage(p: Palette) {
    var selected by rememberSaveable { mutableStateOf("İnsan anatomisi") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text("3B Bilim Laboratuvarı", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("Harici görsel arama motoru kaldırıldı. Bunun yerine uygulama içindeki etkileşimli modelleri incele. Modelleri sürükleyerek döndürebilir, yakınlaştırabilir ve katmanlarını kontrol edebilirsin.", color = p.muted, lineHeight = 20.sp)
        }
        listOf("İnsan anatomisi", "Su molekülü", "Hücre ve organeller", "Dolaşım sistemi", "Solunum sistemi").forEach { item ->
            FilterChip(selected = selected == item, onClick = { selected = item }, label = { Text(item) })
        }
        when (selected) {
            "İnsan anatomisi" -> Panel(p) { Text("İnsan vücudu · katmanlı model", color = p.accent, fontWeight = FontWeight.Bold); Anatomy3DView() }
            "Su molekülü" -> Panel(p) { Text("H₂O · moleküler geometri", color = p.accent, fontWeight = FontWeight.Bold); Molecule3DView() }
            else -> Panel(p) {
                Text(selected, color = p.accent, fontWeight = FontWeight.Bold)
                Text("Bu başlık için ayrıntılı 3B model geliştirme aşamasındadır. Şimdilik anatomi modelindeki organ katmanlarını kullanarak genel konumları inceleyebilirsin.", color = p.text, lineHeight = 21.sp)
                Anatomy3DView()
            }
        }
        Panel(p) {
            Text("Model doğruluğu hakkında", color = p.accent, fontWeight = FontWeight.Bold)
            Text("İnsan anatomisi modeli eğitim amaçlı şematik bir görselleştirmedir; organların gerçek hacimlerini, damar dallanmalarını ve tüm anatomik varyasyonları temsil etmez. Kesit aracı görsel kırpma uygular, kapalı cerrahi kesit yüzeyi üretmez. Molekül modelinde H–O–H açısı 104,5° olarak tanımlanır; atom boyutları görsel ölçekte normalize edilmiştir.", color = p.text, lineHeight = 20.sp)
        }
    }
}

@Composable
private fun Molecule3DView() {
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>
    *{box-sizing:border-box}body{margin:0;background:#081321;color:#eaf4ff;font:12px Arial}.bar{display:flex;gap:7px;flex-wrap:wrap;padding:8px}.bar button{background:#19334e;color:#dff5ff;border:1px solid #47718d;border-radius:8px;padding:7px 10px}.stage{height:230px;position:relative;overflow:hidden}canvas{width:100%;height:100%;display:block}.note{padding:2px 10px 8px;color:#a9c3dc;line-height:1.4}
    </style></head><body><div class='bar'><button id='spin'>Otomatik döndür: Açık</button><button id='reset'>Görünümü sıfırla</button><button id='bonds'>Bağları göster</button></div><div class='stage' id='stage'><canvas id='c'></canvas></div><div class='note'>H₂O · H–O–H bağ açısı: 104,5°. Şematik küresel model; atom yarıçapları ve bağ uzunlukları görsel ölçekte normalize edilmiştir. Sürükle: döndür · iki parmak/tekerlek: yakınlaş.</div>
    <script src='https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js'></script><script>
    const stage=document.getElementById('stage'),canvas=document.getElementById('c');const scene=new THREE.Scene();scene.background=new THREE.Color(0x081321);const camera=new THREE.PerspectiveCamera(42,1,.1,100);camera.position.set(0,1.2,6.5);const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(stage.clientWidth,stage.clientHeight,false);renderer.outputColorSpace=THREE.SRGBColorSpace;
    scene.add(new THREE.HemisphereLight(0xb9ddff,0x182338,2));const key=new THREE.DirectionalLight(0xffffff,2.4);key.position.set(3,4,5);scene.add(key);const group=new THREE.Group();scene.add(group);
    function atom(r,color,x,y,z){const m=new THREE.Mesh(new THREE.SphereGeometry(r,40,28),new THREE.MeshStandardMaterial({color,roughness:.28,metalness:.08}));m.position.set(x,y,z);group.add(m);return m}
    function bond(a,b,r=.075){const d=new THREE.Vector3().subVectors(b,a),mesh=new THREE.Mesh(new THREE.CylinderGeometry(r,r,d.length(),20),new THREE.MeshStandardMaterial({color:0xa9c9e7,metalness:.35,roughness:.3}));mesh.position.copy(a).add(b).multiplyScalar(.5);mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize());group.add(mesh);return mesh}
    const angle=104.5*Math.PI/180,oh=1.35,half=angle/2;const O=new THREE.Vector3(0,0,0),H1=new THREE.Vector3(-Math.sin(half)*oh,Math.cos(half)*oh,0),H2=new THREE.Vector3(Math.sin(half)*oh,Math.cos(half)*oh,0);
    bond(O,H1);bond(O,H2);atom(.62,0xe34f65,0,0,0);atom(.34,0xeaf4ff,H1.x,H1.y,H1.z);atom(.34,0xeaf4ff,H2.x,H2.y,H2.z);
    let auto=true,drag=false,px=0,py=0;stage.onpointerdown=e=>{drag=true;px=e.clientX;py=e.clientY;stage.setPointerCapture(e.pointerId)};stage.onpointermove=e=>{if(!drag)return;group.rotation.y+=(e.clientX-px)*.008;group.rotation.x+=(e.clientY-py)*.008;px=e.clientX;py=e.clientY};stage.onpointerup=()=>drag=false;stage.onpointercancel=()=>drag=false;stage.onwheel=e=>{camera.position.z=Math.max(3,Math.min(10,camera.position.z+e.deltaY*.005))};document.getElementById('spin').onclick=e=>{auto=!auto;e.target.textContent='Otomatik döndür: '+(auto?'Açık':'Kapalı')};document.getElementById('reset').onclick=()=>{group.rotation.set(0,0,0);camera.position.set(0,1.2,6.5)};document.getElementById('bonds').onclick=e=>{group.children.filter(x=>x.geometry.type==='CylinderGeometry').forEach(x=>x.visible=!x.visible);e.target.textContent=e.target.textContent==='Bağları göster'?'Bağları gizle':'Bağları göster'};
    function resize(){const w=stage.clientWidth,h=stage.clientHeight;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false)}new ResizeObserver(resize).observe(stage);function frame(){requestAnimationFrame(frame);if(auto&&!drag)group.rotation.y+=.003;renderer.render(scene,camera)}frame();
    </script></body></html>"""
    AndroidView(modifier = Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(12.dp)), factory = { ctx -> WebView(ctx).apply { settings.javaScriptEnabled = true; settings.domStorageEnabled = true; setBackgroundColor(android.graphics.Color.TRANSPARENT); loadDataWithBaseURL("https://spectrum.local/", html, "text/html", "UTF-8", null) } })
}

@Composable
private fun Anatomy3DView() {
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>
    *{box-sizing:border-box}body{margin:0;background:#081321;color:#eaf4ff;font:12px Arial,sans-serif}.toolbar{display:flex;gap:6px;flex-wrap:wrap;padding:8px;background:#0d1d30}.toolbar button{background:#19334e;color:#e4f4ff;border:1px solid #47718d;border-radius:9px;padding:8px 10px;font-size:11px}.toolbar button.active{background:#75c8ff;color:#071321;border-color:#75c8ff}.stage{height:410px;position:relative;touch-action:none}canvas{width:100%;height:100%;display:block}.hint{padding:7px 10px 10px;color:#a9c3dc;line-height:1.45}.readout{padding:8px 10px;background:#10243a;color:#eaf4ff;min-height:34px}.legend{display:flex;gap:12px;flex-wrap:wrap;padding:4px 10px;color:#b3c3d5}.dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:4px}
    </style></head><body>
    <div class='toolbar'>
      <button class='active' data-layer='bones'>Kemikler</button><button class='active' data-layer='muscles'>Kaslar</button><button class='active' data-layer='vessels'>Damarlar</button><button class='active' data-layer='organs'>Organlar</button><button class='active' data-layer='nerves'>Sinirler</button><button class='active' data-layer='skin'>Dış katman</button>
      <button id='front'>Ön görünüm</button><button id='side'>Yan görünüm</button><button id='reset'>Sıfırla</button><button id='zoomIn'>Yaklaştır +</button><button id='zoomOut'>Uzaklaştır −</button>
    </div>
    <div class='stage' id='stage'><canvas id='c'></canvas></div><div class='readout' id='readout'>Bir yapıya dokun: adı ve kısa açıklaması burada görünür.</div>
    <div class='legend'><span><i class='dot' style='background:#ef625f'></i>Atardamar</span><span><i class='dot' style='background:#579be8'></i>Toplardamar</span><span><i class='dot' style='background:#e9d7ae'></i>Kemik</span><span><i class='dot' style='background:#c96f78'></i>Kas</span></div>
    <div class='hint'>Sürükle: döndür · iki parmak: yakınlaştır/uzaklaştır · düğmeler: anatomik katmanları aç/kapat. Model eğitim amaçlı şematik 3B görselleştirmedir; klinik anatomi verisi veya tanı aracı değildir.</div>
    <script src='https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js'></script><script>
    (()=>{
      const stage=document.getElementById('stage'),canvas=document.getElementById('c'),readout=document.getElementById('readout');
      const scene=new THREE.Scene();scene.background=new THREE.Color(0x081321);
      const camera=new THREE.PerspectiveCamera(36,1,.1,100);camera.position.set(0,.1,9.8);
      const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'low-power'});
      renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5));renderer.setSize(stage.clientWidth,stage.clientHeight,false);
      renderer.outputColorSpace=THREE.SRGBColorSpace;
      scene.add(new THREE.HemisphereLight(0xd9efff,0x1b2536,2.0));
      const key=new THREE.DirectionalLight(0xffffff,2.1);key.position.set(4,6,7);scene.add(key);
      const fill=new THREE.DirectionalLight(0x7dbbff,.7);fill.position.set(-5,1,-4);scene.add(fill);
      const root=new THREE.Group();scene.add(root);
      const layers={bones:new THREE.Group(),muscles:new THREE.Group(),vessels:new THREE.Group(),organs:new THREE.Group(),nerves:new THREE.Group(),skin:new THREE.Group()};Object.values(layers).forEach(g=>root.add(g));
      const pickables=[];
      const materials={bone:new THREE.MeshStandardMaterial({color:0xe9d7ae,roughness:.72}),muscle:new THREE.MeshStandardMaterial({color:0xb94e62,roughness:.66}),artery:new THREE.MeshStandardMaterial({color:0xef625f,roughness:.48}),vein:new THREE.MeshStandardMaterial({color:0x579be8,roughness:.48}),organ:new THREE.MeshStandardMaterial({color:0xc77a56,roughness:.62}),nerve:new THREE.MeshStandardMaterial({color:0xe8c85c,roughness:.58}),skin:new THREE.MeshStandardMaterial({color:0xc58f78,transparent:true,opacity:.16,roughness:.7,depthWrite:false})};
      function ell(group,name,pos,scale,mat,info){const m=new THREE.Mesh(new THREE.SphereGeometry(1,24,18),mat);m.name=name;m.position.set(...pos);m.scale.set(...scale);m.userData.info=info||name;group.add(m);pickables.push(m);return m}
      function bone(name,a,b,r1,r2){const va=new THREE.Vector3(...a),vb=new THREE.Vector3(...b),d=vb.clone().sub(va);const mesh=new THREE.Mesh(new THREE.CylinderGeometry(r2,r1,d.length(),12),materials.bone);mesh.name=name;mesh.position.copy(va).add(vb).multiplyScalar(.5);mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.clone().normalize());mesh.userData.info=name+' · destek ve hareket sisteminin parçası';layers.bones.add(mesh);pickables.push(mesh);return mesh}
      function curve(group,name,points,r,material,info){const path=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)));const mesh=new THREE.Mesh(new THREE.TubeGeometry(path,Math.max(24,points.length*8),r,7,false),material);mesh.name=name;mesh.userData.info=info||name;group.add(mesh);pickables.push(mesh);return mesh}
      // Skeletal framework: skull, vertebral column, rib cage, pelvis and long bones.
      ell(layers.bones,'Kafatası',[0,2.75,0],[.37,.44,.31],materials.bone,'Kafatası · beyni çevreleyen kemik yapı');
      ell(layers.bones,'Alt çene',[0,2.48,.08],[.25,.10,.24],materials.bone,'Mandibula · alt çene kemiği');
      for(let i=0;i<24;i++){const y=2.2-i*.105;ell(layers.bones,'Omur '+(i+1),[0,y,-.01],[.105,.055,.12],materials.bone,'Omurga · omurilik kanalını çevreleyen omurlar');}
      for(let i=0;i<12;i++){const y=1.95-i*.105;const w=.36+Math.sin(i/12*Math.PI)*.18;for(const side of [-1,1]){curve(layers.bones,'Kaburga '+(i+1),[[0,y,0],[side*w*.55,y+.08,.02],[side*w,y-.02,.04],[side*w*.94,y-.12,.06]],.035,materials.bone,'Kaburgalar · göğüs organlarını korur');}}
      bone('Göğüs kemiği',[0,1.95,.14],[0,.92,.16],.09,.07);
      bone('Köprücük kemiği',[-.42,1.95,.03],[.42,1.95,.03],.055,.045);
      ell(layers.bones,'Leğen kemiği',[0,-.05,0],[.58,.28,.22],materials.bone,'Pelvis · gövde ile alt ekstremiteler arasında yük aktarımı');
      bone('Sağ üst kol kemiği',[.47,1.78,0],[.72,.72,0],.09,.07);bone('Sol üst kol kemiği',[-.47,1.78,0],[-.72,.72,0],.09,.07);
      bone('Sağ radius',[.72,.72,.02],[.76,-.12,.02],.045,.035);bone('Sağ ulna',[.63,.72,-.04],[.66,-.12,-.04],.05,.04);
      bone('Sol radius',[-.72,.72,.02],[-.76,-.12,.02],.045,.035);bone('Sol ulna',[-.63,.72,-.04],[-.66,-.12,-.04],.05,.04);
      bone('Sağ femur',[.25,-.22,0],[.32,-1.18,0],.12,.085);bone('Sol femur',[-.25,-.22,0],[-.32,-1.18,0],.12,.085);
      bone('Sağ tibia',[.32,-1.18,0],[.34,-2.12,.02],.07,.05);bone('Sol tibia',[-.32,-1.18,0],[-.34,-2.12,.02],.07,.05);
      bone('Sağ fibula',[.43,-1.2,-.04],[.42,-2.1,-.04],.035,.025);bone('Sol fibula',[-.43,-1.2,-.04],[-.42,-2.1,-.04],.035,.025);
      // Major muscle groups.
      ell(layers.muscles,'Sağ deltoid',[.48,1.78,.04],[.23,.27,.22],materials.muscle,'Deltoid · omuz ekleminde kol hareketlerine yardım eder');ell(layers.muscles,'Sol deltoid',[-.48,1.78,.04],[.23,.27,.22],materials.muscle,'Deltoid · omuz ekleminde kol hareketlerine yardım eder');
      ell(layers.muscles,'Sağ büyük göğüs kası',[.22,1.55,.19],[.25,.25,.12],materials.muscle,'Pectoralis major · kolun gövdeye yaklaşmasına yardım eder');ell(layers.muscles,'Sol büyük göğüs kası',[-.22,1.55,.19],[.25,.25,.12],materials.muscle,'Pectoralis major · kolun gövdeye yaklaşmasına yardım eder');
      ell(layers.muscles,'Karın kasları',[0,.83,.18],[.26,.48,.11],materials.muscle,'Karın kasları · gövde stabilizasyonu ve gövde hareketleri');
      ell(layers.muscles,'Sağ biseps',[.61,1.22,.08],[.13,.38,.14],materials.muscle,'Biseps brachii · dirsek fleksiyonuna katkı verir');ell(layers.muscles,'Sol biseps',[-.61,1.22,.08],[.13,.38,.14],materials.muscle,'Biseps brachii · dirsek fleksiyonuna katkı verir');
      ell(layers.muscles,'Sağ triseps',[.72,1.22,-.09],[.12,.38,.12],materials.muscle,'Triseps brachii · dirsek ekstansiyonuna katkı verir');ell(layers.muscles,'Sol triseps',[-.72,1.22,-.09],[.12,.38,.12],materials.muscle,'Triseps brachii · dirsek ekstansiyonuna katkı verir');
      ell(layers.muscles,'Sağ kuadriseps',[.29,-.72,.1],[.19,.49,.17],materials.muscle,'Kuadriseps femoris · diz ekstansiyonunda temel kas grubu');ell(layers.muscles,'Sol kuadriseps',[-.29,-.72,.1],[.19,.49,.17],materials.muscle,'Kuadriseps femoris · diz ekstansiyonunda temel kas grubu');
      ell(layers.muscles,'Sağ baldır',[.36,-1.65,-.02],[.12,.34,.13],materials.muscle,'Gastroknemius ve soleus · ayak bileği plantar fleksiyonu');ell(layers.muscles,'Sol baldır',[-.36,-1.65,-.02],[.12,.34,.13],materials.muscle,'Gastroknemius ve soleus · ayak bileği plantar fleksiyonu');
      // Internal organs, placed as separate selectable meshes.
      ell(layers.organs,'Beyin',[0,2.79,.06],[.27,.27,.25],new THREE.MeshStandardMaterial({color:0xd19ac9,roughness:.65}),'Beyin · merkezi sinir sisteminin ana organı');
      ell(layers.organs,'Sağ akciğer',[.22,1.43,.04],[.22,.42,.16],new THREE.MeshStandardMaterial({color:0x6eb9c8,roughness:.6}),'Sağ akciğer · gaz alışverişinin gerçekleştiği alveolleri içerir');ell(layers.organs,'Sol akciğer',[-.22,1.43,.04],[.22,.42,.16],new THREE.MeshStandardMaterial({color:0x6eb9c8,roughness:.6}),'Sol akciğer · gaz alışverişinin gerçekleştiği alveolleri içerir');
      ell(layers.organs,'Kalp',[0,1.35,.23],[.17,.22,.17],new THREE.MeshStandardMaterial({color:0xd94d57,roughness:.5}),'Kalp · kanı akciğer ve sistemik dolaşıma pompalar');
      ell(layers.organs,'Karaciğer',[.19,.77,.08],[.32,.16,.18],new THREE.MeshStandardMaterial({color:0x9c5b42,roughness:.65}),'Karaciğer · metabolizma, safra üretimi ve detoksifikasyon süreçleri');
      ell(layers.organs,'Mide',[-.19,.65,.13],[.16,.23,.13],new THREE.MeshStandardMaterial({color:0xd88c62,roughness:.65}),'Mide · besini karıştırır ve kimyasal sindirimi başlatır');
      ell(layers.organs,'Sağ böbrek',[.23,.25,-.02],[.12,.2,.1],new THREE.MeshStandardMaterial({color:0x9d5d70,roughness:.6}),'Böbrek · kanı süzer ve idrar oluşumuna katkıda bulunur');ell(layers.organs,'Sol böbrek',[-.23,.25,-.02],[.12,.2,.1],new THREE.MeshStandardMaterial({color:0x9d5d70,roughness:.6}),'Böbrek · kanı süzer ve idrar oluşumuna katkıda bulunur');
      ell(layers.organs,'İnce bağırsak',[0,.05,.15],[.28,.19,.1],new THREE.MeshStandardMaterial({color:0xd5a36e,roughness:.7}),'İnce bağırsak · besinlerin büyük bölümünün emildiği bölge');
      // Major arterial and venous pathways; educationally simplified routes.
      const red=materials.artery,blue=materials.vein;
      curve(layers.vessels,'Aort',[ [0,1.22,.28],[0,1.05,.3],[0,.72,.3],[0,.35,.22],[0,.05,.14] ],.045,red,'Aort · sol karıncıktan çıkan ana sistemik atardamar');
      curve(layers.vessels,'Üst ana toplardamar',[[.08,1.85,-.02],[.08,1.55,-.03],[.08,1.28,-.02],[0,1.12,.05]],.04,blue,'Üst ana toplardamar · baş ve üst gövdeden kanı sağ kulakçığa taşır');
      curve(layers.vessels,'Alt ana toplardamar',[[0,.15,-.03],[0,.5,-.02],[0,.9,-.02],[0,1.18,-.02]],.04,blue,'Alt ana toplardamar · alt vücuttan kanı kalbe taşır');
      for(const side of [-1,1]){
        curve(layers.vessels,'Şah damarı',[[side*.06,1.4,.05],[side*.08,1.85,.04],[side*.1,2.3,.03],[side*.08,2.58,.02]],.018,red,'Karotis atardamarı · baş ve beyne kan taşır');
        curve(layers.vessels,'Boyun toplardamarı',[[side*.13,2.45,-.03],[side*.15,2.0,-.04],[side*.12,1.55,-.03],[side*.07,1.28,-.02]],.02,blue,'Juguler toplardamar · baş bölgesinden venöz kanı taşır');
        curve(layers.vessels,'Köprücük altı atardamarı',[[0,1.92,.03],[side*.32,1.9,.02],[side*.55,1.75,.02],[side*.65,1.48,.02]],.018,red,'Subklavyen atardamar · üst ekstremite dolaşımına katılır');
        curve(layers.vessels,'Kol atardamarı',[[side*.65,1.48,.02],[side*.68,1.1,.02],[side*.75,.65,.02],[side*.78,.2,.02]],.014,red,'Brakiyal atardamar · kola kan taşır');
        curve(layers.vessels,'Kol toplardamarı',[[side*.78,.2,-.04],[side*.75,.65,-.04],[side*.68,1.1,-.04],[side*.65,1.48,-.04]],.016,blue,'Üst ekstremite toplardamarı · kol kanını kalbe geri taşır');
        curve(layers.vessels,'İliak atardamar',[[0,.05,.12],[side*.22,-.12,.12],[side*.3,-.3,.12],[side*.3,-.52,.12]],.025,red,'İliak atardamar · pelvis ve alt ekstremiteye kan taşır');
        curve(layers.vessels,'Femoral atardamar',[[side*.3,-.45,.12],[side*.31,-.8,.12],[side*.32,-1.15,.12],[side*.34,-1.48,.12]],.02,red,'Femoral atardamar · uyluğun ana atardamarıdır');
        curve(layers.vessels,'Femoral toplardamar',[[side*.35,-1.48,-.06],[side*.33,-1.1,-.06],[side*.31,-.75,-.06],[side*.29,-.42,-.06]],.022,blue,'Femoral toplardamar · alt ekstremiteden kanı geri taşır');
      }
      // Main nerves and spinal cord.
      curve(layers.nerves,'Omurilik',[[0,2.35,-.12],[0,1.85,-.13],[0,1.3,-.13],[0,.75,-.13],[0,.15,-.12]],.035,materials.nerve,'Omurilik · beyin ile çevresel sinir sistemi arasında iletişim yolu');
      for(const side of [-1,1]){
        curve(layers.nerves,'Brakiyal pleksus',[[0,1.8,-.12],[side*.25,1.72,-.12],[side*.48,1.5,-.12],[side*.68,1.15,-.12]],.018,materials.nerve,'Brakiyal pleksus · üst ekstremitenin motor ve duyu sinirleri');
        curve(layers.nerves,'Siyatik sinir',[[side*.08,.05,-.12],[side*.18,-.35,-.12],[side*.28,-.8,-.12],[side*.34,-1.25,-.12],[side*.37,-1.7,-.12]],.022,materials.nerve,'Siyatik sinir · alt ekstremitenin büyük periferik siniri');
      }
      // Translucent outer silhouette, deliberately shown as a separate layer.
      ell(layers.skin,'Baş dış katmanı',[0,2.76,-.04],[.42,.49,.35],materials.skin,'Başın dış anatomik sınırı');
      ell(layers.skin,'Gövde dış katmanı',[0,1.0,-.05],[.69,1.05,.34],materials.skin,'Gövde dış anatomik sınırı');
      ell(layers.skin,'Pelvis dış katmanı',[0,-.12,-.04],[.58,.38,.31],materials.skin,'Pelvis çevresindeki dış anatomik sınır');
      bone('Sağ el bileği',[.76,-.12,0],[.77,-.28,0],.04,.035);bone('Sol el bileği',[-.76,-.12,0],[-.77,-.28,0],.04,.035);
      const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();let down=false,px=0,py=0,moved=0,pinch=0,raf=0,dirty=true;
      function resize(){const w=Math.max(1,stage.clientWidth),h=Math.max(1,stage.clientHeight);camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false);dirty=true}
      
      stage.addEventListener('pointerdown',e=>{down=true;px=e.clientX;py=e.clientY;moved=0;stage.setPointerCapture(e.pointerId)});
      stage.addEventListener('pointermove',e=>{if(!down||pointers.size>1)return;const dx=e.clientX-px,dy=e.clientY-py;moved+=Math.abs(dx)+Math.abs(dy);root.rotation.y+=dx*.008;root.rotation.x=Math.max(-.35,Math.min(.35,root.rotation.x+dy*.004));px=e.clientX;py=e.clientY;dirty=true});
      stage.addEventListener('pointerup',e=>{down=false;if(pointers.size>1)return;if(moved<8){const r=stage.getBoundingClientRect();pointer.x=((e.clientX-r.left)/r.width)*2-1;pointer.y=-((e.clientY-r.top)/r.height)*2+1;raycaster.setFromCamera(pointer,camera);const hits=raycaster.intersectObjects(pickables,false);if(hits.length){const o=hits[0].object;readout.textContent=o.userData.info||o.name;}else readout.textContent='Bir anatomik yapıya dokun: adı ve işlevi burada görünür.'}});
      stage.addEventListener('pointercancel',()=>down=false);
      stage.addEventListener('wheel',e=>{e.preventDefault();camera.position.z=Math.max(5.2,Math.min(15,camera.position.z+e.deltaY*.008));dirty=true},{passive:false});
      let pointers=new Map();stage.addEventListener('pointerdown',e=>pointers.set(e.pointerId,[e.clientX,e.clientY]));stage.addEventListener('pointermove',e=>{if(!pointers.has(e.pointerId))return;const prev=pointers.get(e.pointerId);pointers.set(e.pointerId,[e.clientX,e.clientY]);if(pointers.size===2){const vals=[...pointers.values()];const d=Math.hypot(vals[0][0]-vals[1][0],vals[0][1]-vals[1][1]);if(pinch){camera.position.z=Math.max(5.2,Math.min(15,camera.position.z+(pinch-d)*.018));dirty=true}pinch=d}});const clearPointer=e=>{pointers.delete(e.pointerId);if(pointers.size<2)pinch=0};stage.addEventListener('pointerup',clearPointer);stage.addEventListener('pointercancel',clearPointer);
      document.querySelectorAll('[data-layer]').forEach(btn=>btn.addEventListener('click',()=>{const g=layers[btn.dataset.layer];g.visible=!g.visible;btn.classList.toggle('active',g.visible);dirty=true}));
      document.getElementById('front').onclick=()=>{root.rotation.set(0,0,0);camera.position.set(0,.1,9.8);dirty=true};document.getElementById('side').onclick=()=>{root.rotation.set(0,Math.PI/2,0);camera.position.set(0,.1,9.8);dirty=true};document.getElementById('reset').onclick=()=>{root.rotation.set(0,0,0);camera.position.set(0,.1,9.8);dirty=true};document.getElementById('zoomIn').onclick=()=>{camera.position.z=Math.max(5.2,camera.position.z-.8);dirty=true};document.getElementById('zoomOut').onclick=()=>{camera.position.z=Math.min(15,camera.position.z+.8);dirty=true};
      function render(){raf=0;if(dirty){renderer.render(scene,camera);dirty=false}}
      function requestRender(){if(!raf)raf=requestAnimationFrame(render)}
      const observer=new MutationObserver(requestRender);observer.observe(root,{attributes:true,subtree:true,attributeFilter:['visible']});
      const watch=new ResizeObserver(()=>{resize();requestRender()});watch.observe(stage);requestRender();
      document.addEventListener('visibilitychange',()=>{if(!document.hidden)requestRender()});
      window.addEventListener('pagehide',()=>{watch.disconnect();observer.disconnect();renderer.dispose();cancelAnimationFrame(raf)});
    })();
    </script></body></html>"""
    AndroidView(modifier = Modifier.fillMaxWidth().height(560.dp).clip(RoundedCornerShape(14.dp)), factory = { ctx -> WebView(ctx).apply { settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.allowContentAccess = false; settings.loadsImagesAutomatically = false; setBackgroundColor(android.graphics.Color.TRANSPARENT); webChromeClient = WebChromeClient(); webViewClient = WebViewClient(); loadDataWithBaseURL("https://spectrum.local/", html, "text/html", "UTF-8", null) } })
}

private fun isotopeMassFor(z: Int): Int? = mapOf(1 to 1, 2 to 4, 6 to 12, 8 to 16, 11 to 23, 17 to 35, 26 to 56, 29 to 64, 79 to 197, 92 to 238)[z]

@Composable
private fun Atom3DView(p: Palette, symbol: String, atomicNumber: Int, isotopeMass: Int? = null) {
    val safeSymbol = symbol.replace("'", "")
    val isotopeLiteral = isotopeMass?.toString() ?: "null"
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>body{margin:0;background:#081321;color:#eaf4ff;font:12px Arial}.stage{height:250px;touch-action:none}canvas{width:100%;height:100%;display:block}.bar{display:flex;gap:8px;padding:6px}.bar button{background:#19334e;color:#eaf4ff;border:1px solid #47718d;border-radius:8px;padding:7px 10px}</style></head><body><div class='bar'><button id='reset'>Görünümü sıfırla</button><span id='label'></span></div><div class='stage' id='stage'><canvas id='c'></canvas></div><script src='https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js'></script><script>
    (()=>{
      const z=$atomicNumber,symbol='$safeSymbol',isotopeMass=$isotopeLiteral,stage=document.getElementById('stage'),canvas=document.getElementById('c');
      document.getElementById('label').textContent=symbol+' · Z = '+z;
      const scene=new THREE.Scene();scene.background=new THREE.Color(0x081321);
      const camera=new THREE.PerspectiveCamera(42,1,.1,100);camera.position.set(0,1,7.2);
      const renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'low-power'});renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.5));renderer.setSize(stage.clientWidth,stage.clientHeight,false);
      scene.add(new THREE.HemisphereLight(0xddeeff,0x17243a,2));const light=new THREE.DirectionalLight(0xffffff,2);light.position.set(3,4,5);scene.add(light);
      const root=new THREE.Group();scene.add(root);
      const protonMat=new THREE.MeshStandardMaterial({color:0xef665f,roughness:.45}),neutronMat=new THREE.MeshStandardMaterial({color:0xb8c6d7,roughness:.55}),electronMat=new THREE.MeshStandardMaterial({color:0x68d6ff,emissive:0x14506b,roughness:.3});
      if(isotopeMass!==null){
        const neutronCount=Math.max(0,isotopeMass-z),count=Math.min(z+neutronCount,240),radius=.18*Math.cbrt(Math.max(1,count));
        for(let i=0;i<count;i++){const a=Math.acos(1-2*(i+.5)/count),b=Math.PI*(1+Math.sqrt(5))*i;const m=new THREE.Mesh(new THREE.SphereGeometry(.105,10,8),i<z?protonMat:neutronMat);m.position.set(radius*Math.sin(a)*Math.cos(b),radius*Math.cos(a),radius*Math.sin(a)*Math.sin(b));root.add(m)}
      }else{
        const core=new THREE.Mesh(new THREE.SphereGeometry(.42,24,18),new THREE.MeshStandardMaterial({color:0xef665f,roughness:.5}));root.add(core);
        const cloud=new THREE.Mesh(new THREE.SphereGeometry(2.05,24,18),new THREE.MeshBasicMaterial({color:0x68d6ff,transparent:true,opacity:.08,wireframe:true}));root.add(cloud);
      }
      const shellMap={1:[1],2:[2],6:[2,4],8:[2,6],11:[2,8,1],17:[2,8,7],26:[2,8,14,2],29:[2,8,18,1],79:[2,8,18,32,18,1],92:[2,8,18,32,21,9,2]};
      const shells=shellMap[z]||null,electrons=[];
      if(shells){shells.forEach((n,i)=>{const r=1.25+i*.65,pts=[];for(let j=0;j<=64;j++){const a=j/64*Math.PI*2;pts.push(new THREE.Vector3(Math.cos(a)*r,0,Math.sin(a)*r))}root.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:0x47718d,transparent:true,opacity:.7})));for(let j=0;j<n;j++){const m=new THREE.Mesh(new THREE.SphereGeometry(.075,10,8),electronMat);root.add(m);electrons.push({m,r,a:j/n*Math.PI*2,s:(i%2?-.55:.55)*(1+i*.08),tilt:i*.22})}})}
      else if(isotopeMass!==null){const cloud=new THREE.Mesh(new THREE.SphereGeometry(2.05,24,18),new THREE.MeshBasicMaterial({color:0x68d6ff,transparent:true,opacity:.08,wireframe:true}));root.add(cloud)}
      let drag=false,x=0,y=0,raf=0,visible=true;
      stage.addEventListener('pointerdown',e=>{drag=true;x=e.clientX;y=e.clientY;stage.setPointerCapture(e.pointerId)});
      stage.addEventListener('pointermove',e=>{if(!drag)return;root.rotation.y+=(e.clientX-x)*.009;root.rotation.x+=(e.clientY-y)*.006;x=e.clientX;y=e.clientY;draw()});
      stage.addEventListener('pointerup',()=>drag=false);stage.addEventListener('pointercancel',()=>drag=false);
      document.getElementById('reset').onclick=()=>{root.rotation.set(0,0,0);camera.position.set(0,1,7.2);draw()};
      function resize(){const w=Math.max(1,stage.clientWidth),h=Math.max(1,stage.clientHeight);camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false);draw()}
      new ResizeObserver(resize).observe(stage);
      function draw(){if(!raf)raf=requestAnimationFrame(()=>{raf=0;renderer.render(scene,camera)})}
      let last=performance.now();
      function animate(now){if(!visible)return;const dt=Math.min(.04,(now-last)/1000);last=now;electrons.forEach(e=>{e.a+=dt*e.s;e.m.position.set(Math.cos(e.a)*e.r,Math.sin(e.a*2+e.tilt)*.16,Math.sin(e.a)*e.r)});root.rotation.y+=dt*.09;renderer.render(scene,camera);requestAnimationFrame(animate)}
      document.addEventListener('visibilitychange',()=>{visible=!document.hidden;if(visible){last=performance.now();requestAnimationFrame(animate)}});
      requestAnimationFrame(animate);window.addEventListener('pagehide',()=>{visible=false;renderer.dispose();cancelAnimationFrame(raf)});
    })();
    </script></body></html>"""
    AndroidView(modifier = Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(14.dp)), factory = { ctx -> WebView(ctx).apply { settings.javaScriptEnabled = true; settings.domStorageEnabled = false; settings.allowContentAccess = false; setBackgroundColor(android.graphics.Color.TRANSPARENT); webViewClient = WebViewClient(); loadDataWithBaseURL("https://spectrum.local/", html, "text/html", "UTF-8", null) } })
}


@Composable
private fun PhysicsKnowledgePage(p: Palette) {
    val topics = listOf("Elektrik yükü ve alan" to "Elektrik yükü maddenin temel özelliklerinden biridir. Aynı işaretli yükler birbirini iter, zıt işaretli yükler birbirini çeker. Elektrik alan, birim pozitif yüke etki eden kuvveti tanımlar.", "Akım, gerilim ve direnç" to "Akım, bir kesitten birim zamanda geçen net yük miktarıdır. Gerilim enerji farkını, direnç ise akıma karşı gösterilen etkiyi ifade eder. Ohm yasası ideal ohmik elemanlarda V=IR biçimindedir.", "Manyetizma" to "Hareketli elektrik yükleri manyetik alan oluşturur. Elektrik akımı taşıyan iletkenler çevresinde manyetik alan meydana gelir; elektromıknatıslar bu ilkeden yararlanır.", "Enerji ve hareket" to "Enerji iş yapabilme kapasitesidir. Kinetik enerji harekete, potansiyel enerji konuma veya etkileşime bağlıdır. Sürtünme gibi süreçlerde mekanik enerji ısıya dönüşebilir.", "Dalgalar ve ışık" to "Dalgalar enerji ve momentum taşır. Ses mekanik dalgadır ve ortam gerektirir; ışık elektromanyetik dalgadır ve boşlukta yayılabilir.", "Newton yasaları" to "Eylemsizlik, ivme ve etki-tepki ilkeleri klasik mekaniğin temelini oluşturur. Net kuvvet, kütle ile ivmenin çarpımına eşittir.", "Momentum" to "Momentum kütle ve hızın çarpımıdır. Yalıtılmış sistemlerde toplam momentum korunur.", "Basınç ve akışkanlar" to "Basınç birim yüzeye etki eden dik kuvvettir. Sıvı basıncı derinlikle artar; akışkanların hareketi yoğunluk ve viskoziteden etkilenir.", "Termodinamik" to "Termodinamik ısı, iş, sıcaklık ve iç enerji arasındaki ilişkileri inceler. Enerjinin korunumu birinci yasa ile ifade edilir.", "Elektromanyetik indüksiyon" to "Değişen manyetik akı bir devrede elektromotor kuvvet oluşturabilir. Jeneratörler bu prensiple mekanik enerjiyi elektrik enerjisine dönüştürür.", "Optik ve kırılma" to "Işık farklı kırılma indislerine sahip ortamların sınırında yön değiştirebilir. Snell yasası n₁ sinθ₁ = n₂ sinθ₂ bağıntısını verir.")
    var open by rememberSaveable { mutableStateOf(topics.first().first) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Fizik ve elektrik", color=p.accent, fontSize=22.sp, fontWeight=FontWeight.Bold); Text("Doğanın temel etkileşimlerini ve enerji dönüşümlerini incele.", color=p.muted) }
        topics.forEach { (t,b) -> Panel(p) { Text(t, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.fillMaxWidth().clickable { open=if(open==t) "" else t }); if(open==t) Text(b, color=p.text, lineHeight=21.sp) } }
    }
}

@Composable
private fun TechnologyKnowledgePage(p: Palette) {
    val topics = listOf("Yarı iletkenler" to "Silisyum gibi yarı iletkenlerin elektriksel iletkenliği katkılama, sıcaklık ve elektrik alanla değiştirilebilir. Diyotlar ve transistörler modern elektroniğin temel yapı taşlarıdır.", "İşlemciler ve bellek" to "İşlemci komutları yürütür ve aritmetik-mantık işlemleri gerçekleştirir. RAM geçici çalışma verilerini tutar; kalıcı depolama veriyi enerji kesildiğinde de korur.", "Sensörler" to "Sensörler sıcaklık, basınç, ivme, ışık veya manyetik alan gibi fiziksel büyüklükleri ölçülebilir sinyallere dönüştürür.", "Robotik ve otomasyon" to "Robotik sistemler algılama, kontrol ve hareket bileşenlerini birleştirir. Geri besleme, sistemin ölçülen çıktıya göre davranışını düzeltmesini sağlar.", "Enerji teknolojileri" to "Güneş hücreleri ışığı elektrik enerjisine dönüştürür. Bataryalar enerjiyi elektrokimyasal süreçlerle depolar; güç elektroniği enerji akışını yönetir.", "İletişim ağları" to "Kablosuz ve kablolu ağlar veriyi protokoller aracılığıyla paketler ve iletir. Gecikme, bant genişliği ve güvenilirlik temel performans ölçütleridir.", "Gömülü sistemler" to "Gömülü bilgisayarlar belirli görevleri yerine getirmek üzere cihazların içine yerleştirilir. Mikrodenetleyici, bellek, giriş-çıkış ve yazılım birlikte çalışır.", "3B baskı" to "Eklemeli üretim, parçaları katmanlar halinde oluşturarak prototipleme ve özel geometrilerin üretimini kolaylaştırır.", "Yapay zekâ" to "Makine öğrenmesi, veriden örüntüler öğrenen modeller geliştirir. Eğitim verisinin niteliği ve modelin değerlendirilmesi sonuçların güvenilirliğini belirler.", "Siber güvenlik" to "Gizlilik, bütünlük ve erişilebilirlik temel güvenlik hedefleridir. Kimlik doğrulama, güncelleme ve güvenli tasarım sistemleri korumaya yardımcı olur.")
    var open by rememberSaveable { mutableStateOf(topics.first().first) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Teknoloji atlası", color=p.accent, fontSize=22.sp, fontWeight=FontWeight.Bold); Text("Elektronikten akıllı sistemlere uzanan temel teknolojiler.", color=p.muted) }
        topics.forEach { (t,b) -> Panel(p) { Text(t, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.fillMaxWidth().clickable { open=if(open==t) "" else t }); if(open==t) Text(b, color=p.text, lineHeight=21.sp) } }
    }
}

@Composable
private fun SettingsPage(p: Palette, selected: Int, soundOn: Boolean, fontIndex: Int, onTheme: (Int) -> Unit, onSound: (Boolean) -> Unit, onFont: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel(p) {
            Text("Görünüm", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text("Temayı yatay kaydırmalı küçük seçeneklerden seç.", color = p.muted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                palettes.forEachIndexed { index, theme ->
                    Column(
                        Modifier.width(74.dp).clip(RoundedCornerShape(13.dp))
                            .border(if (selected == index) 2.dp else 1.dp, if (selected == index) p.accent else p.muted.copy(alpha = .3f), RoundedCornerShape(13.dp))
                            .clickable { onTheme(index) }.padding(7.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.fillMaxWidth().height(30.dp).clip(RoundedCornerShape(8.dp)).background(theme.bg), contentAlignment = Alignment.Center) {
                            Box(Modifier.size(13.dp).clip(CircleShape).background(theme.accent))
                        }
                        Text(theme.name, color = p.text, fontSize = 10.sp, maxLines = 1)
                    }
                }
            }
        }
        Panel(p) {
            Text("Yazı tipi", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Okuma görünümünü seç. Seçim uygulama genelinde saklanır.", color = p.muted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("Standart", "Kitap", "Teknik", "Yuvarlak") .forEachIndexed { index, label ->
                    FilterChip(selected = fontIndex == index, onClick = { onFont(index) }, label = { Text(label, fontSize = 11.sp) })
                }
            }
        }
        Panel(p) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Arayüz sesleri", color = p.accent, fontWeight = FontWeight.Bold)
                    Text("Gezinme ve doğru cevaplarda kısa ses.", color = p.muted, fontSize = 12.sp)
                }
                Switch(checked = soundOn, onCheckedChange = onSound)
            }
        }
        Panel(p) {
            Text("3B modeller", color = p.accent, fontWeight = FontWeight.Bold)
            Text("İnsan anatomisi ve molekül modelleri uygulama içinde üretilir. Güneş Sistemi'nin NASA tabanlı etkileşimli sahnesi internet bağlantısı gerektirir.", color = p.text, lineHeight = 20.sp)
        }
        Panel(p) {
            Text("Uygulama bilgisi", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Spectrum 1.5.1\nElyionn tarafından tasarlanmıştır.\nBilimsel içerikler eğitim amaçlıdır. Sayısal veriler zamanla güncellenebilir.", color = p.text, lineHeight = 21.sp)
        }
    }
}
