# Spectrum 1.5.1 scientific data notes

## Periodic table

- The 118 element identities, Turkish display names, atomic-number order and rounded atomic-mass labels are carried forward from the Spectrum 1.5.0 element table. This update corrects selected spelling and representative-isotope display issues; it does not claim that every atomic-weight value has been independently re-certified against the latest CIAAW table.
- Period, group and block are derived from the standard 1–18 group layout, with the f-block series explicitly identified.
- Covalent-radius values for elements 1–103 are bundled from the RDKit PeriodicTable data in RDKit 2025.09.4 and converted from ångström to picometre (pm). Values for elements 104–118 are intentionally not displayed as measured values.
- Electron configurations are displayed only where the bundled table contains a curated configuration. Missing entries are marked as unverified instead of being filled by an unlabelled Aufbau estimate. Superheavy-element configurations and bulk physical properties require explicit theoretical/experimental status labels.
- The representative isotope masses shown in the atom-lab presets are explicitly listed in `isotopeMassFor`; these are educational examples, not a claim that every element has one unique isotope.

## Anatomy and atom visuals

- The human-body scene is generated from procedural Three.js meshes. The layers are independently switchable and major structures can be selected, but the model is schematic rather than a complete segmented anatomical dataset. It is not suitable for diagnosis, treatment, or clinical planning.
- The atom model is schematic. Classical-looking shell paths are a teaching aid and do not represent literal electron trajectories. A nucleus is not drawn as an exact-scale structure.

## Supplied reference project

The uploaded Grok science-atlas project was reviewed for its category taxonomy, mobile layout, topic-page information order, periodic-table interaction and atom-viewer controls. Its `BodySystems` component is a step-based text lesson rather than a full 3D anatomical model. Spectrum's Android UI and 3D scene in this update are separately implemented in Kotlin/Compose and embedded Three.js.
