# Spectrum 1.5.5

Kotlin / Jetpack Compose Android science-learning application.

## Build identity

- `versionName`: `1.5.5`
- `versionCode`: `12`
- Namespace: `com.elyionn.spektrum`
- Application ID: `com.elyionn.spectrum`
- Minimum Android: API 26
- Compile / target SDK: 35
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- Gradle: 8.9
- JDK: 17

## 1.5.5 update contents

- Improved periodic-table pan/zoom boundary handling and added visible zoom-in / zoom-out controls.
- Periodic-table search now normalizes diacritics, improving searches with and without Turkish accents.
- Retains the 118-element dataset, element details, category colors, and existing learning modules.
- Updated the Credits copy to identify the project as created by Elyionn.
- GitHub Actions now locates ZIP files even when a download adds `(1)` or another suffix, validates archive contents, checks the 118 element records and embedded JavaScript, and uploads Gradle diagnostics even when compilation fails.
- App version remains `1.5.5` / versionCode `12` as requested.

## Known limitations

- A licensed, clinically reviewed, fully modelled human-body asset is not included. The former schematic body renderer was removed; this build does not claim to include a realistic full-body 3D model.
- The Solar System, atom and molecule visuals are local interactive projections / diagrams. A bundled Three.js or dedicated WebGL scene engine is not integrated yet.
- Some science topics are expandable topic panels rather than separate navigation destinations.
- A complete screen-by-screen localization audit and physical-device QA remain outstanding.

## Build

The GitHub Actions workflow is `.github/workflows/android-apk.yml`. Place the project ZIP in the repository root and run the workflow, or open the extracted `Spectrum` folder in Android Studio using JDK 17 and Gradle 8.9.
