# Spectrum 1.5.5

Kotlin / Jetpack Compose Android science-learning application.

## Build identity

- `versionName`: `1.5.5`
- `versionCode`: `12`
- Namespace: `com.elyionn.spektrum`
- Application ID: `com.elyionn.spectrum`
- Minimum Android: API 26
- Compile / target SDK: 35
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- Gradle: 8.9
- JDK: 17

## Included in this update

- Periodic-table interaction changed to a unified two-finger pan/zoom gesture surface with a reset control. Zoom is applied once through the graphics layer rather than being multiplied into both layout dimensions and the graphics transform.
- Added immediate-answer feedback and score counters to short knowledge checks in biology, chemistry, mathematics, physics, space, microbiology, technology and the model lab.
- Added an animated DNA double-helix projection and retained the existing interactive science visualizations.
- Removed the old schematic human-body renderer instead of presenting it as a realistic anatomical model.
- Added a compact system sans-serif typeface option and retained selectable themes and Turkish / English UI.
- Added projectile-motion and derivative explorations to the mathematics / physics workspaces.
- Updated app version metadata and the CI workflow to `1.5.5` / `12`.

## Known limitations (not represented as completed)

- A licensed, clinically reviewed, fully modelled human-body asset is not included. The inaccurate schematic body renderer has been removed; this release does not claim to replace it with a realistic full-body model.
- The current solar-system, atom and molecule visuals are local interactive projections / diagrams. A bundled Three.js or dedicated WebGL scene engine has not yet been integrated.
- Some science topics remain expandable topic panels rather than separate dedicated navigation destinations.
- Turkish and English strings are present across the main learning modules, but a full screen-by-screen localization audit and device-level visual QA remain necessary.

## Build

The GitHub Actions workflow is `.github/workflows/android-apk.yml`. Place `Spectrum_v1.5.5_Android_Project.zip` in the repository root and run the workflow, or open the project in Android Studio with JDK 17 and Gradle 8.9.
