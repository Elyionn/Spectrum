# Scientific data sources and scope

Existing periodic-table and educational content is retained from the supplied Spectrum 1.5.5 source package. The new Science Atlas entries are bundled educational summaries written for this application; they are not live API responses and have not been externally revalidated in this update.

Recommended primary references for future data expansion and verification:

- IUPAC: https://iupac.org/ — element nomenclature and chemical terminology.
- PubChem: https://pubchem.ncbi.nlm.nih.gov/ — compound records and molecular properties.
- NIST Chemistry WebBook: https://webbook.nist.gov/chemistry/ — thermochemical and spectroscopic reference data.
- NASA: https://science.nasa.gov/ — planetary and space-science reference material.
- NASA/JPL Solar System Dynamics: https://ssd.jpl.nasa.gov/ — orbital and small-body data.
- ESA: https://www.esa.int/Science_Exploration — astronomy and planetary science.
- NIH: https://www.nih.gov/ — biomedical research context.
- NCBI Bookshelf: https://www.ncbi.nlm.nih.gov/books/ — biomedical and life-science references.
- OpenStax: https://openstax.org/subjects/science — open educational science textbooks.

The app does not currently fetch these sources automatically. Any future imported dataset should record its source URL, units, retrieval/verification date, license and uncertainty. Missing values should remain unknown rather than being guessed.

## Spectrum 1.6.2 — additional Earth Science references

The following sources support the seven new Earth Science lessons and are linked from their topic pages:

- USGS, Geology Education: https://www.usgs.gov/educational-resources/geology-education
- USGS, Earthquake Education: https://earthquake.usgs.gov/education/
- USGS, Natural Hazards Education: https://www.usgs.gov/educational-resources/natural-hazards-education
- National Geographic, Plate Tectonics: https://education.nationalgeographic.org/resource/plate-tectonics/
- Smithsonian National Museum of Natural History, Volcanoes and Plate Tectonics: https://naturalhistory.si.edu/education/teaching-resources/earth-science/volcanoes-and-plate-tectonics
- U.S. National Park Service, Physical Features of the Earth: https://www.nps.gov/teachers/classrooms/physical-features-of-the-earth.htm
- USGS, National Minerals Information Center: https://www.usgs.gov/centers/national-minerals-information-center

The imported Grok Workspace lesson catalogue did not attach per-topic bibliographies to most records. Such records are retained as educational content but are not presented as independently source-verified. See `SOURCE_AUDIT_1.6.2.md`.
