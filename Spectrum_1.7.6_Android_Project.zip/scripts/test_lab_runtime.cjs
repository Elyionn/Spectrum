'use strict';

const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const htmlPath = path.join(process.cwd(), 'app/src/main/assets/lab/index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const scriptMatch = html.match(/<script>([\s\S]*?)<\/script>/);
if (!scriptMatch) throw new Error('Canvas 3D Lab script not found.');

const documentListeners = Object.create(null);
const windowListeners = Object.create(null);
const queuedFrames = new Map();
const buttons = [];
let nextFrameId = 0;

function makeElement(name) {
  return {
    name,
    textContent: '',
    innerHTML: '',
    dataset: {},
    style: {},
    attrs: {},
    listeners: Object.create(null),
    classList: {
      toggle() {},
      add() {},
      remove() {},
    },
    setAttribute(key, value) { this.attrs[key] = value; },
    addEventListener(type, callback) { this.listeners[type] = callback; },
    appendChild(child) {
      if (child.name === 'button') buttons.push(child);
    },
    querySelectorAll() { return buttons; },
    getBoundingClientRect() { return { width: 390, height: 520, left: 0, top: 0 }; },
    setPointerCapture() {},
  };
}

const canvasContext = {
  setTransform() {},
  clearRect() {},
  createRadialGradient() { return { addColorStop() {} }; },
  beginPath() {},
  arc() {},
  fill() {},
  stroke() {},
  moveTo() {},
  lineTo() {},
};

const elements = Object.fromEntries(
  ['stage', 'scene', 'label', 'caption', 'models', 'rotate', 'reset', 'hint']
    .map((id) => [id, makeElement(id)]),
);
elements.stage.clientWidth = 390;
elements.stage.clientHeight = 520;
elements.scene.getContext = (kind) => kind === '2d' ? canvasContext : null;
elements.models.appendChild = (child) => {
  if (child.name === 'button') buttons.push(child);
};
elements.models.querySelectorAll = () => buttons;

const documentMock = {
  hidden: false,
  getElementById(id) { return elements[id]; },
  createElement(name) { return makeElement(name); },
  addEventListener(type, callback) { documentListeners[type] = callback; },
};
const windowMock = {
  devicePixelRatio: 2,
  SpectrumBridge: {
    reportReady() { windowMock.readyReported = true; },
    reportError(message) { windowMock.errorReported = message; },
  },
  addEventListener(type, callback) { windowListeners[type] = callback; },
};
const sandbox = {
  document: documentMock,
  window: windowMock,
  location: { search: '?model=atom&lang=tr' },
  URLSearchParams,
  requestAnimationFrame(callback) {
    const id = ++nextFrameId;
    queuedFrames.set(id, callback);
    return id;
  },
  cancelAnimationFrame(id) { queuedFrames.delete(id); },
  console,
  Math,
  Map,
  Set,
  Array,
  Number,
  String,
  Object,
};

vm.runInNewContext(scriptMatch[1], sandbox, { timeout: 10000, filename: 'spectrum-lab.js' });
if (buttons.length !== 48) {
  throw new Error(`Expected 48 scene buttons; found ${buttons.length}.`);
}
const click = elements.models.listeners.click;
if (typeof click !== 'function') throw new Error('Scene selection handler was not registered.');

for (const button of buttons) {
  const id = button.dataset.id;
  if (!id) throw new Error('A scene button has no data-id.');
  click({ target: { closest: () => ({ dataset: { id } }) } });
  if (!elements.label.textContent || !elements.caption.textContent) {
    throw new Error(`Scene metadata was not populated for ${id}.`);
  }
}

for (const callback of queuedFrames.values()) callback(16);
if (!windowMock.readyReported) throw new Error('Native WebView bridge did not receive reportReady.');
if (windowMock.errorReported) throw new Error(`3D scene runtime reported an error: ${windowMock.errorReported}`);
if (elements.scene.width < 1 || elements.scene.height < 1) {
  throw new Error('Canvas backing dimensions were not initialized.');
}

// Exercise pointer rotation, pinch zoom, wheel zoom, reset and auto-rotation.
const canvasListeners = elements.scene.listeners;
for (const event of ['pointerdown', 'pointermove', 'pointerup', 'pointercancel', 'wheel']) {
  if (typeof canvasListeners[event] !== 'function') {
    throw new Error(`Canvas interaction handler missing: ${event}`);
  }
}
canvasListeners.pointerdown({ pointerId: 1, clientX: 20, clientY: 30 });
canvasListeners.pointermove({ pointerId: 1, clientX: 38, clientY: 44 });
canvasListeners.pointerup({ pointerId: 1 });
canvasListeners.pointerdown({ pointerId: 1, clientX: 40, clientY: 60 });
canvasListeners.pointerdown({ pointerId: 2, clientX: 90, clientY: 60 });
canvasListeners.pointermove({ pointerId: 2, clientX: 110, clientY: 60 });
canvasListeners.pointerup({ pointerId: 1 });
canvasListeners.pointerup({ pointerId: 2 });
let wheelPrevented = false;
canvasListeners.wheel({ deltaY: -120, preventDefault() { wheelPrevented = true; } });
if (!wheelPrevented) throw new Error('Wheel zoom did not prevent page scrolling.');

const rotate = elements.rotate;
if (typeof rotate.listeners.click !== 'function') throw new Error('Auto-rotate control is missing.');
rotate.listeners.click();
if (rotate.attrs['aria-pressed'] !== 'true') throw new Error('Auto-rotate did not enter the enabled state.');
for (const [id, callback] of [...queuedFrames.entries()]) {
  queuedFrames.delete(id);
  callback(80);
}
rotate.listeners.click();
if (rotate.attrs['aria-pressed'] !== 'false') throw new Error('Auto-rotate did not stop.');
elements.reset.listeners.click();

// Verify renderer exceptions are contained and reported to the native bridge.
canvasContext.stroke = () => { throw new Error('injected canvas failure'); };
elements.reset.listeners.click();
if (!windowMock.errorReported || !String(windowMock.errorReported).includes('injected canvas failure')) {
  throw new Error('Canvas render exception was not contained and reported.');
}

console.log(`PASS: rendered all ${buttons.length} scenes; pointer/zoom/reset/rotation passed; renderer failure was contained; DPR capped at 1.0.`);
