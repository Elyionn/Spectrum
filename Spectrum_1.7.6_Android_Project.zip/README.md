# Spectrum 1.7.6

Android science learning app built with Kotlin and Jetpack Compose.

- Application ID: `com.elyionn.spectrum`
- Namespace: `com.elyionn.spektrum`
- Version: `1.7.6` (versionCode `29`)
- compileSdk/targetSdk: `35`
- 3D Lab: local Canvas 2D renderer with 48 interactive schematic scenes; no WebGL dependency.

See `CHANGELOG_1.7.6.md`, `SOURCE_AUDIT_1.7.6.md`, `TEST_REPORT_1.7.6.md` and `PERFORMANCE_REPORT_1.7.6.md`. Run `.github/workflows/android-apk.yml` via GitHub Actions to compile, test and build APK artifacts.

## GitHub Actions build

1. Upload this archive itself to the repository root as `Spectrum_1.7.6_Android_Project.zip` (do not extract it in the repository).
2. Upload `android-apk-1.7.6.yml` to `.github/workflows/android-apk.yml`.
3. Commit both files, then open **Actions → Spectrum 1.7.6 Android Build**. You can also use **Run workflow**.
4. On success, download the `Spectrum-1.7.6-build-results` artifact. It contains the debug APK, release APK output, JUnit XML results and SHA-256 checksums. The release APK is unsigned unless signing secrets are configured; the debug APK is debug-signed.

The local checks listed in `TEST_REPORT_1.7.6.md` are not a substitute for the Android Gradle build or a physical-device test. The GitHub workflow performs compilation, JUnit tests, APK assembly and APK package/ZIP validation.
