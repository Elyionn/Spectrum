package com.elyionn.spektrum

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private data class Palette(val name: String, val bg: Color, val panel: Color, val accent: Color, val text: Color, val muted: Color)
private val palettes = listOf(
    Palette("Kozmik", Color(0xFF081321), Color(0xFF192D45), Color(0xFF75C8FF), Color(0xFFF0F6FF), Color(0xFFB3C3D5)),
    Palette("Aurora", Color(0xFF071A19), Color(0xFF12332E), Color(0xFF73E0B5), Color(0xFFE8FFF6), Color(0xFFB0D4C8)),
    Palette("Nebula", Color(0xFF180E29), Color(0xFF2D1B49), Color(0xFFC5A0FF), Color(0xFFF6F0FF), Color(0xFFC8B8DD)),
    Palette("Arktik", Color(0xFF101C2B), Color(0xFF203B54), Color(0xFF8DD5FF), Color(0xFFEAF7FF), Color(0xFFB8CCDC)),
    Palette("Laboratuvar", Color(0xFFF1F5F7), Color(0xFFFFFFFF), Color(0xFF087F8C), Color(0xFF17232B), Color(0xFF52616B)),
    Palette("Gün Batımı", Color(0xFF24131A), Color(0xFF42232D), Color(0xFFFFAD83), Color(0xFFFFF1E9), Color(0xFFDCC0B5)),
    Palette("Obsidyen", Color(0xFF101014), Color(0xFF22232B), Color(0xFFFFD166), Color(0xFFF8F7F2), Color(0xFFB9B8C2)),
    Palette("Okyanus", Color(0xFF061B2A), Color(0xFF0E3448), Color(0xFF4DE3D0), Color(0xFFE8FBFF), Color(0xFFA7C9D5)),
    Palette("Lavanta", Color(0xFF211B31), Color(0xFF352A4B), Color(0xFFE0B8FF), Color(0xFFFAF0FF), Color(0xFFC9B9D5)),
    Palette("Zümrüt", Color(0xFF0C211A), Color(0xFF19382B), Color(0xFF9AE6A6), Color(0xFFEFFFF0), Color(0xFFB5D2BC))
)

private val elementRows = listOf(
"H|Hidrojen|1|1.008|Ametal", "He|Helyum|2|4.0026|Soygaz", "Li|Lityum|3|6.94|Alkali metal", "Be|Berilyum|4|9.0122|Toprak alkali", "B|Bor|5|10.81|Yarı metal", "C|Karbon|6|12.011|Ametal", "N|Azot|7|14.007|Ametal", "O|Oksijen|8|15.999|Ametal", "F|Flor|9|18.998|Halojen", "Ne|Neon|10|20.180|Soygaz",
"Na|Sodyum|11|22.990|Alkali metal", "Mg|Magnezyum|12|24.305|Toprak alkali", "Al|Alüminyum|13|26.982|Metal", "Si|Silisyum|14|28.085|Yarı metal", "P|Fosfor|15|30.974|Ametal", "S|Kükürt|16|32.06|Ametal", "Cl|Klor|17|35.45|Halojen", "Ar|Argon|18|39.948|Soygaz",
"K|Potasyum|19|39.098|Alkali metal", "Ca|Kalsiyum|20|40.078|Toprak alkali", "Sc|Skandiyum|21|44.956|Geçiş metali", "Ti|Titanyum|22|47.867|Geçiş metali", "V|Vanadyum|23|50.942|Geçiş metali", "Cr|Krom|24|51.996|Geçiş metali", "Mn|Manganez|25|54.938|Geçiş metali", "Fe|Demir|26|55.845|Geçiş metali", "Co|Kobalt|27|58.933|Geçiş metali", "Ni|Nikel|28|58.693|Geçiş metali", "Cu|Bakır|29|63.546|Geçiş metali", "Zn|Çinko|30|65.38|Geçiş metali", "Ga|Galyum|31|69.723|Metal", "Ge|Germanyum|32|72.630|Yarı metal", "As|Arsenik|33|74.922|Yarı metal", "Se|Selenyum|34|78.971|Ametal", "Br|Brom|35|79.904|Halojen", "Kr|Kripton|36|83.798|Soygaz",
"Rb|Rubidyum|37|85.468|Alkali metal", "Sr|Stronsiyum|38|87.62|Toprak alkali", "Y|İtriyum|39|88.906|Geçiş metali", "Zr|Zirkonyum|40|91.224|Geçiş metali", "Nb|Niyobyum|41|92.906|Geçiş metali", "Mo|Molibden|42|95.95|Geçiş metali", "Tc|Teknesyum|43|98|Geçiş metali", "Ru|Rutenyum|44|101.07|Geçiş metali", "Rh|Rodyum|45|102.91|Geçiş metali", "Pd|Paladyum|46|106.42|Geçiş metali", "Ag|Gümüş|47|107.87|Geçiş metali", "Cd|Kadmiyum|48|112.41|Geçiş metali", "In|İndiyum|49|114.82|Metal", "Sn|Kalay|50|118.71|Metal", "Sb|Antimon|51|121.76|Yarı metal", "Te|Tellür|52|127.60|Yarı metal", "I|İyot|53|126.90|Halojen", "Xe|Ksenon|54|131.29|Soygaz",
"Cs|Sezyum|55|132.91|Alkali metal", "Ba|Baryum|56|137.33|Toprak alkali", "La|Lantan|57|138.91|Lantanit", "Ce|Seryum|58|140.12|Lantanit", "Pr|Praseodim|59|140.91|Lantanit", "Nd|Neodim|60|144.24|Lantanit", "Pm|Prometyum|61|145|Lantanit", "Sm|Samaryum|62|150.36|Lantanit", "Eu|Öropiyum|63|151.96|Lantanit", "Gd|Gadolinyum|64|157.25|Lantanit", "Tb|Terbiyum|65|158.93|Lantanit", "Dy|Disprozyum|66|162.50|Lantanit", "Ho|Holmiyum|67|164.93|Lantanit", "Er|Erbiyum|68|167.26|Lantanit", "Tm|Tulyum|69|168.93|Lantanit", "Yb|İterbiyum|70|173.05|Lantanit", "Lu|Lutesyum|71|174.97|Lantanit",
"Hf|Hafniyum|72|178.49|Geçiş metali", "Ta|Tantal|73|180.95|Geçiş metali", "W|Tungsten|74|183.84|Geçiş metali", "Re|Ren|75|186.21|Geçiş metali", "Os|Osmiyum|76|190.23|Geçiş metali", "Ir|İridyum|77|192.22|Geçiş metali", "Pt|Platin|78|195.08|Geçiş metali", "Au|Altın|79|196.97|Geçiş metali", "Hg|Cıva|80|200.59|Geçiş metali", "Tl|Talyum|81|204.38|Metal", "Pb|Kurşun|82|207.2|Metal", "Bi|Bizmut|83|208.98|Metal", "Po|Polonyum|84|209|Yarı metal", "At|Astatin|85|210|Halojen", "Rn|Radon|86|222|Soygaz",
"Fr|Fransiyum|87|223|Alkali metal", "Ra|Radyum|88|226|Toprak alkali", "Ac|Aktinyum|89|227|Aktinit", "Th|Toryum|90|232.04|Aktinit", "Pa|Protaktinyum|91|231.04|Aktinit", "U|Uranyum|92|238.03|Aktinit", "Np|Neptünyum|93|237|Aktinit", "Pu|Plütonyum|94|244|Aktinit", "Am|Amerikyum|95|243|Aktinit", "Cm|Küriyum|96|247|Aktinit", "Bk|Berkelyum|97|247|Aktinit", "Cf|Kaliforniyum|98|251|Aktinit", "Es|Aynştaynyum|99|252|Aktinit", "Fm|Fermiyum|100|257|Aktinit", "Md|Mendelevyum|101|258|Aktinit", "No|Nobelyum|102|259|Aktinit", "Lr|Lavrensiyum|103|266|Aktinit", "Rf|Rutherfordiyum|104|267|Geçiş metali", "Db|Dubniyum|105|268|Geçiş metali", "Sg|Seaborgiyum|106|269|Geçiş metali", "Bh|Bohriyum|107|270|Geçiş metali", "Hs|Hassiyum|108|277|Geçiş metali", "Mt|Meitneriyum|109|278|Bilinmiyor", "Ds|Darmstadtiyum|110|281|Bilinmiyor", "Rg|Röntgenyum|111|282|Bilinmiyor", "Cn|Kopernikyum|112|285|Bilinmiyor", "Nh|Nihonyum|113|286|Bilinmiyor", "Fl|Flerovyum|114|289|Bilinmiyor", "Mc|Moskovyum|115|290|Bilinmiyor", "Lv|Livermoryum|116|293|Bilinmiyor", "Ts|Tennessin|117|294|Halojen", "Og|Oganesson|118|294|Soygaz"
).map { it.split('|') }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { SpectrumApp() }
    }
}

@Composable
private fun SpectrumApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("spectrum_settings", Context.MODE_PRIVATE) }
    var page by rememberSaveable { mutableStateOf("Keşif") }
    var category by rememberSaveable { mutableStateOf("") }
    var selectedElement by rememberSaveable { mutableStateOf("H") }
    var fontIndex by rememberSaveable { mutableIntStateOf(prefs.getInt("font", 0).coerceIn(0, 3)) }
    var themeIndex by rememberSaveable { mutableIntStateOf(prefs.getInt("theme", 0).coerceIn(palettes.indices)) }
    var soundOn by rememberSaveable { mutableStateOf(prefs.getBoolean("sound", false)) }
    val p = palettes[themeIndex]
    val tone = remember { ToneGenerator(AudioManager.STREAM_MUSIC, 35) }
    DisposableEffect(Unit) { onDispose { tone.release() } }
    fun clickSound() { if (soundOn) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 65) }
    val scheme = if (themeIndex == 4) lightColorScheme(
        primary = p.accent, background = p.bg, surface = p.panel, onSurface = p.text, onBackground = p.text
    ) else darkColorScheme(
        primary = p.accent, background = p.bg, surface = p.panel, onSurface = p.text, onBackground = p.text
    )

    val appFont = when (fontIndex) { 1 -> androidx.compose.ui.text.font.FontFamily.Serif; 2 -> androidx.compose.ui.text.font.FontFamily.Monospace; 3 -> androidx.compose.ui.text.font.FontFamily.Cursive; else -> androidx.compose.ui.text.font.FontFamily.SansSerif }
    MaterialTheme(colorScheme = scheme) {
      androidx.compose.runtime.CompositionLocalProvider(androidx.compose.material3.LocalTextStyle provides androidx.compose.material3.LocalTextStyle.current.copy(fontFamily = appFont)) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = p.bg,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                NavigationBar(
                    containerColor = p.panel,
                    contentColor = p.text
                ) {
                    val items = listOf(
                        Triple("Keşif", Icons.Default.Explore, "Keşif"),
                        Triple("Kategoriler", Icons.Default.Category, "Kategoriler"),
                        Triple("Ayarlar", Icons.Default.Settings, "Ayarlar")
                    )
                    items.forEach { item ->
                        NavigationBarItem(
                            selected = page == item.first || ((page == "Detay" || page == "ElementDetay") && item.first == "Kategoriler"),
                            onClick = { clickSound(); page = item.first; category = "" },
                            icon = { Icon(item.second, contentDescription = item.first) },
                            label = { Text(item.first, fontSize = 11.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = p.accent,
                                selectedTextColor = p.accent,
                                indicatorColor = p.accent.copy(alpha = .16f),
                                unselectedIconColor = p.muted,
                                unselectedTextColor = p.muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).background(p.bg)
            ) {
                Header(p = p, title = when (page) { "Detay" -> category; "ElementDetay" -> selectedElement; else -> page })
                when (page) {
                    "Keşif" -> HomePage(p, onOpen = { category = it; page = "Detay" }, onAll = { page = "Kategoriler" })
                    "Kategoriler" -> CategoryHub(p, onOpen = { category = it; page = "Detay" })
                    "Ayarlar" -> SettingsPage(
                        p, themeIndex, soundOn, fontIndex,
                        onTheme = { themeIndex = it; prefs.edit().putInt("theme", it).apply(); clickSound() },
                        onSound = { soundOn = it; prefs.edit().putBoolean("sound", it).apply() },
                        onFont = { fontIndex = it; prefs.edit().putInt("font", it).apply() }
                    )
                    "ElementDetay" -> ElementDetailPage(p, elementRows.firstOrNull { it[0] == selectedElement } ?: elementRows.first(), onBack = { page = "Detay" })
                    "Detay" -> CategoryDetail(p, category, onBack = { page = "Kategoriler"; category = "" }, onElement = { selectedElement = it; page = "ElementDetay" })
                    else -> HomePage(p, onOpen = { category = it; page = "Detay" }, onAll = { page = "Kategoriler" })
                }
            }
        }
      }
    }
}

@Composable
private fun Header(p: Palette, title: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("S P E C T R U M", color = p.accent, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text(if (title == "Keşif") "Bilim, keşif ve merak alanı" else title, color = p.muted, fontSize = 12.sp)
        }
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(com.elyionn.spektrum.R.drawable.spectrum_logo),
            contentDescription = "Spectrum logosu",
            modifier = Modifier.size(42.dp).clip(CircleShape)
        )
    }
}

@Composable
private fun Panel(p: Palette, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth()
            .background(p.panel, RoundedCornerShape(20.dp))
            .border(1.dp, p.accent.copy(alpha = .18f), RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}

private val categoryDescriptions = listOf(
    "Biyoloji" to "İnsan vücudu, organlar, hücre, DNA ve canlılık",
    "Uzay" to "Güneş Sistemi, gezegenler, uydular ve derin uzay",
    "Elementler" to "118 element, periyodik tablo ve atom özellikleri",
    "Kimya" to "Atomlar, bağlar, tepkimeler, çözeltiler ve pH",
    "Mikrobiyoloji" to "Bakteriler, virüsler, mantarlar ve mikroskobik yaşam",
    "3B Bilim Laboratuvarı" to "İnsan anatomisi, organ katmanları, moleküller ve etkileşimli bilim modelleri",
    "Fizik & Elektrik" to "Elektrik, hareket, enerji, dalgalar ve manyetizma",
    "Teknoloji" to "Elektronik, sensörler, işlemciler ve modern mühendislik"
)

@Composable
private fun HomePage(p: Palette, onOpen: (String) -> Unit, onAll: () -> Unit) {
    var search by rememberSaveable { mutableStateOf("") }
    val results = categoryDescriptions.filter { it.first.contains(search, true) || it.second.contains(search, true) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel(p, Modifier.heightIn(min = 165.dp)) {
            Text("BİLİM ATLASI  ·  SÜRÜM 1.5", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(10.dp))
            Text("Merak et.\nKeşfet. Öğren.", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = p.text, lineHeight = 35.sp)
            Spacer(Modifier.height(8.dp))
            Text("İnsan bedeninden galaksilere, atomlardan modern teknolojilere uzanan etkileşimli öğrenme alanı.", color = p.muted, lineHeight = 21.sp)
        }
        OutlinedTextField(
            value = search, onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Kategori ara...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(16.dp)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Keşif kategorileri", color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            TextButton(onClick = onAll) { Text("Tümünü gör", color = p.accent) }
        }
        results.forEach { (name, desc) ->
            Panel(p, Modifier.clickable { onOpen(name) }) {
                Text(name, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(desc, color = p.muted, fontSize = 13.sp)
            }
        }
        Text("Elyionn tarafından tasarlanmıştır · Spectrum 1.5", color = p.muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(8.dp))
    }
}

@Composable
private fun CategoryHub(p: Palette, onOpen: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = categoryDescriptions.filter { it.first.contains(query, true) || it.second.contains(query, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text("Bilim alanları", color = p.text, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Text("Bir kategori seçerek kendi bölümüne geç.", color = p.muted)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Kategori veya konu ara") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            filtered.forEach { (name, desc) ->
                Panel(p, Modifier.clickable { onOpen(name) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(p.accent.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                            Icon(categoryIcon(name), null, tint = p.accent)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(desc, color = p.muted, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = p.muted)
                    }
                }
            }
            if (filtered.isEmpty()) Text("Eşleşen kategori bulunamadı.", color = p.muted, modifier = Modifier.padding(12.dp))
        }
    }
}

@Composable
private fun categoryIcon(name: String) = when (name) {
    "Biyoloji" -> Icons.Default.Favorite
    "Uzay" -> Icons.Default.Public
    "Elementler", "Kimya" -> Icons.Default.Science
    "Mikrobiyoloji" -> Icons.Default.Biotech
    "3B Bilim Laboratuvarı" -> Icons.Default.ViewInAr
    "Fizik & Elektrik" -> Icons.Default.Bolt
    "Teknoloji" -> Icons.Default.Memory
    else -> Icons.Default.Explore
}

@Composable
private fun CategoryDetail(p: Palette, category: String, onBack: () -> Unit, onElement: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri", tint = p.accent) }
            Text(category, color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        when (category) {
            "Biyoloji" -> BiologyPage(p)
            "Uzay" -> SpacePage(p)
            "Elementler" -> ElementsPage(p, onElement)
            "Kimya" -> ChemistryPage(p)
            "Fizik & Elektrik" -> PhysicsKnowledgePage(p)
            "Teknoloji" -> TechnologyKnowledgePage(p)
            "Mikrobiyoloji" -> MicrobiologyPage(p)
            "3B Bilim Laboratuvarı" -> VisualAtlasPage(p)
            else -> Text("Kategori bulunamadı.", color = p.text)
        }
    }
}

@Composable
private fun BiologyPage(p: Palette) {
    val systems = listOf(
        "Sinir sistemi" to "Beyin, omurilik ve sinirlerden oluşur. Duyuları işler, hareketleri koordine eder ve organların faaliyetlerini düzenler. Beyincik denge ve hareket koordinasyonunda; beyin sapı solunum ve kalp ritmi gibi yaşamsal işlevlerde rol oynar.",
        "Dolaşım sistemi" to "Kalp, kan ve damarlardan oluşur. Kalbin sağ tarafı kanı akciğerlere, sol tarafı vücuda pompalar. Atardamarlar kanı kalpten uzaklaştırır; toplardamarlar geri taşır; kılcal damarlar oksijen, besin ve atık alışverişini sağlar.",
        "Solunum sistemi" to "Burun ve ağızdan alınan hava yutak, gırtlak, soluk borusu, bronşlar ve bronşçuklardan geçerek alveollere ulaşır. Alveollerde oksijen kana, karbondioksit ise alveol havasına geçer. Diyafram solunumun temel kasıdır.",
        "Sindirim sistemi" to "Ağızda mekanik ve kimyasal sindirim başlar. Yemek borusu besini mideye taşır. Mide asit ve enzimlerle sindirime katkı verir. İnce bağırsak besinlerin büyük bölümünü emer; kalın bağırsak su ve elektrolit emilimine katkıda bulunur. Karaciğer safra üretir, pankreas enzim salgılar.",
        "Kas-iskelet sistemi" to "Kemikler destek ve koruma sağlar; eklemler hareket açıklığını belirler; kaslar kasılarak kuvvet üretir. İskelet kasları istemli hareketlerde, düz kaslar iç organlarda, kalp kası kalpte görev yapar. Kemik iliği kan hücrelerinin üretiminde rol alır.",
        "Üriner sistem" to "Böbreklerdeki nefronlar kanı süzer; gerekli maddeler geri emilir ve bazı maddeler tübüllere salgılanır. Oluşan idrar üreterlerle mesaneye taşınır ve üretradan atılır. Sistem su, elektrolit ve asit-baz dengesine katkı sağlar.",
        "Endokrin sistem" to "Hormonlar aracılığıyla büyüme, metabolizma, stres yanıtı ve iç dengeyi düzenler. Hipofiz, tiroit, paratiroit, pankreas, böbreküstü bezleri ve eşey bezleri önemli bileşenleridir.",
        "Bağışıklık ve lenf sistemi" to "Deri ve mukozalar ilk savunma hattıdır. Doğuştan gelen bağışıklık hızlı ve genel yanıt verir; B ve T lenfositleri kazanılmış bağışıklıkta görev alır. Lenf düğümleri bağışıklık hücrelerinin karşılaşma ve etkinleşme alanlarıdır.",
        "Üreme sistemi" to "Üreme organları gamet üretimi ve üreme işlevlerinde rol oynar. Hormonlar üreme sisteminin gelişimini ve işleyişini düzenler. İnsan gelişimi döllenme, embriyonik gelişim ve doğum sonrası büyüme aşamalarını kapsar.",
        "Deri ve duyu sistemi" to "Deri vücudun dış örtüsüdür; bariyer, sıcaklık düzenleme ve duyu işlevleri görür. Dokunma, basınç, sıcaklık ve ağrı reseptörleri çevreden bilgi alır. Deri epidermis, dermis ve deri altı dokudan oluşur.",
        "Kan ve bağışıklık hücreleri" to "Plazma, alyuvarlar, akyuvarlar ve trombositler kanın temel bileşenleridir. Alyuvarlar oksijen taşır; akyuvarlar savunmada; trombositler pıhtılaşmada görev alır."
    )
    var expanded by rememberSaveable { mutableStateOf("Sinir sistemi") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) {
            Text("İnsan vücudu atlası", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 21.sp)
            Text("Organlar tek başına değil, birlikte çalışan sistemler halinde işlev görür. Aşağıdaki başlıklardan birini açarak temel yapı ve görevleri incele.", color = p.muted)
        }
        Panel(p) {
            Text("3B anatomi modeli", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Modeli parmağınla sürükleyerek döndür. Organlar şematik gösterimdir.", color = p.muted, fontSize = 12.sp)
            Anatomy3DView()
        }
        systems.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == title) "" else title }, verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded == title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == title) { Spacer(Modifier.height(8.dp)); Text(body, color = p.text, lineHeight = 21.sp) }
            }
        }
        Panel(p) {
            Text("Hücreden organizmaya", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Hücreler dokuları, dokular organları, organlar da sistemleri oluşturur. DNA, hücrelerin kalıtsal bilgisinin büyük bölümünü taşır. Proteinler hücre yapısında ve işlevlerinde temel rol oynar.", color = p.text)
        }
    }
}

private data class Planet(val name: String, val type: String, val diameter: String, val year: String, val moons: String, val facts: String, val mission: String)
private val planets = listOf(
    Planet("Merkür","Karasal","4.879 km","88 Dünya günü","0","Güneş'e en yakın gezegendir. Çok ince bir dış gaz örtüsüne sahiptir; gündüz ve gece sıcaklık farkı çok büyüktür. Büyük metalik çekirdeği gezegenin iç yapısında önemli yer tutar.","MESSENGER görevi yüzeyini ve manyetik alanını ayrıntılı haritaladı. BepiColombo Merkür'e yolculuğunu sürdürüyor."),
    Planet("Venüs","Karasal","12.104 km","225 Dünya günü","0","Yoğun karbondioksit atmosferi ve güçlü sera etkisi nedeniyle yüzeyi çok sıcaktır. Sülfürik asit bulutları bulunur. Yavaş ve ters yönlü dönüşüyle dikkat çeker.","Magellan radar haritalaması yaptı; Akatsuki atmosfer dinamiklerini inceledi."),
    Planet("Dünya","Karasal","12.742 km","365,25 gün","1","Yüzeyinde kalıcı sıvı su ve bildiğimiz yaşam bulunur. Atmosferi çoğunlukla azot ve oksijenden oluşur. Manyetik alanı Güneş rüzgârıyla etkileşir.","Çok sayıda uydu atmosferi, okyanusları, iklimi ve yüzeyi izler."),
    Planet("Mars","Karasal","6.779 km","687 Dünya günü","2","Demir oksit yüzeyine kızıl renk verir. Olympus Mons dev bir volkandır; Valles Marineris büyük bir kanyon sistemidir. Eski nehir yatakları ve mineraller geçmişte sıvı su bulunduğunu gösterir.","Curiosity ve Perseverance yüzeyi inceliyor; yörünge araçları haritalama yapıyor."),
    Planet("Jüpiter","Gaz devi","139.820 km","11,86 Dünya yılı","Çok sayıda","En büyük gezegendir; çoğunlukla hidrojen ve helyumdan oluşur. Büyük Kırmızı Leke dev bir fırtınadır. Europa'nın buz altında okyanusu olabileceğine dair güçlü kanıtlar vardır.","Juno gezegenin iç yapısını ve manyetik alanını inceliyor; Europa Clipper Europa'yı araştıracak."),
    Planet("Satürn","Gaz devi","116.460 km","29,4 Dünya yılı","Çok sayıda","Buz ve kaya parçacıklarından oluşan halkalarıyla tanınır. Titan'da metan ve etan gölleri; Enceladus'ta buz altı okyanusuna işaret eden püskürmeler vardır.","Cassini-Huygens görevi Satürn, halkaları ve uyduları hakkında büyük miktarda veri topladı."),
    Planet("Uranüs","Buz devi","50.724 km","84 Dünya yılı","Çok sayıda","Eksen eğikliği yaklaşık 98 derecedir; adeta yan yatmış şekilde döner. Atmosferindeki metan mavi-yeşil görünmesine katkı verir.","Yakından ziyaret eden tek araç Voyager 2'dir. Gelecekte yeni bir yörünge görevi önerilmektedir."),
    Planet("Neptün","Buz devi","49.244 km","165 Dünya yılı","Çok sayıda","Güneş'ten uzaklığı nedeniyle çok az enerji alır. Atmosferinde çok hızlı rüzgârlar ve değişken koyu fırtınalar görülür.","Voyager 2 1989'da yakınından geçti; günümüzde teleskoplarla izlenir.")
)

@Composable
private fun SpacePage(p: Palette) {
    var expanded by rememberSaveable { mutableStateOf("Dünya") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) {
            Text("Güneş Sistemi", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("Güneş'in kütleçekimiyle bağlı sekiz gezegen, cüce gezegenler, uydular, asteroitler ve kuyruklu yıldızlardan oluşur.", color = p.muted)
        }
        planets.forEach { planet ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == planet.name) "" else planet.name }, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(planet.name, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("${planet.type} · ${planet.year}", color = p.muted, fontSize = 12.sp)
                    }
                    Icon(if (expanded == planet.name) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == planet.name) {
                    Spacer(Modifier.height(8.dp))
                    Text("Çap: ${planet.diameter}   ·   Bilinen uydu: ${planet.moons}", color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(planet.facts, color = p.text, lineHeight = 21.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Keşif görevleri: ${planet.mission}", color = p.muted, lineHeight = 19.sp, fontSize = 12.sp)
                }
            }
        }
        Text("Uzay ve astrofizik konuları", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        val spaceTopics = listOf(
            "Güneş'in yapısı" to "Güneş, kütlesinin büyük bölümünü hidrojen ve helyumun oluşturduğu bir yıldızdır. Çekirdeğinde nükleer füzyon enerji üretir.",
            "Ay ve gelgitler" to "Ay'ın kütleçekimi okyanus gelgitlerinin başlıca nedenidir. Güneş'in çekimi de gelgit düzenini etkiler.",
            "Cüce gezegenler" to "Cüce gezegenler Güneş'in çevresinde dolanır ve yaklaşık küresel şekle ulaşacak kütleye sahiptir; yörüngelerinin çevresini temizlememişlerdir.",
            "Asteroitler" to "Asteroitlerin çoğu Mars ile Jüpiter arasındaki ana kuşakta bulunur. Boyutları küçük kaya parçalarından yüzlerce kilometrelik cisimlere kadar değişir.",
            "Kuyruklu yıldızlar" to "Kuyruklu yıldızlar buz, toz ve kaya içerir. Güneş'e yaklaştıklarında ısınan yüzeylerinden gaz ve toz salınır; koma ve kuyruk oluşabilir.",
            "Ötegezegenler" to "Ötegezegenler Güneş dışındaki yıldızların çevresinde dolanır. Geçiş ve dikey hız yöntemleri keşiflerde sık kullanılır.",
            "Yıldızların yaşam döngüsü" to "Yıldızların evrimi başlangıç kütlesine bağlıdır. Son evrelerinde beyaz cüce, nötron yıldızı veya kara delik oluşturabilirler.",
            "Kara delikler" to "Kara delik, olay ufkunun içinden ışığın kaçamadığı uzay-zaman bölgesidir. Çevresindeki madde güçlü kütleçekimsel etkiler gösterebilir.",
            "Galaksiler" to "Galaksiler yıldızlar, gaz, toz, karanlık madde ve diğer bileşenlerden oluşan kütleçekimsel sistemlerdir. Samanyolu çubuklu sarmal galaksidir.",
            "Kozmik uzaklıklar" to "Astronomide astronomik birim, ışık yılı ve parsek kullanılır. Işık yılı zaman değil, ışığın bir yılda aldığı mesafedir."
        )
        spaceTopics.forEach { (title, body) ->
            Panel(p) {
                Text(title, color = p.accent, fontWeight = FontWeight.Bold)
                Text(body, color = p.text, lineHeight = 20.sp)
            }
        }
        Panel(p) {
            Text("Cüce gezegenler ve küçük cisimler", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Plüton, Ceres, Eris, Haumea ve Makemake cüce gezegenler arasında sayılır. Asteroit kuşağı Mars ile Jüpiter arasında; Kuiper Kuşağı ise Neptün ötesinde bulunur. Kuyruklu yıldızlar buz, toz ve kayaçlardan oluşur.", color = p.text)
        }
        Panel(p) {
            Text("3B Uzay gözlemevi", color = p.accent, fontWeight = FontWeight.Bold)
            Text("NASA'nın etkileşimli sayfasında gezegenleri yakınlaştırıp döndürebilirsin.", color = p.muted)
            Text("Sahneyi parmağınla sürükleyerek döndürebilir, yakınlaştırabilir ve gezegenleri seçebilirsin. İnternet bağlantısı gerekir.", color = p.muted, fontSize = 12.sp)
            AndroidView(modifier = Modifier.fillMaxWidth().height(270.dp).clip(RoundedCornerShape(14.dp)), factory = { ctx -> WebView(ctx).apply { webViewClient = WebViewClient(); webChromeClient = WebChromeClient(); settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.loadWithOverviewMode = true; settings.useWideViewPort = true; loadUrl("https://eyes.nasa.gov/apps/solar-system/") } })
        }
    }
}

@Composable
private fun ElementsPage(p: Palette, onElement: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = elementRows.filter { it[0].contains(query, true) || it[1].contains(query, true) || it[2] == query }
    val byNumber = elementRows.associateBy { it[2].toInt() }
    val periodicRows: List<List<Int?>> = listOf(
        listOf<Int?>(1) + List(16) { null } + listOf(2),
        listOf<Int?>(3, 4) + List(10) { null } + listOf(5, 6, 7, 8, 9, 10),
        listOf<Int?>(11, 12) + List(10) { null } + listOf(13, 14, 15, 16, 17, 18),
        (19..36).map { it },
        (37..54).map { it },
        listOf<Int?>(55, 56, null) + (72..86).map { it },
        listOf<Int?>(87, 88, null) + (104..118).map { it },
        listOf<Int?>(null, null, null) + (57..71).map { it },
        listOf<Int?>(null, null, null) + (89..103).map { it }
    )
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Periyodik tablo · 118 element", color = p.text, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text("Tabloyu yatay kaydır. Bir elemente dokunarak ayrı bilgi sayfasını aç.", color = p.muted, fontSize = 12.sp)
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("İsim, sembol veya atom numarası ara") }, shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.height(8.dp))
        if (query.isBlank()) {
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    periodicRows.forEachIndexed { rowIndex, row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            row.forEach { atomicNumber ->
                                val e = atomicNumber?.let { byNumber[it] }
                                if (e == null) {
                                    Spacer(Modifier.size(52.dp, 58.dp))
                                } else {
                                    Card(onClick = { onElement(e[0]) }, modifier = Modifier.size(52.dp, 58.dp), colors = CardDefaults.cardColors(containerColor = p.panel), border = BorderStroke(1.dp, p.accent.copy(alpha = .25f))) {
                                        Column(Modifier.fillMaxSize().padding(4.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(e[2], color = p.muted, fontSize = 8.sp)
                                            Text(e[0], color = p.accent, fontWeight = FontWeight.Black, fontSize = 19.sp)
                                            Text(e[1], color = p.text, fontSize = 8.sp, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Text("Üstteki 7 satır ana grupları, alttaki iki satır lantanitleri ve aktinitleri gösterir.", color = p.muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.weight(1f), contentPadding = PaddingValues(3.dp), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(filtered, key = { it[2] }) { e ->
                    Card(onClick = { onElement(e[0]) }, colors = CardDefaults.cardColors(containerColor = p.panel), border = BorderStroke(1.dp, p.accent.copy(alpha = .28f)), modifier = Modifier.heightIn(min = 88.dp)) {
                        Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(e[2], color = p.muted, fontSize = 10.sp)
                            Text(e[0], color = p.accent, fontWeight = FontWeight.Black, fontSize = 25.sp)
                            Text(e[1], color = p.text, fontSize = 11.sp, maxLines = 1)
                            Text(e[4], color = p.muted, fontSize = 9.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ElementDetailPage(p: Palette, element: List<String>, onBack: () -> Unit) {
    val (symbol, name, number, mass, kind) = element
    val detail = elementDescription(element)
    val electrons = number.toIntOrNull() ?: 1
    val shell = when (electrons) { in 1..2 -> "1"; in 3..10 -> "2, ${electrons-2}"; in 11..18 -> "2, 8, ${electrons-10}"; in 19..36 -> "2, 8, 18, ${electrons-28}"; else -> "Elektron dağılımı elementin alt kabuklarına göre belirlenir." }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri", tint = p.accent) }
            Text("Element dosyası", color = p.text, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Panel(p) {
            Text("ATOM NUMARASI $number", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text(symbol, color = p.text, fontSize = 64.sp, fontWeight = FontWeight.Black)
            Text(name, color = p.accent, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(kind, color = p.muted)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ElementStat(p, "Atom kütlesi", "$mass u")
                ElementStat(p, "Proton", number)
                ElementStat(p, "Elektron", number)
            }
        }
        Panel(p) {
            Text("Element hakkında", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(detail, color = p.text, lineHeight = 22.sp)
        }
        Panel(p) {
            Text("Atomun yapısı", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Atom numarası $number olduğundan çekirdeğinde $number proton bulunur. Nötr atomda elektron sayısı da $number olur. Elektronların enerji düzeylerine dağılımı kimyasal davranışı anlamaya yardımcı olur.", color = p.text, lineHeight = 21.sp)
            Text("Basitleştirilmiş katman gösterimi: $shell", color = p.muted, fontSize = 12.sp)
        }
        Panel(p) {
            Text("Özellikler ve kullanım", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Sınıf: $kind\nGöreli atom kütlesi: $mass u\nAtom numarası: $number", color = p.text, lineHeight = 22.sp)
            Text("Elementin kullanım alanları saf elemente, alaşımlarına ve kimyasal bileşiklerine göre değişebilir. Buradaki açıklamalar genel eğitim bilgisidir.", color = p.muted, fontSize = 12.sp)
        }
        Panel(p) {
            Text("Atomik gösterim", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Bu elementin atom numarası $number'dir. Çekirdek yükü +$number e değerindedir. Gerçek atomlarda elektronlar gezegenler gibi belirli dairesel yörüngelerde dönmez; elektron durumu kuantum orbitalleri ve olasılık dağılımlarıyla tanımlanır.", color = p.text, lineHeight = 21.sp)
        }
    }
}

@Composable
private fun ElementStat(p: Palette, title: String, value: String) {
    Column(Modifier.widthIn(min = 76.dp).background(p.bg.copy(alpha=.5f), RoundedCornerShape(12.dp)).padding(9.dp)) {
        Text(title, color = p.muted, fontSize = 10.sp)
        Text(value, color = p.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

private fun elementDescription(e:List<String>):String { val (s,n,z,m,c)=e;val uses=mapOf("H" to "Yıldızlarda füzyonun temel yakıtıdır; yakıt hücrelerinde ve amonyak üretiminde kullanılır.","He" to "Düşük sıcaklık fiziğinde soğutucu, MRI cihazlarının süperiletken mıknatıslarında ve balonlarda kullanılır.","Li" to "Şarj edilebilir lityum-iyon pillerde, cam-seramiklerde ve bazı alaşımlarda önemli rol oynar.","C" to "Canlı kimyasının temel elementidir. Grafit, elmas ve grafen gibi farklı yapısal biçimleri vardır.","O" to "Hücresel solunumda elektron alıcısıdır; çelik üretimi, tıp ve su arıtma süreçlerinde kullanılır.","N" to "Atmosferin büyük bölümünü oluşturur. Amonyak ve gübre üretiminde, ayrıca inert gaz ortamlarında kullanılır.","Fe" to "Çelik üretiminin ana bileşenidir. Hemoglobindeki demir oksijen taşınmasına katkı verir.","Cu" to "Elektrik ve ısıyı iyi iletir; kablolarda, motorlarda, elektronik devrelerde ve alaşımlarda kullanılır.","Si" to "Yarı iletken teknolojisinin temelidir. Bilgisayar çipleri, güneş hücreleri ve cam üretiminde kullanılır.","Au" to "Korozyona dayanıklı ve iyi iletken olduğu için elektronik bağlantılarda, mücevheratta ve finansal rezervlerde kullanılır.","Ag" to "Metaller arasında çok yüksek elektrik iletkenliğine sahiptir; elektronik, aynalar ve bazı antimikrobiyal uygulamalarda kullanılır.","Al" to "Hafifliği ve korozyon direnci sayesinde ulaşım, yapı, ambalaj ve elektrik iletiminde yaygındır.","Ti" to "Yüksek dayanım/ağırlık oranı ve biyouyumluluğu nedeniyle havacılıkta ve tıbbi implantlarda kullanılır.","U" to "Bazı izotopları nükleer yakıttır. Jeolojide uranyum-kurşun tarihlemesi gibi yöntemlerde de önemlidir.")
val use=uses[s] ?: when(c){"Soygaz"->"Kimyasal tepkimeye girme eğilimi düşüktür. Aydınlatma, koruyucu atmosfer, algılama veya özel optik uygulamalarda kullanılabilir.";"Halojen"->"Tuzlar ve çok sayıda organik bileşik oluşturur. Su arıtma, polimer üretimi ve kimya endüstrisinde farklı bileşikleri önem taşır.";"Alkali metal","Toprak alkali"->"Reaktif metal grubundadır. Saf halde değil, çoğunlukla bileşikleri ve kontrollü endüstriyel süreçleri aracılığıyla kullanılır.";"Lantanit"->"Elektronik, güçlü kalıcı mıknatıslar, optik camlar ve enerji teknolojilerinde kullanılan özel manyetik ve ışıldama özellikleri gösterebilir.";"Aktinit"->"Birçoğu radyoaktiftir. Nükleer bilim, araştırma ve bazı izotopların enerji uygulamalarında önem taşır.";else->"Bu elementin fiziksel ve kimyasal özellikleri alaşımlar, kataliz, elektronik veya özel malzeme tasarımında kullanımını belirler."}
return "$n, atom numarası $z olan $s sembollü elementtir. Göreli atom kütlesi yaklaşık $m u'dur ve sınıflandırması $c olarak verilir. $use Keşif tarihi ve kullanım alanları elementin izotopuna, saflığına ve kimyasal bileşiğine göre değişebilir." }


@Composable
private fun ChemistryPage(p: Palette) {
    val topics = listOf(
        "Atomun yapısı" to "Atom; proton ve nötronlardan oluşan çekirdek ile elektron bulutundan meydana gelir. Proton sayısı elementin kimliğini belirler. Nötron sayısı izotopları, elektron dizilimi ise kimyasal davranışın önemli bölümünü belirler.",
        "Periyodik eğilimler" to "Aynı gruptaki elementlerin değerlik elektron yapıları benzerdir. Atom yarıçapı, iyonlaşma enerjisi ve elektronegatiflik periyodik tabloda düzenli eğilimler gösterir; bu eğilimler elementlerin tepkime davranışını anlamaya yardımcı olur.",
        "Kimyasal bağlar" to "İyonik bağ zıt yüklü iyonların elektrostatik çekimidir. Kovalent bağda atomlar elektron çiftlerini paylaşır. Metalik bağda değerlik elektronları metal yapısı boyunca delokalizedir.",
        "Tepkimeler ve denkleştirme" to "Kimyasal tepkimelerde atomlar yeniden düzenlenir; kapalı sistemlerde toplam atom sayısı ve kütle korunur. Denklem denkleştirme, her elementin atom sayısını iki tarafta eşitler.",
        "Asit, baz ve pH" to "pH sulu çözeltilerin asitlik-bazlık durumunu ifade eden logaritmik bir ölçüdür. 25 °C'de pH 7 nötr kabul edilir; daha düşük değerler asidik, daha yüksek değerler bazik ortamı gösterir.",
        "Çözeltiler ve derişim" to "Çözelti, çözücü içinde dağılmış çözünen maddeden oluşur. Derişim molarite veya yüzde gibi birimlerle ifade edilebilir. Sıcaklık ve maddenin türü çözünürlüğü etkiler.",
        "Organik kimya" to "Karbon bileşiklerinin yapısını, özelliklerini ve tepkimelerini inceler. Hidrokarbonlar, alkoller, karboksilik asitler, esterler ve polimerler önemli bileşik sınıflarıdır.",
        "Kimya ve enerji" to "Ekzotermik tepkimeler çevreye enerji verir; endotermik tepkimeler çevreden enerji alır. Tepkime hızı sıcaklık, derişim, yüzey alanı ve katalizör gibi etkenlerden etkilenebilir.",
        "Laboratuvar güvenliği" to "Etiketler ve güvenlik bilgi formları okunur; koruyucu gözlük ve uygun ekipman kullanılır. Bilinmeyen maddeler karıştırılmaz, maddeler tadılmaz veya doğrudan koklanmaz. Deneyler yalnızca yetkili gözetiminde yapılır.",
        "Kimyasal denge" to "Tersinir tepkimelerde ileri ve geri tepkime hızları eşitlendiğinde dinamik denge oluşur. Derişim, basınç ve sıcaklık değişimleri denge konumunu etkileyebilir.",
        "Elektrokimya" to "Redoks tepkimelerinde elektron aktarımı gerçekleşir. Galvanik hücreler kendiliğinden gerçekleşen tepkimelerden elektrik üretirken elektroliz dış enerjiyle kimyasal dönüşüm sağlar.",
        "Polimerler" to "Polimerler tekrarlayan monomer birimlerinden oluşan büyük moleküllerdir. Doğal örnekler arasında protein ve selüloz; sentetik örnekler arasında polietilen ve naylon bulunur."
    )
    var expanded by rememberSaveable { mutableStateOf("Atomun yapısı") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Kimya", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp); Text("Maddenin yapısını, dönüşümünü ve enerjiyle ilişkisini incele.", color = p.muted) }
        Panel(p) {
            Text("Su molekülü · 3B model", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Model otomatik döner; dokunup sürükleyerek açısını değiştirebilirsin.", color = p.muted, fontSize = 12.sp)
            Molecule3DView()
        }
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == title) "" else title }, verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded == title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == title) { Spacer(Modifier.height(7.dp)); Text(body, color = p.text, lineHeight = 21.sp) }
            }
        }
    }
}

@Composable
private fun MicrobiologyPage(p: Palette) {
    val topics = listOf(
        "Mikroorganizmalara giriş" to "Mikrobiyoloji, mikroorganizmaları ve mikroskobik biyolojik yapıları inceler. Bakteriler ve arkeler prokaryot; maya ve protozoalar ökaryot hücre yapısına sahiptir.",
        "Bakteriler" to "Bakteriler tek hücreli prokaryotlardır. Şekilleri, metabolizmaları ve yaşadıkları ortamlar çeşitlidir. Bazıları insan sağlığı için yararlı roller üstlenirken bazıları hastalıklara neden olabilir.",
        "Virüsler" to "Virüsler hücresel yapıda değildir; genetik materyallerini protein kılıf içinde taşırlar. Çoğalmak için konak hücrelerin mekanizmalarını kullanırlar. Antibiyotikler virüslere karşı etkili değildir.",
        "Mantarlar ve mayalar" to "Mantarlar ökaryot canlılardır. Mayalar tek hücreli, küfler çoğunlukla ipliksi yapılara sahip olabilir. Ayrıştırma, gıda üretimi ve ekosistem döngülerinde önemli görevleri vardır.",
        "Protozoalar ve algler" to "Protozoalar çoğunlukla tek hücreli ökaryotlardır. Algler fotosentez yapabilen çeşitli organizmaları kapsar; su ekosistemlerinde birincil üretime katkı sağlar.",
        "Mikrobiyota" to "İnsan vücudunda ve üzerinde yaşayan mikroorganizma toplulukları mikrobiyotayı oluşturur. Bağırsak mikrobiyotası sindirim, metabolizma ve bağışıklıkla ilişkili işlevlerde rol oynar.",
        "Mikroskopi" to "Işık mikroskopları hücre ve mikroorganizma yapılarını incelemekte kullanılır. Büyütme kadar çözünürlük, örnek hazırlama ve uygun boyama yöntemi de gözlemin kalitesini belirler.",
        "Hücre zarı" to "Fosfolipit çift tabakası seçici geçirgen bir sınır oluşturur. Zar proteinleri madde taşınması, hücre iletişimi ve tanımada görev alır.",
        "Ribozomlar" to "Ribozomlar mRNA bilgisini kullanarak amino asitleri polipeptit zincirlerine bağlar. Hem prokaryot hem ökaryot hücrelerde bulunurlar.",
        "Mitokondri" to "Mitokondriler oksijenli solunumun birçok basamağında ATP üretimine katkı sağlar. Kendi DNA'larına ve çift zarlı yapıya sahiptirler.",
        "Mikrobiyal ekoloji" to "Mikroorganizmalar karbon, azot ve kükürt döngülerinde önemli rol oynar. Toprak ve okyanus ekosistemlerinin işleyişine katkı verir.",
        "Antibiyotik direnci" to "Direnç, bakterilerin bir antibiyotiğe rağmen çoğalabilmesini sağlayan kalıtsal özelliklerle ilişkilidir. Antibiyotiklerin gereksiz veya yanlış kullanımı direnç seçilimini artırabilir."
    )
    var expanded by rememberSaveable { mutableStateOf("Mikroorganizmalara giriş") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Mikrobiyoloji", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp); Text("Mikroskobik dünyanın çeşitliliğini keşfet.", color = p.muted) }
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == title) "" else title }, verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded == title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == title) { Spacer(Modifier.height(7.dp)); Text(body, color = p.text, lineHeight = 21.sp) }
            }
        }
        Panel(p) { Text("Bilimsel not", color = p.accent, fontWeight = FontWeight.Bold); Text("Virüslerin canlı olarak sınıflandırılması tartışmalıdır; hücresel canlılarla aynı grupta değerlendirilmezler.", color = p.text) }
    }
}

@Composable
private fun VisualAtlasPage(p: Palette) {
    var selected by rememberSaveable { mutableStateOf("İnsan anatomisi") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text("3B Bilim Laboratuvarı", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("Harici görsel arama motoru kaldırıldı. Bunun yerine uygulama içindeki etkileşimli modelleri incele. Modelleri sürükleyerek döndürebilir, yakınlaştırabilir ve katmanlarını kontrol edebilirsin.", color = p.muted, lineHeight = 20.sp)
        }
        listOf("İnsan anatomisi", "Su molekülü", "Hücre ve organeller", "Dolaşım sistemi", "Solunum sistemi").forEach { item ->
            FilterChip(selected = selected == item, onClick = { selected = item }, label = { Text(item) })
        }
        when (selected) {
            "İnsan anatomisi" -> Panel(p) { Text("İnsan vücudu · katmanlı model", color = p.accent, fontWeight = FontWeight.Bold); Anatomy3DView() }
            "Su molekülü" -> Panel(p) { Text("H₂O · moleküler geometri", color = p.accent, fontWeight = FontWeight.Bold); Molecule3DView() }
            else -> Panel(p) {
                Text(selected, color = p.accent, fontWeight = FontWeight.Bold)
                Text("Bu başlık için ayrıntılı 3B model geliştirme aşamasındadır. Şimdilik anatomi modelindeki organ katmanlarını kullanarak genel konumları inceleyebilirsin.", color = p.text, lineHeight = 21.sp)
                Anatomy3DView()
            }
        }
        Panel(p) {
            Text("Model doğruluğu hakkında", color = p.accent, fontWeight = FontWeight.Bold)
            Text("İnsan anatomisi modeli eğitim amaçlı şematik bir görselleştirmedir; organların gerçek hacimlerini, damar dallanmalarını ve tüm anatomik varyasyonları temsil etmez. Kesit aracı görsel kırpma uygular, kapalı cerrahi kesit yüzeyi üretmez. Molekül modelinde H–O–H açısı 104,5° olarak tanımlanır; atom boyutları görsel ölçekte normalize edilmiştir.", color = p.text, lineHeight = 20.sp)
        }
    }
}

@Composable
private fun Molecule3DView() {
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>
    *{box-sizing:border-box}body{margin:0;background:#081321;color:#eaf4ff;font:12px Arial}.bar{display:flex;gap:7px;flex-wrap:wrap;padding:8px}.bar button{background:#19334e;color:#dff5ff;border:1px solid #47718d;border-radius:8px;padding:7px 10px}.stage{height:230px;position:relative;overflow:hidden}canvas{width:100%;height:100%;display:block}.note{padding:2px 10px 8px;color:#a9c3dc;line-height:1.4}
    </style></head><body><div class='bar'><button id='spin'>Otomatik döndür: Açık</button><button id='reset'>Görünümü sıfırla</button><button id='bonds'>Bağları göster</button></div><div class='stage' id='stage'><canvas id='c'></canvas></div><div class='note'>H₂O · H–O–H bağ açısı: 104,5°. Şematik küresel model; atom yarıçapları ve bağ uzunlukları görsel ölçekte normalize edilmiştir. Sürükle: döndür · iki parmak/tekerlek: yakınlaş.</div>
    <script src='https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js'></script><script>
    const stage=document.getElementById('stage'),canvas=document.getElementById('c');const scene=new THREE.Scene();scene.background=new THREE.Color(0x081321);const camera=new THREE.PerspectiveCamera(42,1,.1,100);camera.position.set(0,1.2,6.5);const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(stage.clientWidth,stage.clientHeight,false);renderer.outputColorSpace=THREE.SRGBColorSpace;
    scene.add(new THREE.HemisphereLight(0xb9ddff,0x182338,2));const key=new THREE.DirectionalLight(0xffffff,2.4);key.position.set(3,4,5);scene.add(key);const group=new THREE.Group();scene.add(group);
    function atom(r,color,x,y,z){const m=new THREE.Mesh(new THREE.SphereGeometry(r,40,28),new THREE.MeshStandardMaterial({color,roughness:.28,metalness:.08}));m.position.set(x,y,z);group.add(m);return m}
    function bond(a,b,r=.075){const d=new THREE.Vector3().subVectors(b,a),mesh=new THREE.Mesh(new THREE.CylinderGeometry(r,r,d.length(),20),new THREE.MeshStandardMaterial({color:0xa9c9e7,metalness:.35,roughness:.3}));mesh.position.copy(a).add(b).multiplyScalar(.5);mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize());group.add(mesh);return mesh}
    const angle=104.5*Math.PI/180,oh=1.35,half=angle/2;const O=new THREE.Vector3(0,0,0),H1=new THREE.Vector3(-Math.sin(half)*oh,Math.cos(half)*oh,0),H2=new THREE.Vector3(Math.sin(half)*oh,Math.cos(half)*oh,0);
    bond(O,H1);bond(O,H2);atom(.62,0xe34f65,0,0,0);atom(.34,0xeaf4ff,H1.x,H1.y,H1.z);atom(.34,0xeaf4ff,H2.x,H2.y,H2.z);
    let auto=true,drag=false,px=0,py=0;stage.onpointerdown=e=>{drag=true;px=e.clientX;py=e.clientY;stage.setPointerCapture(e.pointerId)};stage.onpointermove=e=>{if(!drag)return;group.rotation.y+=(e.clientX-px)*.008;group.rotation.x+=(e.clientY-py)*.008;px=e.clientX;py=e.clientY};stage.onpointerup=()=>drag=false;stage.onpointercancel=()=>drag=false;stage.onwheel=e=>{camera.position.z=Math.max(3,Math.min(10,camera.position.z+e.deltaY*.005))};document.getElementById('spin').onclick=e=>{auto=!auto;e.target.textContent='Otomatik döndür: '+(auto?'Açık':'Kapalı')};document.getElementById('reset').onclick=()=>{group.rotation.set(0,0,0);camera.position.set(0,1.2,6.5)};document.getElementById('bonds').onclick=e=>{group.children.filter(x=>x.geometry.type==='CylinderGeometry').forEach(x=>x.visible=!x.visible);e.target.textContent=e.target.textContent==='Bağları göster'?'Bağları gizle':'Bağları göster'};
    function resize(){const w=stage.clientWidth,h=stage.clientHeight;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false)}new ResizeObserver(resize).observe(stage);function frame(){requestAnimationFrame(frame);if(auto&&!drag)group.rotation.y+=.003;renderer.render(scene,camera)}frame();
    </script></body></html>"""
    AndroidView(modifier = Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(12.dp)), factory = { ctx -> WebView(ctx).apply { settings.javaScriptEnabled = true; settings.domStorageEnabled = true; setBackgroundColor(android.graphics.Color.TRANSPARENT); loadDataWithBaseURL("https://spectrum.local/", html, "text/html", "UTF-8", null) } })
}

@Composable
private fun Anatomy3DView() {
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>
    *{box-sizing:border-box}body{margin:0;background:#081321;color:#eaf4ff;font:12px Arial}.bar{display:flex;gap:6px;flex-wrap:wrap;padding:7px}.bar button,.bar label{background:#19334e;color:#e4f4ff;border:1px solid #47718d;border-radius:8px;padding:7px 9px}.stage{height:330px;position:relative}canvas{width:100%;height:100%;display:block}.note{padding:2px 10px 8px;color:#a9c3dc;line-height:1.4}
    </style></head><body><div class='bar'><button id='skin'>Dış katman: Açık</button><button id='organs'>Organlar: Açık</button><button id='skeleton'>İskelet: Açık</button><button id='reset'>Sıfırla</button><label>Kesit <input id='cut' type='range' min='-1.5' max='1.5' step='.05' value='1.5'></label></div><div class='stage' id='stage'><canvas id='c'></canvas></div><div class='note'>Eğitim amaçlı şematik 3B anatomi. Sürükle: 360° döndür · tekerlek: yakınlaş · katman düğmeleri: görünürlük. Kesit düzlemi görsel inceleme içindir; anatomik tanı veya cerrahi planlama için kullanılmaz.</div>
    <script src='https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js'></script><script>
    const stage=document.getElementById('stage'),canvas=document.getElementById('c');const scene=new THREE.Scene();scene.background=new THREE.Color(0x081321);const camera=new THREE.PerspectiveCamera(38,1,.1,100);camera.position.set(0,1.1,7.8);const renderer=new THREE.WebGLRenderer({canvas,antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(stage.clientWidth,stage.clientHeight,false);renderer.localClippingEnabled=true;
    scene.add(new THREE.HemisphereLight(0xc5e4ff,0x17243a,2));let light=new THREE.DirectionalLight(0xffffff,2.2);light.position.set(4,5,6);scene.add(light);const root=new THREE.Group();scene.add(root);const skin=new THREE.Group(),organs=new THREE.Group(),bones=new THREE.Group();root.add(skin,organs,bones);
    const clipPlane=new THREE.Plane(new THREE.Vector3(1,0,0),1.5);
    function mat(color,opacity=1){return new THREE.MeshStandardMaterial({color,roughness:.55,metalness:.02,transparent:opacity<1,opacity,side:THREE.DoubleSide,clippingPlanes:[clipPlane]})}
    function ell(group,x,y,z,sx,sy,sz,color,opacity=1){const m=new THREE.Mesh(new THREE.SphereGeometry(1,36,28),mat(color,opacity));m.position.set(x,y,z);m.scale.set(sx,sy,sz);group.add(m);return m}
    function limb(group,a,b,r,color){const va=new THREE.Vector3(...a),vb=new THREE.Vector3(...b),d=vb.clone().sub(va);const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,d.length(),24),mat(color));m.position.copy(va).add(vb).multiplyScalar(.5);m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize());group.add(m)}
    // Outer body silhouette, kept as separate closed primitives for stable surfaces.
    ell(skin,0,1.75,0,.42,.48,.34,0xc58f78,.22);ell(skin,0,.65,0,.72,1.05,.38,0xc58f78,.22);ell(skin,0,-.55,0,.58,.85,.34,0xc58f78,.22);ell(skin,0,2.55,0,.31,.4,.3,0xc58f78,.22);
    limb(skin,[-.48,1.35,0],[-.82,.15,0],.14,0xc58f78);limb(skin,[.48,1.35,0],[.82,.15,0],.14,0xc58f78);limb(skin,[-.3,-.9,0],[-.38,-2.15,0],.19,0xc58f78);limb(skin,[.3,-.9,0],[.38,-2.15,0],.19,0xc58f78);
    // Organs are illustrative volumes positioned within the torso.
    ell(organs,0,2.62,0,.23,.19,.2,0xb58be8);ell(organs,-.19,.95,.13,.18,.34,.17,0x55b9d0);ell(organs,.19,.95,.13,.18,.34,.17,0x55b9d0);ell(organs,.02,.83,.28,.13,.2,.12,0xe34f65);ell(organs,-.12,.35,.1,.34,.17,.22,0xb97843);ell(organs,.15,-.15,.12,.13,.22,.12,0xdaa4c7);ell(organs,-.16,-.15,.12,.13,.22,.12,0xdaa4c7);
    // Simplified skeletal landmarks, separate group for toggling.
    limb(bones,[0,2.2,0],[0,1.1,0],.055,0xe1e8ef);limb(bones,[0,1.1,0],[0,.1,0],.055,0xe1e8ef);limb(bones,[0,.1,0],[0,-.85,0],.07,0xe1e8ef);limb(bones,[-.48,1.35,0],[-.82,.15,0],.065,0xe1e8ef);limb(bones,[.48,1.35,0],[.82,.15,0],.065,0xe1e8ef);limb(bones,[-.3,-.9,0],[-.38,-2.15,0],.075,0xe1e8ef);limb(bones,[.3,-.9,0],[.38,-2.15,0],.075,0xe1e8ef);
    document.getElementById('skin').onclick=e=>{skin.visible=!skin.visible;e.target.textContent='Dış katman: '+(skin.visible?'Açık':'Kapalı')};document.getElementById('organs').onclick=e=>{organs.visible=!organs.visible;e.target.textContent='Organlar: '+(organs.visible?'Açık':'Kapalı')};document.getElementById('skeleton').onclick=e=>{bones.visible=!bones.visible;e.target.textContent='İskelet: '+(bones.visible?'Açık':'Kapalı')};document.getElementById('cut').oninput=e=>{clipPlane.constant=Number(e.target.value)};
    let drag=false,x=0,y=0;stage.onpointerdown=e=>{drag=true;x=e.clientX;y=e.clientY;stage.setPointerCapture(e.pointerId)};stage.onpointermove=e=>{if(!drag)return;root.rotation.y+=(e.clientX-x)*.008;root.rotation.x+=(e.clientY-y)*.006;x=e.clientX;y=e.clientY};stage.onpointerup=()=>drag=false;stage.onpointercancel=()=>drag=false;stage.onwheel=e=>{camera.position.z=Math.max(4,Math.min(13,camera.position.z+e.deltaY*.006))};document.getElementById('reset').onclick=()=>{root.rotation.set(0,0,0);camera.position.set(0,1.1,7.8);document.getElementById('cut').value=1.5;clipPlane.constant=1.5};
    function resize(){let w=stage.clientWidth,h=stage.clientHeight;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false)}new ResizeObserver(resize).observe(stage);function frame(){requestAnimationFrame(frame);renderer.render(scene,camera)}frame();
    </script></body></html>"""
    AndroidView(modifier = Modifier.fillMaxWidth().height(390.dp).clip(RoundedCornerShape(14.dp)), factory = { ctx -> WebView(ctx).apply { settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.allowContentAccess = false; setBackgroundColor(android.graphics.Color.TRANSPARENT); loadDataWithBaseURL("https://spectrum.local/", html, "text/html", "UTF-8", null) } })
}


@Composable
private fun PhysicsKnowledgePage(p: Palette) {
    val topics = listOf("Elektrik yükü ve alan" to "Elektrik yükü maddenin temel özelliklerinden biridir. Aynı işaretli yükler birbirini iter, zıt işaretli yükler birbirini çeker. Elektrik alan, birim pozitif yüke etki eden kuvveti tanımlar.", "Akım, gerilim ve direnç" to "Akım, bir kesitten birim zamanda geçen net yük miktarıdır. Gerilim enerji farkını, direnç ise akıma karşı gösterilen etkiyi ifade eder. Ohm yasası ideal ohmik elemanlarda V=IR biçimindedir.", "Manyetizma" to "Hareketli elektrik yükleri manyetik alan oluşturur. Elektrik akımı taşıyan iletkenler çevresinde manyetik alan meydana gelir; elektromıknatıslar bu ilkeden yararlanır.", "Enerji ve hareket" to "Enerji iş yapabilme kapasitesidir. Kinetik enerji harekete, potansiyel enerji konuma veya etkileşime bağlıdır. Sürtünme gibi süreçlerde mekanik enerji ısıya dönüşebilir.", "Dalgalar ve ışık" to "Dalgalar enerji ve momentum taşır. Ses mekanik dalgadır ve ortam gerektirir; ışık elektromanyetik dalgadır ve boşlukta yayılabilir.", "Newton yasaları" to "Eylemsizlik, ivme ve etki-tepki ilkeleri klasik mekaniğin temelini oluşturur. Net kuvvet, kütle ile ivmenin çarpımına eşittir.", "Momentum" to "Momentum kütle ve hızın çarpımıdır. Yalıtılmış sistemlerde toplam momentum korunur.", "Basınç ve akışkanlar" to "Basınç birim yüzeye etki eden dik kuvvettir. Sıvı basıncı derinlikle artar; akışkanların hareketi yoğunluk ve viskoziteden etkilenir.", "Termodinamik" to "Termodinamik ısı, iş, sıcaklık ve iç enerji arasındaki ilişkileri inceler. Enerjinin korunumu birinci yasa ile ifade edilir.", "Elektromanyetik indüksiyon" to "Değişen manyetik akı bir devrede elektromotor kuvvet oluşturabilir. Jeneratörler bu prensiple mekanik enerjiyi elektrik enerjisine dönüştürür.", "Optik ve kırılma" to "Işık farklı kırılma indislerine sahip ortamların sınırında yön değiştirebilir. Snell yasası n₁ sinθ₁ = n₂ sinθ₂ bağıntısını verir.")
    var open by rememberSaveable { mutableStateOf(topics.first().first) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Fizik ve elektrik", color=p.accent, fontSize=22.sp, fontWeight=FontWeight.Bold); Text("Doğanın temel etkileşimlerini ve enerji dönüşümlerini incele.", color=p.muted) }
        topics.forEach { (t,b) -> Panel(p) { Text(t, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.fillMaxWidth().clickable { open=if(open==t) "" else t }); if(open==t) Text(b, color=p.text, lineHeight=21.sp) } }
    }
}

@Composable
private fun TechnologyKnowledgePage(p: Palette) {
    val topics = listOf("Yarı iletkenler" to "Silisyum gibi yarı iletkenlerin elektriksel iletkenliği katkılama, sıcaklık ve elektrik alanla değiştirilebilir. Diyotlar ve transistörler modern elektroniğin temel yapı taşlarıdır.", "İşlemciler ve bellek" to "İşlemci komutları yürütür ve aritmetik-mantık işlemleri gerçekleştirir. RAM geçici çalışma verilerini tutar; kalıcı depolama veriyi enerji kesildiğinde de korur.", "Sensörler" to "Sensörler sıcaklık, basınç, ivme, ışık veya manyetik alan gibi fiziksel büyüklükleri ölçülebilir sinyallere dönüştürür.", "Robotik ve otomasyon" to "Robotik sistemler algılama, kontrol ve hareket bileşenlerini birleştirir. Geri besleme, sistemin ölçülen çıktıya göre davranışını düzeltmesini sağlar.", "Enerji teknolojileri" to "Güneş hücreleri ışığı elektrik enerjisine dönüştürür. Bataryalar enerjiyi elektrokimyasal süreçlerle depolar; güç elektroniği enerji akışını yönetir.", "İletişim ağları" to "Kablosuz ve kablolu ağlar veriyi protokoller aracılığıyla paketler ve iletir. Gecikme, bant genişliği ve güvenilirlik temel performans ölçütleridir.", "Gömülü sistemler" to "Gömülü bilgisayarlar belirli görevleri yerine getirmek üzere cihazların içine yerleştirilir. Mikrodenetleyici, bellek, giriş-çıkış ve yazılım birlikte çalışır.", "3B baskı" to "Eklemeli üretim, parçaları katmanlar halinde oluşturarak prototipleme ve özel geometrilerin üretimini kolaylaştırır.", "Yapay zekâ" to "Makine öğrenmesi, veriden örüntüler öğrenen modeller geliştirir. Eğitim verisinin niteliği ve modelin değerlendirilmesi sonuçların güvenilirliğini belirler.", "Siber güvenlik" to "Gizlilik, bütünlük ve erişilebilirlik temel güvenlik hedefleridir. Kimlik doğrulama, güncelleme ve güvenli tasarım sistemleri korumaya yardımcı olur.")
    var open by rememberSaveable { mutableStateOf(topics.first().first) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Teknoloji atlası", color=p.accent, fontSize=22.sp, fontWeight=FontWeight.Bold); Text("Elektronikten akıllı sistemlere uzanan temel teknolojiler.", color=p.muted) }
        topics.forEach { (t,b) -> Panel(p) { Text(t, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.fillMaxWidth().clickable { open=if(open==t) "" else t }); if(open==t) Text(b, color=p.text, lineHeight=21.sp) } }
    }
}

@Composable
private fun SettingsPage(p: Palette, selected: Int, soundOn: Boolean, fontIndex: Int, onTheme: (Int) -> Unit, onSound: (Boolean) -> Unit, onFont: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel(p) {
            Text("Görünüm", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text("Temayı yatay kaydırmalı küçük seçeneklerden seç.", color = p.muted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                palettes.forEachIndexed { index, theme ->
                    Column(
                        Modifier.width(74.dp).clip(RoundedCornerShape(13.dp))
                            .border(if (selected == index) 2.dp else 1.dp, if (selected == index) p.accent else p.muted.copy(alpha = .3f), RoundedCornerShape(13.dp))
                            .clickable { onTheme(index) }.padding(7.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.fillMaxWidth().height(30.dp).clip(RoundedCornerShape(8.dp)).background(theme.bg), contentAlignment = Alignment.Center) {
                            Box(Modifier.size(13.dp).clip(CircleShape).background(theme.accent))
                        }
                        Text(theme.name, color = p.text, fontSize = 10.sp, maxLines = 1)
                    }
                }
            }
        }
        Panel(p) {
            Text("Yazı tipi", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Okuma görünümünü seç. Seçim uygulama genelinde saklanır.", color = p.muted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("Standart", "Kitap", "Teknik", "Yuvarlak") .forEachIndexed { index, label ->
                    FilterChip(selected = fontIndex == index, onClick = { onFont(index) }, label = { Text(label, fontSize = 11.sp) })
                }
            }
        }
        Panel(p) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Arayüz sesleri", color = p.accent, fontWeight = FontWeight.Bold)
                    Text("Gezinme ve doğru cevaplarda kısa ses.", color = p.muted, fontSize = 12.sp)
                }
                Switch(checked = soundOn, onCheckedChange = onSound)
            }
        }
        Panel(p) {
            Text("3B modeller", color = p.accent, fontWeight = FontWeight.Bold)
            Text("İnsan anatomisi ve molekül modelleri uygulama içinde üretilir. Güneş Sistemi'nin NASA tabanlı etkileşimli sahnesi internet bağlantısı gerektirir.", color = p.text, lineHeight = 20.sp)
        }
        Panel(p) {
            Text("Uygulama bilgisi", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Spectrum 1.5.0\nElyionn tarafından tasarlanmıştır.\nBilimsel içerikler eğitim amaçlıdır. Sayısal veriler zamanla güncellenebilir.", color = p.text, lineHeight = 21.sp)
        }
    }
}
