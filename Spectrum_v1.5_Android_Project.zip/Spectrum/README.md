# Spectrum 1.5.0

Kotlin + Jetpack Compose Android science atlas.

## Build
- JDK 17
- Android SDK platform 35 and build-tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.3

Run `gradle :app:assembleDebug` from this directory.

## Notes
- 3D anatomy and molecule scenes are interactive WebGL scenes hosted in Android WebView. Three.js is loaded from a CDN, so those scenes require an internet connection on first load.
- The anatomy model is an educational schematic, not a clinically accurate anatomical dataset. Its clipping control is a visual clipping plane and does not generate watertight cut caps.
- The NASA solar-system scene requires an internet connection.
- Scientific content is educational and should not be used for diagnosis or engineering design.
