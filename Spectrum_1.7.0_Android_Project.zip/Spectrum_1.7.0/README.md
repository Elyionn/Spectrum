# Spectrum 1.7.0

Spectrum is an Android science-learning application built with Kotlin, Jetpack Compose and a local Three.js laboratory.

## Build

The GitHub Actions workflow is located at `.github/workflows/android-apk.yml`. It validates the source archive, compiles Kotlin, runs unit tests, builds Debug and Release APKs, and uploads build artifacts.

## App identity
- Application ID: `com.elyionn.spectrum`
- Namespace: `com.elyionn.spektrum`
- Version: `1.7.0` (code 23)

## Main areas
- Science home and category collections
- Structured topic pages and science atlas
- Search and periodic table
- Interactive 3D laboratory
- Dark Observatory, Light Laboratory and Deep Space themes

See `CHANGELOG_1.7.0.md` and `TEST_REPORT_1.7.0.md` for release details and verification limits.
