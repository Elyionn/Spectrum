# Spectrum 1.6.9 — Science Platform

**Version:** `1.6.9` (`versionCode` 22)  
**Application ID:** `com.elyionn.spectrum`  
**Namespace:** `com.elyionn.spektrum`  
**Platform:** Android · Kotlin · Jetpack Compose · local Three.js WebView

Spectrum is an offline-first science learning application. Scientific lessons, periodic-table data, and the Three.js laboratory are bundled locally. The 3D scenes are educational schematics, not clinical, engineering, or scale-accurate simulations unless a lesson explicitly says otherwise.

## 1.6.9 update

- Expanded the Science Atlas from 116 to **151 lessons**.
- Added 35 lessons, five per science category, each with structured explanations, examples, key data and two HTTPS learning references.
- Reworked category lesson navigation into a two-column topic directory instead of a clipped horizontal carousel.
- Reworked lesson details with a core-concept panel, numbered learning map, key-data cards, level selection, examples, formulas and sources.
- Added **35 new Three.js scenes**, bringing the laboratory to 48 selectable scenes across biology, physics, chemistry, mathematics, space, electronics and Earth science.
- Fixed the quadratic graph's plotting bounds so the curve and marker stay inside the graph area and do not run into surrounding labels.
- Reduced WebGL rendering cost on mobile, delayed initial resize until WebView layout, and added context-loss feedback.
- Removed the duplicate category-level lesson shelf presentation; topic navigation now uses a compact, touch-friendly directory.
- Updated app metadata and CI workflow to version 1.6.9 / versionCode 22.

## Build

The GitHub Actions workflow validates the source archive, lesson dataset, periodic table, XML resources and JavaScript syntax; compiles Kotlin, runs unit tests, and builds debug and release APKs. A successful local source check is not a substitute for a successful CI build or physical-device test.
