# Visual asset credits — Spectrum 1.6.2

- `app/src/main/res/drawable-nodpi/space_hero.webp`: original AI-generated Spectrum home hero image, generated for this release and optimized to WebP for Android.
- 3D scene geometry in `app/src/main/assets/lab/index.html`: procedural educational models authored for this Android integration. They are not imported clinical meshes or photogrammetry scans.
- Three.js runtime: see `THIRD_PARTY_NOTICES.md`.
