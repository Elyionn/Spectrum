# Spectrum 1.7.4 — GitHub Actions yükleme

1. Depo ana dizinine `Spectrum_1.7.4_Android_Project.zip` dosyasını yükle.
2. `.github/workflows/` klasörünü oluştur (yoksa).
3. `android-apk.yml` dosyasını bu klasöre yükle; dosya yolu tam olarak `.github/workflows/android-apk.yml` olmalı.
4. GitHub deposunda **Actions** sekmesine gir. `Spectrum 1.7.4 Android Build` iş akışını seçip **Run workflow** düğmesine bas. Ana dala iki dosyayı push etmek de iş akışını tetikler.
5. İşlem tamamlanınca ilgili çalıştırmanın **Artifacts** bölümünden `Spectrum-1.7.4-build-results` dosyasını indirip aç.
6. Telefona kurmak için `app-debug.apk` dosyasını kullan. `app-release-unsigned.apk` imzasızdır; günlük kurulum için `app-debug.apk` kullan. Play Store veya normal dağıtım için release APK'sını kendi imza anahtarınla imzalamalısın.

Not: Derleme iş akışı, kaynak ZIP'i açıp doğrular; projeyi derler, birim testlerini ve Android lint'i çalıştırır. GitHub Actions çıktısı oluşmadan APK'nın başarılı derlendiği varsayılmamalıdır.
