# Spectrum 1.7.4 — Kaynak denetimi

## İncelenen alanlar
- `MainActivity.kt`, Android manifest, Gradle yapılandırması, yerel bilim içeriği, Three.js laboratuvar HTML/JS ve uygulama ikonu.
- 1.7.3 kaynak projesi temel alınmıştır; 1.7.2 arşivi yalnızca önceki kaynak sürümünü karşılaştırmak için kullanılmıştır.

## Bulgu ve düzeltmeler
1. WebGL context kaybı yalnızca kullanıcıya hata metni gösteriyordu. Context geri yüklendiğinde aktif sahneyi yeniden kuran akış eklendi.
2. WebView renderer süreci beklenmedik kapandığında uygulama tarafında renderer ölümü yakalanmıyordu. `onRenderProcessGone` ile bozuk WebView örneği ayrılıp yeniden oluşturuluyor.
3. GPU piksel yükü cihaz piksel yoğunluğuyla büyüyebiliyordu. Renderer pixel ratio 1.0 ile sınırlandı.
4. Yeni kategori işaretleri kategori bazında ziyaret edilme durumunu kalıcı olarak saklayacak şekilde düzenlendi.
5. Tema, font ve uygulama ikonu güncellendi.

## Bilinen doğrulama sınırları
- Bu kaynak paketinden bu çalışma ortamında Android SDK/Gradle tam derlemesi ve fiziksel cihaz testi henüz tamamlanmış sayılmaz.
- WebGL sürücü kaynaklı cihaz özelinde hatalar için CI'da statik testlerin yanında hedef Android cihazda açılış, sahne değiştirme, arka plana alma/geri dönme ve bellek baskısı senaryoları test edilmelidir.
