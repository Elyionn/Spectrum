# Spectrum 1.7.4 — Performans ve kararlılık raporu

## Uygulanan iyileştirmeler
- Three.js renderer piksel oranı 1.0 ile sınırlandı; yüksek yoğunluklu ekranlarda gereksiz GPU piksel yükü azaltıldı.
- Otomatik döndürme kapalıyken yalnızca etkileşim/yeniden boyutlandırma anında tek kare çizilir.
- WebGL context kaybı için geri yükleme akışı eklendi.
- Android WebView renderer süreci kapanırsa Activity sürecini çökertmek yerine WebView yeniden oluşturulur.
- Kategoriye ilk girişte yeni içerik işaretleri SharedPreferences içinde kategori bazında okundu olarak kaydedilir.

## Doğrulama sınırları
- Statik kaynak kontrolleri ve JavaScript sözdizimi doğrulaması CI workflow içinde yürütülür.
- Gerçek GPU/WebGL davranışı cihazın Android System WebView sürümüne, GPU sürücüsüne ve belleğine bağlıdır. Fiziksel cihaz/emülatör testi yapılmadan bütün cihazlarda kesin çalışma garantisi verilemez.
- CI APK üretimi ve test raporları GitHub Actions çalıştırmasında doğrulanacaktır.
