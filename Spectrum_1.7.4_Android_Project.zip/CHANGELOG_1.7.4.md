# Spectrum 1.7.4 — 3D Lab stabilizasyonu, performans ve görünüm

## 3D Lab
- WebGL context kaybında otomatik sahne yenileme ve hazır durum bildirimi eklendi.
- Android WebView renderer sürecinin beklenmedik kapanması yakalanıyor; WebView yeniden oluşturularak uygulama sürecinin kapanması engelleniyor.
- Yeniden dene işlemi, renderer kaybı sonrasında WebView örneğini de yeniden oluşturabiliyor.
- GPU yükünü azaltmak için renderer piksel oranı 1.0 ile sınırlandırıldı; antialias kapalı ve düşük güç tercihi korunuyor.
- Sahne oluşturma ve render hataları yerel hata köprüsüne iletiliyor.

## Performans ve arayüz
- Ayarlara dört yeni koyu tema eklendi; toplam on tema.
- İki yeni sistem yazı tipi seçeneği eklendi; toplam sekiz seçenek.
- Yeni kategori ziyaret edildiğinde o kategoriye ait YENİ/NEW işaretleri kalıcı olarak gizlenir.
- Yeni minimal prizma/ışık simgesi uygulama ikonu olarak ayarlandı.

## Platform ve sürüm
- `versionName`: `1.7.4`
- `versionCode`: `27`
- Android Gradle Plugin `9.3.1`, Gradle `9.7.0`, Kotlin `2.4.21`, build JDK `25`.
- Compile SDK `37`, target SDK `36`, minimum SDK `26`.
- Java bytecode hedefi, eski Android cihazlarla uyumluluk için 17 olarak korundu.
- Application ID ve namespace değişmedi.
