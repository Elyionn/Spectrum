package com.elyionn.spektrum

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private data class Palette(val name: String, val bg: Color, val panel: Color, val accent: Color, val text: Color, val muted: Color)
private val palettes = listOf(
    Palette("Kozmik", Color(0xFF081321), Color(0xFF192D45), Color(0xFF75C8FF), Color(0xFFF0F6FF), Color(0xFFB3C3D5)),
    Palette("Aurora", Color(0xFF071A19), Color(0xFF12332E), Color(0xFF73E0B5), Color(0xFFE8FFF6), Color(0xFFB0D4C8)),
    Palette("Nebula", Color(0xFF180E29), Color(0xFF2D1B49), Color(0xFFC5A0FF), Color(0xFFF6F0FF), Color(0xFFC8B8DD)),
    Palette("Arktik", Color(0xFF101C2B), Color(0xFF203B54), Color(0xFF8DD5FF), Color(0xFFEAF7FF), Color(0xFFB8CCDC)),
    Palette("Laboratuvar", Color(0xFFF1F5F7), Color(0xFFFFFFFF), Color(0xFF087F8C), Color(0xFF17232B), Color(0xFF52616B)),
    Palette("Gün Batımı", Color(0xFF24131A), Color(0xFF42232D), Color(0xFFFFAD83), Color(0xFFFFF1E9), Color(0xFFDCC0B5)),
    Palette("Obsidyen", Color(0xFF101014), Color(0xFF22232B), Color(0xFFFFD166), Color(0xFFF8F7F2), Color(0xFFB9B8C2)),
    Palette("Okyanus", Color(0xFF061B2A), Color(0xFF0E3448), Color(0xFF4DE3D0), Color(0xFFE8FBFF), Color(0xFFA7C9D5)),
    Palette("Lavanta", Color(0xFF211B31), Color(0xFF352A4B), Color(0xFFE0B8FF), Color(0xFFFAF0FF), Color(0xFFC9B9D5)),
    Palette("Zümrüt", Color(0xFF0C211A), Color(0xFF19382B), Color(0xFF9AE6A6), Color(0xFFEFFFF0), Color(0xFFB5D2BC))
)

private val elementRows = listOf(
"H|Hidrojen|1|1.008|Ametal", "He|Helyum|2|4.0026|Soygaz", "Li|Lityum|3|6.94|Alkali metal", "Be|Berilyum|4|9.0122|Toprak alkali", "B|Bor|5|10.81|Yarı metal", "C|Karbon|6|12.011|Ametal", "N|Azot|7|14.007|Ametal", "O|Oksijen|8|15.999|Ametal", "F|Flor|9|18.998|Halojen", "Ne|Neon|10|20.180|Soygaz",
"Na|Sodyum|11|22.990|Alkali metal", "Mg|Magnezyum|12|24.305|Toprak alkali", "Al|Alüminyum|13|26.982|Metal", "Si|Silisyum|14|28.085|Yarı metal", "P|Fosfor|15|30.974|Ametal", "S|Kükürt|16|32.06|Ametal", "Cl|Klor|17|35.45|Halojen", "Ar|Argon|18|39.948|Soygaz",
"K|Potasyum|19|39.098|Alkali metal", "Ca|Kalsiyum|20|40.078|Toprak alkali", "Sc|Skandiyum|21|44.956|Geçiş metali", "Ti|Titanyum|22|47.867|Geçiş metali", "V|Vanadyum|23|50.942|Geçiş metali", "Cr|Krom|24|51.996|Geçiş metali", "Mn|Manganez|25|54.938|Geçiş metali", "Fe|Demir|26|55.845|Geçiş metali", "Co|Kobalt|27|58.933|Geçiş metali", "Ni|Nikel|28|58.693|Geçiş metali", "Cu|Bakır|29|63.546|Geçiş metali", "Zn|Çinko|30|65.38|Geçiş metali", "Ga|Galyum|31|69.723|Metal", "Ge|Germanyum|32|72.630|Yarı metal", "As|Arsenik|33|74.922|Yarı metal", "Se|Selenyum|34|78.971|Ametal", "Br|Brom|35|79.904|Halojen", "Kr|Kripton|36|83.798|Soygaz",
"Rb|Rubidyum|37|85.468|Alkali metal", "Sr|Stronsiyum|38|87.62|Toprak alkali", "Y|İtriyum|39|88.906|Geçiş metali", "Zr|Zirkonyum|40|91.224|Geçiş metali", "Nb|Niyobyum|41|92.906|Geçiş metali", "Mo|Molibden|42|95.95|Geçiş metali", "Tc|Teknesyum|43|98|Geçiş metali", "Ru|Rutenyum|44|101.07|Geçiş metali", "Rh|Rodyum|45|102.91|Geçiş metali", "Pd|Paladyum|46|106.42|Geçiş metali", "Ag|Gümüş|47|107.87|Geçiş metali", "Cd|Kadmiyum|48|112.41|Geçiş metali", "In|İndiyum|49|114.82|Metal", "Sn|Kalay|50|118.71|Metal", "Sb|Antimon|51|121.76|Yarı metal", "Te|Tellür|52|127.60|Yarı metal", "I|İyot|53|126.90|Halojen", "Xe|Ksenon|54|131.29|Soygaz",
"Cs|Sezyum|55|132.91|Alkali metal", "Ba|Baryum|56|137.33|Toprak alkali", "La|Lantan|57|138.91|Lantanit", "Ce|Seryum|58|140.12|Lantanit", "Pr|Praseodim|59|140.91|Lantanit", "Nd|Neodimyum|60|144.24|Lantanit", "Pm|Prometyum|61|145|Lantanit", "Sm|Samaryum|62|150.36|Lantanit", "Eu|Evropiyum|63|151.96|Lantanit", "Gd|Gadolinyum|64|157.25|Lantanit", "Tb|Terbiyum|65|158.93|Lantanit", "Dy|Disprozyum|66|162.50|Lantanit", "Ho|Holmiyum|67|164.93|Lantanit", "Er|Erbiyum|68|167.26|Lantanit", "Tm|Tulyum|69|168.93|Lantanit", "Yb|İterbiyum|70|173.05|Lantanit", "Lu|Lutesyum|71|174.97|Lantanit",
"Hf|Hafniyum|72|178.49|Geçiş metali", "Ta|Tantal|73|180.95|Geçiş metali", "W|Tungsten|74|183.84|Geçiş metali", "Re|Renyum|75|186.21|Geçiş metali", "Os|Osmiyum|76|190.23|Geçiş metali", "Ir|İridyum|77|192.22|Geçiş metali", "Pt|Platin|78|195.08|Geçiş metali", "Au|Altın|79|196.97|Geçiş metali", "Hg|Cıva|80|200.59|Geçiş metali", "Tl|Talyum|81|204.38|Metal", "Pb|Kurşun|82|207.2|Metal", "Bi|Bizmut|83|208.98|Metal", "Po|Polonyum|84|209|Yarı metal", "At|Astatin|85|210|Halojen", "Rn|Radon|86|222|Soygaz",
"Fr|Fransiyum|87|223|Alkali metal", "Ra|Radyum|88|226|Toprak alkali", "Ac|Aktinyum|89|227|Aktinit", "Th|Toryum|90|232.04|Aktinit", "Pa|Protaktinyum|91|231.04|Aktinit", "U|Uranyum|92|238.03|Aktinit", "Np|Neptünyum|93|237|Aktinit", "Pu|Plütonyum|94|244|Aktinit", "Am|Amerikyum|95|243|Aktinit", "Cm|Küriyum|96|247|Aktinit", "Bk|Berkelyum|97|247|Aktinit", "Cf|Kaliforniyum|98|251|Aktinit", "Es|Einsteinyum|99|252|Aktinit", "Fm|Fermiyum|100|257|Aktinit", "Md|Mendelevyum|101|258|Aktinit", "No|Nobelyum|102|259|Aktinit", "Lr|Lavrensiyum|103|266|Aktinit", "Rf|Rutherfordiyum|104|267|Geçiş metali", "Db|Dubniyum|105|268|Geçiş metali", "Sg|Seaborgiyum|106|269|Geçiş metali", "Bh|Bohriyum|107|270|Geçiş metali", "Hs|Hassiyum|108|269|Geçiş metali", "Mt|Meitneriyum|109|278|Bilinmiyor", "Ds|Darmstadtiyum|110|281|Bilinmiyor", "Rg|Röntgenyum|111|282|Bilinmiyor", "Cn|Kopernikyum|112|285|Bilinmiyor", "Nh|Nihonyum|113|286|Bilinmiyor", "Fl|Flerovyum|114|289|Bilinmiyor", "Mc|Moskovyum|115|290|Bilinmiyor", "Lv|Livermoryum|116|293|Bilinmiyor", "Ts|Tennessin|117|294|Halojen", "Og|Oganesson|118|294|Soygaz"
).map { it.split('|') }

private val covalentRadiiPm = intArrayOf(0, 31, 28, 128, 96, 84, 76, 71, 66, 57, 58, 166, 141, 121, 111, 107, 105, 102, 106, 203, 176, 170, 160, 152, 139, 139, 132, 126, 124, 132, 122, 122, 120, 119, 120, 120, 116, 220, 195, 190, 175, 164, 154, 147, 146, 142, 139, 145, 144, 142, 139, 139, 138, 139, 140, 244, 215, 207, 204, 203, 201, 199, 198, 198, 196, 194, 192, 192, 189, 190, 187, 187, 175, 170, 162, 151, 144, 141, 136, 136, 132, 145, 146, 148, 140, 150, 150, 260, 220, 215, 206, 200, 196, 190, 187, 180, 169, 190, 190, 190, 190, 190, 190, 190)
private val englishNames = mapOf("H" to "Hydrogen", "He" to "Helium", "Li" to "Lithium", "Be" to "Beryllium", "B" to "Boron", "C" to "Carbon", "N" to "Nitrogen", "O" to "Oxygen", "F" to "Fluorine", "Ne" to "Neon", "Na" to "Sodium", "Mg" to "Magnesium", "Al" to "Aluminium", "Si" to "Silicon", "P" to "Phosphorus", "S" to "Sulfur", "Cl" to "Chlorine", "Ar" to "Argon", "K" to "Potassium", "Ca" to "Calcium", "Fe" to "Iron", "Cu" to "Copper", "Ag" to "Silver", "Sn" to "Tin", "I" to "Iodine", "Au" to "Gold", "Hg" to "Mercury", "Pb" to "Lead", "U" to "Uranium")
private fun englishElementName(z: Int): String = englishNames[elementRows.firstOrNull { it[2].toIntOrNull() == z }?.get(0)] ?: (elementRows.firstOrNull { it[2].toIntOrNull() == z }?.get(1) ?: "Element")

private fun covalentRadiusPm(z: Int): Int? = if (z in 1..103) covalentRadiiPm.getOrNull(z) else null

private fun elementPeriod(z: Int): Int = when (z) {
    in 1..2 -> 1
    in 3..10 -> 2
    in 11..18 -> 3
    in 19..36 -> 4
    in 37..54 -> 5
    in 55..86 -> 6
    else -> 7
}

private fun elementGroup(z: Int): String = when (z) {
    1 -> "1"; 2 -> "18"
    in 3..4 -> (z - 2).toString()
    in 5..10 -> (z + 8).toString()
    in 11..12 -> (z - 10).toString()
    in 13..18 -> (z + 2).toString()
    in 19..36 -> (z - 18).toString()
    in 37..54 -> (z - 36).toString()
    in 55..56 -> (z - 54).toString()
    in 57..71 -> "3 · f-blok"
    in 72..86 -> (z - 68).toString()
    in 87..88 -> (z - 86).toString()
    in 89..103 -> "3 · f-blok"
    else -> (z - 100).toString()
}

private fun elementBlock(z: Int): String = when {
    z == 2 -> "s"
    z in 57..71 || z in 89..103 -> "f"
    elementGroup(z).substringBefore(" ").toIntOrNull()?.let { it in 1..2 } == true -> "s"
    elementGroup(z).substringBefore(" ").toIntOrNull()?.let { it in 13..18 } == true -> "p"
    else -> "d"
}

private fun elementState(z: Int): String = when (z) {
    1, 2, 7, 8, 9, 10, 17, 18, 36, 54, 86 -> "Gaz (25 °C, 1 atm)"
    35, 80 -> "Sıvı (25 °C, 1 atm)"
    in 104..118 -> "Makroskopik hâli deneysel olarak belirlenemedi"
    else -> "Katı (25 °C, 1 atm)"
}

private fun elementElectronConfig(z: Int): String? = when (z) {
    1 -> "1s¹"; 2 -> "1s²"; 3 -> "[He] 2s¹"; 4 -> "[He] 2s²"
    5 -> "[He] 2s² 2p¹"; 6 -> "[He] 2s² 2p²"; 7 -> "[He] 2s² 2p³"; 8 -> "[He] 2s² 2p⁴"; 9 -> "[He] 2s² 2p⁵"; 10 -> "[He] 2s² 2p⁶"
    11 -> "[Ne] 3s¹"; 12 -> "[Ne] 3s²"; 13 -> "[Ne] 3s² 3p¹"; 14 -> "[Ne] 3s² 3p²"; 15 -> "[Ne] 3s² 3p³"; 16 -> "[Ne] 3s² 3p⁴"; 17 -> "[Ne] 3s² 3p⁵"; 18 -> "[Ne] 3s² 3p⁶"
    19 -> "[Ar] 4s¹"; 20 -> "[Ar] 4s²"; 21 -> "[Ar] 3d¹ 4s²"; 22 -> "[Ar] 3d² 4s²"; 23 -> "[Ar] 3d³ 4s²"; 24 -> "[Ar] 3d⁵ 4s¹"; 25 -> "[Ar] 3d⁵ 4s²"; 26 -> "[Ar] 3d⁶ 4s²"; 27 -> "[Ar] 3d⁷ 4s²"; 28 -> "[Ar] 3d⁸ 4s²"; 29 -> "[Ar] 3d¹⁰ 4s¹"; 30 -> "[Ar] 3d¹⁰ 4s²"
    31 -> "[Ar] 3d¹⁰ 4s² 4p¹"; 32 -> "[Ar] 3d¹⁰ 4s² 4p²"; 33 -> "[Ar] 3d¹⁰ 4s² 4p³"; 34 -> "[Ar] 3d¹⁰ 4s² 4p⁴"; 35 -> "[Ar] 3d¹⁰ 4s² 4p⁵"; 36 -> "[Ar] 3d¹⁰ 4s² 4p⁶"
    47 -> "[Kr] 4d¹⁰ 5s¹"; 53 -> "[Kr] 4d¹⁰ 5s² 5p⁵"; 79 -> "[Xe] 4f¹⁴ 5d¹⁰ 6s¹"; 80 -> "[Xe] 4f¹⁴ 5d¹⁰ 6s²"; 82 -> "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p²"; 92 -> "[Rn] 5f³ 6d¹ 7s²"
    else -> null
}

private fun elementElectronConfigNote(z: Int): String = elementElectronConfig(z)
    ?: if (z >= 104) "Bu süper ağır elementin elektron yapısı teorik hesaplamalara dayanır; deneysel doğrulama sınırlıdır."
    else "Tam orbital dizilimi bu ekranda henüz kaynaklı veriyle doğrulanmadı. Yanlış bir dizilim göstermek yerine alan boş bırakıldı."

private fun elementEducation(e: List<String>): String {
    val symbol = e[0]
    val kind = e[4]
    val known = mapOf(
        "H" to "Hidrojen en hafif elementtir. En yaygın izotopu bir proton ve bir elektrondan oluşur. Yıldızlarda proton-proton zinciri ve diğer füzyon süreçlerinde enerji açığa çıkmasının temel yakıtıdır. Su ve organik bileşiklerin yapısında bulunur.",
        "He" to "Helyumun atom numarası 2'dir ve kapalı 1s² elektron kabuğu nedeniyle kimyasal tepkimeye girme eğilimi çok düşüktür. Çok düşük kaynama sıcaklığı, kriyojenik soğutma ve süperiletken mıknatıs sistemlerinde önemlidir.",
        "Li" to "Lityum en hafif metaldir. Li⁺ iyonlarının elektrotlar arasında hareket edebilmesi, lityum-iyon pillerin şarj ve deşarj mekanizmasının temelidir. Seramik ve cam bileşiklerinde de kullanılır.",
        "C" to "Karbon dört değerlik elektronu sayesinde çok çeşitli kovalent bağlar kurabilir. Elmas, grafit ve grafen aynı elementin farklı allotroplarıdır. Organik kimyanın ve bilinen yaşam kimyasının temel iskeletini oluşturur.",
        "N" to "Azot atmosferin yaklaşık %78'ini N₂ gazı olarak oluşturur. N₂ molekülündeki üçlü bağın koparılması enerji gerektirir. Azot bağlanması ve Haber-Bosch süreci, biyolojik azot döngüsü ile gübre üretiminde önemlidir.",
        "O" to "Oksijen atmosferde O₂ hâlinde bulunur ve aerobik hücresel solunumda elektron alıcısı olarak görev yapar. Oksijenin allotroplarından ozon (O₃), stratosferde Güneş'in morötesi ışınımının bir bölümünü soğurur.",
        "Na" to "Sodyum bir alkali metaldir ve nötr atomunun dış kabuğunda bir 3s elektronu bulunur. Bileşiklerinde çoğunlukla +1 yükseltgenme basamağındadır. Sodyum iyonları sinir hücrelerinin zar potansiyelinde ve sıvı dengesinde rol oynar.",
        "Mg" to "Magnezyum hafif bir toprak alkali metaldir. Klorofil molekülünün merkezinde Mg²⁺ bulunur. Hafif alaşımlar, piroteknik ışık kaynakları ve biyolojik enzim sistemleri açısından önemlidir.",
        "Al" to "Alüminyum düşük yoğunluklu, elektrik ve ısı iletkenliği iyi bir metaldir. Yüzeyinde oluşan ince alüminyum oksit tabakası korozyonu yavaşlatır. Ambalaj, ulaşım, yapı ve elektrik iletiminde kullanılır.",
        "Si" to "Silisyum yarı iletken teknolojisinin temel malzemelerindendir. Kristal yapısına kontrollü katkılama yapılarak p-tipi ve n-tipi bölgeler oluşturulur. Silisyum dioksit ise kum ve birçok camın ana bileşenidir.",
        "P" to "Fosfor DNA ve RNA'nın fosfat omurgasında, ATP'de ve kemik mineralinde bulunur. Elementel fosfor farklı allotroplara sahiptir; beyaz fosfor oldukça reaktif, kırmızı fosfor ise daha kararlıdır.",
        "S" to "Kükürt proteinlerdeki bazı amino asitlerin yapısında bulunur. İki sistein kalıntısı arasında oluşabilen disülfit bağları proteinlerin üç boyutlu yapısını kararlı hâle getirebilir. Sülfürik asit üretimi büyük ölçekli kimya sanayisinin temel süreçlerindendir.",
        "Cl" to "Klor bir halojendir. Cl₂ güçlü bir oksitleyici ve dezenfektan olarak kontrollü su arıtımında kullanılır; klorür iyonu ise sofra tuzu ve canlıların elektrolit dengesinin parçasıdır. Elementel klor ile klorür iyonunun özellikleri aynı değildir.",
        "K" to "Potasyum bir alkali metaldir. K⁺ iyonu hücre içi sıvının başlıca katyonudur ve sinir iletimi, kas işlevi ile hücresel elektriksel dengenin sürdürülmesine katkıda bulunur.",
        "Ca" to "Kalsiyum kemik ve dişlerde hidroksiapatit mineralinin önemli bileşenidir. Ca²⁺ iyonları kas kasılması, hücre içi sinyal iletimi, kan pıhtılaşması ve birçok enzimin düzenlenmesinde görev alır.",
        "Fe" to "Demir geçiş metalidir. Hemoglobindeki hem grubu oksijenin akciğerlerden dokulara taşınmasına yardımcı olur. Demir ayrıca sitokromlar ve elektron taşıma zincirindeki proteinlerde bulunur.",
        "Cu" to "Bakır elektrik ve ısıyı iyi iletir. Elektrik kabloları, motor sargıları ve elektronik bileşenlerde yaygındır. Canlılarda bazı oksidasyon-indirgenme enzimlerinin aktif merkezinde bakır iyonları bulunur.",
        "Zn" to "Çinko birçok enzimin yapısal veya katalitik bileşenidir. Galvanizleme işlemi çeliğin yüzeyini çinko ile kaplayarak korozyona karşı korur. Bileşiklerinde çoğunlukla +2 iyonu oluşturur.",
        "Ag" to "Gümüş görünür ışığı iyi yansıtır ve metaller arasında en yüksek elektrik iletkenliğine sahiptir. Elektronik kontaklar, özel kaplamalar ve bazı fotoğrafçılık kimyasallarında kullanılır.",
        "I" to "İyot tiroit hormonları T₃ ve T₄'ün yapısında bulunur. İyot eksikliği tiroit hormon üretimini etkileyebilir. Elementel iyot ile iyodür tuzları kimyasal açıdan farklı türlerdir.",
        "Au" to "Altın kimyasal olarak görece kararlı ve dövülebilir bir metaldir. Korozyona dayanımı, elektrik kontaklarında güvenilir yüzeyler oluşturmasını sağlar. Mücevherat, elektronik ve bazı kataliz uygulamalarında kullanılır.",
        "Hg" to "Cıva oda sıcaklığında sıvı olan iki elementten biridir. Yoğunluğu yüksektir; ancak cıva ve birçok bileşiği toksiktir. Eski ölçüm cihazlarında kullanılmış olsa da sağlık ve çevre riskleri nedeniyle kullanımı birçok alanda sınırlandırılmıştır.",
        "Pb" to "Kurşun yoğun ve yumuşak bir metaldir. Kurşun-asit akülerde elektrot malzemesi olarak kullanılır. Kurşun ve bileşiklerinin sinir sistemi üzerindeki toksik etkileri nedeniyle maruziyetin önlenmesi gerekir.",
        "U" to "Uranyum doğal olarak bulunan ağır bir aktinittir. U-235 fisil bir izotoptur; U-238 ise uranyum serisinin ve jeokronolojide kullanılan uranyum-kurşun tarihleme yöntemlerinin parçasıdır. İzotopların özellikleri birbirinden ayrılmalıdır."
    )
    return known[symbol] ?: when (kind) {
        "Alkali metal" -> "${e[1]} alkali metaller grubundadır. Bu grupta dış elektron düzeni genel olarak ns¹ biçimindedir ve elementler çoğunlukla +1 iyon oluşturur. Tepkime eğilimleri ve fiziksel özellikleri grupta aşağı doğru değişir. Saf metalin davranışı bileşiklerinin davranışından farklıdır."
        "Toprak alkali" -> "${e[1]} toprak alkali metaller grubundadır. Genel değerlik elektron düzeni ns²'dir ve bileşiklerinde +2 yükseltgenme basamağı yaygındır. Karbonatlar, oksitler ve sülfatlar gibi bileşikleri jeoloji, malzeme bilimi ve endüstride önem taşır."
        "Halojen" -> "${e[1]} halojenler grubundadır. Bu elementlerin değerlik katmanında genel olarak yedi elektron bulunur; birçok bileşikte −1 yükseltgenme basamağı gösterirler. Moleküler hâlleri, reaktiviteleri ve fiziksel durumları grup boyunca değişir."
        "Soygaz" -> "${e[1]} soygazlar grubundadır. Değerlik kabuklarının dolu olması, kimyasal tepkimeye girme eğilimlerini genellikle düşürür. Aydınlatma, koruyucu atmosferler, kriyojenik uygulamalar ve hassas ölçüm sistemlerinde farklı soygazlardan yararlanılır."
        "Lantanit" -> "${e[1]} lantanitler serisindedir. 4f orbitallerinin dolması manyetik, optik ve ışıldama özelliklerinde önemli rol oynar. Bazı lantanitler kalıcı mıknatıslar, fosforlar, lazer malzemeleri ve katalizörlerde kullanılır."
        "Aktinit" -> "${e[1]} aktinitler serisindedir. Bu elementlerin çekirdekleri radyoaktiftir; birçok izotopları yapay olarak üretilir. Nükleer kimya, çekirdek fiziği ve radyokimya araştırmalarında önem taşırlar."
        "Yarı metal" -> "${e[1]} yarı metal olarak sınıflandırılır. Yarı metallerin elektriksel ve kimyasal özellikleri metaller ile ametaller arasında değişebilir. Bazıları yarı iletken, alaşım, cam ve özel kimyasal malzemelerin üretiminde kullanılır."
        "Ametal" -> "${e[1]} ametaldir. Ametaller metalik parlaklık ve iletkenlik özelliklerini genellikle göstermez; kovalent bağlar veya anyonlar oluşturabilir. Elementin moleküler biçimi ve kimyasal tepkimeleri bulunduğu koşullara bağlıdır."
        "Bilinmiyor" -> "${e[1]} süper ağır, yapay olarak sentezlenen bir elementtir. Çok kısa ömürlü izotopları nedeniyle makroskopik örnekleri üzerinde olağan fiziksel ve kimyasal ölçümler yapılamamıştır. Bu nedenle birçok özellik teorik tahmin olarak kalır."
        else -> "${e[1]} bir metal elementidir. Metalik bağ, elektrik iletkenliği, dövülebilirlik ve alaşım oluşturma gibi özellikler gösterebilir. Geçiş metalleri ve p-blok metalleri arasında fiziksel özellikler ile kimyasal davranış önemli ölçüde farklılaşır."
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { SpectrumApp() }
    }
}

@Composable
private fun SpectrumApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("spectrum_settings", Context.MODE_PRIVATE) }
    var page by rememberSaveable { mutableStateOf("Keşif") }
    var category by rememberSaveable { mutableStateOf("") }
    var selectedElement by rememberSaveable { mutableStateOf("H") }
    var fontIndex by rememberSaveable { mutableIntStateOf(prefs.getInt("font", 0).coerceIn(0, 3)) }
    var themeIndex by rememberSaveable { mutableIntStateOf(prefs.getInt("theme", 0).coerceIn(palettes.indices)) }
    var soundOn by rememberSaveable { mutableStateOf(prefs.getBoolean("sound", true)) }
    var language by rememberSaveable { mutableStateOf(prefs.getString("language", "tr") ?: "tr") }
    val english = language == "en"
    val p = palettes[themeIndex]
    val tone = remember { ToneGenerator(AudioManager.STREAM_MUSIC, 35) }
    DisposableEffect(Unit) { onDispose { tone.release() } }
    fun clickSound() { if (soundOn) tone.startTone(ToneGenerator.TONE_PROP_ACK, 55) }
    fun selectSound() { if (soundOn) tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 45) }
    fun confirmSound() { if (soundOn) tone.startTone(ToneGenerator.TONE_PROP_PROMPT, 75) }
    val scheme = if (themeIndex == 4) lightColorScheme(
        primary = p.accent, background = p.bg, surface = p.panel, onSurface = p.text, onBackground = p.text
    ) else darkColorScheme(
        primary = p.accent, background = p.bg, surface = p.panel, onSurface = p.text, onBackground = p.text
    )

    val appFont = when (fontIndex) { 1 -> androidx.compose.ui.text.font.FontFamily.Serif; 2 -> androidx.compose.ui.text.font.FontFamily.Monospace; 3 -> androidx.compose.ui.text.font.FontFamily.Cursive; else -> androidx.compose.ui.text.font.FontFamily.SansSerif }
    MaterialTheme(colorScheme = scheme) {
      androidx.compose.runtime.CompositionLocalProvider(androidx.compose.material3.LocalTextStyle provides androidx.compose.material3.LocalTextStyle.current.copy(fontFamily = appFont)) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = p.bg,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                NavigationBar(
                    containerColor = p.panel,
                    contentColor = p.text
                ) {
                    val items = listOf(
                        Triple("Keşif", Icons.Default.Explore, if (english) "Explore" else "Keşif"),
                        Triple("Kategoriler", Icons.Default.Category, if (english) "Categories" else "Kategoriler"),
                        Triple("Ayarlar", Icons.Default.Settings, if (english) "Settings" else "Ayarlar")
                    )
                    items.forEach { item ->
                        NavigationBarItem(
                            selected = page == item.first || ((page == "Detay" || page == "ElementDetay") && item.first == "Kategoriler"),
                            onClick = { clickSound(); page = item.first; category = "" },
                            icon = { Icon(item.second, contentDescription = item.first) },
                            label = { Text(item.third, fontSize = 11.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = p.accent,
                                selectedTextColor = p.accent,
                                indicatorColor = p.accent.copy(alpha = .16f),
                                unselectedIconColor = p.muted,
                                unselectedTextColor = p.muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).background(p.bg)
            ) {
                Header(p = p, title = when (page) { "Detay" -> category; "ElementDetay" -> selectedElement; else -> if (english) mapOf("Keşif" to "Explore", "Kategoriler" to "Categories", "Ayarlar" to "Settings")[page] ?: page else page })
                when (page) {
                    "Keşif" -> HomePage(p, onOpen = { category = it; page = "Detay" }, onAll = { page = "Kategoriler" })
                    "Kategoriler" -> CategoryHub(p, onOpen = { category = it; page = "Detay" })
                    "Ayarlar" -> SettingsPage(
                        p, themeIndex, soundOn, fontIndex, language,
                        onTheme = { themeIndex = it; prefs.edit().putInt("theme", it).apply(); clickSound() },
                        onSound = { soundOn = it; prefs.edit().putBoolean("sound", it).apply() },
                        onFont = { fontIndex = it; prefs.edit().putInt("font", it).apply() },
                        onLanguage = { language = it; prefs.edit().putString("language", it).apply(); confirmSound() }
                    )
                    "ElementDetay" -> ElementDetailPage(p, elementRows.firstOrNull { it[0] == selectedElement } ?: elementRows.first(), onBack = { page = "Detay" })
                    "Detay" -> CategoryDetail(p, category, english, onBack = { page = "Kategoriler"; category = "" }, onElement = { selectedElement = it; page = "ElementDetay"; selectSound() })
                    else -> HomePage(p, onOpen = { category = it; page = "Detay" }, onAll = { page = "Kategoriler" })
                }
            }
        }
      }
    }
}

@Composable
private fun Header(p: Palette, title: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("S P E C T R U M", color = p.accent, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text(if (title == "Keşif") "Bilim, keşif ve merak alanı" else title, color = p.muted, fontSize = 12.sp)
        }
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(com.elyionn.spektrum.R.drawable.spectrum_logo),
            contentDescription = "Spectrum logosu",
            modifier = Modifier.size(42.dp).clip(CircleShape)
        )
    }
}

@Composable
private fun Panel(p: Palette, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth()
            .background(p.panel, RoundedCornerShape(20.dp))
            .border(1.dp, p.accent.copy(alpha = .18f), RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}

private val categoryDescriptions = listOf(
    "Biyoloji" to "İnsan anatomisi, hücre, DNA, genetik ve canlı sistemleri",
    "Kimya" to "Kimyasal bağlar, tepkimeler, çözeltiler, asitler ve bazlar",
    "Elementler" to "118 element, etkileşimli periyodik tablo ve ayrıntılı element dosyaları",
    "Atomlar" to "Atomun yapısı, orbitaller, elektron dizilimi, iyonlar ve izotoplar",
    "Fizik & Elektrik" to "Kuvvet, hareket, enerji, dalgalar, optik ve elektrik",
    "Uzay" to "Güneş Sistemi, gezegenler, yıldızlar, galaksiler ve kozmoloji",
    "Matematik" to "Sayılar, cebir, geometri, fonksiyonlar ve olasılık",
    "Mikrobiyoloji" to "Bakteriler, virüsler, mantarlar ve mikroskobik yaşam",
    "Teknoloji" to "Elektronik, sensörler, işlemciler ve modern mühendislik",
    "3B Bilim Laboratuvarı" to "İnsan vücudu, atomlar ve molekülleri etkileşimli 3B inceleme"
)

@Composable
private fun HomePage(p: Palette, onOpen: (String) -> Unit, onAll: () -> Unit) {
    var search by rememberSaveable { mutableStateOf("") }
    val results = categoryDescriptions.filter { it.first.contains(search, true) || it.second.contains(search, true) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Panel(p, Modifier.heightIn(min = 178.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("SPECTRUM  ·  BİLİM ATLASI", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(if (english) "Explore science more closely." else "Bilimi daha yakından keşfet.", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = p.text, lineHeight = 30.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(if (english) "Learn · Explore structure · Understand how it works" else "Öğren · Yapıyı incele · Nasıl çalıştığını anla", color = p.muted, lineHeight = 19.sp, fontSize = 12.sp)
                }
                androidx.compose.foundation.Image(painter = androidx.compose.ui.res.painterResource(com.elyionn.spektrum.R.drawable.spectrum_logo), contentDescription = "Spectrum prizma logosu", modifier = Modifier.size(76.dp))
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("3B modeller", "Detaylı bilgi", "Çevrimdışı atlas").forEach { label ->
                    Text(label, color = p.accent, fontSize = 10.sp, modifier = Modifier.background(p.accent.copy(alpha=.10f), RoundedCornerShape(20.dp)).padding(horizontal=9.dp, vertical=6.dp))
                }
            }
        }
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Bilim alanı veya konu ara...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("Keşif alanları", color = p.text, fontWeight = FontWeight.Bold, fontSize = 19.sp); Text("İlgini çeken başlığa dokun.", color = p.muted, fontSize = 11.sp) }
            TextButton(onClick = onAll) { Text("Tümü", color = p.accent) }
        }
        results.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { (name, desc) ->
                    Panel(p, Modifier.weight(1f).heightIn(min = 116.dp).clickable { onOpen(name) }) {
                        Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(p.accent.copy(alpha=.13f)), contentAlignment = Alignment.Center) { Icon(categoryIcon(name), null, tint = p.accent) }
                        Spacer(Modifier.height(8.dp))
                        Text(name, color = p.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(desc, color = p.muted, fontSize = 10.sp, lineHeight = 14.sp, maxLines = 3)
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Text("Elyionn tarafından tasarlanmıştır · Spectrum 1.5.3", color = p.muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(8.dp))
    }
}


@Composable
private fun CategoryHub(p: Palette, onOpen: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = categoryDescriptions.filter { it.first.contains(query, true) || it.second.contains(query, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text("Bilim alanları", color = p.text, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Text("Bir kategori seçerek kendi bölümüne geç.", color = p.muted)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Kategori veya konu ara") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            filtered.forEach { (name, desc) ->
                Panel(p, Modifier.clickable { onOpen(name) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(p.accent.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                            Icon(categoryIcon(name), null, tint = p.accent)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(desc, color = p.muted, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = p.muted)
                    }
                }
            }
            if (filtered.isEmpty()) Text("Eşleşen kategori bulunamadı.", color = p.muted, modifier = Modifier.padding(12.dp))
        }
    }
}

@Composable
private fun categoryIcon(name: String) = when (name) {
    "Biyoloji" -> Icons.Default.Favorite
    "Uzay" -> Icons.Default.Public
    "Elementler", "Kimya", "Atomlar" -> Icons.Default.Science
    "Matematik" -> Icons.Default.Calculate
    "Mikrobiyoloji" -> Icons.Default.Biotech
    "3B Bilim Laboratuvarı" -> Icons.Default.ViewInAr
    "Fizik & Elektrik" -> Icons.Default.Bolt
    "Teknoloji" -> Icons.Default.Memory
    else -> Icons.Default.Explore
}

@Composable
private fun CategoryDetail(p: Palette, category: String, english: Boolean, onBack: () -> Unit, onElement: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri", tint = p.accent) }
            Text(category, color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        when (category) {
            "Biyoloji" -> BiologyPage(p)
            "Uzay" -> SpacePage(p)
            "Elementler" -> ElementsPage(p, english, onElement)
            "Atomlar" -> AtomLabPage(p)
            "Kimya" -> ChemistryPage(p)
            "Matematik" -> MathematicsPage(p)
            "Fizik & Elektrik" -> PhysicsKnowledgePage(p)
            "Teknoloji" -> TechnologyKnowledgePage(p)
            "Mikrobiyoloji" -> MicrobiologyPage(p)
            "3B Bilim Laboratuvarı" -> VisualAtlasPage(p)
            else -> Text("Kategori bulunamadı.", color = p.text)
        }
    }
}

@Composable
private fun LearningTabs(p: Palette, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(p.panel, RoundedCornerShape(14.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        listOf("Özet", "Yapı", "İşleyiş").forEach { tab ->
            Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if(selected==tab) p.accent else Color.Transparent).clickable { onSelect(tab) }.padding(vertical=10.dp), contentAlignment=Alignment.Center) {
                Text(tab, color=if(selected==tab) Color(0xFF071321) else p.text, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
            }
        }
    }
}

@Composable
private fun BiologyPage(p: Palette) {
    var expanded by rememberSaveable { mutableStateOf("Sinir sistemi") }
    var tab by rememberSaveable { mutableStateOf("Özet") }
    val systems = listOf(
        "Sinir sistemi" to "Beyin, omurilik ve sinirlerden oluşur. Duyuları işler, hareketleri koordine eder ve organların faaliyetlerini düzenler.",
        "Dolaşım sistemi" to "Kalp, kan ve damarlardan oluşur. Atardamarlar kanı kalpten uzaklaştırır; toplardamarlar geri taşır; kılcal damarlar madde alışverişini sağlar.",
        "Solunum sistemi" to "Hava, solunum yollarından alveollere ulaşır. Alveollerde oksijen kana, karbondioksit ise alveol havasına geçer. Diyafram temel solunum kasıdır.",
        "Sindirim sistemi" to "Ağızda başlayan sindirim mide ve bağırsaklarda sürer. İnce bağırsak besinlerin büyük bölümünü emer; karaciğer safra üretir, pankreas enzim salgılar.",
        "Kas-iskelet sistemi" to "Kemikler destek ve koruma sağlar; eklemler hareket açıklığını belirler; iskelet kasları kasılarak kuvvet üretir. Kemik iliği kan hücrelerinin üretiminde rol oynar.",
        "Üriner sistem" to "Böbrek nefronları kanı süzer; gerekli maddeler geri emilir. İdrar üreterlerle mesaneye taşınır ve üretradan atılır.",
        "Endokrin sistem" to "Hormonlar büyüme, metabolizma, stres yanıtı ve iç dengeyi düzenler. Hipofiz, tiroit, pankreas ve böbreküstü bezleri önemli bileşenlerdir.",
        "Bağışıklık ve lenf sistemi" to "Deri ve mukozalar ilk savunma hattıdır. Doğuştan gelen ve kazanılmış bağışıklık sistemleri birlikte çalışır.",
        "Üreme sistemi" to "Üreme organları gamet üretimi ve üreme işlevlerinde rol oynar. Hormonlar sistemin gelişimini ve işleyişini düzenler.",
        "Deri ve duyu sistemi" to "Deri bariyer, sıcaklık düzenleme ve duyu işlevleri görür. Epidermis, dermis ve deri altı dokudan oluşur."
    )
    val selectedBody = systems.firstOrNull { it.first == expanded }?.second ?: systems.first().second
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) { Text("İnsan vücudu atlası", color=p.accent, fontWeight=FontWeight.Bold, fontSize=22.sp); Text("Vücudu sistemler halinde incele. Her başlıkta özet, anatomik yapı ve çalışma mekanizması ayrı sunulur.", color=p.muted, lineHeight=19.sp, fontSize=12.sp) }
        LearningTabs(p, tab) { tab=it }
        when(tab) {
            "Özet" -> Panel(p) { Text("İnsan organizması", color=p.accent, fontWeight=FontWeight.Bold); Text("İnsan vücudu; hücre, doku, organ ve organ sistemlerinin birlikte çalıştığı bütünleşik bir biyolojik sistemdir. İç denge (homeostaz), sıcaklık, sıvı, iyon ve enerji dengesinin düzenlenmesiyle korunur.", color=p.text, lineHeight=21.sp) }
            "Yapı" -> Panel(p) { Text("Anatomik organizasyon", color=p.accent, fontWeight=FontWeight.Bold); Text("Hücreler benzer görevli dokuları; dokular organları; organlar da sistemleri oluşturur. Temel doku tipleri epitel, bağ, kas ve sinir dokusudur. Organların konumu ve komşuluk ilişkileri anatomik incelemenin temelidir.", color=p.text, lineHeight=21.sp) }
            else -> Panel(p) { Text("Fizyolojik işleyiş", color=p.accent, fontWeight=FontWeight.Bold); Text("Organ sistemleri sinirsel, hormonal ve yerel geri bildirim mekanizmalarıyla eşgüdüm sağlar. Örneğin solunum ve dolaşım sistemleri birlikte çalışarak oksijeni dokulara taşır ve karbondioksiti uzaklaştırır.", color=p.text, lineHeight=21.sp) }
        }
        Panel(p) { Text("Etkileşimli 3B anatomi", color=p.accent, fontWeight=FontWeight.Bold, fontSize=17.sp); Text("Katmanları açıp kapat; modeli sürükleyerek döndür ve yakınlaştır.", color=p.muted, fontSize=11.sp); Anatomy3DView() }
        Text("Vücut sistemleri", color=p.text, fontWeight=FontWeight.Bold, fontSize=18.sp)
        systems.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded=if(expanded==title) "" else title }, verticalAlignment=Alignment.CenterVertically) {
                    Text(title, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                    Icon(if(expanded==title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.accent)
                }
                if(expanded==title) {
                    Spacer(Modifier.height(8.dp))
                    Text("Özet", color=p.accent, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
                    Text(body, color=p.text, lineHeight=20.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Yapı", color=p.accent, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
                    Text("Bu sistemin temel anatomik bileşenleri organlar, dokular ve bunları birbirine bağlayan damar veya sinir ağlarıdır. Ayrıntılı alt yapılar ilgili anatomi başlıklarında incelenir.", color=p.muted, lineHeight=19.sp, fontSize=12.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("İşleyiş", color=p.accent, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
                    Text("Sistem, diğer organ sistemleriyle madde, enerji veya bilgi alışverişi yaparak organizmanın iç dengesine katkıda bulunur.", color=p.muted, lineHeight=19.sp, fontSize=12.sp)
                }
            }
        }
    }
}


private data class Planet(val name: String, val type: String, val diameter: String, val year: String, val moons: String, val facts: String, val mission: String)
private val planets = listOf(
    Planet("Merkür","Karasal","4.879 km","88 Dünya günü","0","Güneş'e en yakın gezegendir. Çok ince bir dış gaz örtüsüne sahiptir; gündüz ve gece sıcaklık farkı çok büyüktür. Büyük metalik çekirdeği gezegenin iç yapısında önemli yer tutar.","MESSENGER görevi yüzeyini ve manyetik alanını ayrıntılı haritaladı. BepiColombo Merkür'e yolculuğunu sürdürüyor."),
    Planet("Venüs","Karasal","12.104 km","225 Dünya günü","0","Yoğun karbondioksit atmosferi ve güçlü sera etkisi nedeniyle yüzeyi çok sıcaktır. Sülfürik asit bulutları bulunur. Yavaş ve ters yönlü dönüşüyle dikkat çeker.","Magellan radar haritalaması yaptı; Akatsuki atmosfer dinamiklerini inceledi."),
    Planet("Dünya","Karasal","12.742 km","365,25 gün","1","Yüzeyinde kalıcı sıvı su ve bildiğimiz yaşam bulunur. Atmosferi çoğunlukla azot ve oksijenden oluşur. Manyetik alanı Güneş rüzgârıyla etkileşir.","Çok sayıda uydu atmosferi, okyanusları, iklimi ve yüzeyi izler."),
    Planet("Mars","Karasal","6.779 km","687 Dünya günü","2","Demir oksit yüzeyine kızıl renk verir. Olympus Mons dev bir volkandır; Valles Marineris büyük bir kanyon sistemidir. Eski nehir yatakları ve mineraller geçmişte sıvı su bulunduğunu gösterir.","Curiosity ve Perseverance yüzeyi inceliyor; yörünge araçları haritalama yapıyor."),
    Planet("Jüpiter","Gaz devi","139.820 km","11,86 Dünya yılı","Çok sayıda","En büyük gezegendir; çoğunlukla hidrojen ve helyumdan oluşur. Büyük Kırmızı Leke dev bir fırtınadır. Europa'nın buz altında okyanusu olabileceğine dair güçlü kanıtlar vardır.","Juno gezegenin iç yapısını ve manyetik alanını inceliyor; Europa Clipper Europa'yı araştıracak."),
    Planet("Satürn","Gaz devi","116.460 km","29,4 Dünya yılı","Çok sayıda","Buz ve kaya parçacıklarından oluşan halkalarıyla tanınır. Titan'da metan ve etan gölleri; Enceladus'ta buz altı okyanusuna işaret eden püskürmeler vardır.","Cassini-Huygens görevi Satürn, halkaları ve uyduları hakkında büyük miktarda veri topladı."),
    Planet("Uranüs","Buz devi","50.724 km","84 Dünya yılı","Çok sayıda","Eksen eğikliği yaklaşık 98 derecedir; adeta yan yatmış şekilde döner. Atmosferindeki metan mavi-yeşil görünmesine katkı verir.","Yakından ziyaret eden tek araç Voyager 2'dir. Gelecekte yeni bir yörünge görevi önerilmektedir."),
    Planet("Neptün","Buz devi","49.244 km","165 Dünya yılı","Çok sayıda","Güneş'ten uzaklığı nedeniyle çok az enerji alır. Atmosferinde çok hızlı rüzgârlar ve değişken koyu fırtınalar görülür.","Voyager 2 1989'da yakınından geçti; günümüzde teleskoplarla izlenir.")
)

@Composable
private fun SpacePage(p: Palette) {
    var expanded by rememberSaveable { mutableStateOf("Dünya") }
    var spaceTab by rememberSaveable { mutableStateOf("Özet") }
    val topics = listOf(
        "Güneş'in yapısı" to "Güneş, kütlesinin büyük bölümünü hidrojen ve helyumun oluşturduğu bir yıldızdır. Çekirdeğinde proton-proton zinciriyle füzyon gerçekleşir.",
        "Yörüngeler ve kütleçekim" to "Gezegenler, Güneş'in kütleçekim alanında eliptik yörüngelerde hareket eder. Kepler yasaları yörünge geometrisini ve dolanım sürelerini açıklar.",
        "Ay ve gelgitler" to "Ay ve Güneş'in kütleçekimi okyanus gelgitlerini oluşturur. Dünya-Ay sistemi ortak kütle merkezi çevresinde hareket eder.",
        "Asteroitler ve kuyruklu yıldızlar" to "Asteroitler çoğunlukla kayaç ve metal içerir. Kuyruklu yıldızlarda uçucu buzlar bulunur; Güneş'e yaklaşınca gaz ve toz salımı artar.",
        "Cüce gezegenler" to "Cüce gezegenler Güneş çevresinde dolanır, yaklaşık küresel şekildedir ancak yörünge çevresini diğer cisimlerden temizlememiştir.",
        "Ötegezegenler" to "Ötegezegenler başka yıldızların çevresinde dolanır. Geçiş yöntemi yıldız parlaklığındaki düzenli azalmayı, dikey hız yöntemi yıldızın tayfsal salınımını ölçer.",
        "Yıldızların yaşam döngüsü" to "Yıldızların evrimi başlangıç kütlesine bağlıdır. Güneş benzeri yıldızlar sonunda beyaz cüceye dönüşür; daha büyük kütleli yıldızlarda farklı son evreler görülür.",
        "Galaksiler" to "Galaksiler yıldız, gaz, toz ve karanlık madde içeren kütleçekimsel sistemlerdir. Samanyolu çubuklu sarmal galaksidir."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Panel(p) { Text("Güneş Sistemi", color=p.accent, fontWeight=FontWeight.Bold, fontSize=22.sp); Text("Güneş, sekiz gezegen, uydular, cüce gezegenler ve küçük cisimlerden oluşan kütleçekimsel sistem. Model ölçekleri anlaşılır görünüm için normalize edilmiştir.", color=p.muted, lineHeight=19.sp, fontSize=12.sp) }
        Panel(p) { Text("Çevrimdışı 3B gözlemevi", color=p.accent, fontWeight=FontWeight.Bold); Text("Sürükle: sistemi döndür · + / −: yakınlaş · bir gezegene dokun: bilgi seç.", color=p.muted, fontSize=11.sp); SolarSystem3DView() }
        Text("Gezegenler", color=p.text, fontWeight=FontWeight.Bold, fontSize=18.sp)
        planets.forEach { planet ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded=if(expanded==planet.name) "" else planet.name }, verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(planet.name, color=p.accent, fontWeight=FontWeight.Bold, fontSize=16.sp); Text("${planet.type} · yörünge dönemi ${planet.year}", color=p.muted, fontSize=11.sp) }
                    Icon(if(expanded==planet.name) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint=p.accent)
                }
                if(expanded==planet.name) { Spacer(Modifier.height(7.dp)); Text("Çap: ${planet.diameter} · Bilinen uydu: ${planet.moons}", color=p.text, fontWeight=FontWeight.SemiBold, fontSize=12.sp); Text(planet.facts, color=p.text, lineHeight=20.sp); Text("Keşif görevleri: ${planet.mission}", color=p.muted, fontSize=11.sp, lineHeight=18.sp) }
            }
        }
        LearningTabs(p, spaceTab) { spaceTab=it }
        when(spaceTab) {
            "Özet" -> Panel(p) { Text("Güneş Sistemi'nin genel görünümü", color=p.accent, fontWeight=FontWeight.Bold); Text("Güneş Sistemi, merkezindeki Güneş'in kütleçekimiyle bağlı gezegenleri, uyduları ve küçük cisimleri içerir. Gezegenlerin yörüngeleri yaklaşık aynı düzlemde ve aynı yönde bulunur.", color=p.text, lineHeight=20.sp) }
            "Yapı" -> Panel(p) { Text("Sistemin bileşenleri", color=p.accent, fontWeight=FontWeight.Bold); Text("Sistemin merkezinde Güneş yer alır. İçte kayasal gezegenler, dışta gaz ve buz devleri bulunur. Asteroit kuşağı, Kuiper Kuşağı ve Oort Bulutu küçük cisim topluluklarıdır.", color=p.text, lineHeight=20.sp) }
            else -> Panel(p) { Text("Yörünge hareketi", color=p.accent, fontWeight=FontWeight.Bold); Text("Gezegenler kütleçekim etkisiyle eliptik yörüngelerde dolanır. Güneş'e yaklaştıklarında yörünge hızları artar; uzaklaştıklarında azalır. Bu hareket Kepler yasalarıyla açıklanır.", color=p.text, lineHeight=20.sp) }
        }
        Text("Uzay ve astrofizik", color=p.accent, fontWeight=FontWeight.Bold, fontSize=18.sp)
        topics.forEach { (title, body) -> Panel(p) { Text(title, color=p.accent, fontWeight=FontWeight.Bold); Text(body, color=p.text, lineHeight=20.sp) } }
        Panel(p) { Text("Cüce gezegenler ve küçük cisimler", color=p.accent, fontWeight=FontWeight.Bold); Text("Plüton, Ceres, Eris, Haumea ve Makemake cüce gezegenler arasındadır. Ana asteroit kuşağı Mars ile Jüpiter arasında; Kuiper Kuşağı Neptün ötesindedir.", color=p.text, lineHeight=20.sp) }
    }
}

@Composable
private fun SolarSystem3DView() {
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>
    *{box-sizing:border-box}body{margin:0;background:#06111f;color:#eaf4ff;font:12px Arial}.tools{display:flex;gap:7px;padding:8px;align-items:center}.tools button{background:#142b42;color:#eaf4ff;border:1px solid #426b89;border-radius:9px;padding:7px 12px}.stage{height:285px;touch-action:none}canvas{width:100%;height:100%;display:block}.caption{padding:0 10px 8px;color:#a9c3dc;font-size:11px;min-height:18px}
    </style></head><body><div class='tools'><button id='minus'>−</button><button id='plus'>+</button><button id='reset'>Sıfırla</button><span>Çevrimdışı 3B model</span></div><div class='stage' id='stage'><canvas id='c'></canvas></div><div class='caption' id='caption'>Bir gezegene dokunarak seç.</div><script>
    (()=>{const stage=document.getElementById('stage'),c=document.getElementById('c'),ctx=c.getContext('2d');let yaw=-.55,pitch=.38,zoom=1,drag=false,px=0,py=0,selected=-1,anim=0,last=0,raf=0;
    const bodies=[['Merkür',0.42,0.12,'#9a9b9e'],['Venüs',0.72,0.19,'#d9a66b'],['Dünya',1.02,0.20,'#4c9de8'],['Mars',1.36,0.16,'#d56b4d'],['Jüpiter',2.05,0.43,'#d7b58b'],['Satürn',2.75,0.36,'#d8c18b'],['Uranüs',3.43,0.28,'#83d5d4'],['Neptün',4.05,0.27,'#477de0']];
    const stars=Array.from({length:90},(_,i)=>[Math.random(),Math.random(),Math.random()*1.5]);function resize(){const d=Math.min(devicePixelRatio||1,1.5),w=stage.clientWidth,h=stage.clientHeight;c.width=Math.floor(w*d);c.height=Math.floor(h*d);ctx.setTransform(d,0,0,d,0,0);draw()}new ResizeObserver(resize).observe(stage);
    function project(x,y,z){const cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch),xx=x*cy-z*sy,zz=x*sy+z*cy,yy=y*cp-zz*sp,depth=y*sp+zz*cp,scale=Math.min(stage.clientWidth*.44,stage.clientHeight*.80)/5.5*zoom/(1+depth*.035);return [stage.clientWidth/2+xx*scale,stage.clientHeight/2+yy*scale,depth,scale]}
    function sphere(x,y,z,r,col,ring=false){const q=project(x,y,z),rad=Math.max(2,r*q[3]);const g=ctx.createRadialGradient(q[0]-rad*.35,q[1]-rad*.4,1,q[0],q[1],rad*1.2);g.addColorStop(0,'#ffffff');g.addColorStop(.18,col);g.addColorStop(1,'#07101b');ctx.fillStyle=g;ctx.beginPath();ctx.arc(q[0],q[1],rad,0,Math.PI*2);ctx.fill();if(ring){ctx.save();ctx.translate(q[0],q[1]);ctx.rotate(-.25);ctx.strokeStyle='#cbbd9a';ctx.lineWidth=Math.max(2,rad*.22);ctx.beginPath();ctx.ellipse(0,0,rad*1.65,rad*.55,0,0,Math.PI*2);ctx.stroke();ctx.restore()}return q}
    function draw(){const w=stage.clientWidth,h=stage.clientHeight;if(!w||!h)return;ctx.clearRect(0,0,w,h);const bg=ctx.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#07172a');bg.addColorStop(1,'#030914');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);stars.forEach(s=>{ctx.fillStyle='rgba(200,225,255,'+(0.2+s[2]*.25)+')';ctx.fillRect(s[0]*w,s[1]*h,1+s[2]*.4,1+s[2]*.4)});
    const center=project(0,0,0);sphere(0,0,0,.56,'#ffb33d');ctx.save();ctx.shadowColor='#ffb33d';ctx.shadowBlur=22;ctx.strokeStyle='rgba(255,183,73,.25)';ctx.lineWidth=2;ctx.beginPath();ctx.arc(center[0],center[1],center[3]*.9,0,Math.PI*2);ctx.stroke();ctx.restore();
    bodies.forEach((b,i)=>{ctx.strokeStyle='rgba(113,167,212,.24)';ctx.lineWidth=1;ctx.beginPath();for(let j=0;j<=100;j++){const a=j/100*Math.PI*2,q=project(Math.cos(a)*b[1]*1.35,0,Math.sin(a)*b[1]*1.35);if(j===0)ctx.moveTo(q[0],q[1]);else ctx.lineTo(q[0],q[1])}ctx.stroke();const a=anim*(.15+i*.018)+i*.8,x=Math.cos(a)*b[1]*1.35,z=Math.sin(a)*b[1]*1.35,q=sphere(x,0,z,b[2],b[3],i===5);if(selected===i){ctx.strokeStyle='#75d5ff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(q[0],q[1],Math.max(7,b[2]*q[3]+5),0,Math.PI*2);ctx.stroke()} });
    ctx.fillStyle='#b9d5ee';ctx.font='10px Arial';ctx.fillText('GÜNEŞ',center[0]+14,center[1]-16);}
    function frame(t){if(document.hidden)return;if(t-last>40){anim+=.012;draw();last=t}raf=requestAnimationFrame(frame)}raf=requestAnimationFrame(frame);document.addEventListener('visibilitychange',()=>{if(!document.hidden){last=performance.now();cancelAnimationFrame(raf);raf=requestAnimationFrame(frame)}else cancelAnimationFrame(raf)});
    stage.addEventListener('pointerdown',e=>{drag=true;px=e.clientX;py=e.clientY;stage.setPointerCapture(e.pointerId)});stage.addEventListener('pointermove',e=>{if(!drag)return;yaw+=(e.clientX-px)*.008;pitch=Math.max(-1.1,Math.min(1.1,pitch+(e.clientY-py)*.006));px=e.clientX;py=e.clientY;draw()});stage.addEventListener('pointerup',()=>drag=false);stage.addEventListener('pointercancel',()=>drag=false);stage.addEventListener('click',e=>{const x=e.offsetX,y=e.offsetY;let best=1e9; bodies.forEach((b,i)=>{const a=anim*(.15+i*.018)+i*.8,q=project(Math.cos(a)*b[1]*1.35,0,Math.sin(a)*b[1]*1.35),d=Math.hypot(x-q[0],y-q[1]);if(d<best){best=d;selected=i}});if(best<42)document.getElementById('caption').textContent=bodies[selected][0]+' seçildi · yörünge şematik gösterilir.';draw()});document.getElementById('plus').onclick=()=>{zoom=Math.min(2.2,zoom*1.15);draw()};document.getElementById('minus').onclick=()=>{zoom=Math.max(.55,zoom/1.15);draw()};document.getElementById('reset').onclick=()=>{yaw=-.55;pitch=.38;zoom=1;selected=-1;draw()};document.addEventListener('visibilitychange',()=>{if(document.hidden)last=performance.now()});window.addEventListener('pagehide',()=>{cancelAnimationFrame(raf)})})();
    </script></body></html>"""
    AndroidView(modifier=Modifier.fillMaxWidth().height(355.dp).clip(RoundedCornerShape(14.dp)), factory={ctx->WebView(ctx).apply{settings.javaScriptEnabled=true;settings.domStorageEnabled=false;settings.allowFileAccess=false;settings.allowContentAccess=false;setBackgroundColor(android.graphics.Color.TRANSPARENT);loadDataWithBaseURL(null,html,"text/html","UTF-8",null)}}, onRelease={ it.stopLoading(); it.loadUrl("about:blank"); it.removeAllViews(); it.destroy() })
}


@Composable
private fun ElementsPage(p: Palette, english: Boolean, onElement: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var zoom by rememberSaveable { mutableStateOf(1f) }
    val filtered = remember(query) { elementRows.filter { it[0].contains(query, true) || it[1].contains(query, true) || it[2] == query } }
    val byNumber = remember { elementRows.associateBy { it[2].toInt() } }
    val periodicRows: List<List<Int?>> = listOf(
        listOf<Int?>(1) + List(16) { null } + listOf(2),
        listOf<Int?>(3, 4) + List(10) { null } + listOf(5, 6, 7, 8, 9, 10),
        listOf<Int?>(11, 12) + List(10) { null } + listOf(13, 14, 15, 16, 17, 18),
        (19..36).map { it },
        (37..54).map { it },
        listOf<Int?>(55, 56, null) + (72..86).map { it },
        listOf<Int?>(87, 88, null) + (104..118).map { it },
        listOf<Int?>(null, null, null) + (57..71).map { it },
        listOf<Int?>(null, null, null) + (89..103).map { it }
    )
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(if (english) "Periodic table · 118 elements" else "Periyodik tablo · 118 element", color = p.text, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text(if (english) "Pinch-independent zoom: use the slider, then scroll in both directions." else "Kaydırıcıyla yakınlaştırıp uzaklaştır; tabloyu iki yönde kaydır.", color = p.muted, fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { zoom = (zoom - .1f).coerceAtLeast(.65f) }) { Icon(Icons.Default.Remove, "Uzaklaştır", tint=p.accent) }
            Slider(value=zoom, onValueChange={zoom=it}, valueRange=.65f..1.5f, modifier=Modifier.weight(1f))
            IconButton(onClick = { zoom = (zoom + .1f).coerceAtMost(1.5f) }) { Icon(Icons.Default.Add, "Yakınlaştır", tint=p.accent) }
            Text("${(zoom*100).toInt()}%", color=p.muted, fontSize=10.sp)
        }
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text(if (english) "Search name, symbol or atomic number" else "İsim, sembol veya atom numarası ara") }, shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.height(8.dp))
        if (query.isBlank()) {
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        (1..18).forEach { group ->
                            Box(Modifier.size((52*zoom).dp, (20*zoom).dp), contentAlignment = Alignment.Center) { Text(group.toString(), color = p.muted, fontSize = 9.sp) }
                        }
                    }
                    periodicRows.forEachIndexed { rowIndex, row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            row.forEach { atomicNumber ->
                                val e = atomicNumber?.let { byNumber[it] }
                                if (e == null) {
                                    Spacer(Modifier.size((52*zoom).dp, (58*zoom).dp))
                                } else {
                                    Card(onClick = { onElement(e[0]) }, modifier = Modifier.size((52*zoom).dp, (58*zoom).dp), colors = CardDefaults.cardColors(containerColor = p.panel), border = BorderStroke(1.dp, p.accent.copy(alpha = .25f))) {
                                        Column(Modifier.fillMaxSize().padding(4.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(e[2], color = p.muted, fontSize = (8*zoom).sp)
                                            Text(e[0], color = p.accent, fontWeight = FontWeight.Black, fontSize = (19*zoom).sp)
                                            Text(if (english) englishElementName(e[2].toInt()) else e[1], color = p.text, fontSize = (8*zoom).sp, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Text(if (english) "The lower rows show the lanthanoids and actinoids." else "Üstteki 7 satır ana grupları, alttaki iki satır lantanitleri ve aktinitleri gösterir.", color = p.muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.weight(1f), contentPadding = PaddingValues(3.dp), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(filtered, key = { it[2] }) { e ->
                    Card(onClick = { onElement(e[0]) }, colors = CardDefaults.cardColors(containerColor = p.panel), border = BorderStroke(1.dp, p.accent.copy(alpha = .28f)), modifier = Modifier.heightIn(min = 88.dp)) {
                        Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(e[2], color = p.muted, fontSize = 10.sp)
                            Text(e[0], color = p.accent, fontWeight = FontWeight.Black, fontSize = 25.sp)
                            Text(e[1], color = p.text, fontSize = 11.sp, maxLines = 1)
                            Text(e[4], color = p.muted, fontSize = 9.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ElementDetailPage(p: Palette, element: List<String>, onBack: () -> Unit) {
    val (symbol, name, numberText, mass, kind) = element
    val z = numberText.toIntOrNull() ?: 1
    val period = elementPeriod(z)
    val group = elementGroup(z)
    val block = elementBlock(z)
    val config = elementElectronConfigNote(z)
    val radioactive = z == 43 || z == 61 || z >= 83
    val noStableIsotope = z == 43 || z == 61 || z >= 84
    val massLabel = if (noStableIsotope) "[$mass] u*" else "$mass u"
    val detail = elementEducation(element)
    var infoTab by rememberSaveable { mutableStateOf("Özet") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri", tint = p.accent) }
            Text("Element öğrenme dosyası", color = p.text, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
        Panel(p) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ATOM NUMARASI $z", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text(name, color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text(kind, color = p.muted)
                }
                Box(Modifier.size(88.dp).clip(RoundedCornerShape(18.dp)).background(p.accent.copy(alpha = .16f)), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(z.toString(), color = p.muted, fontSize = 11.sp)
                        Text(symbol, color = p.accent, fontSize = 38.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                ElementStat(p, "Atom kütlesi", massLabel)
                ElementStat(p, "Proton", z.toString())
                ElementStat(p, "Elektron*", z.toString())
            }
            Text("* Elektron sayısı nötr atom için verilmiştir. İyonlarda elektron sayısı yük durumuna göre değişir.", color = p.muted, fontSize = 10.sp)
        }
        LearningTabs(p, infoTab) { infoTab = it }
        Panel(p) {
            Text(when(infoTab) { "Özet" -> "Elementin genel tanımı"; "Yapı" -> "Atomik yapı ve sınıflandırma"; else -> "Kimyasal davranış ve işleyiş" }, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(when(infoTab) { "Özet" -> "$name ( $symbol ), atom numarası $z olan kimyasal elementtir. Elementin kimliği proton sayısıyla belirlenir."; "Yapı" -> "Nötr atomda $z proton ve $z elektron bulunur. Nötron sayısı izotopa göre değişir. Elektron dizilimi: $config."; else -> detail }, color = p.text, lineHeight = 21.sp)
        }
        Panel(p) {
            Text("Periyodik tablodaki konumu", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Periyot: $period     Grup: $group     Blok: $block", color = p.text, fontWeight = FontWeight.SemiBold)
            Text("Fiziksel hâl: ${elementState(z)}", color = p.text)
            Text("Kovalent yarıçap: ${covalentRadiusPm(z)?.let { "$it pm" } ?: "güvenilir deneysel değer yok"}", color = p.text)
            Text("Elektron dizilimi: $config", color = p.text, lineHeight = 21.sp)
            Text("Elementin periyodik tablodaki konumu, atom numarası ve elektron yapısıyla ilişkilidir. Aynı gruptaki elementlerin değerlik elektron düzenleri benzer olduğundan bazı kimyasal özellikleri de benzerlik gösterir.", color = p.muted, lineHeight = 20.sp, fontSize = 12.sp)
        }
        Panel(p) {
            Text(if (setOf("H", "He", "Li", "C", "N", "O", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "K", "Ca", "Fe", "Cu", "Zn", "Ag", "I", "Au", "Hg", "Pb", "U").contains(symbol)) "Elementin kimyası ve önemi" else "Element ailesi ve kimyasal bağlam", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(detail, color = p.text, lineHeight = 22.sp)
        }
        Panel(p) {
            Text("Atomun temel parçacıkları", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Proton sayısı: $z\nNötr atomdaki elektron sayısı: $z\nNötron sayısı: seçilen izotopa bağlıdır.", color = p.text, lineHeight = 22.sp)
            Text("Atom numarası elementin kimliğini belirler. Aynı elementin proton sayısı aynı, nötron sayısı farklı olan atomlarına izotop denir. Bu nedenle tek bir nötron sayısı bütün atomlar için geçerli değildir.", color = p.muted, lineHeight = 20.sp, fontSize = 12.sp)
        }
        if (radioactive) Panel(p) {
            Text("Radyoaktivite ve atom kütlesi notu", color = p.accent, fontWeight = FontWeight.Bold)
            Text(if (noStableIsotope) "Bu elementin kararlı izotopu yoktur. Köşeli parantez içindeki sayı, standart atom ağırlığı yerine seçilmiş bir izotopun kütle numarasını belirtir; doğal izotopların ortalama atom ağırlığı gibi yorumlanmamalıdır." else "Bizmutun bilinen izotopları radyoaktiftir; Bi-209 çok uzun yarı ömürlüdür. Bu nedenle tabloda standart atom ağırlığı gösterimi korunur.", color = p.text, lineHeight = 21.sp)
        }
        Panel(p) {
            Text("3B atom modeli", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Atom3DView(p, symbol, z)
            Text("Model, atomun ölçekli veya kuantum-mekanik açıdan tam temsili değildir. Elektronların belirli dairesel yörüngelerde dolaştığı izlenimi vermemek için bu görünüm eğitim amaçlı şematik bir görselleştirmedir.", color = p.muted, fontSize = 11.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun ElementStat(p: Palette, title: String, value: String) {
    Column(Modifier.widthIn(min = 76.dp).background(p.bg.copy(alpha=.5f), RoundedCornerShape(12.dp)).padding(9.dp)) {
        Text(title, color = p.muted, fontSize = 10.sp)
        Text(value, color = p.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}


@Composable
private fun AtomLabPage(p: Palette) {
    var selected by rememberSaveable { mutableIntStateOf(6) }
    val choices = listOf(1, 2, 6, 8, 11, 17, 26, 29, 79, 92)
    val current = elementRows.firstOrNull { it[2].toIntOrNull() == selected } ?: elementRows[5]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel(p) {
            Text("ATOM LABORATUVARI", color = p.accent, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 11.sp)
            Text("Atomu katman katman incele", color = p.text, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("Element seç, çekirdek ve elektron gösterimini incele. Model ölçekli değildir; elektronlar klasik gezegen yörüngelerinde hareket etmez.", color = p.muted, lineHeight = 20.sp)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            choices.forEach { z ->
                val el = elementRows[z - 1]
                FilterChip(selected = selected == z, onClick = { selected = z }, label = { Text(el[0]) })
            }
        }
        Panel(p) {
            Text("${current[1]} (${current[0]})", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text("Atom numarası ${current[2]} · Proton ${current[2]} · Nötr atom elektronu ${current[2]}", color = p.text)
            Atom3DView(p, current[0], selected, isotopeMassFor(selected))
            Text("Elektron dizilimi: ${elementElectronConfigNote(selected)}", color = p.muted, fontSize = 12.sp)
        }
        Panel(p) {
            Text("Atom nasıl tanımlanır?", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Çekirdekte pozitif yüklü protonlar ve yüksüz nötronlar bulunur. Negatif yüklü elektronlar atomun kuantum durumlarını oluşturur. Proton sayısı atom numarasıdır ve elementin kimliğini belirler. Nötron sayısı değişirse izotop, elektron sayısı değişirse iyon oluşur.", color = p.text, lineHeight = 22.sp)
        }
        Panel(p) {
            Text("Orbital fikri", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("s, p, d ve f orbitalleri elektronların bulunma olasılığını tanımlayan kuantum durumlarıdır. Bir orbital en fazla iki elektron barındırır ve bu elektronların spin kuantum sayıları zıttır. Bohr kabuk çizimleri başlangıç düzeyinde yararlı olabilir; ancak atomların gerçek elektron yapısı olasılık dağılımlarıyla açıklanır.", color = p.text, lineHeight = 22.sp)
        }
    }
}

@Composable
private fun MathematicsPage(p: Palette) {
    val topics = listOf(
        "Sayı kümeleri" to "Doğal sayılar, tam sayılar, rasyonel, irrasyonel ve gerçek sayılar farklı özelliklere göre tanımlanır. Her küme bir öncekinin bazı işlemlere göre kapanışını genişletir.",
        "Cebir ve denklemler" to "Denklem, iki ifadenin eşitliğini sağlayan bilinmeyen değerlerini arar. Eşitliğin iki tarafına aynı işlem uygulanırsa çözüm kümesi korunur.",
        "Fonksiyonlar" to "Fonksiyon, tanım kümesindeki her girdiye değer kümesinde tek bir çıktı eşleyen kuraldır. Grafik, tablo, cebirsel ifade ve sözel açıklama aynı ilişkiyi farklı biçimlerde gösterebilir.",
        "Geometri" to "Geometri şekillerin, açıların, uzunlukların, alanların ve hacimlerin ilişkilerini inceler. Öklid geometrisinde üçgen iç açıları toplamı 180 derecedir.",
        "Trigonometri" to "Sinüs, kosinüs ve tanjant açıları kenar oranlarıyla ilişkilendirir. Birim çember, bu oranların dar açıların ötesine nasıl genişlediğini açıklar.",
        "Olasılık ve istatistik" to "Olasılık belirsiz olayların matematiksel ölçüsüdür. İstatistik veri toplama, özetleme, değişkenliği inceleme ve çıkarım yapma yöntemlerini kapsar.",
        "Türev ve integral" to "Türev anlık değişim hızını, integral birikimi ve alan ilişkilerini inceler. Kalkülüs bu iki işlemin temel teoremiyle birbirine bağlanır."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text("MATEMATİK ATLASI", color = p.accent, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 11.sp)
            Text("Tanımlardan modellere", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Kavramları kısa tanım, temel ilişki ve örneklerle sırayla öğren.", color = p.muted)
        }
        var xValue by rememberSaveable { mutableStateOf(1.5f) }
        Panel(p) {
            Text("INTERACTIVE FUNCTION LAB", color=p.accent, fontWeight=FontWeight.Bold, fontSize=11.sp, letterSpacing=1.sp)
            Text("Parabola explorer · y = ax²", color=p.text, fontWeight=FontWeight.Bold, fontSize=18.sp)
            Text("Move x and observe the output. This is a live numerical model, not a static formula card.", color=p.muted, fontSize=12.sp)
            Slider(value=xValue, onValueChange={xValue=it}, valueRange=-4f..4f)
            Text("x = ${"%.2f".format(xValue)}     y = ${"%.2f".format(xValue*xValue)}", color=p.accent, fontWeight=FontWeight.Bold)
            androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(150.dp).background(p.bg, RoundedCornerShape(12.dp)).padding(8.dp)) {
                val midY=size.height/2; val midX=size.width/2; val unit=size.width/9f
                drawLine(p.muted.copy(alpha=.5f), androidx.compose.ui.geometry.Offset(0f,midY), androidx.compose.ui.geometry.Offset(size.width,midY),1.dp.toPx())
                drawLine(p.muted.copy(alpha=.5f), androidx.compose.ui.geometry.Offset(midX,0f), androidx.compose.ui.geometry.Offset(midX,size.height),1.dp.toPx())
                val path=androidx.compose.ui.graphics.Path()
                for(i in 0..120){ val x=-4f+i/15f; val y=x*x; val pt=androidx.compose.ui.geometry.Offset(midX+x*unit, midY-y*unit*.45f); if(i==0)path.moveTo(pt.x,pt.y) else path.lineTo(pt.x,pt.y) }
                drawPath(path,p.accent,style=Stroke(width=3.dp.toPx()))
                drawCircle(Color(0xFFFFC857),5.dp.toPx(),androidx.compose.ui.geometry.Offset(midX+xValue*unit,midY-xValue*xValue*unit*.45f))
            }
        }
        topics.forEachIndexed { index, topic ->
            var expanded by rememberSaveable(topic.first) { mutableStateOf(index == 0) }
            Panel(p, Modifier.clickable { expanded = !expanded }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${index + 1}.", color = p.accent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Text(topic.first, color = p.text, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.muted)
                }
                if (expanded) Text(topic.second, color = p.muted, lineHeight = 21.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
private fun ChemistryPage(p: Palette) {
    val topics = listOf(
        "Atomun yapısı" to "Atom; proton ve nötronlardan oluşan çekirdek ile elektron bulutundan meydana gelir. Proton sayısı elementin kimliğini belirler. Nötron sayısı izotopları, elektron dizilimi ise kimyasal davranışın önemli bölümünü belirler.",
        "Periyodik eğilimler" to "Aynı gruptaki elementlerin değerlik elektron yapıları benzerdir. Atom yarıçapı, iyonlaşma enerjisi ve elektronegatiflik periyodik tabloda düzenli eğilimler gösterir; bu eğilimler elementlerin tepkime davranışını anlamaya yardımcı olur.",
        "Kimyasal bağlar" to "İyonik bağ zıt yüklü iyonların elektrostatik çekimidir. Kovalent bağda atomlar elektron çiftlerini paylaşır. Metalik bağda değerlik elektronları metal yapısı boyunca delokalizedir.",
        "Tepkimeler ve denkleştirme" to "Kimyasal tepkimelerde atomlar yeniden düzenlenir; kapalı sistemlerde toplam atom sayısı ve kütle korunur. Denklem denkleştirme, her elementin atom sayısını iki tarafta eşitler.",
        "Asit, baz ve pH" to "pH sulu çözeltilerin asitlik-bazlık durumunu ifade eden logaritmik bir ölçüdür. 25 °C'de pH 7 nötr kabul edilir; daha düşük değerler asidik, daha yüksek değerler bazik ortamı gösterir.",
        "Çözeltiler ve derişim" to "Çözelti, çözücü içinde dağılmış çözünen maddeden oluşur. Derişim molarite veya yüzde gibi birimlerle ifade edilebilir. Sıcaklık ve maddenin türü çözünürlüğü etkiler.",
        "Organik kimya" to "Karbon bileşiklerinin yapısını, özelliklerini ve tepkimelerini inceler. Hidrokarbonlar, alkoller, karboksilik asitler, esterler ve polimerler önemli bileşik sınıflarıdır.",
        "Kimya ve enerji" to "Ekzotermik tepkimeler çevreye enerji verir; endotermik tepkimeler çevreden enerji alır. Tepkime hızı sıcaklık, derişim, yüzey alanı ve katalizör gibi etkenlerden etkilenebilir.",
        "Laboratuvar güvenliği" to "Etiketler ve güvenlik bilgi formları okunur; koruyucu gözlük ve uygun ekipman kullanılır. Bilinmeyen maddeler karıştırılmaz, maddeler tadılmaz veya doğrudan koklanmaz. Deneyler yalnızca yetkili gözetiminde yapılır.",
        "Kimyasal denge" to "Tersinir tepkimelerde ileri ve geri tepkime hızları eşitlendiğinde dinamik denge oluşur. Derişim, basınç ve sıcaklık değişimleri denge konumunu etkileyebilir.",
        "Elektrokimya" to "Redoks tepkimelerinde elektron aktarımı gerçekleşir. Galvanik hücreler kendiliğinden gerçekleşen tepkimelerden elektrik üretirken elektroliz dış enerjiyle kimyasal dönüşüm sağlar.",
        "Polimerler" to "Polimerler tekrarlayan monomer birimlerinden oluşan büyük moleküllerdir. Doğal örnekler arasında protein ve selüloz; sentetik örnekler arasında polietilen ve naylon bulunur."
    )
    var expanded by rememberSaveable { mutableStateOf("Atomun yapısı") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Kimya", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp); Text("Maddenin yapısını, dönüşümünü ve enerjiyle ilişkisini incele.", color = p.muted) }
        Panel(p) {
            Text("Su molekülü · 3B model", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Model otomatik döner; dokunup sürükleyerek açısını değiştirebilirsin.", color = p.muted, fontSize = 12.sp)
            Molecule3DView()
        }
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == title) "" else title }, verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded == title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == title) { Spacer(Modifier.height(7.dp)); Text(body, color = p.text, lineHeight = 21.sp) }
            }
        }
    }
}

@Composable
private fun MicrobiologyPage(p: Palette) {
    val topics = listOf(
        "Mikroorganizmalara giriş" to "Mikrobiyoloji, mikroorganizmaları ve mikroskobik biyolojik yapıları inceler. Bakteriler ve arkeler prokaryot; maya ve protozoalar ökaryot hücre yapısına sahiptir.",
        "Bakteriler" to "Bakteriler tek hücreli prokaryotlardır. Şekilleri, metabolizmaları ve yaşadıkları ortamlar çeşitlidir. Bazıları insan sağlığı için yararlı roller üstlenirken bazıları hastalıklara neden olabilir.",
        "Virüsler" to "Virüsler hücresel yapıda değildir; genetik materyallerini protein kılıf içinde taşırlar. Çoğalmak için konak hücrelerin mekanizmalarını kullanırlar. Antibiyotikler virüslere karşı etkili değildir.",
        "Mantarlar ve mayalar" to "Mantarlar ökaryot canlılardır. Mayalar tek hücreli, küfler çoğunlukla ipliksi yapılara sahip olabilir. Ayrıştırma, gıda üretimi ve ekosistem döngülerinde önemli görevleri vardır.",
        "Protozoalar ve algler" to "Protozoalar çoğunlukla tek hücreli ökaryotlardır. Algler fotosentez yapabilen çeşitli organizmaları kapsar; su ekosistemlerinde birincil üretime katkı sağlar.",
        "Mikrobiyota" to "İnsan vücudunda ve üzerinde yaşayan mikroorganizma toplulukları mikrobiyotayı oluşturur. Bağırsak mikrobiyotası sindirim, metabolizma ve bağışıklıkla ilişkili işlevlerde rol oynar.",
        "Mikroskopi" to "Işık mikroskopları hücre ve mikroorganizma yapılarını incelemekte kullanılır. Büyütme kadar çözünürlük, örnek hazırlama ve uygun boyama yöntemi de gözlemin kalitesini belirler.",
        "Hücre zarı" to "Fosfolipit çift tabakası seçici geçirgen bir sınır oluşturur. Zar proteinleri madde taşınması, hücre iletişimi ve tanımada görev alır.",
        "Ribozomlar" to "Ribozomlar mRNA bilgisini kullanarak amino asitleri polipeptit zincirlerine bağlar. Hem prokaryot hem ökaryot hücrelerde bulunurlar.",
        "Mitokondri" to "Mitokondriler oksijenli solunumun birçok basamağında ATP üretimine katkı sağlar. Kendi DNA'larına ve çift zarlı yapıya sahiptirler.",
        "Mikrobiyal ekoloji" to "Mikroorganizmalar karbon, azot ve kükürt döngülerinde önemli rol oynar. Toprak ve okyanus ekosistemlerinin işleyişine katkı verir.",
        "Antibiyotik direnci" to "Direnç, bakterilerin bir antibiyotiğe rağmen çoğalabilmesini sağlayan kalıtsal özelliklerle ilişkilidir. Antibiyotiklerin gereksiz veya yanlış kullanımı direnç seçilimini artırabilir."
    )
    var expanded by rememberSaveable { mutableStateOf("Mikroorganizmalara giriş") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Mikrobiyoloji", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp); Text("Mikroskobik dünyanın çeşitliliğini keşfet.", color = p.muted) }
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == title) "" else title }, verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded == title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == title) { Spacer(Modifier.height(7.dp)); Text(body, color = p.text, lineHeight = 21.sp) }
            }
        }
        Panel(p) { Text("Bilimsel not", color = p.accent, fontWeight = FontWeight.Bold); Text("Virüslerin canlı olarak sınıflandırılması tartışmalıdır; hücresel canlılarla aynı grupta değerlendirilmezler.", color = p.text) }
    }
}

@Composable
private fun VisualAtlasPage(p: Palette) {
    var selected by rememberSaveable { mutableStateOf("İnsan anatomisi") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text("3B Bilim Laboratuvarı", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("Harici görsel arama motoru kaldırıldı. Bunun yerine uygulama içindeki etkileşimli modelleri incele. Modelleri sürükleyerek döndürebilir, yakınlaştırabilir ve katmanlarını kontrol edebilirsin.", color = p.muted, lineHeight = 20.sp)
        }
        listOf("İnsan anatomisi", "Su molekülü", "Hücre ve organeller", "Dolaşım sistemi", "Solunum sistemi").forEach { item ->
            FilterChip(selected = selected == item, onClick = { selected = item }, label = { Text(item) })
        }
        when (selected) {
            "İnsan anatomisi" -> Panel(p) { Text("İnsan vücudu · şematik katman modeli", color = p.accent, fontWeight = FontWeight.Bold); Text("Bilgilendirme: Bu çizim gerçek anatomik ölçülere ve organ geometrilerine sahip tıbbi bir model değildir. Katman etkileşimini göstermek için hazırlanmış şematik görselleştirmedir.", color=p.muted, fontSize=11.sp, lineHeight=16.sp); Anatomy3DView() }
            "Su molekülü" -> Panel(p) { Text("H₂O · moleküler geometri", color = p.accent, fontWeight = FontWeight.Bold); Molecule3DView() }
            else -> Panel(p) {
                Text(selected, color = p.accent, fontWeight = FontWeight.Bold)
                Text("Bu başlık için ayrıntılı 3B model geliştirme aşamasındadır. Şimdilik anatomi modelindeki organ katmanlarını kullanarak genel konumları inceleyebilirsin.", color = p.text, lineHeight = 21.sp)
                Anatomy3DView()
            }
        }
        Panel(p) {
            Text("Model doğruluğu hakkında", color = p.accent, fontWeight = FontWeight.Bold)
            Text("İnsan anatomisi modeli eğitim amaçlı şematik bir görselleştirmedir; organların gerçek hacimlerini, damar dallanmalarını ve tüm anatomik varyasyonları temsil etmez. Kesit aracı görsel kırpma uygular, kapalı cerrahi kesit yüzeyi üretmez. Molekül modelinde H–O–H açısı 104,5° olarak tanımlanır; atom boyutları görsel ölçekte normalize edilmiştir.", color = p.text, lineHeight = 20.sp)
        }
    }
}

@Composable
private fun Molecule3DView() {
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>body{margin:0;background:#071525;color:#eaf4ff;font:12px Arial}.tools{padding:8px;display:flex;gap:8px}.tools button{background:#17334e;color:#eaf4ff;border:1px solid #47718d;border-radius:9px;padding:7px 10px}.stage{height:245px;touch-action:none}canvas{width:100%;height:100%;display:block}.note{padding:4px 10px 9px;color:#afc6dc}</style></head><body><div class='tools'><button id='spin'>Döndür: Açık</button><button id='reset'>Sıfırla</button></div><div class='stage' id='stage'><canvas id='c'></canvas></div><div class='note'>H₂O · H–O–H bağ açısı 104,5°. Sürükleyerek döndür.</div><script>(()=>{const st=document.getElementById('stage'),c=document.getElementById('c'),x=c.getContext('2d');let rot=0,tilt=-.2,auto=true,drag=false,px=0,py=0;function size(){let d=Math.min(devicePixelRatio||1,1.5);c.width=st.clientWidth*d;c.height=st.clientHeight*d;x.setTransform(d,0,0,d,0,0);draw()}new ResizeObserver(size).observe(st);function dot(a,b,r,col){let g=x.createRadialGradient(a-r*.35,b-r*.4,1,a,b,r);g.addColorStop(0,'#fff');g.addColorStop(.2,col);g.addColorStop(1,'#07101b');x.fillStyle=g;x.beginPath();x.arc(a,b,r,0,Math.PI*2);x.fill()}function draw(){let w=st.clientWidth,h=st.clientHeight;x.clearRect(0,0,w,h);x.fillStyle='#071525';x.fillRect(0,0,w,h);let cx=w/2,cy=h/2,ang=1.824,rad=Math.min(w,h)*.23;let pts=[{x:0,y:0,z:0,r:rad*.44,c:'#e65b6c',n:'Oksijen'},{x:-Math.sin(ang/2),y:Math.cos(ang/2),z:0,r:rad*.25,c:'#eaf4ff',n:'Hidrojen'},{x:Math.sin(ang/2),y:Math.cos(ang/2),z:0,r:rad*.25,c:'#eaf4ff',n:'Hidrojen'}].map(p=>{let xx=p.x*Math.cos(rot)-p.z*Math.sin(rot),zz=p.x*Math.sin(rot)+p.z*Math.cos(rot),yy=p.y*Math.cos(tilt)-zz*Math.sin(tilt);return {...p,X:cx+xx*rad*1.35,Y:cy-yy*rad*1.35,Z:zz}});x.strokeStyle='#b7d6ee';x.lineWidth=5;x.lineCap='round';pts.slice(1).forEach(p=>{x.beginPath();x.moveTo(pts[0].X,pts[0].Y);x.lineTo(p.X,p.Y);x.stroke()});pts.sort((a,b)=>a.Z-b.Z).forEach(p=>dot(p.X,p.Y,p.r,p.c));x.fillStyle='#c9dced';x.font='11px Arial';x.textAlign='center';x.fillText('O',cx,cy+rad*.75);x.fillText('H',cx-rad*.95,cy-rad*.65);x.fillText('H',cx+rad*.95,cy-rad*.65)}let raf=0,last=0;function frame(t){if(document.hidden)return;if(t-last>33){if(auto&&!drag)rot+=.006;draw();last=t}raf=requestAnimationFrame(frame)}raf=requestAnimationFrame(frame);document.addEventListener('visibilitychange',()=>{if(document.hidden)cancelAnimationFrame(raf);else{last=performance.now();raf=requestAnimationFrame(frame)}});window.addEventListener('pagehide',()=>cancelAnimationFrame(raf));st.onpointerdown=e=>{drag=true;px=e.clientX;py=e.clientY;st.setPointerCapture(e.pointerId)};st.onpointermove=e=>{if(!drag)return;rot+=(e.clientX-px)*.009;tilt+=(e.clientY-py)*.009;px=e.clientX;py=e.clientY};st.onpointerup=()=>drag=false;st.onpointercancel=()=>drag=false;document.getElementById('spin').onclick=e=>{auto=!auto;e.target.textContent='Döndür: '+(auto?'Açık':'Kapalı')};document.getElementById('reset').onclick=()=>{rot=0;tilt=-.2}})()</script></body></html>"""
    AndroidView(modifier=Modifier.fillMaxWidth().height(320.dp).clip(RoundedCornerShape(12.dp)),factory={ctx->WebView(ctx).apply{settings.javaScriptEnabled=true;settings.allowFileAccess=false;settings.allowContentAccess=false;setBackgroundColor(android.graphics.Color.TRANSPARENT);loadDataWithBaseURL(null,html,"text/html","UTF-8",null)}}, onRelease={ it.stopLoading(); it.loadUrl("about:blank"); it.removeAllViews(); it.destroy() })
}


@Composable
private fun Anatomy3DView() {
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>body{margin:0;background:#071525;color:#eaf4ff;font:12px Arial}.tools{display:flex;gap:5px;flex-wrap:wrap;padding:7px;background:#0c2035}.tools button{background:#18364f;color:#eaf4ff;border:1px solid #456d8a;border-radius:8px;padding:7px 9px}.tools button.off{opacity:.38}.stage{height:380px;touch-action:none}canvas{width:100%;height:100%;display:block}.hint{padding:7px 10px;color:#adc5dc;line-height:1.4}</style></head><body><div class='tools'><button data-k='bones'>Kemik</button><button data-k='muscles'>Kas</button><button data-k='vessels'>Damar</button><button data-k='organs'>Organ</button><button data-k='nerves'>Sinir</button><button data-k='skin'>Dış katman</button><button id='front'>Ön</button><button id='side'>Yan</button><button id='reset'>Sıfırla</button></div><div class='stage' id='stage'><canvas id='c'></canvas></div><div class='hint' id='hint'>Katmanları seç. Sürükle: döndür · yakınlaştırma için iki parmak hareketi.</div><script>(()=>{const st=document.getElementById('stage'),c=document.getElementById('c'),ctx=c.getContext('2d');let yaw=0,zoom=1,drag=false,px=0,py=0;const on={bones:true,muscles:true,vessels:true,organs:true,nerves:true,skin:false};function resize(){let d=Math.min(devicePixelRatio||1,1.5);c.width=st.clientWidth*d;c.height=st.clientHeight*d;ctx.setTransform(d,0,0,d,0,0);draw()}new ResizeObserver(resize).observe(st);function path(points,color,width){ctx.beginPath();points.forEach((p,i)=>{let x=st.clientWidth/2+(p[0]*Math.cos(yaw)-p[2]*Math.sin(yaw))*zoom,y=st.clientHeight*.49+p[1]*zoom;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)});ctx.strokeStyle=color;ctx.lineWidth=width*zoom;ctx.lineCap='round';ctx.lineJoin='round';ctx.stroke()}function oval(x,y,rx,ry,color){let xx=st.clientWidth/2+x*Math.cos(yaw)*zoom;ctx.fillStyle=color;ctx.beginPath();ctx.ellipse(xx,st.clientHeight*.49+y*zoom,rx*zoom,ry*zoom,yaw*.16,0,Math.PI*2);ctx.fill()}function draw(){let w=st.clientWidth,h=st.clientHeight;ctx.clearRect(0,0,w,h);let g=ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,'#0a1c30');g.addColorStop(1,'#06111f');ctx.fillStyle=g;ctx.fillRect(0,0,w,h);let scale=Math.min(w/330,h/360)*1.02*zoom;ctx.save();ctx.translate(0,0);const old=zoom;zoom=scale;
    if(on.skin){oval(0,-125,33,43,'rgba(126,174,204,.22)');oval(0,-42,52,75,'rgba(126,174,204,.18)');oval(-43,45,15,83,'rgba(126,174,204,.18)');oval(43,45,15,83,'rgba(126,174,204,.18)')}
    if(on.muscles){oval(-23,-45,19,48,'rgba(190,80,93,.62)');oval(23,-45,19,48,'rgba(190,80,93,.62)');oval(-48,17,12,58,'rgba(185,75,90,.62)');oval(48,17,12,58,'rgba(185,75,90,.62)');oval(-17,68,13,52,'rgba(185,75,90,.62)');oval(17,68,13,52,'rgba(185,75,90,.62)')}
    if(on.organs){oval(0,-128,20,23,'#d8a2a2');oval(-13,-38,16,24,'#a84e62');oval(13,-38,16,24,'#a84e62');oval(0,7,19,27,'#b86a50');oval(0,47,22,16,'#b88a54');oval(0,-3,8,12,'#e35d5d')}
    if(on.bones){ctx.strokeStyle='#e1d9c6';ctx.lineWidth=6;ctx.lineCap='round';ctx.beginPath();ctx.arc(w/2,st.clientHeight*.49-125*scale,19*scale,0,Math.PI*2);ctx.stroke();path([[0,-103,0],[0,-74,0],[0,-43,0],[0,-10,0],[0,25,0],[0,58,0],[0,93,0]],'#e4ddca',6);for(let i=0;i<6;i++){let yy=-70+i*13;path([[-27,yy,0],[-12,yy-5,0],[0,yy,0],[12,yy-5,0],[27,yy,0]],'#d8d0bd',3)}path([[-22,30,0],[0,40,0],[22,30,0]],'#d8d0bd',5);path([[-22,30,0],[-27,65,0],[-20,108,0],[-22,143,0]],'#e4ddca',7);path([[22,30,0],[27,65,0],[20,108,0],[22,143,0]],'#e4ddca',7);path([[-22,30,0],[-45,55,0],[-52,90,0],[-57,118,0]],'#e4ddca',6);path([[22,30,0],[45,55,0],[52,90,0],[57,118,0]],'#e4ddca',6)}
    if(on.vessels){path([[0,-8,0],[0,-55,0],[0,-82,0],[0,-104,0]],'#e45d62',3);path([[0,-8,0],[-22,-35,0],[-40,-62,0],[-48,-92,0]],'#e45d62',2);path([[0,-8,0],[22,-35,0],[40,-62,0],[48,-92,0]],'#e45d62',2);path([[0,-8,0],[-18,28,0],[-20,75,0],[-22,130,0]],'#e45d62',2);path([[0,-8,0],[18,28,0],[20,75,0],[22,130,0]],'#e45d62',2);path([[4,-8,0],[4,-54,0],[4,-100,0]],'#55a9e8',2);path([[4,-8,0],[-18,-38,0],[-43,-70,0]],'#55a9e8',2);path([[4,-8,0],[18,-38,0],[43,-70,0]],'#55a9e8',2)}
    if(on.nerves){path([[0,-125,0],[0,-90,0],[0,-48,0],[0,0,0],[0,45,0]],'#e9c96d',2);path([[0,-105,0],[-20,-125,0],[-30,-145,0]],'#e9c96d',2);path([[0,-105,0],[20,-125,0],[30,-145,0]],'#e9c96d',2);path([[0,-5,0],[-35,30,0],[-48,72,0]],'#e9c96d',2);path([[0,-5,0],[35,30,0],[48,72,0]],'#e9c96d',2)}
    ctx.restore();zoom=old;ctx.fillStyle='#d8e8f7';ctx.font='11px Arial';ctx.fillText('Şematik anatomi modeli · katman görünümü',10,h-12)}
    document.querySelectorAll('[data-k]').forEach(b=>{b.classList.add('off');b.onclick=()=>{let k=b.dataset.k;on[k]=!on[k];b.classList.toggle('off',!on[k]);draw()}});st.onpointerdown=e=>{drag=true;px=e.clientX;py=e.clientY;st.setPointerCapture(e.pointerId)};st.onpointermove=e=>{if(!drag)return;yaw+=(e.clientX-px)*.009;zoom=Math.max(.7,Math.min(1.6,zoom+(py-e.clientY)*.002));px=e.clientX;py=e.clientY;draw()};st.onpointerup=()=>drag=false;st.onpointercancel=()=>drag=false;document.getElementById('front').onclick=()=>{yaw=0;draw()};document.getElementById('side').onclick=()=>{yaw=1.25;draw()};document.getElementById('reset').onclick=()=>{yaw=0;zoom=1;Object.keys(on).forEach(k=>on[k]=k!=='skin');document.querySelectorAll('[data-k]').forEach(b=>b.classList.toggle('off',!on[b.dataset.k]));draw()};})();</script></body></html>"""
    AndroidView(modifier=Modifier.fillMaxWidth().height(470.dp).clip(RoundedCornerShape(14.dp)),factory={ctx->WebView(ctx).apply{settings.javaScriptEnabled=true;settings.allowFileAccess=false;settings.allowContentAccess=false;setBackgroundColor(android.graphics.Color.TRANSPARENT);loadDataWithBaseURL(null,html,"text/html","UTF-8",null)}}, onRelease={ it.stopLoading(); it.loadUrl("about:blank"); it.removeAllViews(); it.destroy() })
}


private fun isotopeMassFor(z: Int): Int? = mapOf(1 to 1, 2 to 4, 6 to 12, 8 to 16, 11 to 23, 17 to 35, 26 to 56, 29 to 64, 79 to 197, 92 to 238)[z]

@Composable
private fun Atom3DView(p: Palette, symbol: String, atomicNumber: Int, isotopeMass: Int? = null) {
    val shellCounts = when(atomicNumber) { 1->listOf(1);2->listOf(2);6->listOf(2,4);8->listOf(2,6);11->listOf(2,8,1);17->listOf(2,8,7);26->listOf(2,8,14,2);29->listOf(2,8,18,1);79->listOf(2,8,18,32,18,1);92->listOf(2,8,18,32,21,9,2);else->listOf(2, minOf(8,(atomicNumber-2).coerceAtLeast(0)), minOf(18,(atomicNumber-10).coerceAtLeast(0))).filter{it>0} }
    val shellJson = shellCounts.joinToString(",")
    val html = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>body{margin:0;background:#071525;color:#eaf4ff;font:12px Arial}.tools{padding:7px;display:flex;gap:8px}.tools button{background:#17334e;color:#eaf4ff;border:1px solid #47718d;border-radius:8px;padding:7px 10px}.stage{height:260px;touch-action:none}canvas{width:100%;height:100%;display:block}</style></head><body><div class='tools'><button id='reset'>Görünümü sıfırla</button><span>$symbol · Z=$atomicNumber</span></div><div class='stage' id='stage'><canvas id='c'></canvas></div><script>(()=>{const st=document.getElementById('stage'),c=document.getElementById('c'),ctx=c.getContext('2d'),shells=[$shellJson];let rot=0,drag=false,px=0,auto=true;function size(){let d=Math.min(devicePixelRatio||1,1.5);c.width=st.clientWidth*d;c.height=st.clientHeight*d;ctx.setTransform(d,0,0,d,0,0)}new ResizeObserver(size).observe(st);function draw(){let w=st.clientWidth,h=st.clientHeight;ctx.clearRect(0,0,w,h);ctx.fillStyle='#071525';ctx.fillRect(0,0,w,h);let cx=w/2,cy=h/2,r0=Math.min(w,h)*.11;let g=ctx.createRadialGradient(cx-r0*.3,cy-r0*.4,1,cx,cy,r0);g.addColorStop(0,'#ffd2c8');g.addColorStop(.35,'#e45f63');g.addColorStop(1,'#651d34');ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,r0,0,Math.PI*2);ctx.fill();shells.forEach((n,i)=>{let r=r0+28+i*24;ctx.strokeStyle='rgba(112,188,225,.48)';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(cx,cy,r,r*.42,rot+i*.3,0,Math.PI*2);ctx.stroke();for(let j=0;j<n;j++){let a=rot*(i%2?-.7:1)+j/n*Math.PI*2;let x=cx+Math.cos(a)*r*Math.cos(rot+i*.3),y=cy+Math.sin(a)*r*.42;let eg=ctx.createRadialGradient(x-2,y-2,1,x,y,5);eg.addColorStop(0,'#fff');eg.addColorStop(.4,'#71d9ff');eg.addColorStop(1,'#14618a');ctx.fillStyle=eg;ctx.beginPath();ctx.arc(x,y,4.5,0,Math.PI*2);ctx.fill()}});ctx.fillStyle='#d5e8f7';ctx.font='11px Arial';ctx.textAlign='center';ctx.fillText('Elektron katmanları şematik gösterimdir',cx,h-10)}let raf=0,last=0;function frame(t){if(document.hidden)return;if(t-last>33){if(auto&&!drag)rot+=.008;draw();last=t}raf=requestAnimationFrame(frame)}raf=requestAnimationFrame(frame);document.addEventListener('visibilitychange',()=>{if(document.hidden)cancelAnimationFrame(raf);else{last=performance.now();raf=requestAnimationFrame(frame)}});window.addEventListener('pagehide',()=>cancelAnimationFrame(raf));st.onpointerdown=e=>{drag=true;px=e.clientX;st.setPointerCapture(e.pointerId)};st.onpointermove=e=>{if(drag){rot+=(e.clientX-px)*.01;px=e.clientX}};st.onpointerup=()=>drag=false;st.onpointercancel=()=>drag=false;document.getElementById('reset').onclick=()=>rot=0})();</script></body></html>"""
    AndroidView(modifier=Modifier.fillMaxWidth().height(320.dp).clip(RoundedCornerShape(12.dp)),factory={ctx->WebView(ctx).apply{settings.javaScriptEnabled=true;settings.allowFileAccess=false;settings.allowContentAccess=false;setBackgroundColor(android.graphics.Color.TRANSPARENT);loadDataWithBaseURL(null,html,"text/html","UTF-8",null)}}, onRelease={ it.stopLoading(); it.loadUrl("about:blank"); it.removeAllViews(); it.destroy() })
}



@Composable
private fun PhysicsKnowledgePage(p: Palette) {
    val topics = listOf("Elektrik yükü ve alan" to "Elektrik yükü maddenin temel özelliklerinden biridir. Aynı işaretli yükler birbirini iter, zıt işaretli yükler birbirini çeker. Elektrik alan, birim pozitif yüke etki eden kuvveti tanımlar.", "Akım, gerilim ve direnç" to "Akım, bir kesitten birim zamanda geçen net yük miktarıdır. Gerilim enerji farkını, direnç ise akıma karşı gösterilen etkiyi ifade eder. Ohm yasası ideal ohmik elemanlarda V=IR biçimindedir.", "Manyetizma" to "Hareketli elektrik yükleri manyetik alan oluşturur. Elektrik akımı taşıyan iletkenler çevresinde manyetik alan meydana gelir; elektromıknatıslar bu ilkeden yararlanır.", "Enerji ve hareket" to "Enerji iş yapabilme kapasitesidir. Kinetik enerji harekete, potansiyel enerji konuma veya etkileşime bağlıdır. Sürtünme gibi süreçlerde mekanik enerji ısıya dönüşebilir.", "Dalgalar ve ışık" to "Dalgalar enerji ve momentum taşır. Ses mekanik dalgadır ve ortam gerektirir; ışık elektromanyetik dalgadır ve boşlukta yayılabilir.", "Newton yasaları" to "Eylemsizlik, ivme ve etki-tepki ilkeleri klasik mekaniğin temelini oluşturur. Net kuvvet, kütle ile ivmenin çarpımına eşittir.", "Momentum" to "Momentum kütle ve hızın çarpımıdır. Yalıtılmış sistemlerde toplam momentum korunur.", "Basınç ve akışkanlar" to "Basınç birim yüzeye etki eden dik kuvvettir. Sıvı basıncı derinlikle artar; akışkanların hareketi yoğunluk ve viskoziteden etkilenir.", "Termodinamik" to "Termodinamik ısı, iş, sıcaklık ve iç enerji arasındaki ilişkileri inceler. Enerjinin korunumu birinci yasa ile ifade edilir.", "Elektromanyetik indüksiyon" to "Değişen manyetik akı bir devrede elektromotor kuvvet oluşturabilir. Jeneratörler bu prensiple mekanik enerjiyi elektrik enerjisine dönüştürür.", "Optik ve kırılma" to "Işık farklı kırılma indislerine sahip ortamların sınırında yön değiştirebilir. Snell yasası n₁ sinθ₁ = n₂ sinθ₂ bağıntısını verir.")
    var open by rememberSaveable { mutableStateOf(topics.first().first) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Fizik ve elektrik", color=p.accent, fontSize=22.sp, fontWeight=FontWeight.Bold); Text("Doğanın temel etkileşimlerini ve enerji dönüşümlerini incele.", color=p.muted) }
        topics.forEach { (t,b) -> Panel(p) { Text(t, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.fillMaxWidth().clickable { open=if(open==t) "" else t }); if(open==t) Text(b, color=p.text, lineHeight=21.sp) } }
    }
}

@Composable
private fun TechnologyKnowledgePage(p: Palette) {
    val topics = listOf("Yarı iletkenler" to "Silisyum gibi yarı iletkenlerin elektriksel iletkenliği katkılama, sıcaklık ve elektrik alanla değiştirilebilir. Diyotlar ve transistörler modern elektroniğin temel yapı taşlarıdır.", "İşlemciler ve bellek" to "İşlemci komutları yürütür ve aritmetik-mantık işlemleri gerçekleştirir. RAM geçici çalışma verilerini tutar; kalıcı depolama veriyi enerji kesildiğinde de korur.", "Sensörler" to "Sensörler sıcaklık, basınç, ivme, ışık veya manyetik alan gibi fiziksel büyüklükleri ölçülebilir sinyallere dönüştürür.", "Robotik ve otomasyon" to "Robotik sistemler algılama, kontrol ve hareket bileşenlerini birleştirir. Geri besleme, sistemin ölçülen çıktıya göre davranışını düzeltmesini sağlar.", "Enerji teknolojileri" to "Güneş hücreleri ışığı elektrik enerjisine dönüştürür. Bataryalar enerjiyi elektrokimyasal süreçlerle depolar; güç elektroniği enerji akışını yönetir.", "İletişim ağları" to "Kablosuz ve kablolu ağlar veriyi protokoller aracılığıyla paketler ve iletir. Gecikme, bant genişliği ve güvenilirlik temel performans ölçütleridir.", "Gömülü sistemler" to "Gömülü bilgisayarlar belirli görevleri yerine getirmek üzere cihazların içine yerleştirilir. Mikrodenetleyici, bellek, giriş-çıkış ve yazılım birlikte çalışır.", "3B baskı" to "Eklemeli üretim, parçaları katmanlar halinde oluşturarak prototipleme ve özel geometrilerin üretimini kolaylaştırır.", "Yapay zekâ" to "Makine öğrenmesi, veriden örüntüler öğrenen modeller geliştirir. Eğitim verisinin niteliği ve modelin değerlendirilmesi sonuçların güvenilirliğini belirler.", "Siber güvenlik" to "Gizlilik, bütünlük ve erişilebilirlik temel güvenlik hedefleridir. Kimlik doğrulama, güncelleme ve güvenli tasarım sistemleri korumaya yardımcı olur.")
    var open by rememberSaveable { mutableStateOf(topics.first().first) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Teknoloji atlası", color=p.accent, fontSize=22.sp, fontWeight=FontWeight.Bold); Text("Elektronikten akıllı sistemlere uzanan temel teknolojiler.", color=p.muted) }
        topics.forEach { (t,b) -> Panel(p) { Text(t, color=p.accent, fontWeight=FontWeight.Bold, modifier=Modifier.fillMaxWidth().clickable { open=if(open==t) "" else t }); if(open==t) Text(b, color=p.text, lineHeight=21.sp) } }
    }
}

@Composable
private fun SettingsPage(p: Palette, selected: Int, soundOn: Boolean, fontIndex: Int, language: String, onTheme: (Int) -> Unit, onSound: (Boolean) -> Unit, onFont: (Int) -> Unit, onLanguage: (String) -> Unit) {
    var languageExpanded by rememberSaveable { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel(p) {
            Text(if (language == "en") "Appearance" else "Görünüm", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (language == "en") "Adjust theme and typeface in one place." else "Tema ve yazı tipini tek bölümden düzenle.", color = p.muted, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                palettes.forEachIndexed { index, theme ->
                    Column(Modifier.width(66.dp).clip(RoundedCornerShape(11.dp)).border(if(selected==index) 2.dp else 1.dp, if(selected==index) p.accent else p.muted.copy(alpha=.25f), RoundedCornerShape(11.dp)).clickable { onTheme(index) }.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.fillMaxWidth().height(25.dp).clip(RoundedCornerShape(7.dp)).background(theme.bg), contentAlignment = Alignment.Center) { Box(Modifier.size(12.dp).clip(CircleShape).background(theme.accent)) }
                        Text(theme.name, color = p.text, fontSize = 9.sp, maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(if (language == "en") "Typeface" else "Yazı tipi", color = p.accent, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Standart", "Kitap", "Teknik", "Yuvarlak").forEachIndexed { index, label ->
                    FilterChip(selected = fontIndex == index, onClick = { onFont(index) }, label = { Text(label, fontSize = 10.sp) })
                }
            }
        }
        Panel(p) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(if (language == "en") "Language" else "Dil", color = p.accent, fontWeight = FontWeight.Bold); Text(if (language == "en") "Application language" else "Uygulama dili", color = p.muted, fontSize = 11.sp) }
                Box {
                    TextButton(onClick = { languageExpanded = true }) { Text(if (language == "en") "English ▾" else "Türkçe ▾", color = p.text) }
                    DropdownMenu(expanded = languageExpanded, onDismissRequest = { languageExpanded = false }) {
                        DropdownMenuItem(text = { Text(if (language == "tr") "Türkçe ✓" else "Türkçe") }, onClick = { languageExpanded = false; onLanguage("tr") })
                        DropdownMenuItem(text = { Text(if (language == "en") "English ✓" else "English") }, onClick = { languageExpanded = false; onLanguage("en") })
                    }
                }
            }
        }
        Panel(p) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(if (language == "en") "Interface sounds" else "Arayüz sesleri", color = p.accent, fontWeight = FontWeight.Bold); Text(if (language == "en") "Enable or disable navigation sounds." else "Gezinme seslerini aç veya kapat.", color = p.muted, fontSize = 11.sp) }
                Switch(checked = soundOn, onCheckedChange = onSound)
            }
        }
        Panel(p) {
            Text(if (language == "en") "Offline mode" else "Çevrimdışı çalışma", color = p.accent, fontWeight = FontWeight.Bold)
            Text(if (language == "en") "Atom, molecule, anatomy and solar-system visuals are rendered locally. No external server or internet connection is required." else "3B atom, molekül, anatomi ve Güneş Sistemi modelleri uygulama içinde çizilir. Harici sunucu veya internet bağlantısı kullanılmaz.", color = p.text, lineHeight = 19.sp, fontSize = 12.sp)
        }
        Panel(p) {
            Text("Spectrum 1.5.3", color = p.accent, fontWeight = FontWeight.Bold)
            Text(if (language == "en") "Designed by Elyionn. Scientific content is for educational use." else "Elyionn tarafından tasarlanmıştır. Bilimsel içerikler eğitim amaçlıdır.", color = p.text, lineHeight = 19.sp, fontSize = 12.sp)
        }
    }
}

