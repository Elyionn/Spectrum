# Spectrum 1.6.0 — Validation report

## Source-level checks

- Project metadata: `versionName=1.6.0`, `versionCode=13`.
- Existing periodic-table source retained; CI validates 118 rows and atomic numbers 1–118.
- Science Atlas dataset is checked for unique topic IDs and minimum entry count by CI.
- Android XML resources are parsed by CI.
- CI builds debug and release variants and verifies that APK files exist and pass ZIP integrity checks.

## Not executed in this authoring environment

- Android Gradle compilation: not run because this environment has no installed Gradle distribution/Android SDK and cannot be relied on to download the required toolchain.
- Emulator or physical-device launch/UI tests: not run.
- Macrobenchmark, Baseline Profile generation, memory/GPU/startup measurements: not run.
- Release signing: not configured; release APK from CI is unsigned unless signing secrets/configuration are added by the owner.

A successful YAML parse or source inspection is not a successful Android build. The first authoritative compile result will be the GitHub Actions run; its logs are uploaded even when a build step fails.
