# Spectrum 1.6.0 — Change report

## Integrated in this update

1. Science Atlas screen and ten top-level domain entry points.
2. Curated topic pages with Explore / Learn / Deep Dive levels.
3. Related-concept navigation and a connected science concept path.
4. Daily Science topic rotation using local date, without a network request.
5. On-device completion tracking and Atlas progress persistence.
6. Unified local search across Atlas topics, all 118 existing element rows, and existing subject-section names.
7. Six additional visual palettes.
8. Version metadata changed to `versionName 1.6.0`, `versionCode 13`.
9. CI now supports a project directory at repository root or a nested ZIP, creates a wrapper if needed, builds debug and release, checks APK existence/integrity, and uploads logs.

## Preserved

Existing Compose screens and the current periodic table, element detail, biology, space, chemistry, mathematics, physics, microbiology, atom and WebView visualizations remain in the project.

## Not represented as completed

- Real anatomical 3D mesh library and validated organ cutaway models.
- A Three.js/WebGL renderer or full 3D molecular geometry engine.
- The full nineteen-experiment physics simulation suite.
- Advanced reaction balancing and validated chemistry reaction simulation.
- Full planet/moon/dwarf-planet database and numerically integrated orbit simulator.
- Full mathematics graphing engine and geology mineral comparison dataset.
- Complete offline encyclopedia, scientist directory, full quiz bank and adaptive learning engine.
- Baseline Profiles, Macrobenchmark, measured startup/memory/GPU performance report, device farm or physical-device QA.

These are explicitly deferred rather than being represented by decorative placeholders as working features.
