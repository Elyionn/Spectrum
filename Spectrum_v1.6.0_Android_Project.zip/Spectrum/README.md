# Spectrum 1.6.0 — The Science Atlas Update

**Developer:** Elyionn
**Platform:** Android / Kotlin / Jetpack Compose
**Application ID:** `com.elyionn.spectrum`
**Version:** `1.6.0` (`versionCode` 13)
**Minimum Android:** API 26

## 1.6.0 additions in this source package

- Added a dedicated **Science Atlas** destination to the existing Compose navigation.
- Added curated offline concept entries with three learning levels: Explore, Learn and Deep Dive.
- Added connected-concept navigation and a concept path (Atom → Electron → Electromagnetism → Light → Astronomy).
- Added a rotating Daily Science topic selected locally by day of year; it requires no network request.
- Added local completion tracking and an overall Atlas progress indicator using the existing SharedPreferences settings store.
- Added a unified offline search page for Atlas topics, the existing 118-element table and existing subject sections.
- Added six new palettes while retaining the original palettes.
- Preserved the existing periodic table, biology, astronomy, mathematics, chemistry, physics, atom and visualization modules.
- Updated GitHub Actions to resolve either a project at repository root or a project nested inside a ZIP, create a Gradle wrapper when missing, build debug and release APKs, verify outputs and upload logs.

## Existing architecture retained

The supplied baseline was **Spectrum 1.5.5**, not 1.5.4. The package contains a Kotlin/Jetpack Compose Android application, a single primary activity, locally embedded HTML/JavaScript visualizations hosted in Android WebView, and no bundled Three.js/WebGL scene engine. The update preserves that architecture rather than introducing a new renderer or replacing working modules.

## Scientific content and model boundaries

Atlas entries are concise educational summaries stored locally. They are not peer-reviewed research articles and do not carry a claim of external live verification. The existing atom, molecule, DNA and Solar System visuals are schematic educational projections. This update does **not** claim to add validated full-body anatomical meshes, a complete real-geometry 3D laboratory, or a full orbital physics engine. Those require licensed/validated assets, model-specific scientific review and device profiling.

## Build

Open the `Spectrum` directory in Android Studio with JDK 17 and Android SDK 35. The CI workflow uses Gradle 8.9 and generates the Gradle wrapper in its runner if the repository does not include one. If Gradle 8.9 is installed locally, run:

```bash
gradle :app:assembleDebug
gradle :app:assembleRelease
```

Release APK output is unsigned unless a signing configuration is supplied by the project owner.

## Data sources

See [DATA_SOURCES.md](DATA_SOURCES.md). Existing element and subject data are retained. The new Atlas is bundled content and does not make live NASA, PubChem, NIST, IUPAC, NIH or NCBI API calls.
