# Spectrum 1.7.5 — Performans notları

- Three.js piksel oranı en fazla 0.8: yüksek DPI ekranlarda GPU fragment yükünü düşürür.
- Render aralığı 42 ms: animasyon yaklaşık 24 FPS ile sınırlıdır.
- Render hatasında sürekli frame döngüsü bırakılmaz.
- WebGL context kaybında çizim çağrıları engellenir.
- Renderer ve sahne nesneleri sayfa kapanışında dispose edilir.

Gerçek FPS/RAM/GPU ölçümü cihazda yapılmalıdır.
