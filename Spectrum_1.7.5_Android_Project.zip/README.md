# Spectrum 1.7.5

Spectrum is an Android science-learning application built with Kotlin, Jetpack Compose and a locally bundled Three.js laboratory.

## Build
- GitHub Actions workflow: `.github/workflows/android-apk.yml`
- Android Gradle Plugin: 9.3.1
- Gradle: 9.7.0
- Kotlin: 2.4.21
- Build JDK: 25 (Android bytecode target remains Java 17 for broad device compatibility)
- Compile SDK: 37; target SDK: 36; minimum SDK: 26

The workflow validates the source archive, XML/JSON/JavaScript, scene registry, compiles Kotlin, runs unit tests and Android lint, builds Debug and Release APKs, verifies package identity, and uploads artifacts. The Debug APK is installable; the Release APK produced by this workflow is unsigned.

## App identity
- Application ID: `com.elyionn.spectrum`
- Namespace: `com.elyionn.spektrum`
- Version: `1.7.5` (code 28)

## Main areas
- Science home, categories and structured lesson pages
- Search with cached lesson index and lazy result rendering
- Periodic table and element details
- Interactive local 3D laboratory with WebGL recovery, WebView renderer-crash recovery and reduced GPU pixel ratio
- Ten color themes and eight system typeface choices

See `CHANGELOG_1.7.5.md`, `PERFORMANCE_REPORT_1.7.5.md` and `SOURCE_AUDIT_1.7.5.md` for scope and verification limits.
