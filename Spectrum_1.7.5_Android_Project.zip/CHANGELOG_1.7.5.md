# Spectrum 1.7.5 — Android SDK CI ve 3D Lab kararlılığı

## GitHub Actions / Android SDK
- SDK lisans kabulünde `yes | sdkmanager` kullanımı kaldırıldı. Bu boru hattı `Broken pipe` üretebildiği için Python `subprocess.run(input=...)` ile sonlu lisans yanıtları gönderiliyor.
- `sdkmanager --licenses` gerçek çıkış koduyla denetleniyor; başarısız olursa derleme açık hata vererek duruyor.
- Workflow, ZIP adı, sürüm doğrulaması ve artifact adı 1.7.5 ile eşleştirildi.

## 3D Lab
- Three.js renderer piksel oranı 0.8 ile sınırlandırıldı; yüksek yoğunluklu ekranlarda GPU piksel yükü azaltıldı.
- Render döngüsü yaklaşık 24 FPS hedefiyle sınırlandı. Render istisnaları yakalanıp döngü güvenli biçimde durduruluyor ve Android köprüsüne raporlanıyor.
- WebGL context kaybında yeni çizim isteği engelleniyor.
- Sayfa kapanırken renderer kaynakları temizleniyor; zorunlu context-loss çağrısı kaldırıldı.
- Görünür WebView renderer süreci Android tarafından bağlı/önemli öncelikte tutuluyor.

## Sürüm
- `versionName`: `1.7.5`
- `versionCode`: `28`

## Test kapsamı ve sınırlar
Kaynak ZIP, XML/JSON, JavaScript sözdizimi ve workflow statik kontrolleri yapılabilir. Bu ortamda Android SDK/Gradle tam derlemesi ve fiziksel cihaz GPU testi çalıştırılmadı. Dolayısıyla cihazlar arası hatasızlık garantisi verilmez; APK ancak GitHub Actions başarılı olduktan ve gerçek cihazda Lab test edildikten sonra doğrulanmış sayılır.
