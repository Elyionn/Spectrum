# Spectrum 1.7.5 — Kaynak denetimi

İncelenen ana dosyalar: `.github/workflows/android-apk.yml`, `app/build.gradle.kts`, `gradle.properties`, `MainActivity.kt` ve `app/src/main/assets/lab/index.html`.

Düzenlemeler:
1. CI lisans kabulundaki `yes` kaynaklı `Broken pipe` riski giderildi; sonlu stdin verisi `subprocess.run` ile gönderiliyor.
2. Sürüm 1.7.5 / versionCode 28 olarak güncellendi.
3. Three.js pixel ratio 0.8'e indirildi ve render döngüsü ~24 FPS ile sınırlandı.
4. WebGL context kaybında çizim durduruluyor; render istisnaları yakalanıyor.
5. Sayfa kapanışında renderer temizleniyor; gereksiz `forceContextLoss()` kaldırıldı.
6. Ön plandaki WebView renderer önceliği BOUND olarak ayarlandı.

Doğrulama notu: Kaynak incelemesi Android cihazda çalışma testi yerine geçmez. Gerçek Gradle derlemesi, APK üretimi ve 3D sahne stres testi GitHub Actions ve Android cihazda yapılmalıdır.
