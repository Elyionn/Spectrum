# Spectrum 1.7.5 — GitHub yükleme

1. Depo kök dizinindeki kaynak arşivini `Spectrum_1.7.5_Android_Project.zip` ile değiştir.
2. Bu ZIP içindeki `.github/workflows/android-apk.yml` dosyasını depodaki aynı yola yükle.
3. GitHub Actions içinden **Spectrum 1.7.5 Android Build** workflow'unu çalıştır.
4. İlk olarak `Accept SDK licenses and install packages` adımının geçtiğini doğrula. Ardından ZIP doğrulama, Kotlin derleme, unit test, lint ve APK adımlarının hepsi başarılı olmalı.
5. Debug APK test amaçlıdır. Release APK, keystore secret'ları tanımlı değilse unsigned olacaktır.

Yalnızca YAML'ı değiştirmek yetmez: yeni ZIP de kök dizine yüklenmelidir.
