# Spectrum 1.7.7 performance notes

- 3D Lab uses Canvas 2D software rendering; WebGL context and GPU shader initialization are not used.
- Maximum 420 scene primitives are retained by the renderer.
- Device pixel ratio is capped at 1.0 to limit backing-store memory.
- Automatic rotation is opt-in and throttled to roughly 24 FPS; it stops when the document is hidden.
- Static scene rendering occurs on selection, resize, gesture and control changes rather than an always-running animation loop.
- WebView network loads, file access, DOM storage and multiple windows remain disabled for the lab.
- Settings theme/font selectors use compact horizontal lists.

Performance and thermal behavior still require measurement on low-memory physical Android devices.
