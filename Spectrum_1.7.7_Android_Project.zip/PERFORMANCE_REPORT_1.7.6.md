# Spectrum 1.7.6 performance notes

The main 3D Lab no longer creates a WebGL context. It uses a software-layer Canvas 2D renderer with projected 3D coordinates and a maximum of 420 primitives per scene. Rendering is event-driven while idle; optional rotation is limited to approximately 25 FPS. Canvas device-pixel ratio is capped at 1.0, and the animation loop is stopped while the document is hidden.

All four embedded WebView paths use software rendering and have renderer-exit cleanup. The main lab can be recreated after a renderer process exits instead of allowing an unhandled renderer loss to destabilize the activity. Network access is disabled for local lab pages.

These changes reduce reliance on GPU drivers, shader compilation, high-resolution buffers and continuous idle rendering. Exact CPU/RAM use depends on the Android device and System WebView version. No physical-device profiler, memory soak test or instrumented crash test was available here, so no numerical performance gain or crash-free guarantee is claimed.
