# Spectrum 1.7.6

## 3D Lab rewrite
- Replaced the WebGL/Three.js dependency with a lightweight local Canvas 2D renderer that projects 3D coordinates into an interactive scene.
- Preserved all 48 model categories, with drag rotation, pinch zoom and optional auto-rotation.
- Added bounded scene complexity, device-pixel-ratio cap, event-driven rendering and visibility-aware animation.
- Added safe failure reporting and Android WebView renderer-process recovery with a manual restart path.

## Interface and settings
- Added Midnight Violet and Obsidian Ember dark palettes.
- Added Casual and Strong system font options.
- Version labels now read from BuildConfig instead of stale hard-coded values.
- Refined settings headings and theme/font naming.

## Build metadata
- versionName: 1.7.6
- versionCode: 29
- compileSdk / targetSdk: 35
- Android Gradle Plugin: 8.7.3; Kotlin: 2.0.21; Gradle: 8.9; JDK: 17
