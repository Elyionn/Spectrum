# Spectrum 1.7.7 Android project

Spectrum is an Android science-learning app built with Kotlin and Jetpack Compose.

## Build
1. Upload `Spectrum_1.7.7_Android_Project.zip` to the repository root.
2. Upload `android-apk-1.7.7.yml` as `.github/workflows/android-apk.yml`.
3. Run **Spectrum 1.7.7 Android Build** from GitHub Actions.
4. Download `Spectrum-1.7.7-build-results` after the workflow completes.

The workflow validates the source ZIP before extracting it, generates a Gradle 8.9 wrapper when absent, compiles Kotlin, runs JUnit, assembles debug and release APKs, and validates APK archive/application IDs. Release output is unsigned unless signing secrets are configured.

## 3D Laboratory
The lab uses local Canvas 2D rendering, not WebGL. It contains 48 educational scenes, scene search, optional XYZ axes, drag rotation, pinch/wheel zoom and opt-in auto-rotation. These are schematic educational projections, not scientific simulation engines.

## Toolchain
AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, JDK 17, compileSdk/targetSdk 35.
