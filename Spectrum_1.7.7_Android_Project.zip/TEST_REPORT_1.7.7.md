# Spectrum 1.7.7 test report

## Passed locally
- Uploaded 1.7.6 baseline ZIP: CRC validation passed before extraction.
- Final 1.7.7 ZIP: CRC validation, duplicate-member check, required-root-file check and clean extraction passed.
- 3D Lab Node runtime test: all 48 scene entries instantiated; model search filtering; axes toggle; pointer rotation; pinch zoom; wheel zoom; reset; auto-rotation; injected Canvas exception containment passed.
- Lab JavaScript syntax check: passed.
- Android XML resources: parsed successfully.
- Science JSON: parsed; 151 unique lesson slugs and 35 `isNew` entries confirmed.
- Periodic table: 118 elements with atomic numbers 1 through 118 confirmed.
- Version metadata: versionName 1.7.7 and versionCode 30 confirmed.
- Settings metadata: 10 palettes, 10 font choices and persisted font range 0..9 confirmed.
- GitHub Actions YAML: parsed successfully. Every workflow `run` block passed `bash -n`; embedded Python heredocs compiled successfully.
- Extracted final ZIP was tested again; Node runtime, YAML, Bash, XML, JSON and version checks passed.

## Not run
- Gradle/Kotlin/Compose compile: unavailable (no Gradle executable, Android SDK or ANDROID_HOME in authoring environment).
- JUnit on Android Gradle plugin: not run.
- APK assembly / APK analyzer: not run.
- Emulator and physical-device lifecycle/crash testing: not run.

GitHub Actions is configured to perform compile, JUnit, debug/release assembly, APK archive checks and application-ID checks. A successful Actions run and physical-device test are still required before claiming a verified APK or crash-free behavior.
