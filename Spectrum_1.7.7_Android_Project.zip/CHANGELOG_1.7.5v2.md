# Spectrum 1.7.5v2

- Android app versionName 1.7.5 / versionCode 28.
- Corrected Android SDK installation target to API 35 (the project compileSdk/targetSdk are 35).
- Replaced unbounded `yes | sdkmanager` license acceptance with finite input through Python subprocess.
- 3D Lab GPU budget reduced to a 0.9 device-pixel ratio cap and 24 FPS animation target.
- WebGL context loss and renderer exceptions now stop the render loop and report a recoverable UI error instead of continuing to render.
- WebView renderer priority is reduced while the lab is not visible (minSdk 26).
- Preserved existing scientific content, scene definitions, app identity, themes, and Kotlin UI.
