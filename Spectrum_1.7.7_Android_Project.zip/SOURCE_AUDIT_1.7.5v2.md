# Spectrum 1.7.5v2 — source audit

## Verified in this environment
- Source archive extracted from the provided 1.7.3 project ZIP; source ZIP CRC was valid.
- Version metadata: versionName 1.7.5, versionCode 28, applicationId com.elyionn.spectrum, namespace com.elyionn.spektrum.
- Android SDK compileSdk/targetSdk remain 35; workflow installs `platforms;android-35` and `build-tools;35.0.0`.
- XML resources parsed; science JSON, periodic-table data and 3D scene registry checked by workflow.
- Bundled Three.js module and inline module syntax checked with Node.js.
- Kotlin changes limited to visible version label and WebView renderer priority policy; minSdk 26 supports that API.
- WebGL context-loss and render exceptions stop the animation loop and report an error to the native layer.

## Not verified here
- This environment has no Gradle installation, Android SDK, or network access to fetch them; Kotlin/Compose compilation and APK production could not be run locally.
- The supplied 1.7.3 build-results ZIP is malformed: its nested debug APK member fails decompression and the extracted APK has no ZIP central directory. It must not be redistributed as a valid APK.
- No physical-device crash, GPU, RAM, or WebView compatibility test was possible. GitHub Actions must pass before treating the APK as build-verified.
