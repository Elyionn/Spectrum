# Spectrum 1.7.6 source audit

## 3D Lab stability rewrite
- Rebuilt the primary 3D Lab using a local Canvas 2D renderer that projects 3D coordinates into an interactive schematic view. Removed the Three.js bundle and WebGL dependency from the main lab.
- Retained all 48 model IDs, with drag rotation, pinch zoom, wheel zoom, reset and optional auto-rotation.
- Bounded scene complexity to 420 primitives, capped canvas DPR at 1.0, used event-driven rendering while idle, limited optional rotation to roughly 25 FPS, and stopped its loop when hidden.
- Added safe JavaScript render-error reporting, Android `onRenderProcessGone` cleanup for all four WebView instances, parent detachment/destruction, and a keyed restart path for the main lab.
- WebView content uses local bundled assets, software rendering layers, restricted navigation and disabled network loads.

## Settings and metadata
- Added Midnight Violet and Obsidian Ember dark palettes.
- Added Casual and Strong system font options.
- Replaced stale in-app version literals with `BuildConfig.VERSION_NAME` and `BuildConfig.VERSION_CODE`.
- Version metadata: `1.7.6`, code `29`, compile/target SDK `35`.

## Validation and limitations
- Local checks passed for XML parsing, science-content structure/counts, periodic-table data, all 48 scene runtime initialization, pointer/zoom/reset/rotation handlers, injected Canvas-error containment, JavaScript syntax, workflow YAML, Bash/Python workflow syntax, and ZIP CRC/path integrity.
- Kotlin parser reported no syntax diagnostics, but unresolved Android/Compose symbols prevented classpath compilation in this environment.
- Gradle build, JUnit execution, APK assembly and physical-device tests have not yet been run because Android SDK and Gradle are not installed in the current container. Do not treat this report as evidence of a successful APK build or device-level crash-free status.
