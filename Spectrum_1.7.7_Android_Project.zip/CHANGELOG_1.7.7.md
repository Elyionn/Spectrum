# Spectrum 1.7.7

## 3D Laboratory
- Added in-lab model search across scene names, descriptions and science groups.
- Added optional XYZ reference axes to improve spatial interpretation.
- Kept the Canvas 2D renderer (no WebGL dependency), bounded scene geometry and capped device-pixel ratio.
- Added automated runtime coverage for all 48 scenes, search filtering, axes, pointer rotation, pinch zoom, reset, auto-rotation and contained renderer exceptions.
- Retained native WebView renderer-exit handling and explicit restart recovery.

## Explore and settings
- Category pages now support local lesson search and a new-topics-only filter.
- Reworked theme and typography selection into compact horizontal rails to reduce vertical scrolling.
- Added Nebula Teal and Solar Flare dark palettes.
- Added Medium and Thin system typefaces; expanded persisted font index validation to include both.

## Build
- versionName: 1.7.7
- versionCode: 30
- compileSdk / targetSdk: 35
- Android Gradle Plugin: 8.7.3; Gradle: 8.9; Kotlin: 2.0.21; JDK target: 17
