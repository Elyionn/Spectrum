# Spectrum 1.7.7 source audit

- Source baseline: uploaded Spectrum 1.7.6 project ZIP.
- ZIP baseline CRC verification: passed before modification.
- Version metadata aligned to 1.7.7 / versionCode 30.
- Existing application ID and namespace retained.
- Lab is Canvas 2D only; no Three.js/WebGL dependency is present in the lab HTML.
- Added scene search, science-group filtering through search, and optional coordinate axes.
- Added category lesson search and new-topic filtering.
- Added two dark palettes and two system font families; saved font range expanded to 0..9.
- WebView renderer process exit is handled natively; lab offers explicit recreation.
- Build workflow checks ZIP CRC, path safety, app metadata, content counts, 48 scenes, Kotlin markers, JS syntax, runtime interactions, unit tests and APK ZIP validity.

## Limitations
Android SDK and Gradle are not installed in the authoring environment. Kotlin/Compose compilation, APK packaging, emulator launch and physical-device crash testing were not run here. These remain mandatory GitHub Actions/device checks; no claim of a verified APK is made.
