# Spectrum application-specific R8 rules.
-keepattributes *Annotation*

# JavaScript bridge methods are invoked reflectively by the local WebView page.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
