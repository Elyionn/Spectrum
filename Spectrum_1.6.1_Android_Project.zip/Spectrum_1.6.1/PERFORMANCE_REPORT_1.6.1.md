# Spectrum 1.6.1 — Performance review

## Source-level hotspots identified

| Area | Source-level observation | Change |
|---|---|---|
| DNA Canvas | `rememberInfiniteTransition` drove a Canvas redraw continuously while the Biology page was visible. | Replaced with a static educational helix diagram; removed the `animateFloat` call/import associated with the previously reported compiler error. |
| Solar System WebView | Canvas animation loop ran at approximately 25 FPS and redrew 90 stars plus 8 orbit paths with 101 sample points each. | Frame cap reduced to approximately 20 FPS; star count reduced to 48 and orbit path samples to 49. |
| Molecule / atom WebViews | Canvas loops ran at approximately 30 FPS while visible. | Frame cap reduced to approximately 20 FPS. WebViews continue to be stopped, cleared and destroyed on release. |
| Periodic table | Table row layout and lookup setup were recreated inside the composable; search normalized each element's symbol/name on every query. | Layout and atomic-number lookup moved to immutable top-level data; normalized searchable text precomputed once; 18-column grid uses stable slot keys. |
| Periodic table gestures | Pan clamping used hard-coded viewport dimensions. | Bounds now use measured BoxWithConstraints dimensions. |
| Navigation | Element details opened from Library returned to the old category detail route. | Added explicit return-route state and corrected bottom navigation selection. |

## What is not measured

No Android Studio Profiler, Macrobenchmark, Baseline Profile, emulator, or physical device was available. The changes above are source-level workload reductions, not measured frame-time, startup, memory, battery, or GPU improvements. Actual performance must be measured on representative low- and mid-range Android devices.

## Expected remaining cost centres

- Three WebView instances contain independent Canvas drawing loops. They are released with `onRelease`, but actual WebView memory/GPU cost must be profiled on device.
- Large scrollable subject pages still use regular Compose `Column` content for curated, finite sections. If future datasets become much larger, migrate those lists to lazy containers.
- The periodic table is a 162-slot fixed layout (118 elements plus placeholders). It is not a large data set; its principal improvement is stable precomputed data and grid structure, not a claimed dramatic performance gain.
