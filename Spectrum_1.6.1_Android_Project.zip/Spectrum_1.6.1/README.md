# Spectrum 1.6.1

Spectrum is an offline-first Kotlin / Jetpack Compose science learning application.

## Open in Android Studio
1. Extract the complete `Spectrum_1.6.1` folder from the ZIP. Do not open the ZIP as if it were a project.
2. In Android Studio choose **Open** and select the extracted `Spectrum_1.6.1` directory (the one containing `settings.gradle.kts`).
3. Use JDK 17 and Android SDK Platform 35.
4. Let Android Studio sync Gradle. The GitHub Actions workflow generates Gradle wrapper files when they are absent.

## Build

```bash
gradle wrapper --gradle-version 8.9 --distribution-type bin
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
```

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01, compileSdk/targetSdk 35 and minSdk 26. Application ID remains `com.elyionn.spectrum`; namespace remains `com.elyionn.spektrum`.

## 1.6.1 changes

- Stability and ZIP extraction workflow improvements.
- Periodic table layout/search data is precomputed; table cells use a stable 18-column grid.
- Periodic table pan bounds use measured viewport dimensions.
- Removed continuous DNA Canvas animation to avoid unnecessary redraws and remove the reported `animateFloat` reference point.
- WebView canvas loops reduced to about 20 FPS; scene drawing complexity reduced.
- Fixed element-detail return navigation when opened from Library.
- Replaced vague slogans with functional navigation and section labels.

See `CHANGELOG_1.6.1.md`, `PERFORMANCE_REPORT_1.6.1.md` and `TEST_REPORT_1.6.1.md`.

## Limitations

No full Android Gradle build, emulator run, physical-device test, or measured CPU/GPU/memory benchmark was possible in the authoring environment. GitHub Actions is configured to perform the actual Debug and Release builds and upload APKs and logs. Do not treat source-level checks as proof of a successful APK build.
