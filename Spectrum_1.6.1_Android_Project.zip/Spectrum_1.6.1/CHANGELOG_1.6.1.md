# Spectrum 1.6.1 — Stability, extraction and performance update

## Changes
- Version metadata: 1.6.1 / versionCode 14; applicationId and namespace preserved.
- Removed the infinite Compose DNA animation and its `animateFloat` dependency usage. The DNA helix remains as a static educational diagram, avoiding a permanent redraw loop and removing the previously reported unresolved animation extension call.
- Periodic table: moved the 9×18 cell layout and atomic-number lookup to immutable top-level data; changed the 162-slot visual grid to `LazyVerticalGrid` with stable slot keys; retained 118 element entries, pinch zoom and pan.
- Pan clamping now uses the measured viewport constraints.
- WebView canvas models are capped at approximately 20 frames per second instead of 25–30; star/orbit drawing workload reduced; WebView teardown remains explicit.
- Replaced vague slogans with functional section labels and descriptions.
- Rebuilt the ZIP using a standard DEFLATE archive with one predictable project-root directory. The workflow selects a matching 1.6.1 project archive by inspecting its contents and version metadata, rather than extracting the first ZIP it finds.
- Added ZIP path-traversal checks, duplicate archive detection and explicit extraction diagnostics in CI.

## Preserved
- Package/application ID, namespace, current local preferences, theme/language settings, Science Atlas content, current modules, and all 118 element records.

## Not claimed
- No measured GPU/CPU benchmark or physical-device profiling was available in this environment.
- No APK is claimed as built unless GitHub Actions completes both Gradle tasks and verifies the artifacts.
