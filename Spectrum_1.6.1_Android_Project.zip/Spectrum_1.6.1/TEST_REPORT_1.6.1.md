# Spectrum 1.6.1 — Validation report

## Environment

- Base project: Spectrum 1.6.0 UI Redesign Preview ZIP.
- Target: versionName 1.6.1, versionCode 14.
- Application ID: `com.elyionn.spectrum` (preserved).
- Namespace: `com.elyionn.spektrum` (preserved).

## Final source archive

- Archive contains one top-level `Spectrum_1.6.1/` folder and 21 files. The exact SHA-256 is supplied separately.

## Source/archive checks performed

- Original ZIP passed `unzip -tq` before extraction.
- Updated project ZIP is built with standard DEFLATE compression and a single predictable top-level project directory.
- Archive entries are checked for path traversal and symlinks in GitHub Actions before extraction.
- Project root is selected by matching `settings.gradle.kts`, `app/build.gradle.kts` and exact versionName 1.6.1; workflow no longer extracts the first arbitrary ZIP it finds.
- Periodic-table source is validated for exactly 118 unique atomic numbers 1–118.
- Periodic-table layout is validated as 9 rows × 18 columns = 162 slots.
- Science Atlas IDs are checked for uniqueness.
- Android XML resources are parsed.
- Embedded WebView JavaScript blocks are checked with Node.js syntax validation in CI.
- Workflow shell scripts are checked with `bash -n` during authoring.
- ZIP integrity is checked after packaging.

## Not executed in this environment

- Full Android Gradle compilation (no Gradle distribution, Android SDK, or cached AGP/Compose dependency graph available locally).
- Debug or Release APK generation.
- Emulator launch, UI tests, or physical-device tests.
- Macrobenchmark, Baseline Profile, CPU/GPU/memory/battery measurements.

The workflow is configured to run `:app:assembleDebug` and `:app:assembleRelease`, verify APK package metadata and ZIP integrity, and upload APKs plus diagnostic logs. A successful YAML parse or source check is not an Android build result.
