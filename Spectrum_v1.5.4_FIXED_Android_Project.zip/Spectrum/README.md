# Spectrum 1.5.4

Kotlin + Jetpack Compose based offline science atlas.

## 1.5.4 update
- Reworked the periodic table with element-family colours and two-finger pinch zoom. Dedicated zoom buttons and slider removed.
- Expanded English element-name coverage to all 118 elements and localized the main science workspaces.
- Added an interactive quadratic-function explorer and a fair-die probability experiment.
- Added interactive Newton's second-law and Ohm's-law calculators to the physics workspace.
- Improved biology, chemistry, microbiology and 3D-lab English interfaces.
- Updated app version to 1.5.4 (versionCode 10).

## Build
Run `gradle :app:assembleDebug` with JDK 17, Android SDK platform 35 and Gradle 8.9.

## Scientific accuracy note
The current anatomy illustration is schematic and is not a clinically validated anatomical 3D model. It must not be used for diagnosis or clinical training.
