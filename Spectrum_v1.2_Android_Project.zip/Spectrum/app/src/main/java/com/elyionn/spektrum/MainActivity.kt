package com.elyionn.spektrum

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import java.net.URLEncoder
import kotlin.random.Random

private data class Palette(val name: String, val bg: Color, val panel: Color, val accent: Color, val text: Color, val muted: Color)
private val palettes = listOf(
    Palette("Kozmik", Color(0xFF081321), Color(0xFF192D45), Color(0xFF75C8FF), Color(0xFFF0F6FF), Color(0xFFB3C3D5)),
    Palette("Aurora", Color(0xFF071A19), Color(0xFF12332E), Color(0xFF73E0B5), Color(0xFFE8FFF6), Color(0xFFB0D4C8)),
    Palette("Nebula", Color(0xFF180E29), Color(0xFF2D1B49), Color(0xFFC5A0FF), Color(0xFFF6F0FF), Color(0xFFC8B8DD)),
    Palette("Arktik", Color(0xFF101C2B), Color(0xFF203B54), Color(0xFF8DD5FF), Color(0xFFEAF7FF), Color(0xFFB8CCDC)),
    Palette("Laboratuvar", Color(0xFFF1F5F7), Color(0xFFFFFFFF), Color(0xFF087F8C), Color(0xFF17232B), Color(0xFF52616B)),
    Palette("Gün Batımı", Color(0xFF24131A), Color(0xFF42232D), Color(0xFFFFAD83), Color(0xFFFFF1E9), Color(0xFFDCC0B5))
)

private val elementRows = listOf(
"H|Hidrojen|1|1.008|Ametal", "He|Helyum|2|4.0026|Soygaz", "Li|Lityum|3|6.94|Alkali metal", "Be|Berilyum|4|9.0122|Toprak alkali", "B|Bor|5|10.81|Yarı metal", "C|Karbon|6|12.011|Ametal", "N|Azot|7|14.007|Ametal", "O|Oksijen|8|15.999|Ametal", "F|Flor|9|18.998|Halojen", "Ne|Neon|10|20.180|Soygaz",
"Na|Sodyum|11|22.990|Alkali metal", "Mg|Magnezyum|12|24.305|Toprak alkali", "Al|Alüminyum|13|26.982|Metal", "Si|Silisyum|14|28.085|Yarı metal", "P|Fosfor|15|30.974|Ametal", "S|Kükürt|16|32.06|Ametal", "Cl|Klor|17|35.45|Halojen", "Ar|Argon|18|39.948|Soygaz",
"K|Potasyum|19|39.098|Alkali metal", "Ca|Kalsiyum|20|40.078|Toprak alkali", "Sc|Skandiyum|21|44.956|Geçiş metali", "Ti|Titanyum|22|47.867|Geçiş metali", "V|Vanadyum|23|50.942|Geçiş metali", "Cr|Krom|24|51.996|Geçiş metali", "Mn|Manganez|25|54.938|Geçiş metali", "Fe|Demir|26|55.845|Geçiş metali", "Co|Kobalt|27|58.933|Geçiş metali", "Ni|Nikel|28|58.693|Geçiş metali", "Cu|Bakır|29|63.546|Geçiş metali", "Zn|Çinko|30|65.38|Geçiş metali", "Ga|Galyum|31|69.723|Metal", "Ge|Germanyum|32|72.630|Yarı metal", "As|Arsenik|33|74.922|Yarı metal", "Se|Selenyum|34|78.971|Ametal", "Br|Brom|35|79.904|Halojen", "Kr|Kripton|36|83.798|Soygaz",
"Rb|Rubidyum|37|85.468|Alkali metal", "Sr|Stronsiyum|38|87.62|Toprak alkali", "Y|İtriyum|39|88.906|Geçiş metali", "Zr|Zirkonyum|40|91.224|Geçiş metali", "Nb|Niyobyum|41|92.906|Geçiş metali", "Mo|Molibden|42|95.95|Geçiş metali", "Tc|Teknesyum|43|98|Geçiş metali", "Ru|Rutenyum|44|101.07|Geçiş metali", "Rh|Rodyum|45|102.91|Geçiş metali", "Pd|Paladyum|46|106.42|Geçiş metali", "Ag|Gümüş|47|107.87|Geçiş metali", "Cd|Kadmiyum|48|112.41|Geçiş metali", "In|İndiyum|49|114.82|Metal", "Sn|Kalay|50|118.71|Metal", "Sb|Antimon|51|121.76|Yarı metal", "Te|Tellür|52|127.60|Yarı metal", "I|İyot|53|126.90|Halojen", "Xe|Ksenon|54|131.29|Soygaz",
"Cs|Sezyum|55|132.91|Alkali metal", "Ba|Baryum|56|137.33|Toprak alkali", "La|Lantan|57|138.91|Lantanit", "Ce|Seryum|58|140.12|Lantanit", "Pr|Praseodim|59|140.91|Lantanit", "Nd|Neodim|60|144.24|Lantanit", "Pm|Prometyum|61|145|Lantanit", "Sm|Samaryum|62|150.36|Lantanit", "Eu|Öropiyum|63|151.96|Lantanit", "Gd|Gadolinyum|64|157.25|Lantanit", "Tb|Terbiyum|65|158.93|Lantanit", "Dy|Disprozyum|66|162.50|Lantanit", "Ho|Holmiyum|67|164.93|Lantanit", "Er|Erbiyum|68|167.26|Lantanit", "Tm|Tulyum|69|168.93|Lantanit", "Yb|İterbiyum|70|173.05|Lantanit", "Lu|Lutesyum|71|174.97|Lantanit",
"Hf|Hafniyum|72|178.49|Geçiş metali", "Ta|Tantal|73|180.95|Geçiş metali", "W|Tungsten|74|183.84|Geçiş metali", "Re|Ren|75|186.21|Geçiş metali", "Os|Osmiyum|76|190.23|Geçiş metali", "Ir|İridyum|77|192.22|Geçiş metali", "Pt|Platin|78|195.08|Geçiş metali", "Au|Altın|79|196.97|Geçiş metali", "Hg|Cıva|80|200.59|Geçiş metali", "Tl|Talyum|81|204.38|Metal", "Pb|Kurşun|82|207.2|Metal", "Bi|Bizmut|83|208.98|Metal", "Po|Polonyum|84|209|Yarı metal", "At|Astatin|85|210|Halojen", "Rn|Radon|86|222|Soygaz",
"Fr|Fransiyum|87|223|Alkali metal", "Ra|Radyum|88|226|Toprak alkali", "Ac|Aktinyum|89|227|Aktinit", "Th|Toryum|90|232.04|Aktinit", "Pa|Protaktinyum|91|231.04|Aktinit", "U|Uranyum|92|238.03|Aktinit", "Np|Neptünyum|93|237|Aktinit", "Pu|Plütonyum|94|244|Aktinit", "Am|Amerikyum|95|243|Aktinit", "Cm|Küriyum|96|247|Aktinit", "Bk|Berkelyum|97|247|Aktinit", "Cf|Kaliforniyum|98|251|Aktinit", "Es|Aynştaynyum|99|252|Aktinit", "Fm|Fermiyum|100|257|Aktinit", "Md|Mendelevyum|101|258|Aktinit", "No|Nobelyum|102|259|Aktinit", "Lr|Lavrensiyum|103|266|Aktinit", "Rf|Rutherfordiyum|104|267|Geçiş metali", "Db|Dubniyum|105|268|Geçiş metali", "Sg|Seaborgiyum|106|269|Geçiş metali", "Bh|Bohriyum|107|270|Geçiş metali", "Hs|Hassiyum|108|277|Geçiş metali", "Mt|Meitneriyum|109|278|Bilinmiyor", "Ds|Darmstadtiyum|110|281|Bilinmiyor", "Rg|Röntgenyum|111|282|Bilinmiyor", "Cn|Kopernikyum|112|285|Bilinmiyor", "Nh|Nihonyum|113|286|Bilinmiyor", "Fl|Flerovyum|114|289|Bilinmiyor", "Mc|Moskovyum|115|290|Bilinmiyor", "Lv|Livermoryum|116|293|Bilinmiyor", "Ts|Tennessin|117|294|Halojen", "Og|Oganesson|118|294|Soygaz"
).map { it.split('|') }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { SpectrumApp() }
    }
}

@Composable
private fun SpectrumApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("spectrum_settings", Context.MODE_PRIVATE) }
    var page by rememberSaveable { mutableStateOf("Keşif") }
    var category by rememberSaveable { mutableStateOf("") }
    var themeIndex by rememberSaveable { mutableIntStateOf(prefs.getInt("theme", 0).coerceIn(palettes.indices)) }
    var soundOn by rememberSaveable { mutableStateOf(prefs.getBoolean("sound", false)) }
    val p = palettes[themeIndex]
    val tone = remember { ToneGenerator(AudioManager.STREAM_MUSIC, 35) }
    DisposableEffect(Unit) { onDispose { tone.release() } }
    fun clickSound() { if (soundOn) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 65) }
    val scheme = if (themeIndex == 4) lightColorScheme(
        primary = p.accent, background = p.bg, surface = p.panel, onSurface = p.text, onBackground = p.text
    ) else darkColorScheme(
        primary = p.accent, background = p.bg, surface = p.panel, onSurface = p.text, onBackground = p.text
    )

    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = p.bg,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                NavigationBar(
                    containerColor = p.panel,
                    contentColor = p.text
                ) {
                    val items = listOf(
                        Triple("Keşif", Icons.Default.Explore, "Keşif"),
                        Triple("Kategoriler", Icons.Default.Category, "Kategoriler"),
                        Triple("Oyunlar", Icons.Default.SportsEsports, "Oyunlar"),
                        Triple("Ayarlar", Icons.Default.Settings, "Ayarlar")
                    )
                    items.forEach { item ->
                        NavigationBarItem(
                            selected = page == item.first || (page == "Detay" && item.first == "Kategoriler"),
                            onClick = { clickSound(); page = item.first; category = "" },
                            icon = { Icon(item.second, contentDescription = item.first) },
                            label = { Text(item.first, fontSize = 11.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = p.accent,
                                selectedTextColor = p.accent,
                                indicatorColor = p.accent.copy(alpha = .16f),
                                unselectedIconColor = p.muted,
                                unselectedTextColor = p.muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).background(p.bg)
            ) {
                Header(p = p, title = if (page == "Detay") category else page)
                when (page) {
                    "Keşif" -> HomePage(p, onOpen = { category = it; page = "Detay" }, onAll = { page = "Kategoriler" })
                    "Kategoriler" -> CategoryHub(p, onOpen = { category = it; page = "Detay" })
                    "Oyunlar" -> MathGames(p, onSound = { clickSound() })
                    "Ayarlar" -> SettingsPage(
                        p, themeIndex, soundOn,
                        onTheme = { themeIndex = it; prefs.edit().putInt("theme", it).apply(); clickSound() },
                        onSound = { soundOn = it; prefs.edit().putBoolean("sound", it).apply() }
                    )
                    "Detay" -> CategoryDetail(p, category, onBack = { page = "Kategoriler"; category = "" })
                    else -> HomePage(p, onOpen = { category = it; page = "Detay" }, onAll = { page = "Kategoriler" })
                }
            }
        }
    }
}

@Composable
private fun Header(p: Palette, title: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("S P E C T R U M", color = p.accent, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text(if (title == "Keşif") "Bilim, keşif ve merak alanı" else title, color = p.muted, fontSize = 12.sp)
        }
        Box(Modifier.size(38.dp).clip(CircleShape).background(p.panel), contentAlignment = Alignment.Center) {
            Text("✦", color = p.accent, fontSize = 22.sp)
        }
    }
}

@Composable
private fun Panel(p: Palette, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth()
            .background(p.panel, RoundedCornerShape(20.dp))
            .border(1.dp, p.accent.copy(alpha = .18f), RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}

private val categoryDescriptions = listOf(
    "Biyoloji" to "İnsan vücudu, organlar, hücre, DNA ve canlılık",
    "Uzay" to "Güneş Sistemi, gezegenler, uydular ve derin uzay",
    "Elementler" to "118 element, periyodik tablo ve atom özellikleri",
    "Kimya" to "Atomlar, bağlar, tepkimeler, çözeltiler ve pH",
    "Mikrobiyoloji" to "Bakteriler, virüsler, mantarlar ve mikroskobik yaşam",
    "Görsel Atlas" to "Bilimsel fotoğraflar, çizimler ve hareketli görseller",
    "Matematik" to "Kısa matematik oyunları ve zihinden işlem pratiği"
)

@Composable
private fun HomePage(p: Palette, onOpen: (String) -> Unit, onAll: () -> Unit) {
    var search by rememberSaveable { mutableStateOf("") }
    val results = categoryDescriptions.filter { it.first.contains(search, true) || it.second.contains(search, true) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel(p, Modifier.heightIn(min = 165.dp)) {
            Text("BİLİM ATLASI  ·  SÜRÜM 1.2", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(10.dp))
            Text("Merak et.\nKeşfet. Öğren.", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = p.text, lineHeight = 35.sp)
            Spacer(Modifier.height(8.dp))
            Text("İnsan bedeninden galaksilere, atomlardan matematiğe uzanan etkileşimli öğrenme alanı.", color = p.muted, lineHeight = 21.sp)
        }
        OutlinedTextField(
            value = search, onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Kategori ara...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(16.dp)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Keşif kategorileri", color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            TextButton(onClick = onAll) { Text("Tümünü gör", color = p.accent) }
        }
        results.filter { it.first != "Matematik" }.forEach { (name, desc) ->
            Panel(p, Modifier.clickable { onOpen(name) }) {
                Text(name, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(desc, color = p.muted, fontSize = 13.sp)
            }
        }
        Panel(p, Modifier.clickable { onOpen("Matematik") }) {
            Text("Matematik oyunları", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Kısa işlemlerle zihnini çalıştır.", color = p.muted, fontSize = 13.sp)
        }
        Text("Elyionn tarafından tasarlanmıştır · Spectrum 1.2", color = p.muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(8.dp))
    }
}

@Composable
private fun CategoryHub(p: Palette, onOpen: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = categoryDescriptions.filter { it.first.contains(query, true) || it.second.contains(query, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text("Bilim alanları", color = p.text, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Text("Bir kategori seçerek kendi bölümüne geç.", color = p.muted)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Kategori veya konu ara") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            filtered.forEach { (name, desc) ->
                Panel(p, Modifier.clickable { onOpen(name) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(p.accent.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                            Icon(categoryIcon(name), null, tint = p.accent)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(desc, color = p.muted, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = p.muted)
                    }
                }
            }
            if (filtered.isEmpty()) Text("Eşleşen kategori bulunamadı.", color = p.muted, modifier = Modifier.padding(12.dp))
        }
    }
}

@Composable
private fun categoryIcon(name: String) = when (name) {
    "Biyoloji" -> Icons.Default.Favorite
    "Uzay" -> Icons.Default.Public
    "Elementler", "Kimya" -> Icons.Default.Science
    "Mikrobiyoloji" -> Icons.Default.Biotech
    "Görsel Atlas" -> Icons.Default.Image
    else -> Icons.Default.Calculate
}

@Composable
private fun CategoryDetail(p: Palette, category: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri", tint = p.accent) }
            Text(category, color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        when (category) {
            "Biyoloji" -> BiologyPage(p)
            "Uzay" -> SpacePage(p)
            "Elementler" -> ElementsPage(p)
            "Kimya" -> ChemistryPage(p)
            "Mikrobiyoloji" -> MicrobiologyPage(p)
            "Görsel Atlas" -> VisualAtlasPage(p)
            "Matematik" -> MathGames(p, onSound = {})
            else -> Text("Kategori bulunamadı.", color = p.text)
        }
    }
}

@Composable
private fun BiologyPage(p: Palette) {
    val systems = listOf(
        "Sinir sistemi" to "Beyin, omurilik ve sinirlerden oluşur. Duyuları işler, hareketleri koordine eder ve organların faaliyetlerini düzenler. Beyincik denge ve hareket koordinasyonunda; beyin sapı solunum ve kalp ritmi gibi yaşamsal işlevlerde rol oynar.",
        "Dolaşım sistemi" to "Kalp, kan ve damarlardan oluşur. Kalbin sağ tarafı kanı akciğerlere, sol tarafı vücuda pompalar. Atardamarlar kanı kalpten uzaklaştırır; toplardamarlar geri taşır; kılcal damarlar oksijen, besin ve atık alışverişini sağlar.",
        "Solunum sistemi" to "Burun ve ağızdan alınan hava yutak, gırtlak, soluk borusu, bronşlar ve bronşçuklardan geçerek alveollere ulaşır. Alveollerde oksijen kana, karbondioksit ise alveol havasına geçer. Diyafram solunumun temel kasıdır.",
        "Sindirim sistemi" to "Ağızda mekanik ve kimyasal sindirim başlar. Yemek borusu besini mideye taşır. Mide asit ve enzimlerle sindirime katkı verir. İnce bağırsak besinlerin büyük bölümünü emer; kalın bağırsak su ve elektrolit emilimine katkıda bulunur. Karaciğer safra üretir, pankreas enzim salgılar.",
        "Kas-iskelet sistemi" to "Kemikler destek ve koruma sağlar; eklemler hareket açıklığını belirler; kaslar kasılarak kuvvet üretir. İskelet kasları istemli hareketlerde, düz kaslar iç organlarda, kalp kası kalpte görev yapar. Kemik iliği kan hücrelerinin üretiminde rol alır.",
        "Üriner sistem" to "Böbreklerdeki nefronlar kanı süzer; gerekli maddeler geri emilir ve bazı maddeler tübüllere salgılanır. Oluşan idrar üreterlerle mesaneye taşınır ve üretradan atılır. Sistem su, elektrolit ve asit-baz dengesine katkı sağlar.",
        "Endokrin sistem" to "Hormonlar aracılığıyla büyüme, metabolizma, stres yanıtı ve iç dengeyi düzenler. Hipofiz, tiroit, paratiroit, pankreas, böbreküstü bezleri ve eşey bezleri önemli bileşenleridir.",
        "Bağışıklık ve lenf sistemi" to "Deri ve mukozalar ilk savunma hattıdır. Doğuştan gelen bağışıklık hızlı ve genel yanıt verir; B ve T lenfositleri kazanılmış bağışıklıkta görev alır. Lenf düğümleri bağışıklık hücrelerinin karşılaşma ve etkinleşme alanlarıdır.",
        "Üreme sistemi" to "Üreme organları gamet üretimi ve üreme işlevlerinde rol oynar. Hormonlar üreme sisteminin gelişimini ve işleyişini düzenler. İnsan gelişimi döllenme, embriyonik gelişim ve doğum sonrası büyüme aşamalarını kapsar.",
        "Deri ve duyu sistemi" to "Deri vücudun dış örtüsüdür; bariyer, sıcaklık düzenleme ve duyu işlevleri görür. Dokunma, basınç, sıcaklık ve ağrı reseptörleri çevreden bilgi alır. Deri epidermis, dermis ve deri altı dokudan oluşur.",
        "Kan ve bağışıklık hücreleri" to "Plazma, alyuvarlar, akyuvarlar ve trombositler kanın temel bileşenleridir. Alyuvarlar oksijen taşır; akyuvarlar savunmada; trombositler pıhtılaşmada görev alır."
    )
    var expanded by rememberSaveable { mutableStateOf("Sinir sistemi") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) {
            Text("İnsan vücudu atlası", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 21.sp)
            Text("Organlar tek başına değil, birlikte çalışan sistemler halinde işlev görür. Aşağıdaki başlıklardan birini açarak temel yapı ve görevleri incele.", color = p.muted)
        }
        systems.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == title) "" else title }, verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded == title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == title) { Spacer(Modifier.height(8.dp)); Text(body, color = p.text, lineHeight = 21.sp) }
            }
        }
        Panel(p) {
            Text("Hücreden organizmaya", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Hücreler dokuları, dokular organları, organlar da sistemleri oluşturur. DNA, hücrelerin kalıtsal bilgisinin büyük bölümünü taşır. Proteinler hücre yapısında ve işlevlerinde temel rol oynar.", color = p.text)
        }
    }
}

private data class Planet(val name: String, val type: String, val diameter: String, val year: String, val moons: String, val facts: String, val mission: String)
private val planets = listOf(
    Planet("Merkür","Karasal","4.879 km","88 Dünya günü","0","Güneş'e en yakın gezegendir. Çok ince bir dış gaz örtüsüne sahiptir; gündüz ve gece sıcaklık farkı çok büyüktür. Büyük metalik çekirdeği gezegenin iç yapısında önemli yer tutar.","MESSENGER görevi yüzeyini ve manyetik alanını ayrıntılı haritaladı. BepiColombo Merkür'e yolculuğunu sürdürüyor."),
    Planet("Venüs","Karasal","12.104 km","225 Dünya günü","0","Yoğun karbondioksit atmosferi ve güçlü sera etkisi nedeniyle yüzeyi çok sıcaktır. Sülfürik asit bulutları bulunur. Yavaş ve ters yönlü dönüşüyle dikkat çeker.","Magellan radar haritalaması yaptı; Akatsuki atmosfer dinamiklerini inceledi."),
    Planet("Dünya","Karasal","12.742 km","365,25 gün","1","Yüzeyinde kalıcı sıvı su ve bildiğimiz yaşam bulunur. Atmosferi çoğunlukla azot ve oksijenden oluşur. Manyetik alanı Güneş rüzgârıyla etkileşir.","Çok sayıda uydu atmosferi, okyanusları, iklimi ve yüzeyi izler."),
    Planet("Mars","Karasal","6.779 km","687 Dünya günü","2","Demir oksit yüzeyine kızıl renk verir. Olympus Mons dev bir volkandır; Valles Marineris büyük bir kanyon sistemidir. Eski nehir yatakları ve mineraller geçmişte sıvı su bulunduğunu gösterir.","Curiosity ve Perseverance yüzeyi inceliyor; yörünge araçları haritalama yapıyor."),
    Planet("Jüpiter","Gaz devi","139.820 km","11,86 Dünya yılı","Çok sayıda","En büyük gezegendir; çoğunlukla hidrojen ve helyumdan oluşur. Büyük Kırmızı Leke dev bir fırtınadır. Europa'nın buz altında okyanusu olabileceğine dair güçlü kanıtlar vardır.","Juno gezegenin iç yapısını ve manyetik alanını inceliyor; Europa Clipper Europa'yı araştıracak."),
    Planet("Satürn","Gaz devi","116.460 km","29,4 Dünya yılı","Çok sayıda","Buz ve kaya parçacıklarından oluşan halkalarıyla tanınır. Titan'da metan ve etan gölleri; Enceladus'ta buz altı okyanusuna işaret eden püskürmeler vardır.","Cassini-Huygens görevi Satürn, halkaları ve uyduları hakkında büyük miktarda veri topladı."),
    Planet("Uranüs","Buz devi","50.724 km","84 Dünya yılı","Çok sayıda","Eksen eğikliği yaklaşık 98 derecedir; adeta yan yatmış şekilde döner. Atmosferindeki metan mavi-yeşil görünmesine katkı verir.","Yakından ziyaret eden tek araç Voyager 2'dir. Gelecekte yeni bir yörünge görevi önerilmektedir."),
    Planet("Neptün","Buz devi","49.244 km","165 Dünya yılı","Çok sayıda","Güneş'ten uzaklığı nedeniyle çok az enerji alır. Atmosferinde çok hızlı rüzgârlar ve değişken koyu fırtınalar görülür.","Voyager 2 1989'da yakınından geçti; günümüzde teleskoplarla izlenir.")
)

@Composable
private fun SpacePage(p: Palette) {
    var expanded by rememberSaveable { mutableStateOf("Dünya") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) {
            Text("Güneş Sistemi", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("Güneş'in kütleçekimiyle bağlı sekiz gezegen, cüce gezegenler, uydular, asteroitler ve kuyruklu yıldızlardan oluşur.", color = p.muted)
        }
        planets.forEach { planet ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == planet.name) "" else planet.name }, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(planet.name, color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("${planet.type} · ${planet.year}", color = p.muted, fontSize = 12.sp)
                    }
                    Icon(if (expanded == planet.name) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == planet.name) {
                    Spacer(Modifier.height(8.dp))
                    Text("Çap: ${planet.diameter}   ·   Bilinen uydu: ${planet.moons}", color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(planet.facts, color = p.text, lineHeight = 21.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Keşif görevleri: ${planet.mission}", color = p.muted, lineHeight = 19.sp, fontSize = 12.sp)
                }
            }
        }
        Panel(p) {
            Text("Cüce gezegenler ve küçük cisimler", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Plüton, Ceres, Eris, Haumea ve Makemake cüce gezegenler arasında sayılır. Asteroit kuşağı Mars ile Jüpiter arasında; Kuiper Kuşağı ise Neptün ötesinde bulunur. Kuyruklu yıldızlar buz, toz ve kayaçlardan oluşur.", color = p.text)
        }
        Panel(p) {
            Text("3B Uzay gözlemevi", color = p.accent, fontWeight = FontWeight.Bold)
            Text("NASA'nın etkileşimli sayfasında gezegenleri yakınlaştırıp döndürebilirsin.", color = p.muted)
            Text("NASA 3B sahnesini açmak için Kategoriler > Görsel Atlas > 3B Güneş Sistemi yolunu izle.", color = p.muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ElementsPage(p: Palette) {
    var selected by remember { mutableStateOf(elementRows.first()) }
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = elementRows.filter { it[0].contains(query, true) || it[1].contains(query, true) || it[2] == query }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Periyodik tablo · 118 element", color = p.text, fontWeight = FontWeight.Bold, fontSize = 21.sp)
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Element ara") }, shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.weight(1f), contentPadding = PaddingValues(3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(filtered) { e ->
                Card(onClick = { selected = e }, colors = CardDefaults.cardColors(containerColor = if (selected == e) p.accent.copy(alpha = .2f) else p.panel), border = BorderStroke(1.dp, p.accent.copy(alpha = .25f))) {
                    Column(Modifier.padding(8.dp)) {
                        Text(e[2], color = p.muted, fontSize = 10.sp)
                        Text(e[0], color = p.accent, fontWeight = FontWeight.Black, fontSize = 21.sp)
                        Text(e[1], color = p.text, fontSize = 10.sp, maxLines = 1)
                    }
                }
            }
        }
        Panel(p) {
            Text("${selected[1]} (${selected[0]})", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text("Atom numarası: ${selected[2]} · Atom kütlesi: ${selected[3]} u · Sınıf: ${selected[4]}", color = p.muted, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Text(elementDescription(selected), color = p.text, lineHeight = 20.sp)
        }
    }
}
private fun elementDescription(e:List<String>):String { val (s,n,z,m,c)=e;val uses=mapOf("H" to "Yıldızlarda füzyonun temel yakıtıdır; yakıt hücrelerinde ve amonyak üretiminde kullanılır.","He" to "Düşük sıcaklık fiziğinde soğutucu, MRI cihazlarının süperiletken mıknatıslarında ve balonlarda kullanılır.","Li" to "Şarj edilebilir lityum-iyon pillerde, cam-seramiklerde ve bazı alaşımlarda önemli rol oynar.","C" to "Canlı kimyasının temel elementidir. Grafit, elmas ve grafen gibi farklı yapısal biçimleri vardır.","O" to "Hücresel solunumda elektron alıcısıdır; çelik üretimi, tıp ve su arıtma süreçlerinde kullanılır.","N" to "Atmosferin büyük bölümünü oluşturur. Amonyak ve gübre üretiminde, ayrıca inert gaz ortamlarında kullanılır.","Fe" to "Çelik üretiminin ana bileşenidir. Hemoglobindeki demir oksijen taşınmasına katkı verir.","Cu" to "Elektrik ve ısıyı iyi iletir; kablolarda, motorlarda, elektronik devrelerde ve alaşımlarda kullanılır.","Si" to "Yarı iletken teknolojisinin temelidir. Bilgisayar çipleri, güneş hücreleri ve cam üretiminde kullanılır.","Au" to "Korozyona dayanıklı ve iyi iletken olduğu için elektronik bağlantılarda, mücevheratta ve finansal rezervlerde kullanılır.","Ag" to "Metaller arasında çok yüksek elektrik iletkenliğine sahiptir; elektronik, aynalar ve bazı antimikrobiyal uygulamalarda kullanılır.","Al" to "Hafifliği ve korozyon direnci sayesinde ulaşım, yapı, ambalaj ve elektrik iletiminde yaygındır.","Ti" to "Yüksek dayanım/ağırlık oranı ve biyouyumluluğu nedeniyle havacılıkta ve tıbbi implantlarda kullanılır.","U" to "Bazı izotopları nükleer yakıttır. Jeolojide uranyum-kurşun tarihlemesi gibi yöntemlerde de önemlidir.")
val use=uses[s] ?: when(c){"Soygaz"->"Kimyasal tepkimeye girme eğilimi düşüktür. Aydınlatma, koruyucu atmosfer, algılama veya özel optik uygulamalarda kullanılabilir.";"Halojen"->"Tuzlar ve çok sayıda organik bileşik oluşturur. Su arıtma, polimer üretimi ve kimya endüstrisinde farklı bileşikleri önem taşır.";"Alkali metal","Toprak alkali"->"Reaktif metal grubundadır. Saf halde değil, çoğunlukla bileşikleri ve kontrollü endüstriyel süreçleri aracılığıyla kullanılır.";"Lantanit"->"Elektronik, güçlü kalıcı mıknatıslar, optik camlar ve enerji teknolojilerinde kullanılan özel manyetik ve ışıldama özellikleri gösterebilir.";"Aktinit"->"Birçoğu radyoaktiftir. Nükleer bilim, araştırma ve bazı izotopların enerji uygulamalarında önem taşır.";else->"Bu elementin fiziksel ve kimyasal özellikleri alaşımlar, kataliz, elektronik veya özel malzeme tasarımında kullanımını belirler."}
return "$n, atom numarası $z olan $s sembollü elementtir. Göreli atom kütlesi yaklaşık $m u'dur ve sınıflandırması $c olarak verilir. $use Keşif tarihi ve kullanım alanları elementin izotopuna, saflığına ve kimyasal bileşiğine göre değişebilir." }


@Composable
private fun ChemistryPage(p: Palette) {
    val topics = listOf(
        "Atomun yapısı" to "Atom; proton ve nötronlardan oluşan çekirdek ile elektron bulutundan meydana gelir. Proton sayısı elementin kimliğini belirler. Nötron sayısı izotopları, elektron dizilimi ise kimyasal davranışın önemli bölümünü belirler.",
        "Periyodik eğilimler" to "Aynı gruptaki elementlerin değerlik elektron yapıları benzerdir. Atom yarıçapı, iyonlaşma enerjisi ve elektronegatiflik periyodik tabloda düzenli eğilimler gösterir; bu eğilimler elementlerin tepkime davranışını anlamaya yardımcı olur.",
        "Kimyasal bağlar" to "İyonik bağ zıt yüklü iyonların elektrostatik çekimidir. Kovalent bağda atomlar elektron çiftlerini paylaşır. Metalik bağda değerlik elektronları metal yapısı boyunca delokalizedir.",
        "Tepkimeler ve denkleştirme" to "Kimyasal tepkimelerde atomlar yeniden düzenlenir; kapalı sistemlerde toplam atom sayısı ve kütle korunur. Denklem denkleştirme, her elementin atom sayısını iki tarafta eşitler.",
        "Asit, baz ve pH" to "pH sulu çözeltilerin asitlik-bazlık durumunu ifade eden logaritmik bir ölçüdür. 25 °C'de pH 7 nötr kabul edilir; daha düşük değerler asidik, daha yüksek değerler bazik ortamı gösterir.",
        "Çözeltiler ve derişim" to "Çözelti, çözücü içinde dağılmış çözünen maddeden oluşur. Derişim molarite veya yüzde gibi birimlerle ifade edilebilir. Sıcaklık ve maddenin türü çözünürlüğü etkiler.",
        "Organik kimya" to "Karbon bileşiklerinin yapısını, özelliklerini ve tepkimelerini inceler. Hidrokarbonlar, alkoller, karboksilik asitler, esterler ve polimerler önemli bileşik sınıflarıdır.",
        "Kimya ve enerji" to "Ekzotermik tepkimeler çevreye enerji verir; endotermik tepkimeler çevreden enerji alır. Tepkime hızı sıcaklık, derişim, yüzey alanı ve katalizör gibi etkenlerden etkilenebilir.",
        "Laboratuvar güvenliği" to "Etiketler ve güvenlik bilgi formları okunur; koruyucu gözlük ve uygun ekipman kullanılır. Bilinmeyen maddeler karıştırılmaz, maddeler tadılmaz veya doğrudan koklanmaz. Deneyler yalnızca yetkili gözetiminde yapılır."
    )
    var expanded by rememberSaveable { mutableStateOf("Atomun yapısı") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Kimya", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp); Text("Maddenin yapısını, dönüşümünü ve enerjiyle ilişkisini incele.", color = p.muted) }
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == title) "" else title }, verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded == title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == title) { Spacer(Modifier.height(7.dp)); Text(body, color = p.text, lineHeight = 21.sp) }
            }
        }
    }
}

@Composable
private fun MicrobiologyPage(p: Palette) {
    val topics = listOf(
        "Mikroorganizmalara giriş" to "Mikrobiyoloji, mikroorganizmaları ve mikroskobik biyolojik yapıları inceler. Bakteriler ve arkeler prokaryot; maya ve protozoalar ökaryot hücre yapısına sahiptir.",
        "Bakteriler" to "Bakteriler tek hücreli prokaryotlardır. Şekilleri, metabolizmaları ve yaşadıkları ortamlar çeşitlidir. Bazıları insan sağlığı için yararlı roller üstlenirken bazıları hastalıklara neden olabilir.",
        "Virüsler" to "Virüsler hücresel yapıda değildir; genetik materyallerini protein kılıf içinde taşırlar. Çoğalmak için konak hücrelerin mekanizmalarını kullanırlar. Antibiyotikler virüslere karşı etkili değildir.",
        "Mantarlar ve mayalar" to "Mantarlar ökaryot canlılardır. Mayalar tek hücreli, küfler çoğunlukla ipliksi yapılara sahip olabilir. Ayrıştırma, gıda üretimi ve ekosistem döngülerinde önemli görevleri vardır.",
        "Protozoalar ve algler" to "Protozoalar çoğunlukla tek hücreli ökaryotlardır. Algler fotosentez yapabilen çeşitli organizmaları kapsar; su ekosistemlerinde birincil üretime katkı sağlar.",
        "Mikrobiyota" to "İnsan vücudunda ve üzerinde yaşayan mikroorganizma toplulukları mikrobiyotayı oluşturur. Bağırsak mikrobiyotası sindirim, metabolizma ve bağışıklıkla ilişkili işlevlerde rol oynar.",
        "Mikroskopi" to "Işık mikroskopları hücre ve mikroorganizma yapılarını incelemekte kullanılır. Büyütme kadar çözünürlük, örnek hazırlama ve uygun boyama yöntemi de gözlemin kalitesini belirler."
    )
    var expanded by rememberSaveable { mutableStateOf("Mikroorganizmalara giriş") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Panel(p) { Text("Mikrobiyoloji", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp); Text("Mikroskobik dünyanın çeşitliliğini keşfet.", color = p.muted) }
        topics.forEach { (title, body) ->
            Panel(p) {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (expanded == title) "" else title }, verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(if (expanded == title) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.accent)
                }
                if (expanded == title) { Spacer(Modifier.height(7.dp)); Text(body, color = p.text, lineHeight = 21.sp) }
            }
        }
        Panel(p) { Text("Bilimsel not", color = p.accent, fontWeight = FontWeight.Bold); Text("Virüslerin canlı olarak sınıflandırılması tartışmalıdır; hücresel canlılarla aynı grupta değerlendirilmezler.", color = p.text) }
    }
}

@Composable
private fun VisualAtlasPage(p: Palette) {
    var query by rememberSaveable { mutableStateOf("human anatomy") }
    var mode by rememberSaveable { mutableStateOf("Görseller") }
    var address by rememberSaveable { mutableStateOf("https://commons.wikimedia.org/wiki/Special:MediaSearch?type=image&search=human%20anatomy") }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 4.dp)) {
        Text("Bilimsel görsel ve GIF atlası", color = p.text, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Wikimedia Commons ve NASA içeriklerini uygulama içinden görüntüle. İnternet bağlantısı gerekir.", color = p.muted, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Görseller", "GIF / hareketli", "NASA uzay", "3B Güneş Sistemi").forEach { item ->
                FilterChip(selected = mode == item, onClick = {
                    mode = item
                    address = when (item) {
                        "Görseller" -> "https://commons.wikimedia.org/wiki/Special:MediaSearch?type=image&search=" + enc(query)
                        "GIF / hareketli" -> "https://commons.wikimedia.org/wiki/Special:MediaSearch?type=image&search=" + enc("$query animated gif")
                        "NASA uzay" -> "https://images.nasa.gov/"
                        else -> "https://eyes.nasa.gov/apps/solar-system/"
                    }
                }, label = { Text(item, fontSize = 11.sp) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Örn. Mars, hücre, DNA") }, shape = RoundedCornerShape(12.dp))
            Spacer(Modifier.width(6.dp))
            IconButton(onClick = {
                address = "https://commons.wikimedia.org/wiki/Special:MediaSearch?type=image&search=" + enc(query)
                mode = "Görseller"
            }) { Icon(Icons.Default.Search, "Ara", tint = p.accent) }
        }
        AndroidView(
            modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)).border(1.dp, p.accent.copy(alpha = .2f), RoundedCornerShape(14.dp)),
            factory = { ctx ->
                WebView(ctx).apply {
                    webViewClient = WebViewClient()
                    webChromeClient = WebChromeClient()
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.cacheMode = WebSettings.LOAD_DEFAULT
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    settings.loadWithOverviewMode = true
                    settings.useWideViewPort = true
                    loadUrl(address)
                }
            },
            update = { web -> if (web.url != address) web.loadUrl(address) }
        )
    }
}
private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

@Composable
private fun MathGames(p: Palette, onSound: () -> Unit) {
    var a by rememberSaveable { mutableIntStateOf(7) }
    var b by rememberSaveable { mutableIntStateOf(5) }
    var op by rememberSaveable { mutableStateOf("+") }
    var answer by rememberSaveable { mutableIntStateOf(12) }
    var options by rememberSaveable { mutableStateOf(listOf(12, 10, 14, 9)) }
    var score by rememberSaveable { mutableIntStateOf(0) }
    var attempts by rememberSaveable { mutableIntStateOf(0) }
    var message by rememberSaveable { mutableStateOf("Doğru seçeneği bul.") }
    var answered by rememberSaveable { mutableStateOf(false) }
    fun newQuestion() {
        a = Random.nextInt(2, 21); b = Random.nextInt(2, 13)
        op = listOf("+", "−", "×").random()
        answer = when (op) { "+" -> a + b; "−" -> a - b; else -> a * b }
        options = (listOf(answer) + (1..3).map { answer + Random.nextInt(-9, 10) }.filter { it != answer }.distinct().take(3))
            .let { values -> (values + (answer + 1..answer + 5).toList()).distinct().take(4).shuffled() }
        message = "Doğru seçeneği bul."
        answered = false
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel(p) {
            Text("Zihin antrenmanı", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("Kısa matematik sorularıyla işlem pratiği yap. Her soru yeni bir işlem üretir.", color = p.muted)
            Spacer(Modifier.height(8.dp))
            Text("Puan: $score    ·    Soru: $attempts", color = p.text, fontWeight = FontWeight.SemiBold)
        }
        Panel(p, Modifier.fillMaxWidth()) {
            Text("Hızlı işlem", color = p.muted, fontWeight = FontWeight.Bold)
            Text("$a $op $b = ?", color = p.text, fontWeight = FontWeight.ExtraBold, fontSize = 38.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(16.dp))
            options.forEach { choice ->
                OutlinedButton(
                    onClick = {
                        if (!answered) {
                            attempts++
                            if (choice == answer) { score++; message = "Doğru cevap!"; onSound() }
                            else message = "Doğru cevap: $answer"
                            answered = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) { Text(choice.toString(), fontSize = 18.sp, color = p.text) }
            }
            Spacer(Modifier.height(8.dp))
            Text(message, color = p.accent, fontWeight = FontWeight.SemiBold)
            TextButton(onClick = { newQuestion() }) { Text(if (answered) "Yeni soru" else "Soruyu değiştir", color = p.accent) }
        }
        Panel(p) {
            Text("Mini oyun kuralları", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Toplama, çıkarma ve çarpma soruları rastgele üretilir. Puan yalnızca doğru cevaplarda artar. Bu bölüm öğrenme ve pratik amaçlıdır.", color = p.text)
        }
    }
}

@Composable
private fun SettingsPage(p: Palette, selected: Int, soundOn: Boolean, onTheme: (Int) -> Unit, onSound: (Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel(p) {
            Text("Görünüm", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text("Temayı yatay kaydırmalı küçük seçeneklerden seç.", color = p.muted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                palettes.forEachIndexed { index, theme ->
                    Column(
                        Modifier.width(74.dp).clip(RoundedCornerShape(13.dp))
                            .border(if (selected == index) 2.dp else 1.dp, if (selected == index) p.accent else p.muted.copy(alpha = .3f), RoundedCornerShape(13.dp))
                            .clickable { onTheme(index) }.padding(7.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.fillMaxWidth().height(30.dp).clip(RoundedCornerShape(8.dp)).background(theme.bg), contentAlignment = Alignment.Center) {
                            Box(Modifier.size(13.dp).clip(CircleShape).background(theme.accent))
                        }
                        Text(theme.name, color = p.text, fontSize = 10.sp, maxLines = 1)
                    }
                }
            }
        }
        Panel(p) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Arayüz sesleri", color = p.accent, fontWeight = FontWeight.Bold)
                    Text("Gezinme ve doğru cevaplarda kısa ses.", color = p.muted, fontSize = 12.sp)
                }
                Switch(checked = soundOn, onCheckedChange = onSound)
            }
        }
        Panel(p) {
            Text("Görsel ve web içerikleri", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Görsel Atlas bölümünde Wikimedia Commons, NASA görselleri ve NASA'nın 3B Güneş Sistemi sayfası uygulama içi tarayıcıda açılır. İnternet bağlantısı gereklidir.", color = p.text, lineHeight = 20.sp)
        }
        Panel(p) {
            Text("Uygulama bilgisi", color = p.accent, fontWeight = FontWeight.Bold)
            Text("Spectrum 1.2.0\nElyionn tarafından tasarlanmıştır.\nBilimsel içerikler eğitim amaçlıdır. Sayısal veriler zamanla güncellenebilir.", color = p.text, lineHeight = 21.sp)
        }
    }
}
