# Spectrum 1.2.0

Kotlin + Jetpack Compose Android application.

## What's new in 1.2.0

- Reworked bottom navigation to four main destinations: Discovery, Categories, Games, Settings.
- Uses Android safe drawing/navigation insets so the app's bottom navigation is kept above Android system navigation controls.
- Added a searchable category hub and in-app category pages.
- Expanded human biology systems and organ functions.
- Expanded Solar System facts, planet properties, moons and mission summaries.
- Added a searchable 118-element periodic table.
- Added chemistry and microbiology learning sections.
- Added a Visual Atlas in-app WebView for Wikimedia Commons image/GIF searches, NASA images and NASA's 3D Solar System.
- Added short arithmetic mini-games.
- Added six compact selectable themes and optional interface sounds.
- Updated app version to 1.2.0 (versionCode 3).

## Build requirements

- Android Studio with Android SDK Platform 35
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3

## Build from Android Studio

1. Open this folder as an existing Gradle project.
2. Wait for Gradle sync.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Build with GitHub Actions from a phone

1. Upload `Spectrum_v1.2_Android_Project.zip` to the root of your GitHub repository.
2. Put the provided workflow at `.github/workflows/android-apk.yml`.
3. Open Actions > Build Spectrum v1.2 APK > Run workflow.
4. Download `Spectrum-v1.2-debug-APK` from the run's Artifacts section.

The APK built by this workflow is a debug APK, suitable for testing and direct installation. A release APK for public distribution should be signed with a private release key.

## Notes

- Visual Atlas requires an internet connection. Wikimedia Commons and NASA pages are displayed inside the app's WebView; availability and page layout are controlled by those sites.
- This project has not been compiled in the current environment because an Android SDK/Gradle build environment is unavailable here. Run the GitHub Actions workflow to perform the real build and report any compiler errors.
